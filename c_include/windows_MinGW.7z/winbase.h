# 1 "c_include/windows/original/winbase.h"
#define __STDC__ 1
# 1 "c_include/windows/original/winbase.h"
#define __STDC_HOSTED__ 1
# 1 "c_include/windows/original/winbase.h"
#define __GNUC__ 4
# 1 "c_include/windows/original/winbase.h"
#define __GNUC_MINOR__ 8
# 1 "c_include/windows/original/winbase.h"
#define __GNUC_PATCHLEVEL__ 1
# 1 "c_include/windows/original/winbase.h"
#define __VERSION__ "4.8.1 20130328 (prerelease)"
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_RELAXED 0
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_SEQ_CST 5
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_ACQUIRE 2
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_RELEASE 3
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_ACQ_REL 4
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_CONSUME 1
# 1 "c_include/windows/original/winbase.h"
#define __pic__ 1
# 1 "c_include/windows/original/winbase.h"
#define __PIC__ 1
# 1 "c_include/windows/original/winbase.h"
#define __FINITE_MATH_ONLY__ 0
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_INT__ 4
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_LONG__ 4
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_LONG_LONG__ 8
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_SHORT__ 2
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_FLOAT__ 4
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_DOUBLE__ 8
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_LONG_DOUBLE__ 16
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_SIZE_T__ 8
# 1 "c_include/windows/original/winbase.h"
#define __CHAR_BIT__ 8
# 1 "c_include/windows/original/winbase.h"
#define __BIGGEST_ALIGNMENT__ 16
# 1 "c_include/windows/original/winbase.h"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 1 "c_include/windows/original/winbase.h"
#define __ORDER_BIG_ENDIAN__ 4321
# 1 "c_include/windows/original/winbase.h"
#define __ORDER_PDP_ENDIAN__ 3412
# 1 "c_include/windows/original/winbase.h"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/winbase.h"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_POINTER__ 8
# 1 "c_include/windows/original/winbase.h"
#define __SIZE_TYPE__ long long unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __PTRDIFF_TYPE__ long long int
# 1 "c_include/windows/original/winbase.h"
#define __WCHAR_TYPE__ short unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __WINT_TYPE__ short unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __INTMAX_TYPE__ long long int
# 1 "c_include/windows/original/winbase.h"
#define __UINTMAX_TYPE__ long long unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __CHAR16_TYPE__ short unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __CHAR32_TYPE__ unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __SIG_ATOMIC_TYPE__ int
# 1 "c_include/windows/original/winbase.h"
#define __INT8_TYPE__ signed char
# 1 "c_include/windows/original/winbase.h"
#define __INT16_TYPE__ short int
# 1 "c_include/windows/original/winbase.h"
#define __INT32_TYPE__ int
# 1 "c_include/windows/original/winbase.h"
#define __INT64_TYPE__ long long int
# 1 "c_include/windows/original/winbase.h"
#define __UINT8_TYPE__ unsigned char
# 1 "c_include/windows/original/winbase.h"
#define __UINT16_TYPE__ short unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __UINT32_TYPE__ unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __UINT64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST8_TYPE__ signed char
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST16_TYPE__ short int
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST32_TYPE__ int
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST64_TYPE__ long long int
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST8_TYPE__ signed char
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST16_TYPE__ short int
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST32_TYPE__ int
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST64_TYPE__ long long int
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __INTPTR_TYPE__ long long int
# 1 "c_include/windows/original/winbase.h"
#define __UINTPTR_TYPE__ long long unsigned int
# 1 "c_include/windows/original/winbase.h"
#define __GXX_ABI_VERSION 1002
# 1 "c_include/windows/original/winbase.h"
#define __SCHAR_MAX__ 127
# 1 "c_include/windows/original/winbase.h"
#define __SHRT_MAX__ 32767
# 1 "c_include/windows/original/winbase.h"
#define __INT_MAX__ 2147483647
# 1 "c_include/windows/original/winbase.h"
#define __LONG_MAX__ 2147483647L
# 1 "c_include/windows/original/winbase.h"
#define __LONG_LONG_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __WCHAR_MAX__ 65535
# 1 "c_include/windows/original/winbase.h"
#define __WCHAR_MIN__ 0
# 1 "c_include/windows/original/winbase.h"
#define __WINT_MAX__ 65535
# 1 "c_include/windows/original/winbase.h"
#define __WINT_MIN__ 0
# 1 "c_include/windows/original/winbase.h"
#define __PTRDIFF_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __SIZE_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/winbase.h"
#define __INTMAX_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __INTMAX_C(c) c ## LL
# 1 "c_include/windows/original/winbase.h"
#define __UINTMAX_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/winbase.h"
#define __UINTMAX_C(c) c ## ULL
# 1 "c_include/windows/original/winbase.h"
#define __SIG_ATOMIC_MAX__ 2147483647
# 1 "c_include/windows/original/winbase.h"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 1 "c_include/windows/original/winbase.h"
#define __INT8_MAX__ 127
# 1 "c_include/windows/original/winbase.h"
#define __INT16_MAX__ 32767
# 1 "c_include/windows/original/winbase.h"
#define __INT32_MAX__ 2147483647
# 1 "c_include/windows/original/winbase.h"
#define __INT64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __UINT8_MAX__ 255
# 1 "c_include/windows/original/winbase.h"
#define __UINT16_MAX__ 65535
# 1 "c_include/windows/original/winbase.h"
#define __UINT32_MAX__ 4294967295U
# 1 "c_include/windows/original/winbase.h"
#define __UINT64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST8_MAX__ 127
# 1 "c_include/windows/original/winbase.h"
#define __INT8_C(c) c
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST16_MAX__ 32767
# 1 "c_include/windows/original/winbase.h"
#define __INT16_C(c) c
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST32_MAX__ 2147483647
# 1 "c_include/windows/original/winbase.h"
#define __INT32_C(c) c
# 1 "c_include/windows/original/winbase.h"
#define __INT_LEAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __INT64_C(c) c ## LL
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST8_MAX__ 255
# 1 "c_include/windows/original/winbase.h"
#define __UINT8_C(c) c
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST16_MAX__ 65535
# 1 "c_include/windows/original/winbase.h"
#define __UINT16_C(c) c
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/winbase.h"
#define __UINT32_C(c) c ## U
# 1 "c_include/windows/original/winbase.h"
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/winbase.h"
#define __UINT64_C(c) c ## ULL
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST8_MAX__ 127
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST16_MAX__ 32767
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST32_MAX__ 2147483647
# 1 "c_include/windows/original/winbase.h"
#define __INT_FAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST8_MAX__ 255
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST16_MAX__ 65535
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/winbase.h"
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/winbase.h"
#define __INTPTR_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/winbase.h"
#define __UINTPTR_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/winbase.h"
#define __FLT_EVAL_METHOD__ 0
# 1 "c_include/windows/original/winbase.h"
#define __DEC_EVAL_METHOD__ 2
# 1 "c_include/windows/original/winbase.h"
#define __FLT_RADIX__ 2
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MANT_DIG__ 24
# 1 "c_include/windows/original/winbase.h"
#define __FLT_DIG__ 6
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MIN_EXP__ (-125)
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MIN_10_EXP__ (-37)
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MAX_EXP__ 128
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MAX_10_EXP__ 38
# 1 "c_include/windows/original/winbase.h"
#define __FLT_DECIMAL_DIG__ 9
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MAX__ 3.40282346638528859812e+38F
# 1 "c_include/windows/original/winbase.h"
#define __FLT_MIN__ 1.17549435082228750797e-38F
# 1 "c_include/windows/original/winbase.h"
#define __FLT_EPSILON__ 1.19209289550781250000e-7F
# 1 "c_include/windows/original/winbase.h"
#define __FLT_DENORM_MIN__ 1.40129846432481707092e-45F
# 1 "c_include/windows/original/winbase.h"
#define __FLT_HAS_DENORM__ 1
# 1 "c_include/windows/original/winbase.h"
#define __FLT_HAS_INFINITY__ 1
# 1 "c_include/windows/original/winbase.h"
#define __FLT_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MANT_DIG__ 53
# 1 "c_include/windows/original/winbase.h"
#define __DBL_DIG__ 15
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MIN_EXP__ (-1021)
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MIN_10_EXP__ (-307)
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MAX_EXP__ 1024
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MAX_10_EXP__ 308
# 1 "c_include/windows/original/winbase.h"
#define __DBL_DECIMAL_DIG__ 17
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MAX__ ((double)1.79769313486231570815e+308L)
# 1 "c_include/windows/original/winbase.h"
#define __DBL_MIN__ ((double)2.22507385850720138309e-308L)
# 1 "c_include/windows/original/winbase.h"
#define __DBL_EPSILON__ ((double)2.22044604925031308085e-16L)
# 1 "c_include/windows/original/winbase.h"
#define __DBL_DENORM_MIN__ ((double)4.94065645841246544177e-324L)
# 1 "c_include/windows/original/winbase.h"
#define __DBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/winbase.h"
#define __DBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/winbase.h"
#define __DBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MANT_DIG__ 64
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_DIG__ 18
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MIN_EXP__ (-16381)
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MIN_10_EXP__ (-4931)
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MAX_EXP__ 16384
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MAX_10_EXP__ 4932
# 1 "c_include/windows/original/winbase.h"
#define __DECIMAL_DIG__ 21
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/winbase.h"
#define __LDBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_MANT_DIG__ 7
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_MIN_EXP__ (-94)
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_MAX_EXP__ 97
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_MIN__ 1E-95DF
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_MAX__ 9.999999E96DF
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_EPSILON__ 1E-6DF
# 1 "c_include/windows/original/winbase.h"
#define __DEC32_SUBNORMAL_MIN__ 0.000001E-95DF
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_MANT_DIG__ 16
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_MIN_EXP__ (-382)
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_MAX_EXP__ 385
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_MIN__ 1E-383DD
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_MAX__ 9.999999999999999E384DD
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_EPSILON__ 1E-15DD
# 1 "c_include/windows/original/winbase.h"
#define __DEC64_SUBNORMAL_MIN__ 0.000000000000001E-383DD
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_MANT_DIG__ 34
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_MIN_EXP__ (-6142)
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_MAX_EXP__ 6145
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_MIN__ 1E-6143DL
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_EPSILON__ 1E-33DL
# 1 "c_include/windows/original/winbase.h"
#define __DEC128_SUBNORMAL_MIN__ 0.000000000000000000000000000000001E-6143DL
# 1 "c_include/windows/original/winbase.h"
#define __REGISTER_PREFIX__ 
# 1 "c_include/windows/original/winbase.h"
#define __USER_LABEL_PREFIX__ 
# 1 "c_include/windows/original/winbase.h"
#define __GNUC_GNU_INLINE__ 1
# 1 "c_include/windows/original/winbase.h"
#define __NO_INLINE__ 1
# 1 "c_include/windows/original/winbase.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 1 "c_include/windows/original/winbase.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 1 "c_include/windows/original/winbase.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 1 "c_include/windows/original/winbase.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 1 "c_include/windows/original/winbase.h"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 1 "c_include/windows/original/winbase.h"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_INT128__ 16
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_WCHAR_T__ 2
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_WINT_T__ 2
# 1 "c_include/windows/original/winbase.h"
#define __SIZEOF_PTRDIFF_T__ 8
# 1 "c_include/windows/original/winbase.h"
#define __amd64 1
# 1 "c_include/windows/original/winbase.h"
#define __amd64__ 1
# 1 "c_include/windows/original/winbase.h"
#define __x86_64 1
# 1 "c_include/windows/original/winbase.h"
#define __x86_64__ 1
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_HLE_ACQUIRE 65536
# 1 "c_include/windows/original/winbase.h"
#define __ATOMIC_HLE_RELEASE 131072
# 1 "c_include/windows/original/winbase.h"
#define __k8 1
# 1 "c_include/windows/original/winbase.h"
#define __k8__ 1
# 1 "c_include/windows/original/winbase.h"
#define __code_model_small__ 1
# 1 "c_include/windows/original/winbase.h"
#define __MMX__ 1
# 1 "c_include/windows/original/winbase.h"
#define __SSE__ 1
# 1 "c_include/windows/original/winbase.h"
#define __SSE2__ 1
# 1 "c_include/windows/original/winbase.h"
#define __SSE_MATH__ 1
# 1 "c_include/windows/original/winbase.h"
#define __SSE2_MATH__ 1
# 1 "c_include/windows/original/winbase.h"
#define __SEH__ 1
# 1 "c_include/windows/original/winbase.h"
#define __stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/winbase.h"
#define __fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/winbase.h"
#define __thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/winbase.h"
#define __cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/winbase.h"
#define _stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/winbase.h"
#define _fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/winbase.h"
#define _thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/winbase.h"
#define _cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/winbase.h"
#define __GXX_MERGED_TYPEINFO_NAMES 0
# 1 "c_include/windows/original/winbase.h"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 1 "c_include/windows/original/winbase.h"
#define __MSVCRT__ 1
# 1 "c_include/windows/original/winbase.h"
#define __MINGW32__ 1
# 1 "c_include/windows/original/winbase.h"
#define _WIN32 1
# 1 "c_include/windows/original/winbase.h"
#define __WIN32 1
# 1 "c_include/windows/original/winbase.h"
#define __WIN32__ 1
# 1 "c_include/windows/original/winbase.h"
#define WIN32 1
# 1 "c_include/windows/original/winbase.h"
#define __WINNT 1
# 1 "c_include/windows/original/winbase.h"
#define __WINNT__ 1
# 1 "c_include/windows/original/winbase.h"
#define WINNT 1
# 1 "c_include/windows/original/winbase.h"
#define _INTEGRAL_MAX_BITS 64
# 1 "c_include/windows/original/winbase.h"
#define __MINGW64__ 1
# 1 "c_include/windows/original/winbase.h"
#define __WIN64 1
# 1 "c_include/windows/original/winbase.h"
#define __WIN64__ 1
# 1 "c_include/windows/original/winbase.h"
#define WIN64 1
# 1 "c_include/windows/original/winbase.h"
#define _WIN64 1
# 1 "c_include/windows/original/winbase.h"
#define __declspec(x) __attribute__((x))
# 1 "c_include/windows/original/winbase.h"
#define __DECIMAL_BID_FORMAT__ 1
# 1 "<command-line>"
#undef _REENTRANT
# 1 "c_include/windows/original/winbase.h"
#define _WIN32_WINNT 0x0602
#define WINVER _WIN32_WINNT

/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */

#define _WINBASE_ 

# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_unicode.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */


/* _INC_CRT_UNICODE_MACROS defined based on UNICODE flag */
# 19 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_unicode.h" 3
#define _INC_CRT_UNICODE_MACROS 2
#define __MINGW_NAME_AW(func) func ##A
#define __MINGW_NAME_AW_EXT(func,ext) func ##A ##ext
#define __MINGW_NAME_UAW(func) func ##_A
#define __MINGW_NAME_UAW_EXT(func,ext) func ##_A_ ##ext
#define __MINGW_STRING_AW(str) str
#define __MINGW_PROCNAMEEXT_AW "A"


#define __MINGW_TYPEDEF_AW(type) typedef __MINGW_NAME_AW(type) type;

#define __MINGW_TYPEDEF_UAW(type) typedef __MINGW_NAME_UAW(type) type;
# 13 "c_include/windows/original/winbase.h" 2



#define WINADVAPI DECLSPEC_IMPORT







#define WINBASEAPI DECLSPEC_IMPORT






#define ZAWPROXYAPI DECLSPEC_IMPORT
# 40 "c_include/windows/original/winbase.h"
/* #define DefineHandleTable(w) ((w),TRUE) */
#define DefineHandleTable(w) ( { (VOID)(w); TRUE; } )
#define LimitEmsPages(dw) 
#define SetSwapAreaSize(w) (w)
#define LockSegment(w) GlobalFix((HANDLE)(w))
#define UnlockSegment(w) GlobalUnfix((HANDLE)(w))

#define Yield() 

#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define INVALID_FILE_SIZE ((DWORD)0xffffffff)
#define INVALID_SET_FILE_POINTER ((DWORD)-1)
#define INVALID_FILE_ATTRIBUTES ((DWORD)-1)

#define FILE_BEGIN 0
#define FILE_CURRENT 1
#define FILE_END 2

#define TIME_ZONE_ID_INVALID ((DWORD)0xffffffff)

#define WAIT_FAILED ((DWORD)0xffffffff)
#define WAIT_OBJECT_0 ((STATUS_WAIT_0) + 0)
#define WAIT_ABANDONED ((STATUS_ABANDONED_WAIT_0) + 0)
#define WAIT_ABANDONED_0 ((STATUS_ABANDONED_WAIT_0) + 0)
#define WAIT_IO_COMPLETION STATUS_USER_APC
#define STILL_ACTIVE STATUS_PENDING
#define EXCEPTION_ACCESS_VIOLATION STATUS_ACCESS_VIOLATION
#define EXCEPTION_DATATYPE_MISALIGNMENT STATUS_DATATYPE_MISALIGNMENT
#define EXCEPTION_BREAKPOINT STATUS_BREAKPOINT
#define EXCEPTION_SINGLE_STEP STATUS_SINGLE_STEP
#define EXCEPTION_ARRAY_BOUNDS_EXCEEDED STATUS_ARRAY_BOUNDS_EXCEEDED
#define EXCEPTION_FLT_DENORMAL_OPERAND STATUS_FLOAT_DENORMAL_OPERAND
#define EXCEPTION_FLT_DIVIDE_BY_ZERO STATUS_FLOAT_DIVIDE_BY_ZERO
#define EXCEPTION_FLT_INEXACT_RESULT STATUS_FLOAT_INEXACT_RESULT
#define EXCEPTION_FLT_INVALID_OPERATION STATUS_FLOAT_INVALID_OPERATION
#define EXCEPTION_FLT_OVERFLOW STATUS_FLOAT_OVERFLOW
#define EXCEPTION_FLT_STACK_CHECK STATUS_FLOAT_STACK_CHECK
#define EXCEPTION_FLT_UNDERFLOW STATUS_FLOAT_UNDERFLOW
#define EXCEPTION_INT_DIVIDE_BY_ZERO STATUS_INTEGER_DIVIDE_BY_ZERO
#define EXCEPTION_INT_OVERFLOW STATUS_INTEGER_OVERFLOW
#define EXCEPTION_PRIV_INSTRUCTION STATUS_PRIVILEGED_INSTRUCTION
#define EXCEPTION_IN_PAGE_ERROR STATUS_IN_PAGE_ERROR
#define EXCEPTION_ILLEGAL_INSTRUCTION STATUS_ILLEGAL_INSTRUCTION
#define EXCEPTION_NONCONTINUABLE_EXCEPTION STATUS_NONCONTINUABLE_EXCEPTION
#define EXCEPTION_STACK_OVERFLOW STATUS_STACK_OVERFLOW
#define EXCEPTION_INVALID_DISPOSITION STATUS_INVALID_DISPOSITION
#define EXCEPTION_GUARD_PAGE STATUS_GUARD_PAGE_VIOLATION
#define EXCEPTION_INVALID_HANDLE STATUS_INVALID_HANDLE
#define EXCEPTION_POSSIBLE_DEADLOCK STATUS_POSSIBLE_DEADLOCK
#define CONTROL_C_EXIT STATUS_CONTROL_C_EXIT
#define MoveMemory RtlMoveMemory
#define CopyMemory RtlCopyMemory
#define FillMemory RtlFillMemory
#define ZeroMemory RtlZeroMemory
#define SecureZeroMemory RtlSecureZeroMemory
#define CaptureStackBackTrace RtlCaptureStackBackTrace

#define FILE_FLAG_WRITE_THROUGH 0x80000000
#define FILE_FLAG_OVERLAPPED 0x40000000
#define FILE_FLAG_NO_BUFFERING 0x20000000
#define FILE_FLAG_RANDOM_ACCESS 0x10000000
#define FILE_FLAG_SEQUENTIAL_SCAN 0x8000000
#define FILE_FLAG_DELETE_ON_CLOSE 0x4000000
#define FILE_FLAG_BACKUP_SEMANTICS 0x2000000
#define FILE_FLAG_POSIX_SEMANTICS 0x1000000
#define FILE_FLAG_OPEN_REPARSE_POINT 0x200000
#define FILE_FLAG_OPEN_NO_RECALL 0x100000
#define FILE_FLAG_FIRST_PIPE_INSTANCE 0x80000

#define CREATE_NEW 1
#define CREATE_ALWAYS 2
#define OPEN_EXISTING 3
#define OPEN_ALWAYS 4
#define TRUNCATE_EXISTING 5

#define PROGRESS_CONTINUE 0
#define PROGRESS_CANCEL 1
#define PROGRESS_STOP 2
#define PROGRESS_QUIET 3

#define CALLBACK_CHUNK_FINISHED 0x0
#define CALLBACK_STREAM_SWITCH 0x1

#define COPY_FILE_FAIL_IF_EXISTS 0x1
#define COPY_FILE_RESTARTABLE 0x2
#define COPY_FILE_OPEN_SOURCE_FOR_WRITE 0x4
#define COPY_FILE_ALLOW_DECRYPTED_DESTINATION 0x8
#define COPY_FILE_COPY_SYMLINK 0x0800
#define COPY_FILE_NO_BUFFERING 0x1000

#define REPLACEFILE_WRITE_THROUGH 0x1
#define REPLACEFILE_IGNORE_MERGE_ERRORS 0x2

#define PIPE_ACCESS_INBOUND 0x1
#define PIPE_ACCESS_OUTBOUND 0x2
#define PIPE_ACCESS_DUPLEX 0x3

#define PIPE_CLIENT_END 0x0
#define PIPE_SERVER_END 0x1

#define PIPE_WAIT 0x0
#define PIPE_NOWAIT 0x1
#define PIPE_READMODE_BYTE 0x0
#define PIPE_READMODE_MESSAGE 0x2
#define PIPE_TYPE_BYTE 0x0
#define PIPE_TYPE_MESSAGE 0x4

#define PIPE_ACCEPT_REMOTE_CLIENTS 0x0
#define PIPE_REJECT_REMOTE_CLIENTS 0x8


#define PIPE_UNLIMITED_INSTANCES 255

#define SECURITY_ANONYMOUS (SecurityAnonymous << 16)
#define SECURITY_IDENTIFICATION (SecurityIdentification << 16)
#define SECURITY_IMPERSONATION (SecurityImpersonation << 16)
#define SECURITY_DELEGATION (SecurityDelegation << 16)

#define SECURITY_CONTEXT_TRACKING 0x40000
#define SECURITY_EFFECTIVE_ONLY 0x80000

#define SECURITY_SQOS_PRESENT 0x100000
#define SECURITY_VALID_SQOS_FLAGS 0x1f0000


/* available in Vista SP1 and higher */
#define PROCESS_DEP_ENABLE 0x1
#define PROCESS_DEP_DISABLE_ATL_THUNK_EMULATION 0x2


  typedef struct _OVERLAPPED {
    ULONG_PTR Internal;
    ULONG_PTR InternalHigh;
    __C89_NAMELESS union {
      __C89_NAMELESS struct {
 DWORD Offset;
 DWORD OffsetHigh;
      };
      PVOID Pointer;
    };
    HANDLE hEvent;
  } OVERLAPPED,*LPOVERLAPPED;

  typedef struct _SECURITY_ATTRIBUTES {
    DWORD nLength;
    LPVOID lpSecurityDescriptor;
    WINBOOL bInheritHandle;
  } SECURITY_ATTRIBUTES,*PSECURITY_ATTRIBUTES,*LPSECURITY_ATTRIBUTES;

  typedef struct _PROCESS_INFORMATION {
    HANDLE hProcess;
    HANDLE hThread;
    DWORD dwProcessId;
    DWORD dwThreadId;
  } PROCESS_INFORMATION,*PPROCESS_INFORMATION,*LPPROCESS_INFORMATION;


#define _FILETIME_ 
  typedef struct _FILETIME {
    DWORD dwLowDateTime;
    DWORD dwHighDateTime;
  } FILETIME,*PFILETIME,*LPFILETIME;



#define _SYSTEMTIME_ 
  typedef struct _SYSTEMTIME {
    WORD wYear;
    WORD wMonth;
    WORD wDayOfWeek;
    WORD wDay;
    WORD wHour;
    WORD wMinute;
    WORD wSecond;
    WORD wMilliseconds;
  } SYSTEMTIME,*PSYSTEMTIME,*LPSYSTEMTIME;


  typedef DWORD (WINAPI *PTHREAD_START_ROUTINE)(LPVOID lpThreadParameter);
  typedef PTHREAD_START_ROUTINE LPTHREAD_START_ROUTINE;
  typedef VOID (WINAPI *PFIBER_START_ROUTINE)(LPVOID lpFiberParameter);
  typedef PFIBER_START_ROUTINE LPFIBER_START_ROUTINE;

  typedef RTL_CRITICAL_SECTION CRITICAL_SECTION;
  typedef PRTL_CRITICAL_SECTION PCRITICAL_SECTION;
  typedef PRTL_CRITICAL_SECTION LPCRITICAL_SECTION;
  typedef RTL_CRITICAL_SECTION_DEBUG CRITICAL_SECTION_DEBUG;
  typedef PRTL_CRITICAL_SECTION_DEBUG PCRITICAL_SECTION_DEBUG;
  typedef PRTL_CRITICAL_SECTION_DEBUG LPCRITICAL_SECTION_DEBUG;

  DECLSPEC_IMPORT PVOID WINAPI EncodePointer(PVOID Ptr);
  DECLSPEC_IMPORT PVOID WINAPI DecodePointer(PVOID Ptr);
  DECLSPEC_IMPORT PVOID WINAPI EncodeSystemPointer(PVOID Ptr);
  DECLSPEC_IMPORT PVOID WINAPI DecodeSystemPointer(PVOID Ptr);




  typedef LPVOID LPLDT_ENTRY;


#define CRITICAL_SECTION_NO_DEBUG_INFO RTL_CRITICAL_SECTION_FLAG_NO_DEBUG_INFO

#define MUTEX_MODIFY_STATE MUTANT_QUERY_STATE
#define MUTEX_ALL_ACCESS MUTANT_ALL_ACCESS

#define SP_SERIALCOMM ((DWORD)0x1)

#define PST_UNSPECIFIED ((DWORD)0x0)
#define PST_RS232 ((DWORD)0x1)
#define PST_PARALLELPORT ((DWORD)0x2)
#define PST_RS422 ((DWORD)0x3)
#define PST_RS423 ((DWORD)0x4)
#define PST_RS449 ((DWORD)0x5)
#define PST_MODEM ((DWORD)0x6)
#define PST_FAX ((DWORD)0x21)
#define PST_SCANNER ((DWORD)0x22)
#define PST_NETWORK_BRIDGE ((DWORD)0x100)
#define PST_LAT ((DWORD)0x101)
#define PST_TCPIP_TELNET ((DWORD)0x102)
#define PST_X25 ((DWORD)0x103)

#define PCF_DTRDSR ((DWORD)0x1)
#define PCF_RTSCTS ((DWORD)0x2)
#define PCF_RLSD ((DWORD)0x4)
#define PCF_PARITY_CHECK ((DWORD)0x8)
#define PCF_XONXOFF ((DWORD)0x10)
#define PCF_SETXCHAR ((DWORD)0x20)
#define PCF_TOTALTIMEOUTS ((DWORD)0x40)
#define PCF_INTTIMEOUTS ((DWORD)0x80)
#define PCF_SPECIALCHARS ((DWORD)0x100)
#define PCF_16BITMODE ((DWORD)0x200)

#define SP_PARITY ((DWORD)0x1)
#define SP_BAUD ((DWORD)0x2)
#define SP_DATABITS ((DWORD)0x4)
#define SP_STOPBITS ((DWORD)0x8)
#define SP_HANDSHAKING ((DWORD)0x10)
#define SP_PARITY_CHECK ((DWORD)0x20)
#define SP_RLSD ((DWORD)0x40)

#define BAUD_075 ((DWORD)0x1)
#define BAUD_110 ((DWORD)0x2)
#define BAUD_134_5 ((DWORD)0x4)
#define BAUD_150 ((DWORD)0x8)
#define BAUD_300 ((DWORD)0x10)
#define BAUD_600 ((DWORD)0x20)
#define BAUD_1200 ((DWORD)0x40)
#define BAUD_1800 ((DWORD)0x80)
#define BAUD_2400 ((DWORD)0x100)
#define BAUD_4800 ((DWORD)0x200)
#define BAUD_7200 ((DWORD)0x400)
#define BAUD_9600 ((DWORD)0x800)
#define BAUD_14400 ((DWORD)0x1000)
#define BAUD_19200 ((DWORD)0x2000)
#define BAUD_38400 ((DWORD)0x4000)
#define BAUD_56K ((DWORD)0x8000)
#define BAUD_128K ((DWORD)0x10000)
#define BAUD_115200 ((DWORD)0x20000)
#define BAUD_57600 ((DWORD)0x40000)
#define BAUD_USER ((DWORD)0x10000000)

#define DATABITS_5 ((WORD)0x1)
#define DATABITS_6 ((WORD)0x2)
#define DATABITS_7 ((WORD)0x4)
#define DATABITS_8 ((WORD)0x8)
#define DATABITS_16 ((WORD)0x10)
#define DATABITS_16X ((WORD)0x20)

#define STOPBITS_10 ((WORD)0x1)
#define STOPBITS_15 ((WORD)0x2)
#define STOPBITS_20 ((WORD)0x4)
#define PARITY_NONE ((WORD)0x100)
#define PARITY_ODD ((WORD)0x200)
#define PARITY_EVEN ((WORD)0x400)
#define PARITY_MARK ((WORD)0x800)
#define PARITY_SPACE ((WORD)0x1000)

  typedef struct _COMMPROP {
    WORD wPacketLength;
    WORD wPacketVersion;
    DWORD dwServiceMask;
    DWORD dwReserved1;
    DWORD dwMaxTxQueue;
    DWORD dwMaxRxQueue;
    DWORD dwMaxBaud;
    DWORD dwProvSubType;
    DWORD dwProvCapabilities;
    DWORD dwSettableParams;
    DWORD dwSettableBaud;
    WORD wSettableData;
    WORD wSettableStopParity;
    DWORD dwCurrentTxQueue;
    DWORD dwCurrentRxQueue;
    DWORD dwProvSpec1;
    DWORD dwProvSpec2;
    WCHAR wcProvChar[1];
  } COMMPROP,*LPCOMMPROP;

#define COMMPROP_INITIALIZED ((DWORD)0xE73CF52E)

  typedef struct _COMSTAT {
    DWORD fCtsHold : 1;
    DWORD fDsrHold : 1;
    DWORD fRlsdHold : 1;
    DWORD fXoffHold : 1;
    DWORD fXoffSent : 1;
    DWORD fEof : 1;
    DWORD fTxim : 1;
    DWORD fReserved : 25;
    DWORD cbInQue;
    DWORD cbOutQue;
  } COMSTAT,*LPCOMSTAT;

#define DTR_CONTROL_DISABLE 0x0
#define DTR_CONTROL_ENABLE 0x1
#define DTR_CONTROL_HANDSHAKE 0x2

#define RTS_CONTROL_DISABLE 0x0
#define RTS_CONTROL_ENABLE 0x1
#define RTS_CONTROL_HANDSHAKE 0x2
#define RTS_CONTROL_TOGGLE 0x3

  typedef struct _DCB {
    DWORD DCBlength;
    DWORD BaudRate;
    DWORD fBinary: 1;
    DWORD fParity: 1;
    DWORD fOutxCtsFlow:1;
    DWORD fOutxDsrFlow:1;
    DWORD fDtrControl:2;
    DWORD fDsrSensitivity:1;
    DWORD fTXContinueOnXoff: 1;
    DWORD fOutX: 1;
    DWORD fInX: 1;
    DWORD fErrorChar: 1;
    DWORD fNull: 1;
    DWORD fRtsControl:2;
    DWORD fAbortOnError:1;
    DWORD fDummy2:17;
    WORD wReserved;
    WORD XonLim;
    WORD XoffLim;
    BYTE ByteSize;
    BYTE Parity;
    BYTE StopBits;
    char XonChar;
    char XoffChar;
    char ErrorChar;
    char EofChar;
    char EvtChar;
    WORD wReserved1;
  } DCB,*LPDCB;

  typedef struct _COMMTIMEOUTS {
    DWORD ReadIntervalTimeout;
    DWORD ReadTotalTimeoutMultiplier;
    DWORD ReadTotalTimeoutConstant;
    DWORD WriteTotalTimeoutMultiplier;
    DWORD WriteTotalTimeoutConstant;
  } COMMTIMEOUTS,*LPCOMMTIMEOUTS;

  typedef struct _COMMCONFIG {
    DWORD dwSize;
    WORD wVersion;
    WORD wReserved;
    DCB dcb;
    DWORD dwProviderSubType;
    DWORD dwProviderOffset;
    DWORD dwProviderSize;
    WCHAR wcProviderData[1];
  } COMMCONFIG,*LPCOMMCONFIG;

  typedef struct _SYSTEM_INFO {
    __C89_NAMELESS union {
      DWORD dwOemId;
      __C89_NAMELESS struct {
 WORD wProcessorArchitecture;
 WORD wReserved;
      } DUMMYSTRUCTNAME;
    } DUMMYUNIONNAME;
    DWORD dwPageSize;
    LPVOID lpMinimumApplicationAddress;
    LPVOID lpMaximumApplicationAddress;
    DWORD_PTR dwActiveProcessorMask;
    DWORD dwNumberOfProcessors;
    DWORD dwProcessorType;
    DWORD dwAllocationGranularity;
    WORD wProcessorLevel;
    WORD wProcessorRevision;
  } SYSTEM_INFO,*LPSYSTEM_INFO;

#define FreeModule(hLibModule) FreeLibrary((hLibModule))
#define MakeProcInstance(lpProc,hInstance) (lpProc)
#define FreeProcInstance(lpProc) (lpProc)

#define GMEM_FIXED 0x0
#define GMEM_MOVEABLE 0x2
#define GMEM_NOCOMPACT 0x10
#define GMEM_NODISCARD 0x20
#define GMEM_ZEROINIT 0x40
#define GMEM_MODIFY 0x80
#define GMEM_DISCARDABLE 0x100
#define GMEM_NOT_BANKED 0x1000
#define GMEM_SHARE 0x2000
#define GMEM_DDESHARE 0x2000
#define GMEM_NOTIFY 0x4000
#define GMEM_LOWER GMEM_NOT_BANKED
#define GMEM_VALID_FLAGS 0x7F72
#define GMEM_INVALID_HANDLE 0x8000

#define GHND (GMEM_MOVEABLE | GMEM_ZEROINIT)
#define GPTR (GMEM_FIXED | GMEM_ZEROINIT)

#define GlobalLRUNewest(h) ((HANDLE)(h))
#define GlobalLRUOldest(h) ((HANDLE)(h))
#define GlobalDiscard(h) GlobalReAlloc((h),0,GMEM_MOVEABLE)

#define GMEM_DISCARDED 0x4000
#define GMEM_LOCKCOUNT 0xff

  typedef struct _MEMORYSTATUS {
    DWORD dwLength;
    DWORD dwMemoryLoad;
    SIZE_T dwTotalPhys;
    SIZE_T dwAvailPhys;
    SIZE_T dwTotalPageFile;
    SIZE_T dwAvailPageFile;
    SIZE_T dwTotalVirtual;
    SIZE_T dwAvailVirtual;
  } MEMORYSTATUS,*LPMEMORYSTATUS;

#define LMEM_FIXED 0x0
#define LMEM_MOVEABLE 0x2
#define LMEM_NOCOMPACT 0x10
#define LMEM_NODISCARD 0x20
#define LMEM_ZEROINIT 0x40
#define LMEM_MODIFY 0x80
#define LMEM_DISCARDABLE 0xf00
#define LMEM_VALID_FLAGS 0xf72
#define LMEM_INVALID_HANDLE 0x8000

#define LHND (LMEM_MOVEABLE | LMEM_ZEROINIT)
#define LPTR (LMEM_FIXED | LMEM_ZEROINIT)

#define NONZEROLHND (LMEM_MOVEABLE)
#define NONZEROLPTR (LMEM_FIXED)

#define LocalDiscard(h) LocalReAlloc((h),0,LMEM_MOVEABLE)

#define LMEM_DISCARDED 0x4000
#define LMEM_LOCKCOUNT 0xff

#define DEBUG_PROCESS 0x1
#define DEBUG_ONLY_THIS_PROCESS 0x2
#define CREATE_SUSPENDED 0x4
#define DETACHED_PROCESS 0x8
#define CREATE_NEW_CONSOLE 0x10
#define NORMAL_PRIORITY_CLASS 0x20
#define IDLE_PRIORITY_CLASS 0x40
#define HIGH_PRIORITY_CLASS 0x80
#define REALTIME_PRIORITY_CLASS 0x100
#define CREATE_NEW_PROCESS_GROUP 0x200
#define CREATE_UNICODE_ENVIRONMENT 0x400
#define CREATE_SEPARATE_WOW_VDM 0x800
#define CREATE_SHARED_WOW_VDM 0x1000
#define CREATE_FORCEDOS 0x2000
#define BELOW_NORMAL_PRIORITY_CLASS 0x4000
#define ABOVE_NORMAL_PRIORITY_CLASS 0x8000
#define STACK_SIZE_PARAM_IS_A_RESERVATION 0x10000

#define CREATE_BREAKAWAY_FROM_JOB 0x1000000
#define CREATE_PRESERVE_CODE_AUTHZ_LEVEL 0x2000000

#define CREATE_DEFAULT_ERROR_MODE 0x4000000
#define CREATE_NO_WINDOW 0x8000000

#define PROFILE_USER 0x10000000
#define PROFILE_KERNEL 0x20000000
#define PROFILE_SERVER 0x40000000

#define CREATE_IGNORE_SYSTEM_DEFAULT 0x80000000

#define THREAD_PRIORITY_LOWEST THREAD_BASE_PRIORITY_MIN
#define THREAD_PRIORITY_BELOW_NORMAL (THREAD_PRIORITY_LOWEST+1)
#define THREAD_PRIORITY_NORMAL 0
#define THREAD_PRIORITY_HIGHEST THREAD_BASE_PRIORITY_MAX
#define THREAD_PRIORITY_ABOVE_NORMAL (THREAD_PRIORITY_HIGHEST-1)
#define THREAD_PRIORITY_ERROR_RETURN (MAXLONG)

#define THREAD_MODE_BACKGROUND_BEGIN 0x00010000
#define THREAD_MODE_BACKGROUND_END 0x00020000

#define THREAD_PRIORITY_TIME_CRITICAL THREAD_BASE_PRIORITY_LOWRT
#define THREAD_PRIORITY_IDLE THREAD_BASE_PRIORITY_IDLE

#define EXCEPTION_DEBUG_EVENT 1
#define CREATE_THREAD_DEBUG_EVENT 2
#define CREATE_PROCESS_DEBUG_EVENT 3
#define EXIT_THREAD_DEBUG_EVENT 4
#define EXIT_PROCESS_DEBUG_EVENT 5
#define LOAD_DLL_DEBUG_EVENT 6
#define UNLOAD_DLL_DEBUG_EVENT 7
#define OUTPUT_DEBUG_STRING_EVENT 8
#define RIP_EVENT 9

  typedef struct _EXCEPTION_DEBUG_INFO {
    EXCEPTION_RECORD ExceptionRecord;
    DWORD dwFirstChance;
  } EXCEPTION_DEBUG_INFO,*LPEXCEPTION_DEBUG_INFO;

  typedef struct _CREATE_THREAD_DEBUG_INFO {
    HANDLE hThread;
    LPVOID lpThreadLocalBase;
    LPTHREAD_START_ROUTINE lpStartAddress;
  } CREATE_THREAD_DEBUG_INFO,*LPCREATE_THREAD_DEBUG_INFO;

  typedef struct _CREATE_PROCESS_DEBUG_INFO {
    HANDLE hFile;
    HANDLE hProcess;
    HANDLE hThread;
    LPVOID lpBaseOfImage;
    DWORD dwDebugInfoFileOffset;
    DWORD nDebugInfoSize;
    LPVOID lpThreadLocalBase;
    LPTHREAD_START_ROUTINE lpStartAddress;
    LPVOID lpImageName;
    WORD fUnicode;
  } CREATE_PROCESS_DEBUG_INFO,*LPCREATE_PROCESS_DEBUG_INFO;

  typedef struct _EXIT_THREAD_DEBUG_INFO {
    DWORD dwExitCode;
  } EXIT_THREAD_DEBUG_INFO,*LPEXIT_THREAD_DEBUG_INFO;

  typedef struct _EXIT_PROCESS_DEBUG_INFO {
    DWORD dwExitCode;
  } EXIT_PROCESS_DEBUG_INFO,*LPEXIT_PROCESS_DEBUG_INFO;

  typedef struct _LOAD_DLL_DEBUG_INFO {
    HANDLE hFile;
    LPVOID lpBaseOfDll;
    DWORD dwDebugInfoFileOffset;
    DWORD nDebugInfoSize;
    LPVOID lpImageName;
    WORD fUnicode;
  } LOAD_DLL_DEBUG_INFO,*LPLOAD_DLL_DEBUG_INFO;

  typedef struct _UNLOAD_DLL_DEBUG_INFO {
    LPVOID lpBaseOfDll;
  } UNLOAD_DLL_DEBUG_INFO,*LPUNLOAD_DLL_DEBUG_INFO;

  typedef struct _OUTPUT_DEBUG_STRING_INFO {
    LPSTR lpDebugStringData;
    WORD fUnicode;
    WORD nDebugStringLength;
  } OUTPUT_DEBUG_STRING_INFO,*LPOUTPUT_DEBUG_STRING_INFO;

  typedef struct _RIP_INFO {
    DWORD dwError;
    DWORD dwType;
  } RIP_INFO,*LPRIP_INFO;

  typedef struct _DEBUG_EVENT {
    DWORD dwDebugEventCode;
    DWORD dwProcessId;
    DWORD dwThreadId;
    union {
      EXCEPTION_DEBUG_INFO Exception;
      CREATE_THREAD_DEBUG_INFO CreateThread;
      CREATE_PROCESS_DEBUG_INFO CreateProcessInfo;
      EXIT_THREAD_DEBUG_INFO ExitThread;
      EXIT_PROCESS_DEBUG_INFO ExitProcess;
      LOAD_DLL_DEBUG_INFO LoadDll;
      UNLOAD_DLL_DEBUG_INFO UnloadDll;
      OUTPUT_DEBUG_STRING_INFO DebugString;
      RIP_INFO RipInfo;
    } u;
  } DEBUG_EVENT,*LPDEBUG_EVENT;

  typedef PCONTEXT LPCONTEXT;
  typedef PEXCEPTION_RECORD LPEXCEPTION_RECORD;
  typedef PEXCEPTION_POINTERS LPEXCEPTION_POINTERS;

#define DRIVE_UNKNOWN 0
#define DRIVE_NO_ROOT_DIR 1
#define DRIVE_REMOVABLE 2
#define DRIVE_FIXED 3
#define DRIVE_REMOTE 4
#define DRIVE_CDROM 5
#define DRIVE_RAMDISK 6

#define GetFreeSpace(w) (__MSABI_LONG(0x100000))
#define FILE_TYPE_UNKNOWN 0x0
#define FILE_TYPE_DISK 0x1
#define FILE_TYPE_CHAR 0x2
#define FILE_TYPE_PIPE 0x3
#define FILE_TYPE_REMOTE 0x8000

#define STD_INPUT_HANDLE ((DWORD)-10)
#define STD_OUTPUT_HANDLE ((DWORD)-11)
#define STD_ERROR_HANDLE ((DWORD)-12)

#define NOPARITY 0
#define ODDPARITY 1
#define EVENPARITY 2
#define MARKPARITY 3
#define SPACEPARITY 4

#define ONESTOPBIT 0
#define ONE5STOPBITS 1
#define TWOSTOPBITS 2

#define IGNORE 0
#define INFINITE 0xffffffff

#define CBR_110 110
#define CBR_300 300
#define CBR_600 600
#define CBR_1200 1200
#define CBR_2400 2400
#define CBR_4800 4800
#define CBR_9600 9600
#define CBR_14400 14400
#define CBR_19200 19200
#define CBR_38400 38400
#define CBR_56000 56000
#define CBR_57600 57600
#define CBR_115200 115200
#define CBR_128000 128000
#define CBR_256000 256000

#define CE_RXOVER 0x1
#define CE_OVERRUN 0x2
#define CE_RXPARITY 0x4
#define CE_FRAME 0x8
#define CE_BREAK 0x10
#define CE_TXFULL 0x100
#define CE_PTO 0x200
#define CE_IOE 0x400
#define CE_DNS 0x800
#define CE_OOP 0x1000
#define CE_MODE 0x8000

#define IE_BADID (-1)
#define IE_OPEN (-2)
#define IE_NOPEN (-3)
#define IE_MEMORY (-4)
#define IE_DEFAULT (-5)
#define IE_HARDWARE (-10)
#define IE_BYTESIZE (-11)
#define IE_BAUDRATE (-12)

#define EV_RXCHAR 0x1
#define EV_RXFLAG 0x2
#define EV_TXEMPTY 0x4
#define EV_CTS 0x8
#define EV_DSR 0x10
#define EV_RLSD 0x20
#define EV_BREAK 0x40
#define EV_ERR 0x80
#define EV_RING 0x100
#define EV_PERR 0x200
#define EV_RX80FULL 0x400
#define EV_EVENT1 0x800
#define EV_EVENT2 0x1000

#define SETXOFF 1
#define SETXON 2
#define SETRTS 3
#define CLRRTS 4
#define SETDTR 5
#define CLRDTR 6
#define RESETDEV 7
#define SETBREAK 8
#define CLRBREAK 9

#define PURGE_TXABORT 0x1
#define PURGE_RXABORT 0x2
#define PURGE_TXCLEAR 0x4
#define PURGE_RXCLEAR 0x8

#define LPTx 0x80

#define MS_CTS_ON ((DWORD)0x10)
#define MS_DSR_ON ((DWORD)0x20)
#define MS_RING_ON ((DWORD)0x40)
#define MS_RLSD_ON ((DWORD)0x80)

#define S_QUEUEEMPTY 0
#define S_THRESHOLD 1
#define S_ALLTHRESHOLD 2

#define S_NORMAL 0
#define S_LEGATO 1
#define S_STACCATO 2

#define S_PERIOD512 0
#define S_PERIOD1024 1
#define S_PERIOD2048 2
#define S_PERIODVOICE 3
#define S_WHITE512 4
#define S_WHITE1024 5
#define S_WHITE2048 6
#define S_WHITEVOICE 7

#define S_SERDVNA (-1)
#define S_SEROFM (-2)
#define S_SERMACT (-3)
#define S_SERQFUL (-4)
#define S_SERBDNT (-5)
#define S_SERDLN (-6)
#define S_SERDCC (-7)
#define S_SERDTP (-8)
#define S_SERDVL (-9)
#define S_SERDMD (-10)
#define S_SERDSH (-11)
#define S_SERDPT (-12)
#define S_SERDFQ (-13)
#define S_SERDDR (-14)
#define S_SERDSR (-15)
#define S_SERDST (-16)

#define NMPWAIT_WAIT_FOREVER 0xffffffff
#define NMPWAIT_NOWAIT 0x1
#define NMPWAIT_USE_DEFAULT_WAIT 0x0

#define FS_CASE_IS_PRESERVED FILE_CASE_PRESERVED_NAMES
#define FS_CASE_SENSITIVE FILE_CASE_SENSITIVE_SEARCH
#define FS_UNICODE_STORED_ON_DISK FILE_UNICODE_ON_DISK
#define FS_PERSISTENT_ACLS FILE_PERSISTENT_ACLS
#define FS_VOL_IS_COMPRESSED FILE_VOLUME_IS_COMPRESSED
#define FS_FILE_COMPRESSION FILE_FILE_COMPRESSION
#define FS_FILE_ENCRYPTION FILE_SUPPORTS_ENCRYPTION

#define FILE_MAP_COPY SECTION_QUERY
#define FILE_MAP_WRITE SECTION_MAP_WRITE
#define FILE_MAP_READ SECTION_MAP_READ
#define FILE_MAP_ALL_ACCESS SECTION_ALL_ACCESS
#define FILE_MAP_EXECUTE SECTION_MAP_EXECUTE_EXPLICIT

#define OF_READ 0x0
#define OF_WRITE 0x1
#define OF_READWRITE 0x2
#define OF_SHARE_COMPAT 0x0
#define OF_SHARE_EXCLUSIVE 0x10
#define OF_SHARE_DENY_WRITE 0x20
#define OF_SHARE_DENY_READ 0x30
#define OF_SHARE_DENY_NONE 0x40
#define OF_PARSE 0x100
#define OF_DELETE 0x200
#define OF_VERIFY 0x400
#define OF_CANCEL 0x800
#define OF_CREATE 0x1000
#define OF_PROMPT 0x2000
#define OF_EXIST 0x4000
#define OF_REOPEN 0x8000

#define OFS_MAXPATHNAME 128
  typedef struct _OFSTRUCT {
    BYTE cBytes;
    BYTE fFixedDisk;
    WORD nErrCode;
    WORD Reserved1;
    WORD Reserved2;
    CHAR szPathName[128];
  } OFSTRUCT,*LPOFSTRUCT,*POFSTRUCT;
# 976 "c_include/windows/original/winbase.h"
#define InterlockedIncrement _InterlockedIncrement
#define InterlockedIncrementAcquire InterlockedIncrement
#define InterlockedIncrementRelease InterlockedIncrement
#define InterlockedDecrement _InterlockedDecrement
#define InterlockedDecrementAcquire InterlockedDecrement
#define InterlockedDecrementRelease InterlockedDecrement
#define InterlockedExchange _InterlockedExchange
#define InterlockedExchangeAdd _InterlockedExchangeAdd
#define InterlockedCompareExchange _InterlockedCompareExchange
#define InterlockedCompareExchangeAcquire InterlockedCompareExchange
#define InterlockedCompareExchangeRelease InterlockedCompareExchange
#define InterlockedExchangePointer _InterlockedExchangePointer
#define InterlockedCompareExchangePointer _InterlockedCompareExchangePointer
#define InterlockedCompareExchangePointerAcquire _InterlockedCompareExchangePointer
#define InterlockedCompareExchangePointerRelease _InterlockedCompareExchangePointer
#define InterlockedAnd64 _InterlockedAnd64
#define InterlockedOr64 _InterlockedOr64
#define InterlockedXor64 _InterlockedXor64
#define InterlockedIncrement64 _InterlockedIncrement64
#define InterlockedDecrement64 _InterlockedDecrement64
#define InterlockedExchange64 _InterlockedExchange64
#define InterlockedExchangeAdd64 _InterlockedExchangeAdd64
#define InterlockedCompareExchange64 _InterlockedCompareExchange64
#define InterlockedCompareExchangeAcquire64 InterlockedCompareExchange64
#define InterlockedCompareExchangeRelease64 InterlockedCompareExchange64

  LONG __attribute__((__cdecl__)) _InterlockedIncrement(LONG volatile *Addend);
  LONG __attribute__((__cdecl__)) _InterlockedDecrement(LONG volatile *Addend);
  LONG __attribute__((__cdecl__)) _InterlockedExchange(LONG volatile *Target,LONG Value);
  LONG __attribute__((__cdecl__)) _InterlockedExchangeAdd(LONG volatile *Addend,LONG Value);
  LONG __attribute__((__cdecl__)) _InterlockedCompareExchange(LONG volatile *Destination,LONG ExChange,LONG Comperand);
  PVOID __attribute__((__cdecl__)) _InterlockedCompareExchangePointer(PVOID volatile *Destination,PVOID Exchange,PVOID Comperand);
  PVOID __attribute__((__cdecl__)) _InterlockedExchangePointer(PVOID volatile *Target,PVOID Value);
  LONG64 __attribute__((__cdecl__)) _InterlockedAnd64(LONG64 volatile *Destination,LONG64 Value);
  LONG64 __attribute__((__cdecl__)) _InterlockedOr64(LONG64 volatile *Destination,LONG64 Value);
  LONG64 __attribute__((__cdecl__)) _InterlockedXor64(LONG64 volatile *Destination,LONG64 Value);
  LONG64 __attribute__((__cdecl__)) _InterlockedIncrement64(LONG64 volatile *Addend);
  LONG64 __attribute__((__cdecl__)) _InterlockedDecrement64(LONG64 volatile *Addend);
  LONG64 __attribute__((__cdecl__)) _InterlockedExchange64(LONG64 volatile *Target,LONG64 Value);
  LONG64 __attribute__((__cdecl__)) _InterlockedExchangeAdd64(LONG64 volatile *Addend,LONG64 Value);
  LONG64 __attribute__((__cdecl__)) _InterlockedCompareExchange64(LONG64 volatile *Destination,LONG64 ExChange,LONG64 Comperand);
# 1133 "c_include/windows/original/winbase.h"
  DECLSPEC_IMPORT WINBOOL WINAPI FreeResource(HGLOBAL hResData);
  DECLSPEC_IMPORT LPVOID WINAPI LockResource(HGLOBAL hResData);

/* #define UnlockResource(hResData) ((hResData),0) */
#define UnlockResource(hResData) ( { (VOID)(hResData); 0; } )
#define MAXINTATOM 0xC000
#define MAKEINTATOM(i) (LPTSTR)((ULONG_PTR)((WORD)(i)))
#define INVALID_ATOM ((ATOM)0)

  int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmd);
  int WINAPI wWinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPWSTR lpCmdLine,int nShowCmd);
/* Unicode entry point is wWinMain, WinMain is just the ANSI version.  */

  DECLSPEC_IMPORT WINBOOL WINAPI FreeLibrary(HMODULE hLibModule);
  DECLSPEC_IMPORT DECLSPEC_NORETURN VOID WINAPI FreeLibraryAndExitThread(HMODULE hLibModule,DWORD dwExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI DisableThreadLibraryCalls(HMODULE hLibModule);
  DECLSPEC_IMPORT FARPROC WINAPI GetProcAddress(HMODULE hModule,LPCSTR lpProcName);
  DECLSPEC_IMPORT DWORD WINAPI GetVersion(VOID);
  DECLSPEC_IMPORT HGLOBAL WINAPI GlobalAlloc(UINT uFlags,SIZE_T dwBytes);
  DECLSPEC_IMPORT HGLOBAL WINAPI GlobalReAlloc(HGLOBAL hMem,SIZE_T dwBytes,UINT uFlags);
  DECLSPEC_IMPORT SIZE_T WINAPI GlobalSize(HGLOBAL hMem);
  DECLSPEC_IMPORT UINT WINAPI GlobalFlags(HGLOBAL hMem);
  DECLSPEC_IMPORT LPVOID WINAPI GlobalLock(HGLOBAL hMem);
  DECLSPEC_IMPORT HGLOBAL WINAPI GlobalHandle(LPCVOID pMem);
  DECLSPEC_IMPORT WINBOOL WINAPI GlobalUnlock(HGLOBAL hMem);
  DECLSPEC_IMPORT HGLOBAL WINAPI GlobalFree(HGLOBAL hMem);
  DECLSPEC_IMPORT SIZE_T WINAPI GlobalCompact(DWORD dwMinFree);
  DECLSPEC_IMPORT VOID WINAPI GlobalFix(HGLOBAL hMem);
  DECLSPEC_IMPORT VOID WINAPI GlobalUnfix(HGLOBAL hMem);
  DECLSPEC_IMPORT LPVOID WINAPI GlobalWire(HGLOBAL hMem);
  DECLSPEC_IMPORT WINBOOL WINAPI GlobalUnWire(HGLOBAL hMem);
  DECLSPEC_IMPORT VOID WINAPI GlobalMemoryStatus(LPMEMORYSTATUS lpBuffer);

  typedef struct _MEMORYSTATUSEX {
    DWORD dwLength;
    DWORD dwMemoryLoad;
    DWORDLONG ullTotalPhys;
    DWORDLONG ullAvailPhys;
    DWORDLONG ullTotalPageFile;
    DWORDLONG ullAvailPageFile;
    DWORDLONG ullTotalVirtual;
    DWORDLONG ullAvailVirtual;
    DWORDLONG ullAvailExtendedVirtual;
  } MEMORYSTATUSEX,*LPMEMORYSTATUSEX;

  DECLSPEC_IMPORT WINBOOL WINAPI GlobalMemoryStatusEx(LPMEMORYSTATUSEX lpBuffer);
  DECLSPEC_IMPORT HLOCAL WINAPI LocalAlloc(UINT uFlags,SIZE_T uBytes);
  DECLSPEC_IMPORT HLOCAL WINAPI LocalReAlloc(HLOCAL hMem,SIZE_T uBytes,UINT uFlags);
  DECLSPEC_IMPORT LPVOID WINAPI LocalLock(HLOCAL hMem);
  DECLSPEC_IMPORT HLOCAL WINAPI LocalHandle(LPCVOID pMem);
  DECLSPEC_IMPORT WINBOOL WINAPI LocalUnlock(HLOCAL hMem);
  DECLSPEC_IMPORT SIZE_T WINAPI LocalSize(HLOCAL hMem);
  DECLSPEC_IMPORT UINT WINAPI LocalFlags(HLOCAL hMem);
  DECLSPEC_IMPORT HLOCAL WINAPI LocalFree(HLOCAL hMem);
  DECLSPEC_IMPORT SIZE_T WINAPI LocalShrink(HLOCAL hMem,UINT cbNewSize);
  DECLSPEC_IMPORT SIZE_T WINAPI LocalCompact(UINT uMinFree);
  DECLSPEC_IMPORT WINBOOL WINAPI FlushInstructionCache(HANDLE hProcess,LPCVOID lpBaseAddress,SIZE_T dwSize);
  DECLSPEC_IMPORT LPVOID WINAPI VirtualAlloc(LPVOID lpAddress,SIZE_T dwSize,DWORD flAllocationType,DWORD flProtect);
  DECLSPEC_IMPORT WINBOOL WINAPI VirtualFree(LPVOID lpAddress,SIZE_T dwSize,DWORD dwFreeType);
  DECLSPEC_IMPORT WINBOOL WINAPI VirtualProtect(LPVOID lpAddress,SIZE_T dwSize,DWORD flNewProtect,PDWORD lpflOldProtect);
  DECLSPEC_IMPORT SIZE_T WINAPI VirtualQuery(LPCVOID lpAddress,PMEMORY_BASIC_INFORMATION lpBuffer,SIZE_T dwLength);
  DECLSPEC_IMPORT LPVOID WINAPI VirtualAllocEx(HANDLE hProcess,LPVOID lpAddress,SIZE_T dwSize,DWORD flAllocationType,DWORD flProtect);
  DECLSPEC_IMPORT UINT WINAPI GetWriteWatch(DWORD dwFlags,PVOID lpBaseAddress,SIZE_T dwRegionSize,PVOID *lpAddresses,ULONG_PTR *lpdwCount,PULONG lpdwGranularity);
  DECLSPEC_IMPORT UINT WINAPI ResetWriteWatch(LPVOID lpBaseAddress,SIZE_T dwRegionSize);
  DECLSPEC_IMPORT SIZE_T WINAPI GetLargePageMinimum(VOID);
  DECLSPEC_IMPORT UINT WINAPI EnumSystemFirmwareTables(DWORD FirmwareTableProviderSignature,PVOID pFirmwareTableEnumBuffer,DWORD BufferSize);
  DECLSPEC_IMPORT UINT WINAPI GetSystemFirmwareTable(DWORD FirmwareTableProviderSignature,DWORD FirmwareTableID,PVOID pFirmwareTableBuffer,DWORD BufferSize);
  DECLSPEC_IMPORT WINBOOL WINAPI VirtualFreeEx(HANDLE hProcess,LPVOID lpAddress,SIZE_T dwSize,DWORD dwFreeType);
  DECLSPEC_IMPORT WINBOOL WINAPI VirtualProtectEx(HANDLE hProcess,LPVOID lpAddress,SIZE_T dwSize,DWORD flNewProtect,PDWORD lpflOldProtect);
  DECLSPEC_IMPORT SIZE_T WINAPI VirtualQueryEx(HANDLE hProcess,LPCVOID lpAddress,PMEMORY_BASIC_INFORMATION lpBuffer,SIZE_T dwLength);
  DECLSPEC_IMPORT HANDLE WINAPI HeapCreate(DWORD flOptions,SIZE_T dwInitialSize,SIZE_T dwMaximumSize);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapDestroy(HANDLE hHeap);
  DECLSPEC_IMPORT LPVOID WINAPI HeapAlloc(HANDLE hHeap,DWORD dwFlags,SIZE_T dwBytes);
  DECLSPEC_IMPORT LPVOID WINAPI HeapReAlloc(HANDLE hHeap,DWORD dwFlags,LPVOID lpMem,SIZE_T dwBytes);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapFree(HANDLE hHeap,DWORD dwFlags,LPVOID lpMem);
  DECLSPEC_IMPORT SIZE_T WINAPI HeapSize(HANDLE hHeap,DWORD dwFlags,LPCVOID lpMem);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapValidate(HANDLE hHeap,DWORD dwFlags,LPCVOID lpMem);
  DECLSPEC_IMPORT SIZE_T WINAPI HeapCompact(HANDLE hHeap,DWORD dwFlags);
  DECLSPEC_IMPORT HANDLE WINAPI GetProcessHeap(VOID);
  DECLSPEC_IMPORT DWORD WINAPI GetProcessHeaps(DWORD NumberOfHeaps,PHANDLE ProcessHeaps);

  typedef struct _PROCESS_HEAP_ENTRY {
    PVOID lpData;
    DWORD cbData;
    BYTE cbOverhead;
    BYTE iRegionIndex;
    WORD wFlags;
    __C89_NAMELESS union {
      struct {
 HANDLE hMem;
 DWORD dwReserved[3];
      } Block;
      struct {
 DWORD dwCommittedSize;
 DWORD dwUnCommittedSize;
 LPVOID lpFirstBlock;
 LPVOID lpLastBlock;
      } Region;
    } DUMMYUNIONNAME;
  } PROCESS_HEAP_ENTRY,*LPPROCESS_HEAP_ENTRY,*PPROCESS_HEAP_ENTRY;

#define PROCESS_HEAP_REGION 0x1
#define PROCESS_HEAP_UNCOMMITTED_RANGE 0x2
#define PROCESS_HEAP_ENTRY_BUSY 0x4
#define PROCESS_HEAP_ENTRY_MOVEABLE 0x10
#define PROCESS_HEAP_ENTRY_DDESHARE 0x20

  DECLSPEC_IMPORT WINBOOL WINAPI HeapLock(HANDLE hHeap);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapUnlock(HANDLE hHeap);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapWalk(HANDLE hHeap,LPPROCESS_HEAP_ENTRY lpEntry);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapSetInformation(HANDLE HeapHandle,HEAP_INFORMATION_CLASS HeapInformationClass,PVOID HeapInformation,SIZE_T HeapInformationLength);
  DECLSPEC_IMPORT WINBOOL WINAPI HeapQueryInformation(HANDLE HeapHandle,HEAP_INFORMATION_CLASS HeapInformationClass,PVOID HeapInformation,SIZE_T HeapInformationLength,PSIZE_T ReturnLength);

#define SCS_32BIT_BINARY 0
#define SCS_DOS_BINARY 1
#define SCS_WOW_BINARY 2
#define SCS_PIF_BINARY 3
#define SCS_POSIX_BINARY 4
#define SCS_OS216_BINARY 5
#define SCS_64BIT_BINARY 6

#define GetBinaryType __MINGW_NAME_AW(GetBinaryType)
#define GetShortPathName __MINGW_NAME_AW(GetShortPathName)
#define GetLongPathName __MINGW_NAME_AW(GetLongPathName)
#define SetEnvironmentStrings __MINGW_NAME_AW(SetEnvironmentStrings)
#define FreeEnvironmentStrings __MINGW_NAME_AW(FreeEnvironmentStrings)






#define SCS_THIS_PLATFORM_BINARY SCS_64BIT_BINARY




  DECLSPEC_IMPORT WINBOOL WINAPI GetBinaryTypeA(LPCSTR lpApplicationName,LPDWORD lpBinaryType);
  DECLSPEC_IMPORT WINBOOL WINAPI GetBinaryTypeW(LPCWSTR lpApplicationName,LPDWORD lpBinaryType);
  DECLSPEC_IMPORT DWORD WINAPI GetShortPathNameA(LPCSTR lpszLongPath,LPSTR lpszShortPath,DWORD cchBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetShortPathNameW(LPCWSTR lpszLongPath,LPWSTR lpszShortPath,DWORD cchBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetLongPathNameA(LPCSTR lpszShortPath,LPSTR lpszLongPath,DWORD cchBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetLongPathNameW(LPCWSTR lpszShortPath,LPWSTR lpszLongPath,DWORD cchBuffer);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessAffinityMask(HANDLE hProcess,PDWORD_PTR lpProcessAffinityMask,PDWORD_PTR lpSystemAffinityMask);
  DECLSPEC_IMPORT WINBOOL WINAPI SetProcessAffinityMask(HANDLE hProcess,DWORD_PTR dwProcessAffinityMask);

  /* available in XP SP3, Vista SP1 and higher */
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessDEPPolicy (HANDLE hProcess,LPDWORD lpFlags,PBOOL lpPermanent);
  DECLSPEC_IMPORT WINBOOL WINAPI SetProcessDEPPolicy (DWORD dwFlags);

  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessHandleCount(HANDLE hProcess,PDWORD pdwHandleCount);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessTimes(HANDLE hProcess,LPFILETIME lpCreationTime,LPFILETIME lpExitTime,LPFILETIME lpKernelTime,LPFILETIME lpUserTime);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessIoCounters(HANDLE hProcess,PIO_COUNTERS lpIoCounters);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessWorkingSetSize(HANDLE hProcess,PSIZE_T lpMinimumWorkingSetSize,PSIZE_T lpMaximumWorkingSetSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessWorkingSetSizeEx(HANDLE hProcess,PSIZE_T lpMinimumWorkingSetSize,PSIZE_T lpMaximumWorkingSetSize,PDWORD Flags);
  DECLSPEC_IMPORT WINBOOL WINAPI SetProcessWorkingSetSize(HANDLE hProcess,SIZE_T dwMinimumWorkingSetSize,SIZE_T dwMaximumWorkingSetSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetProcessWorkingSetSizeEx(HANDLE hProcess,SIZE_T dwMinimumWorkingSetSize,SIZE_T dwMaximumWorkingSetSize,DWORD Flags);
  DECLSPEC_IMPORT HANDLE WINAPI OpenProcess(DWORD dwDesiredAccess,WINBOOL bInheritHandle,DWORD dwProcessId);
  DECLSPEC_IMPORT HANDLE WINAPI GetCurrentProcess(VOID);
  DECLSPEC_IMPORT DWORD WINAPI GetCurrentProcessId(VOID);
  DECLSPEC_IMPORT DECLSPEC_NORETURN VOID WINAPI ExitProcess(UINT uExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI TerminateProcess(HANDLE hProcess,UINT uExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI GetExitCodeProcess(HANDLE hProcess,LPDWORD lpExitCode);
  DECLSPEC_IMPORT VOID WINAPI FatalExit(int ExitCode);
       
#undef GetEnvironmentStrings
#define GetEnvironmentStringsA GetEnvironmentStrings
  DECLSPEC_IMPORT LPCH WINAPI GetEnvironmentStrings(VOID);
       
  DECLSPEC_IMPORT LPWCH WINAPI GetEnvironmentStringsW(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI SetEnvironmentStringsA(LPCH NewEnvironment);
  DECLSPEC_IMPORT WINBOOL WINAPI SetEnvironmentStringsW(LPWCH NewEnvironment);
  DECLSPEC_IMPORT WINBOOL WINAPI FreeEnvironmentStringsA(LPCH);
  DECLSPEC_IMPORT WINBOOL WINAPI FreeEnvironmentStringsW(LPWCH);
  DECLSPEC_IMPORT VOID WINAPI RaiseException(DWORD dwExceptionCode,DWORD dwExceptionFlags,DWORD nNumberOfArguments,CONST ULONG_PTR *lpArguments);
  DECLSPEC_IMPORT LONG WINAPI UnhandledExceptionFilter(struct _EXCEPTION_POINTERS *ExceptionInfo);

  typedef LONG (WINAPI *PTOP_LEVEL_EXCEPTION_FILTER)(struct _EXCEPTION_POINTERS *ExceptionInfo);
  typedef PTOP_LEVEL_EXCEPTION_FILTER LPTOP_LEVEL_EXCEPTION_FILTER;

  DECLSPEC_IMPORT LPTOP_LEVEL_EXCEPTION_FILTER WINAPI SetUnhandledExceptionFilter(LPTOP_LEVEL_EXCEPTION_FILTER lpTopLevelExceptionFilter);

#define FIBER_FLAG_FLOAT_SWITCH 0x1

  DECLSPEC_IMPORT LPVOID WINAPI CreateFiber(SIZE_T dwStackSize,LPFIBER_START_ROUTINE lpStartAddress,LPVOID lpParameter);
  DECLSPEC_IMPORT LPVOID WINAPI CreateFiberEx(SIZE_T dwStackCommitSize,SIZE_T dwStackReserveSize,DWORD dwFlags,LPFIBER_START_ROUTINE lpStartAddress,LPVOID lpParameter);
  DECLSPEC_IMPORT VOID WINAPI DeleteFiber(LPVOID lpFiber);
  DECLSPEC_IMPORT LPVOID WINAPI ConvertThreadToFiber(LPVOID lpParameter);
  DECLSPEC_IMPORT LPVOID WINAPI ConvertThreadToFiberEx(LPVOID lpParameter,DWORD dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI ConvertFiberToThread(VOID);
  DECLSPEC_IMPORT VOID WINAPI SwitchToFiber(LPVOID lpFiber);
  DECLSPEC_IMPORT WINBOOL WINAPI SwitchToThread(VOID);
  DECLSPEC_IMPORT HANDLE WINAPI CreateThread(LPSECURITY_ATTRIBUTES lpThreadAttributes,SIZE_T dwStackSize,LPTHREAD_START_ROUTINE lpStartAddress,LPVOID lpParameter,DWORD dwCreationFlags,LPDWORD lpThreadId);
  DECLSPEC_IMPORT HANDLE WINAPI CreateRemoteThread(HANDLE hProcess,LPSECURITY_ATTRIBUTES lpThreadAttributes,SIZE_T dwStackSize,LPTHREAD_START_ROUTINE lpStartAddress,LPVOID lpParameter,DWORD dwCreationFlags,LPDWORD lpThreadId);
  DECLSPEC_IMPORT HANDLE WINAPI GetCurrentThread(VOID);
  DECLSPEC_IMPORT DWORD WINAPI GetCurrentThreadId(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI SetThreadStackGuarantee (PULONG StackSizeInBytes);
  DECLSPEC_IMPORT DWORD WINAPI GetProcessIdOfThread(HANDLE Thread);
  DECLSPEC_IMPORT DWORD WINAPI GetThreadId(HANDLE Thread);
  DECLSPEC_IMPORT DWORD WINAPI GetProcessId(HANDLE Process);
  DECLSPEC_IMPORT DWORD WINAPI GetCurrentProcessorNumber(VOID);
  DECLSPEC_IMPORT DWORD_PTR WINAPI SetThreadAffinityMask(HANDLE hThread,DWORD_PTR dwThreadAffinityMask);
  DECLSPEC_IMPORT DWORD WINAPI SetThreadIdealProcessor(HANDLE hThread,DWORD dwIdealProcessor);
  DECLSPEC_IMPORT WINBOOL WINAPI SetProcessPriorityBoost(HANDLE hProcess,WINBOOL bDisablePriorityBoost);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessPriorityBoost(HANDLE hProcess,PBOOL pDisablePriorityBoost);
  DECLSPEC_IMPORT WINBOOL WINAPI RequestWakeupLatency(LATENCY_TIME latency);
  DECLSPEC_IMPORT WINBOOL WINAPI IsSystemResumeAutomatic(VOID);
  DECLSPEC_IMPORT HANDLE WINAPI OpenThread(DWORD dwDesiredAccess,WINBOOL bInheritHandle,DWORD dwThreadId);
  DECLSPEC_IMPORT WINBOOL WINAPI SetThreadPriority(HANDLE hThread,int nPriority);
  DECLSPEC_IMPORT WINBOOL WINAPI SetThreadPriorityBoost(HANDLE hThread,WINBOOL bDisablePriorityBoost);
  DECLSPEC_IMPORT WINBOOL WINAPI GetThreadPriorityBoost(HANDLE hThread,PBOOL pDisablePriorityBoost);
  DECLSPEC_IMPORT int WINAPI GetThreadPriority(HANDLE hThread);
  DECLSPEC_IMPORT WINBOOL WINAPI GetThreadTimes(HANDLE hThread,LPFILETIME lpCreationTime,LPFILETIME lpExitTime,LPFILETIME lpKernelTime,LPFILETIME lpUserTime);
  DECLSPEC_IMPORT WINBOOL WINAPI GetThreadIOPendingFlag(HANDLE hThread,PBOOL lpIOIsPending);
  DECLSPEC_IMPORT DECLSPEC_NORETURN VOID WINAPI ExitThread(DWORD dwExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI TerminateThread(HANDLE hThread,DWORD dwExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI GetExitCodeThread(HANDLE hThread,LPDWORD lpExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI GetThreadSelectorEntry(HANDLE hThread,DWORD dwSelector,LPLDT_ENTRY lpSelectorEntry);
  DECLSPEC_IMPORT EXECUTION_STATE WINAPI SetThreadExecutionState(EXECUTION_STATE esFlags);
  DECLSPEC_IMPORT DWORD WINAPI GetLastError(VOID);
  DECLSPEC_IMPORT VOID WINAPI SetLastError(DWORD dwErrCode);
# 1367 "c_include/windows/original/winbase.h"
#define HasOverlappedIoCompleted(lpOverlapped) (((DWORD)(lpOverlapped)->Internal)!=STATUS_PENDING)

  DECLSPEC_IMPORT WINBOOL WINAPI GetOverlappedResult(HANDLE hFile,LPOVERLAPPED lpOverlapped,LPDWORD lpNumberOfBytesTransferred,WINBOOL bWait);
  DECLSPEC_IMPORT HANDLE WINAPI CreateIoCompletionPort(HANDLE FileHandle,HANDLE ExistingCompletionPort,ULONG_PTR CompletionKey,DWORD NumberOfConcurrentThreads);
  DECLSPEC_IMPORT WINBOOL WINAPI GetQueuedCompletionStatus(HANDLE CompletionPort,LPDWORD lpNumberOfBytesTransferred,PULONG_PTR lpCompletionKey,LPOVERLAPPED *lpOverlapped,DWORD dwMilliseconds);
  DECLSPEC_IMPORT WINBOOL WINAPI PostQueuedCompletionStatus(HANDLE CompletionPort,DWORD dwNumberOfBytesTransferred,ULONG_PTR dwCompletionKey,LPOVERLAPPED lpOverlapped);

#define SEM_FAILCRITICALERRORS 0x1
#define SEM_NOGPFAULTERRORBOX 0x2
#define SEM_NOALIGNMENTFAULTEXCEPT 0x4
#define SEM_NOOPENFILEERRORBOX 0x8000

  DECLSPEC_IMPORT UINT WINAPI SetErrorMode(UINT uMode);
  DECLSPEC_IMPORT WINBOOL WINAPI ReadProcessMemory(HANDLE hProcess,LPCVOID lpBaseAddress,LPVOID lpBuffer,SIZE_T nSize,SIZE_T *lpNumberOfBytesRead);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteProcessMemory(HANDLE hProcess,LPVOID lpBaseAddress,LPCVOID lpBuffer,SIZE_T nSize,SIZE_T *lpNumberOfBytesWritten);
  DECLSPEC_IMPORT WINBOOL WINAPI GetThreadContext(HANDLE hThread,LPCONTEXT lpContext);
  DECLSPEC_IMPORT WINBOOL WINAPI SetThreadContext(HANDLE hThread,CONST CONTEXT *lpContext);
  DECLSPEC_IMPORT DWORD WINAPI SuspendThread(HANDLE hThread);
  DECLSPEC_IMPORT DWORD WINAPI ResumeThread(HANDLE hThread);

  typedef VOID (WINAPI *PAPCFUNC)(ULONG_PTR dwParam);

  DECLSPEC_IMPORT DWORD WINAPI QueueUserAPC(PAPCFUNC pfnAPC,HANDLE hThread,ULONG_PTR dwData);
  DECLSPEC_IMPORT WINBOOL WINAPI IsDebuggerPresent(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI CheckRemoteDebuggerPresent(HANDLE hProcess,PBOOL pbDebuggerPresent);
  DECLSPEC_IMPORT VOID WINAPI DebugBreak(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI WaitForDebugEvent(LPDEBUG_EVENT lpDebugEvent,DWORD dwMilliseconds);
  DECLSPEC_IMPORT WINBOOL WINAPI ContinueDebugEvent(DWORD dwProcessId,DWORD dwThreadId,DWORD dwContinueStatus);
  DECLSPEC_IMPORT WINBOOL WINAPI DebugActiveProcess(DWORD dwProcessId);
  DECLSPEC_IMPORT WINBOOL WINAPI DebugActiveProcessStop(DWORD dwProcessId);
  DECLSPEC_IMPORT WINBOOL WINAPI DebugSetProcessKillOnExit(WINBOOL KillOnExit);
  DECLSPEC_IMPORT WINBOOL WINAPI DebugBreakProcess(HANDLE Process);
  DECLSPEC_IMPORT VOID WINAPI InitializeCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
  DECLSPEC_IMPORT VOID WINAPI EnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
  DECLSPEC_IMPORT VOID WINAPI LeaveCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
  DECLSPEC_IMPORT WINBOOL WINAPI InitializeCriticalSectionAndSpinCount(LPCRITICAL_SECTION lpCriticalSection,DWORD dwSpinCount);
  DECLSPEC_IMPORT DWORD WINAPI SetCriticalSectionSpinCount(LPCRITICAL_SECTION lpCriticalSection,DWORD dwSpinCount);
  DECLSPEC_IMPORT WINBOOL WINAPI TryEnterCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
  DECLSPEC_IMPORT VOID WINAPI DeleteCriticalSection(LPCRITICAL_SECTION lpCriticalSection);
  DECLSPEC_IMPORT WINBOOL WINAPI SetEvent(HANDLE hEvent);
  DECLSPEC_IMPORT WINBOOL WINAPI ResetEvent(HANDLE hEvent);
  DECLSPEC_IMPORT WINBOOL WINAPI PulseEvent(HANDLE hEvent);
  DECLSPEC_IMPORT WINBOOL WINAPI ReleaseSemaphore(HANDLE hSemaphore,LONG lReleaseCount,LPLONG lpPreviousCount);
  DECLSPEC_IMPORT WINBOOL WINAPI ReleaseMutex(HANDLE hMutex);
  DECLSPEC_IMPORT DWORD WINAPI WaitForSingleObject(HANDLE hHandle,DWORD dwMilliseconds);
  DECLSPEC_IMPORT DWORD WINAPI WaitForMultipleObjects(DWORD nCount,CONST HANDLE *lpHandles,WINBOOL bWaitAll,DWORD dwMilliseconds);
  DECLSPEC_IMPORT VOID WINAPI Sleep(DWORD dwMilliseconds);
  DECLSPEC_IMPORT HGLOBAL WINAPI LoadResource(HMODULE hModule,HRSRC hResInfo);
  DECLSPEC_IMPORT DWORD WINAPI SizeofResource(HMODULE hModule,HRSRC hResInfo);
  DECLSPEC_IMPORT ATOM WINAPI GlobalDeleteAtom(ATOM nAtom);
  DECLSPEC_IMPORT WINBOOL WINAPI InitAtomTable(DWORD nSize);
  DECLSPEC_IMPORT ATOM WINAPI DeleteAtom(ATOM nAtom);
  DECLSPEC_IMPORT UINT WINAPI SetHandleCount(UINT uNumber);
  DECLSPEC_IMPORT DWORD WINAPI GetLogicalDrives(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI LockFile(HANDLE hFile,DWORD dwFileOffsetLow,DWORD dwFileOffsetHigh,DWORD nNumberOfBytesToLockLow,DWORD nNumberOfBytesToLockHigh);
  DECLSPEC_IMPORT WINBOOL WINAPI UnlockFile(HANDLE hFile,DWORD dwFileOffsetLow,DWORD dwFileOffsetHigh,DWORD nNumberOfBytesToUnlockLow,DWORD nNumberOfBytesToUnlockHigh);
  DECLSPEC_IMPORT WINBOOL WINAPI LockFileEx(HANDLE hFile,DWORD dwFlags,DWORD dwReserved,DWORD nNumberOfBytesToLockLow,DWORD nNumberOfBytesToLockHigh,LPOVERLAPPED lpOverlapped);

#define LOCKFILE_FAIL_IMMEDIATELY 0x1
#define LOCKFILE_EXCLUSIVE_LOCK 0x2

  DECLSPEC_IMPORT WINBOOL WINAPI UnlockFileEx(HANDLE hFile,DWORD dwReserved,DWORD nNumberOfBytesToUnlockLow,DWORD nNumberOfBytesToUnlockHigh,LPOVERLAPPED lpOverlapped);

  typedef struct _BY_HANDLE_FILE_INFORMATION {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD dwVolumeSerialNumber;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD nNumberOfLinks;
    DWORD nFileIndexHigh;
    DWORD nFileIndexLow;
  } BY_HANDLE_FILE_INFORMATION,*PBY_HANDLE_FILE_INFORMATION,*LPBY_HANDLE_FILE_INFORMATION;

#define SetFileShortName __MINGW_NAME_AW(SetFileShortName)

  DECLSPEC_IMPORT WINBOOL WINAPI GetFileInformationByHandle(HANDLE hFile,LPBY_HANDLE_FILE_INFORMATION lpFileInformation);
  DECLSPEC_IMPORT DWORD WINAPI GetFileType(HANDLE hFile);
  DECLSPEC_IMPORT DWORD WINAPI GetFileSize(HANDLE hFile,LPDWORD lpFileSizeHigh);
  DECLSPEC_IMPORT WINBOOL WINAPI GetFileSizeEx(HANDLE hFile,PLARGE_INTEGER lpFileSize);
  DECLSPEC_IMPORT HANDLE WINAPI GetStdHandle(DWORD nStdHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI SetStdHandle(DWORD nStdHandle,HANDLE hHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteFile(HANDLE hFile,LPCVOID lpBuffer,DWORD nNumberOfBytesToWrite,LPDWORD lpNumberOfBytesWritten,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT WINBOOL WINAPI ReadFile(HANDLE hFile,LPVOID lpBuffer,DWORD nNumberOfBytesToRead,LPDWORD lpNumberOfBytesRead,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT WINBOOL WINAPI FlushFileBuffers(HANDLE hFile);
  DECLSPEC_IMPORT WINBOOL WINAPI DeviceIoControl(HANDLE hDevice,DWORD dwIoControlCode,LPVOID lpInBuffer,DWORD nInBufferSize,LPVOID lpOutBuffer,DWORD nOutBufferSize,LPDWORD lpBytesReturned,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT WINBOOL WINAPI RequestDeviceWakeup(HANDLE hDevice);
  DECLSPEC_IMPORT WINBOOL WINAPI CancelDeviceWakeupRequest(HANDLE hDevice);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDevicePowerState(HANDLE hDevice,WINBOOL *pfOn);
  DECLSPEC_IMPORT WINBOOL WINAPI SetMessageWaitingIndicator(HANDLE hMsgIndicator,ULONG ulMsgCount);
  DECLSPEC_IMPORT WINBOOL WINAPI SetEndOfFile(HANDLE hFile);
  DECLSPEC_IMPORT DWORD WINAPI SetFilePointer(HANDLE hFile,LONG lDistanceToMove,PLONG lpDistanceToMoveHigh,DWORD dwMoveMethod);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFilePointerEx(HANDLE hFile,LARGE_INTEGER liDistanceToMove,PLARGE_INTEGER lpNewFilePointer,DWORD dwMoveMethod);
  DECLSPEC_IMPORT WINBOOL WINAPI FindClose(HANDLE hFindFile);
  DECLSPEC_IMPORT WINBOOL WINAPI GetFileTime(HANDLE hFile,LPFILETIME lpCreationTime,LPFILETIME lpLastAccessTime,LPFILETIME lpLastWriteTime);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileTime(HANDLE hFile,CONST FILETIME *lpCreationTime,CONST FILETIME *lpLastAccessTime,CONST FILETIME *lpLastWriteTime);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileValidData(HANDLE hFile,LONGLONG ValidDataLength);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileShortNameA(HANDLE hFile,LPCSTR lpShortName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileShortNameW(HANDLE hFile,LPCWSTR lpShortName);
  DECLSPEC_IMPORT WINBOOL WINAPI CloseHandle(HANDLE hObject);
  DECLSPEC_IMPORT WINBOOL WINAPI DuplicateHandle(HANDLE hSourceProcessHandle,HANDLE hSourceHandle,HANDLE hTargetProcessHandle,LPHANDLE lpTargetHandle,DWORD dwDesiredAccess,WINBOOL bInheritHandle,DWORD dwOptions);
  DECLSPEC_IMPORT WINBOOL WINAPI GetHandleInformation(HANDLE hObject,LPDWORD lpdwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI SetHandleInformation(HANDLE hObject,DWORD dwMask,DWORD dwFlags);

#define HANDLE_FLAG_INHERIT 0x1
#define HANDLE_FLAG_PROTECT_FROM_CLOSE 0x2

#define HINSTANCE_ERROR 32

  DECLSPEC_IMPORT DWORD WINAPI LoadModule(LPCSTR lpModuleName,LPVOID lpParameterBlock);
  DECLSPEC_IMPORT UINT WINAPI WinExec(LPCSTR lpCmdLine,UINT uCmdShow);
  DECLSPEC_IMPORT WINBOOL WINAPI ClearCommBreak(HANDLE hFile);
  DECLSPEC_IMPORT WINBOOL WINAPI ClearCommError(HANDLE hFile,LPDWORD lpErrors,LPCOMSTAT lpStat);
  DECLSPEC_IMPORT WINBOOL WINAPI SetupComm(HANDLE hFile,DWORD dwInQueue,DWORD dwOutQueue);
  DECLSPEC_IMPORT WINBOOL WINAPI EscapeCommFunction(HANDLE hFile,DWORD dwFunc);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCommConfig(HANDLE hCommDev,LPCOMMCONFIG lpCC,LPDWORD lpdwSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCommMask(HANDLE hFile,LPDWORD lpEvtMask);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCommProperties(HANDLE hFile,LPCOMMPROP lpCommProp);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCommModemStatus(HANDLE hFile,LPDWORD lpModemStat);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCommState(HANDLE hFile,LPDCB lpDCB);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCommTimeouts(HANDLE hFile,LPCOMMTIMEOUTS lpCommTimeouts);
  DECLSPEC_IMPORT WINBOOL WINAPI PurgeComm(HANDLE hFile,DWORD dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI SetCommBreak(HANDLE hFile);
  DECLSPEC_IMPORT WINBOOL WINAPI SetCommConfig(HANDLE hCommDev,LPCOMMCONFIG lpCC,DWORD dwSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetCommMask(HANDLE hFile,DWORD dwEvtMask);
  DECLSPEC_IMPORT WINBOOL WINAPI SetCommState(HANDLE hFile,LPDCB lpDCB);
  DECLSPEC_IMPORT WINBOOL WINAPI SetCommTimeouts(HANDLE hFile,LPCOMMTIMEOUTS lpCommTimeouts);
  DECLSPEC_IMPORT WINBOOL WINAPI TransmitCommChar(HANDLE hFile,char cChar);
  DECLSPEC_IMPORT WINBOOL WINAPI WaitCommEvent(HANDLE hFile,LPDWORD lpEvtMask,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT DWORD WINAPI SetTapePosition(HANDLE hDevice,DWORD dwPositionMethod,DWORD dwPartition,DWORD dwOffsetLow,DWORD dwOffsetHigh,WINBOOL bImmediate);
  DECLSPEC_IMPORT DWORD WINAPI GetTapePosition(HANDLE hDevice,DWORD dwPositionType,LPDWORD lpdwPartition,LPDWORD lpdwOffsetLow,LPDWORD lpdwOffsetHigh);
  DECLSPEC_IMPORT DWORD WINAPI PrepareTape(HANDLE hDevice,DWORD dwOperation,WINBOOL bImmediate);
  DECLSPEC_IMPORT DWORD WINAPI EraseTape(HANDLE hDevice,DWORD dwEraseType,WINBOOL bImmediate);
  DECLSPEC_IMPORT DWORD WINAPI CreateTapePartition(HANDLE hDevice,DWORD dwPartitionMethod,DWORD dwCount,DWORD dwSize);
  DECLSPEC_IMPORT DWORD WINAPI WriteTapemark(HANDLE hDevice,DWORD dwTapemarkType,DWORD dwTapemarkCount,WINBOOL bImmediate);
  DECLSPEC_IMPORT DWORD WINAPI GetTapeStatus(HANDLE hDevice);
  DECLSPEC_IMPORT DWORD WINAPI GetTapeParameters(HANDLE hDevice,DWORD dwOperation,LPDWORD lpdwSize,LPVOID lpTapeInformation);

#define GET_TAPE_MEDIA_INFORMATION 0
#define GET_TAPE_DRIVE_INFORMATION 1

  DECLSPEC_IMPORT DWORD WINAPI SetTapeParameters(HANDLE hDevice,DWORD dwOperation,LPVOID lpTapeInformation);

#define SET_TAPE_MEDIA_INFORMATION 0
#define SET_TAPE_DRIVE_INFORMATION 1

  DECLSPEC_IMPORT WINBOOL WINAPI Beep(DWORD dwFreq,DWORD dwDuration);
  DECLSPEC_IMPORT int WINAPI MulDiv(int nNumber,int nNumerator,int nDenominator);
  DECLSPEC_IMPORT VOID WINAPI GetSystemTime(LPSYSTEMTIME lpSystemTime);
  DECLSPEC_IMPORT VOID WINAPI GetSystemTimeAsFileTime(LPFILETIME lpSystemTimeAsFileTime);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSystemTime(CONST SYSTEMTIME *lpSystemTime);
  DECLSPEC_IMPORT VOID WINAPI GetLocalTime(LPSYSTEMTIME lpSystemTime);
  DECLSPEC_IMPORT WINBOOL WINAPI SetLocalTime(CONST SYSTEMTIME *lpSystemTime);
  DECLSPEC_IMPORT VOID WINAPI GetSystemInfo(LPSYSTEM_INFO lpSystemInfo);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSystemFileCacheSize(SIZE_T MinimumFileCacheSize,SIZE_T MaximumFileCacheSize,DWORD Flags);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSystemFileCacheSize(PSIZE_T lpMinimumFileCacheSize,PSIZE_T lpMaximumFileCacheSize,PDWORD lpFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSystemRegistryQuota(PDWORD pdwQuotaAllowed,PDWORD pdwQuotaUsed);
  WINBOOL WINAPI GetSystemTimes(LPFILETIME lpIdleTime,LPFILETIME lpKernelTime,LPFILETIME lpUserTime);
  DECLSPEC_IMPORT VOID WINAPI GetNativeSystemInfo(LPSYSTEM_INFO lpSystemInfo);
  DECLSPEC_IMPORT WINBOOL WINAPI IsProcessorFeaturePresent(DWORD ProcessorFeature);

  typedef struct _TIME_ZONE_INFORMATION {
    LONG Bias;
    WCHAR StandardName[32];
    SYSTEMTIME StandardDate;
    LONG StandardBias;
    WCHAR DaylightName[32];
    SYSTEMTIME DaylightDate;
    LONG DaylightBias;
  } TIME_ZONE_INFORMATION,*PTIME_ZONE_INFORMATION,*LPTIME_ZONE_INFORMATION;

#define FormatMessage __MINGW_NAME_AW(FormatMessage)

  DECLSPEC_IMPORT WINBOOL WINAPI SystemTimeToTzSpecificLocalTime(LPTIME_ZONE_INFORMATION lpTimeZoneInformation,LPSYSTEMTIME lpUniversalTime,LPSYSTEMTIME lpLocalTime);
  DECLSPEC_IMPORT WINBOOL WINAPI TzSpecificLocalTimeToSystemTime(LPTIME_ZONE_INFORMATION lpTimeZoneInformation,LPSYSTEMTIME lpLocalTime,LPSYSTEMTIME lpUniversalTime);
  DECLSPEC_IMPORT DWORD WINAPI GetTimeZoneInformation(LPTIME_ZONE_INFORMATION lpTimeZoneInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI SetTimeZoneInformation(CONST TIME_ZONE_INFORMATION *lpTimeZoneInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI SystemTimeToFileTime(CONST SYSTEMTIME *lpSystemTime,LPFILETIME lpFileTime);
  DECLSPEC_IMPORT WINBOOL WINAPI FileTimeToLocalFileTime(CONST FILETIME *lpFileTime,LPFILETIME lpLocalFileTime);
  DECLSPEC_IMPORT WINBOOL WINAPI LocalFileTimeToFileTime(CONST FILETIME *lpLocalFileTime,LPFILETIME lpFileTime);
  DECLSPEC_IMPORT WINBOOL WINAPI FileTimeToSystemTime(CONST FILETIME *lpFileTime,LPSYSTEMTIME lpSystemTime);
  DECLSPEC_IMPORT LONG WINAPI CompareFileTime(CONST FILETIME *lpFileTime1,CONST FILETIME *lpFileTime2);
  DECLSPEC_IMPORT WINBOOL WINAPI FileTimeToDosDateTime(CONST FILETIME *lpFileTime,LPWORD lpFatDate,LPWORD lpFatTime);
  DECLSPEC_IMPORT WINBOOL WINAPI DosDateTimeToFileTime(WORD wFatDate,WORD wFatTime,LPFILETIME lpFileTime);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSystemTimeAdjustment(DWORD dwTimeAdjustment,WINBOOL bTimeAdjustmentDisabled);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSystemTimeAdjustment(PDWORD lpTimeAdjustment,PDWORD lpTimeIncrement,PBOOL lpTimeAdjustmentDisabled);
  DECLSPEC_IMPORT DWORD WINAPI FormatMessageA(DWORD dwFlags,LPCVOID lpSource,DWORD dwMessageId,DWORD dwLanguageId,LPSTR lpBuffer,DWORD nSize,va_list *Arguments);
  DECLSPEC_IMPORT DWORD WINAPI FormatMessageW(DWORD dwFlags,LPCVOID lpSource,DWORD dwMessageId,DWORD dwLanguageId,LPWSTR lpBuffer,DWORD nSize,va_list *Arguments);

  DECLSPEC_IMPORT DWORD WINAPI GetTickCount(VOID);

#define GetCurrentTime() GetTickCount()






#define FORMAT_MESSAGE_ALLOCATE_BUFFER 0x100
#define FORMAT_MESSAGE_IGNORE_INSERTS 0x200
#define FORMAT_MESSAGE_FROM_STRING 0x400
#define FORMAT_MESSAGE_FROM_HMODULE 0x800
#define FORMAT_MESSAGE_FROM_SYSTEM 0x1000
#define FORMAT_MESSAGE_ARGUMENT_ARRAY 0x2000
#define FORMAT_MESSAGE_MAX_WIDTH_MASK 0xff

#define CreateMailslot __MINGW_NAME_AW(CreateMailslot)
#define EncryptFile __MINGW_NAME_AW(EncryptFile)
#define DecryptFile __MINGW_NAME_AW(DecryptFile)
#define FileEncryptionStatus __MINGW_NAME_AW(FileEncryptionStatus)

  DECLSPEC_IMPORT WINBOOL WINAPI CreatePipe(PHANDLE hReadPipe,PHANDLE hWritePipe,LPSECURITY_ATTRIBUTES lpPipeAttributes,DWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI ConnectNamedPipe(HANDLE hNamedPipe,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT WINBOOL WINAPI DisconnectNamedPipe(HANDLE hNamedPipe);
  DECLSPEC_IMPORT WINBOOL WINAPI SetNamedPipeHandleState(HANDLE hNamedPipe,LPDWORD lpMode,LPDWORD lpMaxCollectionCount,LPDWORD lpCollectDataTimeout);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeInfo(HANDLE hNamedPipe,LPDWORD lpFlags,LPDWORD lpOutBufferSize,LPDWORD lpInBufferSize,LPDWORD lpMaxInstances);
  DECLSPEC_IMPORT WINBOOL WINAPI PeekNamedPipe(HANDLE hNamedPipe,LPVOID lpBuffer,DWORD nBufferSize,LPDWORD lpBytesRead,LPDWORD lpTotalBytesAvail,LPDWORD lpBytesLeftThisMessage);
  DECLSPEC_IMPORT WINBOOL WINAPI TransactNamedPipe(HANDLE hNamedPipe,LPVOID lpInBuffer,DWORD nInBufferSize,LPVOID lpOutBuffer,DWORD nOutBufferSize,LPDWORD lpBytesRead,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT HANDLE WINAPI CreateMailslotA(LPCSTR lpName,DWORD nMaxMessageSize,DWORD lReadTimeout,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT HANDLE WINAPI CreateMailslotW(LPCWSTR lpName,DWORD nMaxMessageSize,DWORD lReadTimeout,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI GetMailslotInfo(HANDLE hMailslot,LPDWORD lpMaxMessageSize,LPDWORD lpNextSize,LPDWORD lpMessageCount,LPDWORD lpReadTimeout);
  DECLSPEC_IMPORT WINBOOL WINAPI SetMailslotInfo(HANDLE hMailslot,DWORD lReadTimeout);
  DECLSPEC_IMPORT LPVOID WINAPI MapViewOfFile(HANDLE hFileMappingObject,DWORD dwDesiredAccess,DWORD dwFileOffsetHigh,DWORD dwFileOffsetLow,SIZE_T dwNumberOfBytesToMap);
  DECLSPEC_IMPORT WINBOOL WINAPI FlushViewOfFile(LPCVOID lpBaseAddress,SIZE_T dwNumberOfBytesToFlush);
  DECLSPEC_IMPORT WINBOOL WINAPI UnmapViewOfFile(LPCVOID lpBaseAddress);
  DECLSPEC_IMPORT WINBOOL WINAPI EncryptFileA(LPCSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI EncryptFileW(LPCWSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI DecryptFileA(LPCSTR lpFileName,DWORD dwReserved);
  DECLSPEC_IMPORT WINBOOL WINAPI DecryptFileW(LPCWSTR lpFileName,DWORD dwReserved);

#define FILE_ENCRYPTABLE 0
#define FILE_IS_ENCRYPTED 1
#define FILE_SYSTEM_ATTR 2
#define FILE_ROOT_DIR 3
#define FILE_SYSTEM_DIR 4
#define FILE_UNKNOWN 5
#define FILE_SYSTEM_NOT_SUPPORT 6
#define FILE_USER_DISALLOWED 7
#define FILE_READ_ONLY 8
#define FILE_DIR_DISALLOWED 9

  DECLSPEC_IMPORT WINBOOL WINAPI FileEncryptionStatusA(LPCSTR lpFileName,LPDWORD lpStatus);
  DECLSPEC_IMPORT WINBOOL WINAPI FileEncryptionStatusW(LPCWSTR lpFileName,LPDWORD lpStatus);

#define EFS_USE_RECOVERY_KEYS (0x1)

  typedef DWORD (WINAPI *PFE_EXPORT_FUNC)(PBYTE pbData,PVOID pvCallbackContext,ULONG ulLength);
  typedef DWORD (WINAPI *PFE_IMPORT_FUNC)(PBYTE pbData,PVOID pvCallbackContext,PULONG ulLength);

#define CREATE_FOR_IMPORT (1)
#define CREATE_FOR_DIR (2)
#define OVERWRITE_HIDDEN (4)

#define OpenEncryptedFileRaw __MINGW_NAME_AW(OpenEncryptedFileRaw)
#define lstrcmp __MINGW_NAME_AW(lstrcmp)
#define lstrcmpi __MINGW_NAME_AW(lstrcmpi)
#define lstrcpyn __MINGW_NAME_AW(lstrcpyn)
#define lstrcpy __MINGW_NAME_AW(lstrcpy)
#define lstrcat __MINGW_NAME_AW(lstrcat)
#define lstrlen __MINGW_NAME_AW(lstrlen)

  DECLSPEC_IMPORT DWORD WINAPI OpenEncryptedFileRawA(LPCSTR lpFileName,ULONG ulFlags,PVOID *pvContext);
  DECLSPEC_IMPORT DWORD WINAPI OpenEncryptedFileRawW(LPCWSTR lpFileName,ULONG ulFlags,PVOID *pvContext);
  DECLSPEC_IMPORT DWORD WINAPI ReadEncryptedFileRaw(PFE_EXPORT_FUNC pfExportCallback,PVOID pvCallbackContext,PVOID pvContext);
  DECLSPEC_IMPORT DWORD WINAPI WriteEncryptedFileRaw(PFE_IMPORT_FUNC pfImportCallback,PVOID pvCallbackContext,PVOID pvContext);
  DECLSPEC_IMPORT VOID WINAPI CloseEncryptedFileRaw(PVOID pvContext);
  DECLSPEC_IMPORT int WINAPI lstrcmpA(LPCSTR lpString1,LPCSTR lpString2);
  DECLSPEC_IMPORT int WINAPI lstrcmpW(LPCWSTR lpString1,LPCWSTR lpString2);
  DECLSPEC_IMPORT int WINAPI lstrcmpiA(LPCSTR lpString1,LPCSTR lpString2);
  DECLSPEC_IMPORT int WINAPI lstrcmpiW(LPCWSTR lpString1,LPCWSTR lpString2);
  DECLSPEC_IMPORT LPSTR WINAPI lstrcpynA(LPSTR lpString1,LPCSTR lpString2,int iMaxLength);
  DECLSPEC_IMPORT LPWSTR WINAPI lstrcpynW(LPWSTR lpString1,LPCWSTR lpString2,int iMaxLength);
  DECLSPEC_IMPORT LPSTR WINAPI lstrcpyA(LPSTR lpString1,LPCSTR lpString2);
  DECLSPEC_IMPORT LPWSTR WINAPI lstrcpyW(LPWSTR lpString1,LPCWSTR lpString2);
  DECLSPEC_IMPORT LPSTR WINAPI lstrcatA(LPSTR lpString1,LPCSTR lpString2);
  DECLSPEC_IMPORT LPWSTR WINAPI lstrcatW(LPWSTR lpString1,LPCWSTR lpString2);
  DECLSPEC_IMPORT int WINAPI lstrlenA(LPCSTR lpString);
  DECLSPEC_IMPORT int WINAPI lstrlenW(LPCWSTR lpString);
  DECLSPEC_IMPORT HFILE WINAPI OpenFile(LPCSTR lpFileName,LPOFSTRUCT lpReOpenBuff,UINT uStyle);
  DECLSPEC_IMPORT HFILE WINAPI _lopen(LPCSTR lpPathName,int iReadWrite);
  DECLSPEC_IMPORT HFILE WINAPI _lcreat(LPCSTR lpPathName,int iAttribute);
  DECLSPEC_IMPORT UINT WINAPI _lread(HFILE hFile,LPVOID lpBuffer,UINT uBytes);
  DECLSPEC_IMPORT UINT WINAPI _lwrite(HFILE hFile,LPCCH lpBuffer,UINT uBytes);
  DECLSPEC_IMPORT __LONG32 WINAPI _hread(HFILE hFile,LPVOID lpBuffer,__LONG32 lBytes);
  DECLSPEC_IMPORT __LONG32 WINAPI _hwrite(HFILE hFile,LPCCH lpBuffer,__LONG32 lBytes);
  DECLSPEC_IMPORT HFILE WINAPI _lclose(HFILE hFile);
  DECLSPEC_IMPORT LONG WINAPI _llseek(HFILE hFile,LONG lOffset,int iOrigin);
  DECLSPEC_IMPORT WINBOOL WINAPI IsTextUnicode(CONST VOID *lpv,int iSize,LPINT lpiResult);

#define FLS_OUT_OF_INDEXES ((DWORD)0xffffffff)

  DECLSPEC_IMPORT DWORD WINAPI FlsAlloc(PFLS_CALLBACK_FUNCTION lpCallback);
  DECLSPEC_IMPORT PVOID WINAPI FlsGetValue(DWORD dwFlsIndex);
  DECLSPEC_IMPORT WINBOOL WINAPI FlsSetValue(DWORD dwFlsIndex,PVOID lpFlsData);
  DECLSPEC_IMPORT WINBOOL WINAPI FlsFree(DWORD dwFlsIndex);

#define TLS_OUT_OF_INDEXES ((DWORD)0xffffffff)

  DECLSPEC_IMPORT DWORD WINAPI TlsAlloc(VOID);
  DECLSPEC_IMPORT LPVOID WINAPI TlsGetValue(DWORD dwTlsIndex);
  DECLSPEC_IMPORT WINBOOL WINAPI TlsSetValue(DWORD dwTlsIndex,LPVOID lpTlsValue);
  DECLSPEC_IMPORT WINBOOL WINAPI TlsFree(DWORD dwTlsIndex);

  typedef VOID (WINAPI *LPOVERLAPPED_COMPLETION_ROUTINE)(DWORD dwErrorCode,DWORD dwNumberOfBytesTransfered,LPOVERLAPPED lpOverlapped);

  DECLSPEC_IMPORT DWORD WINAPI SleepEx(DWORD dwMilliseconds,WINBOOL bAlertable);
  DECLSPEC_IMPORT DWORD WINAPI WaitForSingleObjectEx(HANDLE hHandle,DWORD dwMilliseconds,WINBOOL bAlertable);
  DECLSPEC_IMPORT DWORD WINAPI WaitForMultipleObjectsEx(DWORD nCount,CONST HANDLE *lpHandles,WINBOOL bWaitAll,DWORD dwMilliseconds,WINBOOL bAlertable);
  DECLSPEC_IMPORT DWORD WINAPI SignalObjectAndWait(HANDLE hObjectToSignal,HANDLE hObjectToWaitOn,DWORD dwMilliseconds,WINBOOL bAlertable);
  DECLSPEC_IMPORT WINBOOL WINAPI ReadFileEx(HANDLE hFile,LPVOID lpBuffer,DWORD nNumberOfBytesToRead,LPOVERLAPPED lpOverlapped,LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteFileEx(HANDLE hFile,LPCVOID lpBuffer,DWORD nNumberOfBytesToWrite,LPOVERLAPPED lpOverlapped,LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);
  DECLSPEC_IMPORT WINBOOL WINAPI BackupRead(HANDLE hFile,LPBYTE lpBuffer,DWORD nNumberOfBytesToRead,LPDWORD lpNumberOfBytesRead,WINBOOL bAbort,WINBOOL bProcessSecurity,LPVOID *lpContext);
  DECLSPEC_IMPORT WINBOOL WINAPI BackupSeek(HANDLE hFile,DWORD dwLowBytesToSeek,DWORD dwHighBytesToSeek,LPDWORD lpdwLowByteSeeked,LPDWORD lpdwHighByteSeeked,LPVOID *lpContext);
  DECLSPEC_IMPORT WINBOOL WINAPI BackupWrite(HANDLE hFile,LPBYTE lpBuffer,DWORD nNumberOfBytesToWrite,LPDWORD lpNumberOfBytesWritten,WINBOOL bAbort,WINBOOL bProcessSecurity,LPVOID *lpContext);

  typedef struct _WIN32_STREAM_ID {
    DWORD dwStreamId;
    DWORD dwStreamAttributes;
    LARGE_INTEGER Size;
    DWORD dwStreamNameSize;
    WCHAR cStreamName[ANYSIZE_ARRAY];
  } WIN32_STREAM_ID,*LPWIN32_STREAM_ID;

#define BACKUP_INVALID 0x0
#define BACKUP_DATA 0x1
#define BACKUP_EA_DATA 0x2
#define BACKUP_SECURITY_DATA 0x3
#define BACKUP_ALTERNATE_DATA 0x4
#define BACKUP_LINK 0x5
#define BACKUP_PROPERTY_DATA 0x6
#define BACKUP_OBJECT_ID 0x7
#define BACKUP_REPARSE_DATA 0x8
#define BACKUP_SPARSE_BLOCK 0x9

#define STREAM_NORMAL_ATTRIBUTE 0x0
#define STREAM_MODIFIED_WHEN_READ 0x1
#define STREAM_CONTAINS_SECURITY 0x2
#define STREAM_CONTAINS_PROPERTIES 0x4
#define STREAM_SPARSE_ATTRIBUTE 0x8

  DECLSPEC_IMPORT WINBOOL WINAPI ReadFileScatter(HANDLE hFile,FILE_SEGMENT_ELEMENT aSegmentArray[],DWORD nNumberOfBytesToRead,LPDWORD lpReserved,LPOVERLAPPED lpOverlapped);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteFileGather(HANDLE hFile,FILE_SEGMENT_ELEMENT aSegmentArray[],DWORD nNumberOfBytesToWrite,LPDWORD lpReserved,LPOVERLAPPED lpOverlapped);

#define STARTF_USESHOWWINDOW 0x1
#define STARTF_USESIZE 0x2
#define STARTF_USEPOSITION 0x4
#define STARTF_USECOUNTCHARS 0x8
#define STARTF_USEFILLATTRIBUTE 0x10
#define STARTF_RUNFULLSCREEN 0x20
#define STARTF_FORCEONFEEDBACK 0x40
#define STARTF_FORCEOFFFEEDBACK 0x80
#define STARTF_USESTDHANDLES 0x100

#define STARTF_USEHOTKEY 0x200

  typedef struct _STARTUPINFOA {
    DWORD cb;
    LPSTR lpReserved;
    LPSTR lpDesktop;
    LPSTR lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
  } STARTUPINFOA,*LPSTARTUPINFOA;

  typedef struct _STARTUPINFOW {
    DWORD cb;
    LPWSTR lpReserved;
    LPWSTR lpDesktop;
    LPWSTR lpTitle;
    DWORD dwX;
    DWORD dwY;
    DWORD dwXSize;
    DWORD dwYSize;
    DWORD dwXCountChars;
    DWORD dwYCountChars;
    DWORD dwFillAttribute;
    DWORD dwFlags;
    WORD wShowWindow;
    WORD cbReserved2;
    LPBYTE lpReserved2;
    HANDLE hStdInput;
    HANDLE hStdOutput;
    HANDLE hStdError;
  } STARTUPINFOW,*LPSTARTUPINFOW;

  typedef STARTUPINFOA STARTUPINFO;
  typedef LPSTARTUPINFOA LPSTARTUPINFO;

#define SHUTDOWN_NORETRY 0x1

  typedef struct _WIN32_FIND_DATAA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    CHAR cFileName[MAX_PATH];
    CHAR cAlternateFileName[14];
  } WIN32_FIND_DATAA,*PWIN32_FIND_DATAA,*LPWIN32_FIND_DATAA;

  typedef struct _WIN32_FIND_DATAW {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
    DWORD dwReserved0;
    DWORD dwReserved1;
    WCHAR cFileName[MAX_PATH];
    WCHAR cAlternateFileName[14];
  } WIN32_FIND_DATAW,*PWIN32_FIND_DATAW,*LPWIN32_FIND_DATAW;

  typedef WIN32_FIND_DATAA WIN32_FIND_DATA;
  typedef PWIN32_FIND_DATAA PWIN32_FIND_DATA;
  typedef LPWIN32_FIND_DATAA LPWIN32_FIND_DATA;

  typedef struct _WIN32_FILE_ATTRIBUTE_DATA {
    DWORD dwFileAttributes;
    FILETIME ftCreationTime;
    FILETIME ftLastAccessTime;
    FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh;
    DWORD nFileSizeLow;
  } WIN32_FILE_ATTRIBUTE_DATA,*LPWIN32_FILE_ATTRIBUTE_DATA;

#define CreateMutex __MINGW_NAME_AW(CreateMutex)
#define OpenMutex __MINGW_NAME_AW(OpenMutex)
#define CreateEvent __MINGW_NAME_AW(CreateEvent)
#define OpenEvent __MINGW_NAME_AW(OpenEvent)
#define CreateSemaphore __MINGW_NAME_AW(CreateSemaphore)
#define OpenSemaphore __MINGW_NAME_AW(OpenSemaphore)

  DECLSPEC_IMPORT HANDLE WINAPI CreateMutexA(LPSECURITY_ATTRIBUTES lpMutexAttributes,WINBOOL bInitialOwner,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateMutexW(LPSECURITY_ATTRIBUTES lpMutexAttributes,WINBOOL bInitialOwner,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenMutexA(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenMutexW(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateEventA(LPSECURITY_ATTRIBUTES lpEventAttributes,WINBOOL bManualReset,WINBOOL bInitialState,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateEventW(LPSECURITY_ATTRIBUTES lpEventAttributes,WINBOOL bManualReset,WINBOOL bInitialState,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenEventA(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenEventW(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateSemaphoreA(LPSECURITY_ATTRIBUTES lpSemaphoreAttributes,LONG lInitialCount,LONG lMaximumCount,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateSemaphoreW(LPSECURITY_ATTRIBUTES lpSemaphoreAttributes,LONG lInitialCount,LONG lMaximumCount,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenSemaphoreA(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenSemaphoreW(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCWSTR lpName);

  typedef VOID (WINAPI *PTIMERAPCROUTINE)(LPVOID lpArgToCompletionRoutine,DWORD dwTimerLowValue,DWORD dwTimerHighValue);

#define CreateWaitableTimer __MINGW_NAME_AW(CreateWaitableTimer)
#define OpenWaitableTimer __MINGW_NAME_AW(OpenWaitableTimer)
#define CreateFileMapping __MINGW_NAME_AW(CreateFileMapping)
#define OpenFileMapping __MINGW_NAME_AW(OpenFileMapping)
#define GetLogicalDriveStrings __MINGW_NAME_AW(GetLogicalDriveStrings)
#define LoadLibrary __MINGW_NAME_AW(LoadLibrary)
#define LoadLibraryEx __MINGW_NAME_AW(LoadLibraryEx)
#define GetModuleFileName __MINGW_NAME_AW(GetModuleFileName)
#define GetModuleHandle __MINGW_NAME_AW(GetModuleHandle)

  DECLSPEC_IMPORT HANDLE WINAPI CreateWaitableTimerA(LPSECURITY_ATTRIBUTES lpTimerAttributes,WINBOOL bManualReset,LPCSTR lpTimerName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateWaitableTimerW(LPSECURITY_ATTRIBUTES lpTimerAttributes,WINBOOL bManualReset,LPCWSTR lpTimerName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenWaitableTimerA(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCSTR lpTimerName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenWaitableTimerW(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCWSTR lpTimerName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetWaitableTimer(HANDLE hTimer,const LARGE_INTEGER *lpDueTime,LONG lPeriod,PTIMERAPCROUTINE pfnCompletionRoutine,LPVOID lpArgToCompletionRoutine,WINBOOL fResume);
  DECLSPEC_IMPORT WINBOOL WINAPI CancelWaitableTimer(HANDLE hTimer);
  DECLSPEC_IMPORT HANDLE WINAPI CreateFileMappingA(HANDLE hFile,LPSECURITY_ATTRIBUTES lpFileMappingAttributes,DWORD flProtect,DWORD dwMaximumSizeHigh,DWORD dwMaximumSizeLow,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateFileMappingW(HANDLE hFile,LPSECURITY_ATTRIBUTES lpFileMappingAttributes,DWORD flProtect,DWORD dwMaximumSizeHigh,DWORD dwMaximumSizeLow,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenFileMappingA(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenFileMappingW(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCWSTR lpName);
  DECLSPEC_IMPORT DWORD WINAPI GetLogicalDriveStringsA(DWORD nBufferLength,LPSTR lpBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetLogicalDriveStringsW(DWORD nBufferLength,LPWSTR lpBuffer);

  typedef enum _MEMORY_RESOURCE_NOTIFICATION_TYPE {
    LowMemoryResourceNotification,HighMemoryResourceNotification
  } MEMORY_RESOURCE_NOTIFICATION_TYPE;

  DECLSPEC_IMPORT HANDLE WINAPI CreateMemoryResourceNotification(MEMORY_RESOURCE_NOTIFICATION_TYPE NotificationType);
  DECLSPEC_IMPORT WINBOOL WINAPI QueryMemoryResourceNotification(HANDLE ResourceNotificationHandle,PBOOL ResourceState);
  DECLSPEC_IMPORT HMODULE WINAPI LoadLibraryA(LPCSTR lpLibFileName);
  DECLSPEC_IMPORT HMODULE WINAPI LoadLibraryW(LPCWSTR lpLibFileName);
  DECLSPEC_IMPORT HMODULE WINAPI LoadLibraryExA(LPCSTR lpLibFileName,HANDLE hFile,DWORD dwFlags);
  DECLSPEC_IMPORT HMODULE WINAPI LoadLibraryExW(LPCWSTR lpLibFileName,HANDLE hFile,DWORD dwFlags);

#define DONT_RESOLVE_DLL_REFERENCES 0x1
#define LOAD_LIBRARY_AS_DATAFILE 0x2
#define LOAD_WITH_ALTERED_SEARCH_PATH 0x8
#define LOAD_IGNORE_CODE_AUTHZ_LEVEL 0x10
#define LOAD_LIBRARY_AS_IMAGE_RESOURCE 0x20
#define LOAD_LIBRARY_AS_DATAFILE_EXCLUSIVE 0x40

  DECLSPEC_IMPORT DWORD WINAPI GetModuleFileNameA(HMODULE hModule,LPCH lpFilename,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI GetModuleFileNameW(HMODULE hModule,LPWCH lpFilename,DWORD nSize);
  DECLSPEC_IMPORT HMODULE WINAPI GetModuleHandleA(LPCSTR lpModuleName);
  DECLSPEC_IMPORT HMODULE WINAPI GetModuleHandleW(LPCWSTR lpModuleName);


#define GET_MODULE_HANDLE_EX_FLAG_PIN (0x1)
#define GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT (0x2)
#define GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS (0x4)

  typedef WINBOOL (WINAPI *PGET_MODULE_HANDLE_EXA)(DWORD dwFlags,LPCSTR lpModuleName,HMODULE *phModule);
  typedef WINBOOL (WINAPI *PGET_MODULE_HANDLE_EXW)(DWORD dwFlags,LPCWSTR lpModuleName,HMODULE *phModule);

#define PGET_MODULE_HANDLE_EX __MINGW_NAME_AW(PGET_MODULE_HANDLE_EX)
#define GetModuleHandleEx __MINGW_NAME_AW(GetModuleHandleEx)

  DECLSPEC_IMPORT WINBOOL WINAPI GetModuleHandleExA(DWORD dwFlags,LPCSTR lpModuleName,HMODULE *phModule);
  DECLSPEC_IMPORT WINBOOL WINAPI GetModuleHandleExW(DWORD dwFlags,LPCWSTR lpModuleName,HMODULE *phModule);


#define NeedCurrentDirectoryForExePath __MINGW_NAME_AW(NeedCurrentDirectoryForExePath)
#define CreateProcess __MINGW_NAME_AW(CreateProcess)
#define FatalAppExit __MINGW_NAME_AW(FatalAppExit)
#define GetStartupInfo __MINGW_NAME_AW(GetStartupInfo)
#define GetCommandLine __MINGW_NAME_AW(GetCommandLine)
#define GetEnvironmentVariable __MINGW_NAME_AW(GetEnvironmentVariable)
#define SetEnvironmentVariable __MINGW_NAME_AW(SetEnvironmentVariable)
#define ExpandEnvironmentStrings __MINGW_NAME_AW(ExpandEnvironmentStrings)
#define GetFirmwareEnvironmentVariable __MINGW_NAME_AW(GetFirmwareEnvironmentVariable)
#define SetFirmwareEnvironmentVariable __MINGW_NAME_AW(SetFirmwareEnvironmentVariable)
#define OutputDebugString __MINGW_NAME_AW(OutputDebugString)
#define FindResource __MINGW_NAME_AW(FindResource)
#define FindResourceEx __MINGW_NAME_AW(FindResourceEx)

  DECLSPEC_IMPORT WINBOOL WINAPI NeedCurrentDirectoryForExePathA(LPCSTR ExeName);
  DECLSPEC_IMPORT WINBOOL WINAPI NeedCurrentDirectoryForExePathW(LPCWSTR ExeName);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateProcessA(LPCSTR lpApplicationName,LPSTR lpCommandLine,LPSECURITY_ATTRIBUTES lpProcessAttributes,LPSECURITY_ATTRIBUTES lpThreadAttributes,WINBOOL bInheritHandles,DWORD dwCreationFlags,LPVOID lpEnvironment,LPCSTR lpCurrentDirectory,LPSTARTUPINFOA lpStartupInfo,LPPROCESS_INFORMATION lpProcessInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateProcessW(LPCWSTR lpApplicationName,LPWSTR lpCommandLine,LPSECURITY_ATTRIBUTES lpProcessAttributes,LPSECURITY_ATTRIBUTES lpThreadAttributes,WINBOOL bInheritHandles,DWORD dwCreationFlags,LPVOID lpEnvironment,LPCWSTR lpCurrentDirectory,LPSTARTUPINFOW lpStartupInfo,LPPROCESS_INFORMATION lpProcessInformation);
  DECLSPEC_IMPORT DWORD WINAPI AddLocalAlternateComputerNameA(LPCSTR lpDnsFQHostname,ULONG ulFlags);
  DECLSPEC_IMPORT DWORD WINAPI AddLocalAlternateComputerNameW(LPCWSTR lpDnsFQHostname,ULONG ulFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI SetProcessShutdownParameters(DWORD dwLevel,DWORD dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI GetProcessShutdownParameters(LPDWORD lpdwLevel,LPDWORD lpdwFlags);
  DECLSPEC_IMPORT DWORD WINAPI GetProcessVersion(DWORD ProcessId);
  DECLSPEC_IMPORT VOID WINAPI FatalAppExitA(UINT uAction,LPCSTR lpMessageText);
  DECLSPEC_IMPORT VOID WINAPI FatalAppExitW(UINT uAction,LPCWSTR lpMessageText);
  DECLSPEC_IMPORT VOID WINAPI GetStartupInfoA(LPSTARTUPINFOA lpStartupInfo);
  DECLSPEC_IMPORT VOID WINAPI GetStartupInfoW(LPSTARTUPINFOW lpStartupInfo);
  DECLSPEC_IMPORT LPSTR WINAPI GetCommandLineA(VOID);
  DECLSPEC_IMPORT LPWSTR WINAPI GetCommandLineW(VOID);
  DECLSPEC_IMPORT DWORD WINAPI GetEnvironmentVariableA(LPCSTR lpName,LPSTR lpBuffer,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI GetEnvironmentVariableW(LPCWSTR lpName,LPWSTR lpBuffer,DWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetEnvironmentVariableA(LPCSTR lpName,LPCSTR lpValue);
  DECLSPEC_IMPORT WINBOOL WINAPI SetEnvironmentVariableW(LPCWSTR lpName,LPCWSTR lpValue);
  DECLSPEC_IMPORT DWORD WINAPI ExpandEnvironmentStringsA(LPCSTR lpSrc,LPSTR lpDst,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI ExpandEnvironmentStringsW(LPCWSTR lpSrc,LPWSTR lpDst,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI GetFirmwareEnvironmentVariableA(LPCSTR lpName,LPCSTR lpGuid,PVOID pBuffer,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI GetFirmwareEnvironmentVariableW(LPCWSTR lpName,LPCWSTR lpGuid,PVOID pBuffer,DWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFirmwareEnvironmentVariableA(LPCSTR lpName,LPCSTR lpGuid,PVOID pValue,DWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFirmwareEnvironmentVariableW(LPCWSTR lpName,LPCWSTR lpGuid,PVOID pValue,DWORD nSize);
  DECLSPEC_IMPORT VOID WINAPI OutputDebugStringA(LPCSTR lpOutputString);
  DECLSPEC_IMPORT VOID WINAPI OutputDebugStringW(LPCWSTR lpOutputString);
  DECLSPEC_IMPORT HRSRC WINAPI FindResourceA(HMODULE hModule,LPCSTR lpName,LPCSTR lpType);
  DECLSPEC_IMPORT HRSRC WINAPI FindResourceW(HMODULE hModule,LPCWSTR lpName,LPCWSTR lpType);
  DECLSPEC_IMPORT HRSRC WINAPI FindResourceExA(HMODULE hModule,LPCSTR lpType,LPCSTR lpName,WORD wLanguage);
  DECLSPEC_IMPORT HRSRC WINAPI FindResourceExW(HMODULE hModule,LPCWSTR lpType,LPCWSTR lpName,WORD wLanguage);

  /* available in XP SP3, Vista SP1 and higher */
  typedef enum _DEP_SYSTEM_POLICY_TYPE {
    AlwaysOff = 0,
    AlwaysOn = 1,
    OptIn = 2,
    OptOut = 3
  } DEP_SYSTEM_POLICY_TYPE;
  DECLSPEC_IMPORT DEP_SYSTEM_POLICY_TYPE WINAPI GetSystemDEPPolicy (void);

#define ENUMRESTYPEPROC __MINGW_NAME_AW(ENUMRESTYPEPROC)
#define ENUMRESNAMEPROC __MINGW_NAME_AW(ENUMRESNAMEPROC)
#define ENUMRESLANGPROC __MINGW_NAME_AW(ENUMRESLANGPROC)
#define EnumResourceTypes __MINGW_NAME_AW(EnumResourceTypes)
#define EnumResourceNames __MINGW_NAME_AW(EnumResourceNames)
#define EnumResourceLanguages __MINGW_NAME_AW(EnumResourceLanguages)
#define BeginUpdateResource __MINGW_NAME_AW(BeginUpdateResource)
#define UpdateResource __MINGW_NAME_AW(UpdateResource)
#define EndUpdateResource __MINGW_NAME_AW(EndUpdateResource)
#define GlobalAddAtom __MINGW_NAME_AW(GlobalAddAtom)
#define GlobalFindAtom __MINGW_NAME_AW(GlobalFindAtom)
#define GlobalGetAtomName __MINGW_NAME_AW(GlobalGetAtomName)
#define AddAtom __MINGW_NAME_AW(AddAtom)
#define FindAtom __MINGW_NAME_AW(FindAtom)
#define GetAtomName __MINGW_NAME_AW(GetAtomName)
#define GetProfileInt __MINGW_NAME_AW(GetProfileInt)
#define GetProfileString __MINGW_NAME_AW(GetProfileString)
#define WriteProfileString __MINGW_NAME_AW(WriteProfileString)
#define GetProfileSection __MINGW_NAME_AW(GetProfileSection)
#define WriteProfileSection __MINGW_NAME_AW(WriteProfileSection)
#define GetPrivateProfileInt __MINGW_NAME_AW(GetPrivateProfileInt)
#define GetPrivateProfileString __MINGW_NAME_AW(GetPrivateProfileString)
#define WritePrivateProfileString __MINGW_NAME_AW(WritePrivateProfileString)
#define GetPrivateProfileSection __MINGW_NAME_AW(GetPrivateProfileSection)
#define WritePrivateProfileSection __MINGW_NAME_AW(WritePrivateProfileSection)
#define GetPrivateProfileSectionNames __MINGW_NAME_AW(GetPrivateProfileSectionNames)
#define GetPrivateProfileStruct __MINGW_NAME_AW(GetPrivateProfileStruct)
#define WritePrivateProfileStruct __MINGW_NAME_AW(WritePrivateProfileStruct)
#define GetDriveType __MINGW_NAME_AW(GetDriveType)
#define GetSystemDirectory __MINGW_NAME_AW(GetSystemDirectory)
#define GetTempPath __MINGW_NAME_AW(GetTempPath)
#define GetTempFileName __MINGW_NAME_AW(GetTempFileName)
#define GetWindowsDirectory __MINGW_NAME_AW(GetWindowsDirectory)
#define GetSystemWindowsDirectory __MINGW_NAME_AW(GetSystemWindowsDirectory)
#define AddLocalAlternateComputerName __MINGW_NAME_AW(AddLocalAlternateComputerName)

  typedef WINBOOL (CALLBACK *ENUMRESTYPEPROCA)(HMODULE hModule,LPSTR lpType,LONG_PTR lParam);
  typedef WINBOOL (CALLBACK *ENUMRESTYPEPROCW)(HMODULE hModule,LPWSTR lpType,LONG_PTR lParam);
  typedef WINBOOL (CALLBACK *ENUMRESNAMEPROCA)(HMODULE hModule,LPCSTR lpType,LPSTR lpName,LONG_PTR lParam);
  typedef WINBOOL (CALLBACK *ENUMRESNAMEPROCW)(HMODULE hModule,LPCWSTR lpType,LPWSTR lpName,LONG_PTR lParam);
  typedef WINBOOL (CALLBACK *ENUMRESLANGPROCA)(HMODULE hModule,LPCSTR lpType,LPCSTR lpName,WORD wLanguage,LONG_PTR lParam);
  typedef WINBOOL (CALLBACK *ENUMRESLANGPROCW)(HMODULE hModule,LPCWSTR lpType,LPCWSTR lpName,WORD wLanguage,LONG_PTR lParam);

  DECLSPEC_IMPORT WINBOOL WINAPI EnumResourceTypesA(HMODULE hModule,ENUMRESTYPEPROCA lpEnumFunc,LONG_PTR lParam);
  DECLSPEC_IMPORT WINBOOL WINAPI EnumResourceTypesW(HMODULE hModule,ENUMRESTYPEPROCW lpEnumFunc,LONG_PTR lParam);
  DECLSPEC_IMPORT WINBOOL WINAPI EnumResourceNamesA(HMODULE hModule,LPCSTR lpType,ENUMRESNAMEPROCA lpEnumFunc,LONG_PTR lParam);
  DECLSPEC_IMPORT WINBOOL WINAPI EnumResourceNamesW(HMODULE hModule,LPCWSTR lpType,ENUMRESNAMEPROCW lpEnumFunc,LONG_PTR lParam);
  DECLSPEC_IMPORT WINBOOL WINAPI EnumResourceLanguagesA(HMODULE hModule,LPCSTR lpType,LPCSTR lpName,ENUMRESLANGPROCA lpEnumFunc,LONG_PTR lParam);
  DECLSPEC_IMPORT WINBOOL WINAPI EnumResourceLanguagesW(HMODULE hModule,LPCWSTR lpType,LPCWSTR lpName,ENUMRESLANGPROCW lpEnumFunc,LONG_PTR lParam);
  DECLSPEC_IMPORT HANDLE WINAPI BeginUpdateResourceA(LPCSTR pFileName,WINBOOL bDeleteExistingResources);
  DECLSPEC_IMPORT HANDLE WINAPI BeginUpdateResourceW(LPCWSTR pFileName,WINBOOL bDeleteExistingResources);
  DECLSPEC_IMPORT WINBOOL WINAPI UpdateResourceA(HANDLE hUpdate,LPCSTR lpType,LPCSTR lpName,WORD wLanguage,LPVOID lpData,DWORD cb);
  DECLSPEC_IMPORT WINBOOL WINAPI UpdateResourceW(HANDLE hUpdate,LPCWSTR lpType,LPCWSTR lpName,WORD wLanguage,LPVOID lpData,DWORD cb);
  DECLSPEC_IMPORT WINBOOL WINAPI EndUpdateResourceA(HANDLE hUpdate,WINBOOL fDiscard);
  DECLSPEC_IMPORT WINBOOL WINAPI EndUpdateResourceW(HANDLE hUpdate,WINBOOL fDiscard);
  DECLSPEC_IMPORT ATOM WINAPI GlobalAddAtomA(LPCSTR lpString);
  DECLSPEC_IMPORT ATOM WINAPI GlobalAddAtomW(LPCWSTR lpString);
  DECLSPEC_IMPORT ATOM WINAPI GlobalFindAtomA(LPCSTR lpString);
  DECLSPEC_IMPORT ATOM WINAPI GlobalFindAtomW(LPCWSTR lpString);
  DECLSPEC_IMPORT UINT WINAPI GlobalGetAtomNameA(ATOM nAtom,LPSTR lpBuffer,int nSize);
  DECLSPEC_IMPORT UINT WINAPI GlobalGetAtomNameW(ATOM nAtom,LPWSTR lpBuffer,int nSize);
  DECLSPEC_IMPORT ATOM WINAPI AddAtomA(LPCSTR lpString);
  DECLSPEC_IMPORT ATOM WINAPI AddAtomW(LPCWSTR lpString);
  DECLSPEC_IMPORT ATOM WINAPI FindAtomA(LPCSTR lpString);
  DECLSPEC_IMPORT ATOM WINAPI FindAtomW(LPCWSTR lpString);
  DECLSPEC_IMPORT UINT WINAPI GetAtomNameA(ATOM nAtom,LPSTR lpBuffer,int nSize);
  DECLSPEC_IMPORT UINT WINAPI GetAtomNameW(ATOM nAtom,LPWSTR lpBuffer,int nSize);
  DECLSPEC_IMPORT UINT WINAPI GetProfileIntA(LPCSTR lpAppName,LPCSTR lpKeyName,INT nDefault);
  DECLSPEC_IMPORT UINT WINAPI GetProfileIntW(LPCWSTR lpAppName,LPCWSTR lpKeyName,INT nDefault);
  DECLSPEC_IMPORT DWORD WINAPI GetProfileStringA(LPCSTR lpAppName,LPCSTR lpKeyName,LPCSTR lpDefault,LPSTR lpReturnedString,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI GetProfileStringW(LPCWSTR lpAppName,LPCWSTR lpKeyName,LPCWSTR lpDefault,LPWSTR lpReturnedString,DWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteProfileStringA(LPCSTR lpAppName,LPCSTR lpKeyName,LPCSTR lpString);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteProfileStringW(LPCWSTR lpAppName,LPCWSTR lpKeyName,LPCWSTR lpString);
  DECLSPEC_IMPORT DWORD WINAPI GetProfileSectionA(LPCSTR lpAppName,LPSTR lpReturnedString,DWORD nSize);
  DECLSPEC_IMPORT DWORD WINAPI GetProfileSectionW(LPCWSTR lpAppName,LPWSTR lpReturnedString,DWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteProfileSectionA(LPCSTR lpAppName,LPCSTR lpString);
  DECLSPEC_IMPORT WINBOOL WINAPI WriteProfileSectionW(LPCWSTR lpAppName,LPCWSTR lpString);
  DECLSPEC_IMPORT UINT WINAPI GetPrivateProfileIntA(LPCSTR lpAppName,LPCSTR lpKeyName,INT nDefault,LPCSTR lpFileName);
  DECLSPEC_IMPORT UINT WINAPI GetPrivateProfileIntW(LPCWSTR lpAppName,LPCWSTR lpKeyName,INT nDefault,LPCWSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetPrivateProfileStringA(LPCSTR lpAppName,LPCSTR lpKeyName,LPCSTR lpDefault,LPSTR lpReturnedString,DWORD nSize,LPCSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetPrivateProfileStringW(LPCWSTR lpAppName,LPCWSTR lpKeyName,LPCWSTR lpDefault,LPWSTR lpReturnedString,DWORD nSize,LPCWSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI WritePrivateProfileStringA(LPCSTR lpAppName,LPCSTR lpKeyName,LPCSTR lpString,LPCSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI WritePrivateProfileStringW(LPCWSTR lpAppName,LPCWSTR lpKeyName,LPCWSTR lpString,LPCWSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetPrivateProfileSectionA(LPCSTR lpAppName,LPSTR lpReturnedString,DWORD nSize,LPCSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetPrivateProfileSectionW(LPCWSTR lpAppName,LPWSTR lpReturnedString,DWORD nSize,LPCWSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI WritePrivateProfileSectionA(LPCSTR lpAppName,LPCSTR lpString,LPCSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI WritePrivateProfileSectionW(LPCWSTR lpAppName,LPCWSTR lpString,LPCWSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetPrivateProfileSectionNamesA(LPSTR lpszReturnBuffer,DWORD nSize,LPCSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetPrivateProfileSectionNamesW(LPWSTR lpszReturnBuffer,DWORD nSize,LPCWSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI GetPrivateProfileStructA(LPCSTR lpszSection,LPCSTR lpszKey,LPVOID lpStruct,UINT uSizeStruct,LPCSTR szFile);
  DECLSPEC_IMPORT WINBOOL WINAPI GetPrivateProfileStructW(LPCWSTR lpszSection,LPCWSTR lpszKey,LPVOID lpStruct,UINT uSizeStruct,LPCWSTR szFile);
  DECLSPEC_IMPORT WINBOOL WINAPI WritePrivateProfileStructA(LPCSTR lpszSection,LPCSTR lpszKey,LPVOID lpStruct,UINT uSizeStruct,LPCSTR szFile);
  DECLSPEC_IMPORT WINBOOL WINAPI WritePrivateProfileStructW(LPCWSTR lpszSection,LPCWSTR lpszKey,LPVOID lpStruct,UINT uSizeStruct,LPCWSTR szFile);
  DECLSPEC_IMPORT UINT WINAPI GetDriveTypeA(LPCSTR lpRootPathName);
  DECLSPEC_IMPORT UINT WINAPI GetDriveTypeW(LPCWSTR lpRootPathName);
  DECLSPEC_IMPORT UINT WINAPI GetSystemDirectoryA(LPSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT UINT WINAPI GetSystemDirectoryW(LPWSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT DWORD WINAPI GetTempPathA(DWORD nBufferLength,LPSTR lpBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetTempPathW(DWORD nBufferLength,LPWSTR lpBuffer);
  DECLSPEC_IMPORT UINT WINAPI GetTempFileNameA(LPCSTR lpPathName,LPCSTR lpPrefixString,UINT uUnique,LPSTR lpTempFileName);
  DECLSPEC_IMPORT UINT WINAPI GetTempFileNameW(LPCWSTR lpPathName,LPCWSTR lpPrefixString,UINT uUnique,LPWSTR lpTempFileName);
  DECLSPEC_IMPORT UINT WINAPI GetWindowsDirectoryA(LPSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT UINT WINAPI GetWindowsDirectoryW(LPWSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT UINT WINAPI GetSystemWindowsDirectoryA(LPSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT UINT WINAPI GetSystemWindowsDirectoryW(LPWSTR lpBuffer,UINT uSize);


#define GetSystemWow64Directory __MINGW_NAME_AW(GetSystemWow64Directory)

  DECLSPEC_IMPORT UINT WINAPI GetSystemWow64DirectoryA(LPSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT UINT WINAPI GetSystemWow64DirectoryW(LPWSTR lpBuffer,UINT uSize);
  DECLSPEC_IMPORT BOOLEAN WINAPI Wow64EnableWow64FsRedirection(BOOLEAN Wow64FsEnableRedirection);
  DECLSPEC_IMPORT WINBOOL WINAPI Wow64DisableWow64FsRedirection(PVOID *OldValue);
  DECLSPEC_IMPORT WINBOOL WINAPI Wow64RevertWow64FsRedirection(PVOID OlValue);

  typedef UINT (WINAPI *PGET_SYSTEM_WOW64_DIRECTORY_A)(LPSTR lpBuffer,UINT uSize);
  typedef UINT (WINAPI *PGET_SYSTEM_WOW64_DIRECTORY_W)(LPWSTR lpBuffer,UINT uSize);

#define GET_SYSTEM_WOW64_DIRECTORY_NAME_A_A "GetSystemWow64DirectoryA"
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_A_W L"GetSystemWow64DirectoryA"
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_A_T TEXT("GetSystemWow64DirectoryA")
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_W_A "GetSystemWow64DirectoryW"
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_W_W L"GetSystemWow64DirectoryW"
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_W_T TEXT("GetSystemWow64DirectoryW")

#define GET_SYSTEM_WOW64_DIRECTORY_NAME_T_A __MINGW_NAME_UAW_EXT(GET_SYSTEM_WOW64_DIRECTORY_NAME,A)
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_T_W __MINGW_NAME_UAW_EXT(GET_SYSTEM_WOW64_DIRECTORY_NAME,W)
#define GET_SYSTEM_WOW64_DIRECTORY_NAME_T_T __MINGW_NAME_UAW_EXT(GET_SYSTEM_WOW64_DIRECTORY_NAME,T)



#define SetCurrentDirectory __MINGW_NAME_AW(SetCurrentDirectory)
#define GetCurrentDirectory __MINGW_NAME_AW(GetCurrentDirectory)
#define SetDllDirectory __MINGW_NAME_AW(SetDllDirectory)
#define GetDllDirectory __MINGW_NAME_AW(GetDllDirectory)
#define GetDiskFreeSpace __MINGW_NAME_AW(GetDiskFreeSpace)
#define GetDiskFreeSpaceEx __MINGW_NAME_AW(GetDiskFreeSpaceEx)
#define CreateDirectory __MINGW_NAME_AW(CreateDirectory)
#define CreateDirectoryEx __MINGW_NAME_AW(CreateDirectoryEx)
#define RemoveDirectory __MINGW_NAME_AW(RemoveDirectory)
#define GetFullPathName __MINGW_NAME_AW(GetFullPathName)
#define DefineDosDevice __MINGW_NAME_AW(DefineDosDevice)
#define QueryDosDevice __MINGW_NAME_AW(QueryDosDevice)
#define CreateFile __MINGW_NAME_AW(CreateFile)
#define SetFileAttributes __MINGW_NAME_AW(SetFileAttributes)
#define GetFileAttributes __MINGW_NAME_AW(GetFileAttributes)

  DECLSPEC_IMPORT WINBOOL WINAPI SetCurrentDirectoryA(LPCSTR lpPathName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetCurrentDirectoryW(LPCWSTR lpPathName);
  DECLSPEC_IMPORT DWORD WINAPI GetCurrentDirectoryA(DWORD nBufferLength,LPSTR lpBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetCurrentDirectoryW(DWORD nBufferLength,LPWSTR lpBuffer);
  DECLSPEC_IMPORT WINBOOL WINAPI SetDllDirectoryA(LPCSTR lpPathName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetDllDirectoryW(LPCWSTR lpPathName);
  DECLSPEC_IMPORT DWORD WINAPI GetDllDirectoryA(DWORD nBufferLength,LPSTR lpBuffer);
  DECLSPEC_IMPORT DWORD WINAPI GetDllDirectoryW(DWORD nBufferLength,LPWSTR lpBuffer);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDiskFreeSpaceA(LPCSTR lpRootPathName,LPDWORD lpSectorsPerCluster,LPDWORD lpBytesPerSector,LPDWORD lpNumberOfFreeClusters,LPDWORD lpTotalNumberOfClusters);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDiskFreeSpaceW(LPCWSTR lpRootPathName,LPDWORD lpSectorsPerCluster,LPDWORD lpBytesPerSector,LPDWORD lpNumberOfFreeClusters,LPDWORD lpTotalNumberOfClusters);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDiskFreeSpaceExA(LPCSTR lpDirectoryName,PULARGE_INTEGER lpFreeBytesAvailableToCaller,PULARGE_INTEGER lpTotalNumberOfBytes,PULARGE_INTEGER lpTotalNumberOfFreeBytes);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDiskFreeSpaceExW(LPCWSTR lpDirectoryName,PULARGE_INTEGER lpFreeBytesAvailableToCaller,PULARGE_INTEGER lpTotalNumberOfBytes,PULARGE_INTEGER lpTotalNumberOfFreeBytes);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateDirectoryA(LPCSTR lpPathName,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateDirectoryW(LPCWSTR lpPathName,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateDirectoryExA(LPCSTR lpTemplateDirectory,LPCSTR lpNewDirectory,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateDirectoryExW(LPCWSTR lpTemplateDirectory,LPCWSTR lpNewDirectory,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI RemoveDirectoryA(LPCSTR lpPathName);
  DECLSPEC_IMPORT WINBOOL WINAPI RemoveDirectoryW(LPCWSTR lpPathName);
  DECLSPEC_IMPORT DWORD WINAPI GetFullPathNameA(LPCSTR lpFileName,DWORD nBufferLength,LPSTR lpBuffer,LPSTR *lpFilePart);
  DECLSPEC_IMPORT DWORD WINAPI GetFullPathNameW(LPCWSTR lpFileName,DWORD nBufferLength,LPWSTR lpBuffer,LPWSTR *lpFilePart);

#define DDD_RAW_TARGET_PATH 0x1
#define DDD_REMOVE_DEFINITION 0x2
#define DDD_EXACT_MATCH_ON_REMOVE 0x4
#define DDD_NO_BROADCAST_SYSTEM 0x8
#define DDD_LUID_BROADCAST_DRIVE 0x10

  DECLSPEC_IMPORT WINBOOL WINAPI DefineDosDeviceA(DWORD dwFlags,LPCSTR lpDeviceName,LPCSTR lpTargetPath);
  DECLSPEC_IMPORT WINBOOL WINAPI DefineDosDeviceW(DWORD dwFlags,LPCWSTR lpDeviceName,LPCWSTR lpTargetPath);
  DECLSPEC_IMPORT DWORD WINAPI QueryDosDeviceA(LPCSTR lpDeviceName,LPSTR lpTargetPath,DWORD ucchMax);
  DECLSPEC_IMPORT DWORD WINAPI QueryDosDeviceW(LPCWSTR lpDeviceName,LPWSTR lpTargetPath,DWORD ucchMax);

#define EXPAND_LOCAL_DRIVES 

  DECLSPEC_IMPORT HANDLE WINAPI CreateFileA(LPCSTR lpFileName,DWORD dwDesiredAccess,DWORD dwShareMode,LPSECURITY_ATTRIBUTES lpSecurityAttributes,DWORD dwCreationDisposition,DWORD dwFlagsAndAttributes,HANDLE hTemplateFile);
  DECLSPEC_IMPORT HANDLE WINAPI CreateFileW(LPCWSTR lpFileName,DWORD dwDesiredAccess,DWORD dwShareMode,LPSECURITY_ATTRIBUTES lpSecurityAttributes,DWORD dwCreationDisposition,DWORD dwFlagsAndAttributes,HANDLE hTemplateFile);
  DECLSPEC_IMPORT HANDLE WINAPI ReOpenFile(HANDLE hOriginalFile,DWORD dwDesiredAccess,DWORD dwShareMode,DWORD dwFlagsAndAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileAttributesA(LPCSTR lpFileName,DWORD dwFileAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileAttributesW(LPCWSTR lpFileName,DWORD dwFileAttributes);
  DECLSPEC_IMPORT DWORD WINAPI GetFileAttributesA(LPCSTR lpFileName);
  DECLSPEC_IMPORT DWORD WINAPI GetFileAttributesW(LPCWSTR lpFileName);

  typedef enum _GET_FILEEX_INFO_LEVELS {
    GetFileExInfoStandard,GetFileExMaxInfoLevel
  } GET_FILEEX_INFO_LEVELS;

#define GetFileAttributesEx __MINGW_NAME_AW(GetFileAttributesEx)
#define GetCompressedFileSize __MINGW_NAME_AW(GetCompressedFileSize)
#define DeleteFile __MINGW_NAME_AW(DeleteFile)
#define CheckNameLegalDOS8Dot3 __MINGW_NAME_AW(CheckNameLegalDOS8Dot3)

  DECLSPEC_IMPORT WINBOOL WINAPI GetFileAttributesExA(LPCSTR lpFileName,GET_FILEEX_INFO_LEVELS fInfoLevelId,LPVOID lpFileInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI GetFileAttributesExW(LPCWSTR lpFileName,GET_FILEEX_INFO_LEVELS fInfoLevelId,LPVOID lpFileInformation);
  DECLSPEC_IMPORT DWORD WINAPI GetCompressedFileSizeA(LPCSTR lpFileName,LPDWORD lpFileSizeHigh);
  DECLSPEC_IMPORT DWORD WINAPI GetCompressedFileSizeW(LPCWSTR lpFileName,LPDWORD lpFileSizeHigh);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteFileA(LPCSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteFileW(LPCWSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI CheckNameLegalDOS8Dot3A(LPCSTR lpName,LPSTR lpOemName,DWORD OemNameSize,PBOOL pbNameContainsSpaces,PBOOL pbNameLegal);
  DECLSPEC_IMPORT WINBOOL WINAPI CheckNameLegalDOS8Dot3W(LPCWSTR lpName,LPSTR lpOemName,DWORD OemNameSize,PBOOL pbNameContainsSpaces,PBOOL pbNameLegal);

  typedef enum _FINDEX_INFO_LEVELS {
    FindExInfoStandard,FindExInfoMaxInfoLevel
  } FINDEX_INFO_LEVELS;

  typedef enum _FINDEX_SEARCH_OPS {
    FindExSearchNameMatch,FindExSearchLimitToDirectories,FindExSearchLimitToDevices,FindExSearchMaxSearchOp
  } FINDEX_SEARCH_OPS;

#define FIND_FIRST_EX_CASE_SENSITIVE 0x1

#define FindFirstFileEx __MINGW_NAME_AW(FindFirstFileEx)
#define FindFirstFile __MINGW_NAME_AW(FindFirstFile)
#define FindNextFile __MINGW_NAME_AW(FindNextFile)
#define SearchPath __MINGW_NAME_AW(SearchPath)
#define CopyFile __MINGW_NAME_AW(CopyFile)
#define CopyFileEx __MINGW_NAME_AW(CopyFileEx)
#define MoveFile __MINGW_NAME_AW(MoveFile)
#define MoveFileEx __MINGW_NAME_AW(MoveFileEx)
#define MoveFileWithProgress __MINGW_NAME_AW(MoveFileWithProgress)
#define ReplaceFile __MINGW_NAME_AW(ReplaceFile)
#define CreateHardLink __MINGW_NAME_AW(CreateHardLink)
#define CreateNamedPipe __MINGW_NAME_AW(CreateNamedPipe)
#define GetNamedPipeHandleState __MINGW_NAME_AW(GetNamedPipeHandleState)
#define CallNamedPipe __MINGW_NAME_AW(CallNamedPipe)
#define WaitNamedPipe __MINGW_NAME_AW(WaitNamedPipe)
#define SetVolumeLabel __MINGW_NAME_AW(SetVolumeLabel)
#define GetVolumeInformation __MINGW_NAME_AW(GetVolumeInformation)
#define ClearEventLog __MINGW_NAME_AW(ClearEventLog)
#define BackupEventLog __MINGW_NAME_AW(BackupEventLog)
#define OpenEventLog __MINGW_NAME_AW(OpenEventLog)
#define RegisterEventSource __MINGW_NAME_AW(RegisterEventSource)
#define OpenBackupEventLog __MINGW_NAME_AW(OpenBackupEventLog)
#define ReadEventLog __MINGW_NAME_AW(ReadEventLog)
#define ReportEvent __MINGW_NAME_AW(ReportEvent)
#define AccessCheckAndAuditAlarm __MINGW_NAME_AW(AccessCheckAndAuditAlarm)
#define AccessCheckByTypeAndAuditAlarm __MINGW_NAME_AW(AccessCheckByTypeAndAuditAlarm)
#define AccessCheckByTypeResultListAndAuditAlarm __MINGW_NAME_AW(AccessCheckByTypeResultListAndAuditAlarm)
#define AccessCheckByTypeResultListAndAuditAlarmByHandle __MINGW_NAME_AW(AccessCheckByTypeResultListAndAuditAlarmByHandle)
#define ObjectOpenAuditAlarm __MINGW_NAME_AW(ObjectOpenAuditAlarm)
#define ObjectPrivilegeAuditAlarm __MINGW_NAME_AW(ObjectPrivilegeAuditAlarm)
#define ObjectCloseAuditAlarm __MINGW_NAME_AW(ObjectCloseAuditAlarm)
#define ObjectDeleteAuditAlarm __MINGW_NAME_AW(ObjectDeleteAuditAlarm)
#define PrivilegedServiceAuditAlarm __MINGW_NAME_AW(PrivilegedServiceAuditAlarm)
#define SetFileSecurity __MINGW_NAME_AW(SetFileSecurity)
#define GetFileSecurity __MINGW_NAME_AW(GetFileSecurity)
#define FindFirstChangeNotification __MINGW_NAME_AW(FindFirstChangeNotification)
#define IsBadStringPtr __MINGW_NAME_AW(IsBadStringPtr)
#define LookupAccountSid __MINGW_NAME_AW(LookupAccountSid)
#define LookupAccountName __MINGW_NAME_AW(LookupAccountName)
#define LookupPrivilegeValue __MINGW_NAME_AW(LookupPrivilegeValue)
#define LookupPrivilegeName __MINGW_NAME_AW(LookupPrivilegeName)
#define LookupPrivilegeDisplayName __MINGW_NAME_AW(LookupPrivilegeDisplayName)
#define BuildCommDCB __MINGW_NAME_AW(BuildCommDCB)
#define BuildCommDCBAndTimeouts __MINGW_NAME_AW(BuildCommDCBAndTimeouts)
#define CommConfigDialog __MINGW_NAME_AW(CommConfigDialog)
#define GetDefaultCommConfig __MINGW_NAME_AW(GetDefaultCommConfig)
#define SetDefaultCommConfig __MINGW_NAME_AW(SetDefaultCommConfig)
#define GetComputerName __MINGW_NAME_AW(GetComputerName)
#define SetComputerName __MINGW_NAME_AW(SetComputerName)
#define GetComputerNameEx __MINGW_NAME_AW(GetComputerNameEx)
#define SetComputerNameEx __MINGW_NAME_AW(SetComputerNameEx)
#define DnsHostnameToComputerName __MINGW_NAME_AW(DnsHostnameToComputerName)
#define GetUserName __MINGW_NAME_AW(GetUserName)

  DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileExA(LPCSTR lpFileName,FINDEX_INFO_LEVELS fInfoLevelId,LPVOID lpFindFileData,FINDEX_SEARCH_OPS fSearchOp,LPVOID lpSearchFilter,DWORD dwAdditionalFlags);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileExW(LPCWSTR lpFileName,FINDEX_INFO_LEVELS fInfoLevelId,LPVOID lpFindFileData,FINDEX_SEARCH_OPS fSearchOp,LPVOID lpSearchFilter,DWORD dwAdditionalFlags);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileA(LPCSTR lpFileName,LPWIN32_FIND_DATAA lpFindFileData);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileW(LPCWSTR lpFileName,LPWIN32_FIND_DATAW lpFindFileData);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextFileA(HANDLE hFindFile,LPWIN32_FIND_DATAA lpFindFileData);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextFileW(HANDLE hFindFile,LPWIN32_FIND_DATAW lpFindFileData);
  DECLSPEC_IMPORT DWORD WINAPI SearchPathA(LPCSTR lpPath,LPCSTR lpFileName,LPCSTR lpExtension,DWORD nBufferLength,LPSTR lpBuffer,LPSTR *lpFilePart);
  DECLSPEC_IMPORT DWORD WINAPI SearchPathW(LPCWSTR lpPath,LPCWSTR lpFileName,LPCWSTR lpExtension,DWORD nBufferLength,LPWSTR lpBuffer,LPWSTR *lpFilePart);
  DECLSPEC_IMPORT WINBOOL WINAPI CopyFileA(LPCSTR lpExistingFileName,LPCSTR lpNewFileName,WINBOOL bFailIfExists);
  DECLSPEC_IMPORT WINBOOL WINAPI CopyFileW(LPCWSTR lpExistingFileName,LPCWSTR lpNewFileName,WINBOOL bFailIfExists);

  typedef DWORD (WINAPI *LPPROGRESS_ROUTINE)(LARGE_INTEGER TotalFileSize,LARGE_INTEGER TotalBytesTransferred,LARGE_INTEGER StreamSize,LARGE_INTEGER StreamBytesTransferred,DWORD dwStreamNumber,DWORD dwCallbackReason,HANDLE hSourceFile,HANDLE hDestinationFile,LPVOID lpData);

  DECLSPEC_IMPORT WINBOOL WINAPI CopyFileExA(LPCSTR lpExistingFileName,LPCSTR lpNewFileName,LPPROGRESS_ROUTINE lpProgressRoutine,LPVOID lpData,LPBOOL pbCancel,DWORD dwCopyFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI CopyFileExW(LPCWSTR lpExistingFileName,LPCWSTR lpNewFileName,LPPROGRESS_ROUTINE lpProgressRoutine,LPVOID lpData,LPBOOL pbCancel,DWORD dwCopyFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI MoveFileA(LPCSTR lpExistingFileName,LPCSTR lpNewFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI MoveFileW(LPCWSTR lpExistingFileName,LPCWSTR lpNewFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI MoveFileExA(LPCSTR lpExistingFileName,LPCSTR lpNewFileName,DWORD dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI MoveFileExW(LPCWSTR lpExistingFileName,LPCWSTR lpNewFileName,DWORD dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI MoveFileWithProgressA(LPCSTR lpExistingFileName,LPCSTR lpNewFileName,LPPROGRESS_ROUTINE lpProgressRoutine,LPVOID lpData,DWORD dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI MoveFileWithProgressW(LPCWSTR lpExistingFileName,LPCWSTR lpNewFileName,LPPROGRESS_ROUTINE lpProgressRoutine,LPVOID lpData,DWORD dwFlags);

#define MOVEFILE_REPLACE_EXISTING 0x1
#define MOVEFILE_COPY_ALLOWED 0x2
#define MOVEFILE_DELAY_UNTIL_REBOOT 0x4
#define MOVEFILE_WRITE_THROUGH 0x8
#define MOVEFILE_CREATE_HARDLINK 0x10
#define MOVEFILE_FAIL_IF_NOT_TRACKABLE 0x20

  DECLSPEC_IMPORT WINBOOL WINAPI ReplaceFileA(LPCSTR lpReplacedFileName,LPCSTR lpReplacementFileName,LPCSTR lpBackupFileName,DWORD dwReplaceFlags,LPVOID lpExclude,LPVOID lpReserved);
  DECLSPEC_IMPORT WINBOOL WINAPI ReplaceFileW(LPCWSTR lpReplacedFileName,LPCWSTR lpReplacementFileName,LPCWSTR lpBackupFileName,DWORD dwReplaceFlags,LPVOID lpExclude,LPVOID lpReserved);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateHardLinkA(LPCSTR lpFileName,LPCSTR lpExistingFileName,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateHardLinkW(LPCWSTR lpFileName,LPCWSTR lpExistingFileName,LPSECURITY_ATTRIBUTES lpSecurityAttributes);

  typedef enum _STREAM_INFO_LEVELS {
    FindStreamInfoStandard,FindStreamInfoMaxInfoLevel
  } STREAM_INFO_LEVELS;

  typedef struct _WIN32_FIND_STREAM_DATA {
    LARGE_INTEGER StreamSize;
    WCHAR cStreamName[MAX_PATH + 36];
  } WIN32_FIND_STREAM_DATA,*PWIN32_FIND_STREAM_DATA;

  HANDLE WINAPI FindFirstStreamW(LPCWSTR lpFileName,STREAM_INFO_LEVELS InfoLevel,LPVOID lpFindStreamData,DWORD dwFlags);
  WINBOOL WINAPI FindNextStreamW(HANDLE hFindStream,LPVOID lpFindStreamData);
  DECLSPEC_IMPORT HANDLE WINAPI CreateNamedPipeA(LPCSTR lpName,DWORD dwOpenMode,DWORD dwPipeMode,DWORD nMaxInstances,DWORD nOutBufferSize,DWORD nInBufferSize,DWORD nDefaultTimeOut,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT HANDLE WINAPI CreateNamedPipeW(LPCWSTR lpName,DWORD dwOpenMode,DWORD dwPipeMode,DWORD nMaxInstances,DWORD nOutBufferSize,DWORD nInBufferSize,DWORD nDefaultTimeOut,LPSECURITY_ATTRIBUTES lpSecurityAttributes);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeHandleStateA(HANDLE hNamedPipe,LPDWORD lpState,LPDWORD lpCurInstances,LPDWORD lpMaxCollectionCount,LPDWORD lpCollectDataTimeout,LPSTR lpUserName,DWORD nMaxUserNameSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeHandleStateW(HANDLE hNamedPipe,LPDWORD lpState,LPDWORD lpCurInstances,LPDWORD lpMaxCollectionCount,LPDWORD lpCollectDataTimeout,LPWSTR lpUserName,DWORD nMaxUserNameSize);
  DECLSPEC_IMPORT WINBOOL WINAPI CallNamedPipeA(LPCSTR lpNamedPipeName,LPVOID lpInBuffer,DWORD nInBufferSize,LPVOID lpOutBuffer,DWORD nOutBufferSize,LPDWORD lpBytesRead,DWORD nTimeOut);
  DECLSPEC_IMPORT WINBOOL WINAPI CallNamedPipeW(LPCWSTR lpNamedPipeName,LPVOID lpInBuffer,DWORD nInBufferSize,LPVOID lpOutBuffer,DWORD nOutBufferSize,LPDWORD lpBytesRead,DWORD nTimeOut);
  DECLSPEC_IMPORT WINBOOL WINAPI WaitNamedPipeA(LPCSTR lpNamedPipeName,DWORD nTimeOut);
  DECLSPEC_IMPORT WINBOOL WINAPI WaitNamedPipeW(LPCWSTR lpNamedPipeName,DWORD nTimeOut);
  DECLSPEC_IMPORT WINBOOL WINAPI SetVolumeLabelA(LPCSTR lpRootPathName,LPCSTR lpVolumeName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetVolumeLabelW(LPCWSTR lpRootPathName,LPCWSTR lpVolumeName);
  DECLSPEC_IMPORT VOID WINAPI SetFileApisToOEM(VOID);
  DECLSPEC_IMPORT VOID WINAPI SetFileApisToANSI(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI AreFileApisANSI(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumeInformationA(LPCSTR lpRootPathName,LPSTR lpVolumeNameBuffer,DWORD nVolumeNameSize,LPDWORD lpVolumeSerialNumber,LPDWORD lpMaximumComponentLength,LPDWORD lpFileSystemFlags,LPSTR lpFileSystemNameBuffer,DWORD nFileSystemNameSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumeInformationW(LPCWSTR lpRootPathName,LPWSTR lpVolumeNameBuffer,DWORD nVolumeNameSize,LPDWORD lpVolumeSerialNumber,LPDWORD lpMaximumComponentLength,LPDWORD lpFileSystemFlags,LPWSTR lpFileSystemNameBuffer,DWORD nFileSystemNameSize);
  DECLSPEC_IMPORT WINBOOL WINAPI CancelIo(HANDLE hFile);
  DECLSPEC_IMPORT WINBOOL WINAPI ClearEventLogA(HANDLE hEventLog,LPCSTR lpBackupFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI ClearEventLogW(HANDLE hEventLog,LPCWSTR lpBackupFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI BackupEventLogA(HANDLE hEventLog,LPCSTR lpBackupFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI BackupEventLogW(HANDLE hEventLog,LPCWSTR lpBackupFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI CloseEventLog(HANDLE hEventLog);
  DECLSPEC_IMPORT WINBOOL WINAPI DeregisterEventSource(HANDLE hEventLog);
  DECLSPEC_IMPORT WINBOOL WINAPI NotifyChangeEventLog(HANDLE hEventLog,HANDLE hEvent);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNumberOfEventLogRecords(HANDLE hEventLog,PDWORD NumberOfRecords);
  DECLSPEC_IMPORT WINBOOL WINAPI GetOldestEventLogRecord(HANDLE hEventLog,PDWORD OldestRecord);
  DECLSPEC_IMPORT HANDLE WINAPI OpenEventLogA(LPCSTR lpUNCServerName,LPCSTR lpSourceName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenEventLogW(LPCWSTR lpUNCServerName,LPCWSTR lpSourceName);
  DECLSPEC_IMPORT HANDLE WINAPI RegisterEventSourceA(LPCSTR lpUNCServerName,LPCSTR lpSourceName);
  DECLSPEC_IMPORT HANDLE WINAPI RegisterEventSourceW(LPCWSTR lpUNCServerName,LPCWSTR lpSourceName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenBackupEventLogA(LPCSTR lpUNCServerName,LPCSTR lpFileName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenBackupEventLogW(LPCWSTR lpUNCServerName,LPCWSTR lpFileName);
  DECLSPEC_IMPORT WINBOOL WINAPI ReadEventLogA(HANDLE hEventLog,DWORD dwReadFlags,DWORD dwRecordOffset,LPVOID lpBuffer,DWORD nNumberOfBytesToRead,DWORD *pnBytesRead,DWORD *pnMinNumberOfBytesNeeded);
  DECLSPEC_IMPORT WINBOOL WINAPI ReadEventLogW(HANDLE hEventLog,DWORD dwReadFlags,DWORD dwRecordOffset,LPVOID lpBuffer,DWORD nNumberOfBytesToRead,DWORD *pnBytesRead,DWORD *pnMinNumberOfBytesNeeded);
  DECLSPEC_IMPORT WINBOOL WINAPI ReportEventA(HANDLE hEventLog,WORD wType,WORD wCategory,DWORD dwEventID,PSID lpUserSid,WORD wNumStrings,DWORD dwDataSize,LPCSTR *lpStrings,LPVOID lpRawData);
  DECLSPEC_IMPORT WINBOOL WINAPI ReportEventW(HANDLE hEventLog,WORD wType,WORD wCategory,DWORD dwEventID,PSID lpUserSid,WORD wNumStrings,DWORD dwDataSize,LPCWSTR *lpStrings,LPVOID lpRawData);

#define EVENTLOG_FULL_INFO 0

  typedef struct _EVENTLOG_FULL_INFORMATION {
    DWORD dwFull;
  } EVENTLOG_FULL_INFORMATION,*LPEVENTLOG_FULL_INFORMATION;

  DECLSPEC_IMPORT WINBOOL WINAPI GetEventLogInformation(HANDLE hEventLog,DWORD dwInfoLevel,LPVOID lpBuffer,DWORD cbBufSize,LPDWORD pcbBytesNeeded);
  DECLSPEC_IMPORT WINBOOL WINAPI DuplicateToken(HANDLE ExistingTokenHandle,SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,PHANDLE DuplicateTokenHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI GetKernelObjectSecurity(HANDLE Handle,SECURITY_INFORMATION RequestedInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor,DWORD nLength,LPDWORD lpnLengthNeeded);
  DECLSPEC_IMPORT WINBOOL WINAPI ImpersonateNamedPipeClient(HANDLE hNamedPipe);
  DECLSPEC_IMPORT WINBOOL WINAPI ImpersonateSelf(SECURITY_IMPERSONATION_LEVEL ImpersonationLevel);
  DECLSPEC_IMPORT WINBOOL WINAPI RevertToSelf(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI SetThreadToken (PHANDLE Thread,HANDLE Token);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheck(PSECURITY_DESCRIPTOR pSecurityDescriptor,HANDLE ClientToken,DWORD DesiredAccess,PGENERIC_MAPPING GenericMapping,PPRIVILEGE_SET PrivilegeSet,LPDWORD PrivilegeSetLength,LPDWORD GrantedAccess,LPBOOL AccessStatus);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByType(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSID PrincipalSelfSid,HANDLE ClientToken,DWORD DesiredAccess,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,PPRIVILEGE_SET PrivilegeSet,LPDWORD PrivilegeSetLength,LPDWORD GrantedAccess,LPBOOL AccessStatus);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeResultList(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSID PrincipalSelfSid,HANDLE ClientToken,DWORD DesiredAccess,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,PPRIVILEGE_SET PrivilegeSet,LPDWORD PrivilegeSetLength,LPDWORD GrantedAccessList,LPDWORD AccessStatusList);
  DECLSPEC_IMPORT WINBOOL WINAPI OpenProcessToken(HANDLE ProcessHandle,DWORD DesiredAccess,PHANDLE TokenHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI OpenThreadToken(HANDLE ThreadHandle,DWORD DesiredAccess,WINBOOL OpenAsSelf,PHANDLE TokenHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI GetTokenInformation(HANDLE TokenHandle,TOKEN_INFORMATION_CLASS TokenInformationClass,LPVOID TokenInformation,DWORD TokenInformationLength,PDWORD ReturnLength);
  DECLSPEC_IMPORT WINBOOL WINAPI SetTokenInformation(HANDLE TokenHandle,TOKEN_INFORMATION_CLASS TokenInformationClass,LPVOID TokenInformation,DWORD TokenInformationLength);
  DECLSPEC_IMPORT WINBOOL WINAPI AdjustTokenPrivileges(HANDLE TokenHandle,WINBOOL DisableAllPrivileges,PTOKEN_PRIVILEGES NewState,DWORD BufferLength,PTOKEN_PRIVILEGES PreviousState,PDWORD ReturnLength);
  DECLSPEC_IMPORT WINBOOL WINAPI AdjustTokenGroups(HANDLE TokenHandle,WINBOOL ResetToDefault,PTOKEN_GROUPS NewState,DWORD BufferLength,PTOKEN_GROUPS PreviousState,PDWORD ReturnLength);
  DECLSPEC_IMPORT WINBOOL WINAPI PrivilegeCheck(HANDLE ClientToken,PPRIVILEGE_SET RequiredPrivileges,LPBOOL pfResult);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckAndAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,LPSTR ObjectTypeName,LPSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,DWORD DesiredAccess,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPBOOL AccessStatus,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckAndAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,LPWSTR ObjectTypeName,LPWSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,DWORD DesiredAccess,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPBOOL AccessStatus,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeAndAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,LPCSTR ObjectTypeName,LPCSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,PSID PrincipalSelfSid,DWORD DesiredAccess,AUDIT_EVENT_TYPE AuditType,DWORD Flags,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPBOOL AccessStatus,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeAndAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,LPCWSTR ObjectTypeName,LPCWSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,PSID PrincipalSelfSid,DWORD DesiredAccess,AUDIT_EVENT_TYPE AuditType,DWORD Flags,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPBOOL AccessStatus,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeResultListAndAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,LPCSTR ObjectTypeName,LPCSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,PSID PrincipalSelfSid,DWORD DesiredAccess,AUDIT_EVENT_TYPE AuditType,DWORD Flags,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPDWORD AccessStatusList,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeResultListAndAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,LPCWSTR ObjectTypeName,LPCWSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,PSID PrincipalSelfSid,DWORD DesiredAccess,AUDIT_EVENT_TYPE AuditType,DWORD Flags,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPDWORD AccessStatusList,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeResultListAndAuditAlarmByHandleA(LPCSTR SubsystemName,LPVOID HandleId,HANDLE ClientToken,LPCSTR ObjectTypeName,LPCSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,PSID PrincipalSelfSid,DWORD DesiredAccess,AUDIT_EVENT_TYPE AuditType,DWORD Flags,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPDWORD AccessStatusList,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI AccessCheckByTypeResultListAndAuditAlarmByHandleW(LPCWSTR SubsystemName,LPVOID HandleId,HANDLE ClientToken,LPCWSTR ObjectTypeName,LPCWSTR ObjectName,PSECURITY_DESCRIPTOR SecurityDescriptor,PSID PrincipalSelfSid,DWORD DesiredAccess,AUDIT_EVENT_TYPE AuditType,DWORD Flags,POBJECT_TYPE_LIST ObjectTypeList,DWORD ObjectTypeListLength,PGENERIC_MAPPING GenericMapping,WINBOOL ObjectCreation,LPDWORD GrantedAccess,LPDWORD AccessStatusList,LPBOOL pfGenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectOpenAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,LPSTR ObjectTypeName,LPSTR ObjectName,PSECURITY_DESCRIPTOR pSecurityDescriptor,HANDLE ClientToken,DWORD DesiredAccess,DWORD GrantedAccess,PPRIVILEGE_SET Privileges,WINBOOL ObjectCreation,WINBOOL AccessGranted,LPBOOL GenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectOpenAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,LPWSTR ObjectTypeName,LPWSTR ObjectName,PSECURITY_DESCRIPTOR pSecurityDescriptor,HANDLE ClientToken,DWORD DesiredAccess,DWORD GrantedAccess,PPRIVILEGE_SET Privileges,WINBOOL ObjectCreation,WINBOOL AccessGranted,LPBOOL GenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectPrivilegeAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,HANDLE ClientToken,DWORD DesiredAccess,PPRIVILEGE_SET Privileges,WINBOOL AccessGranted);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectPrivilegeAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,HANDLE ClientToken,DWORD DesiredAccess,PPRIVILEGE_SET Privileges,WINBOOL AccessGranted);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectCloseAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,WINBOOL GenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectCloseAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,WINBOOL GenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectDeleteAuditAlarmA(LPCSTR SubsystemName,LPVOID HandleId,WINBOOL GenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI ObjectDeleteAuditAlarmW(LPCWSTR SubsystemName,LPVOID HandleId,WINBOOL GenerateOnClose);
  DECLSPEC_IMPORT WINBOOL WINAPI PrivilegedServiceAuditAlarmA(LPCSTR SubsystemName,LPCSTR ServiceName,HANDLE ClientToken,PPRIVILEGE_SET Privileges,WINBOOL AccessGranted);
  DECLSPEC_IMPORT WINBOOL WINAPI PrivilegedServiceAuditAlarmW(LPCWSTR SubsystemName,LPCWSTR ServiceName,HANDLE ClientToken,PPRIVILEGE_SET Privileges,WINBOOL AccessGranted);
  DECLSPEC_IMPORT WINBOOL WINAPI IsWellKnownSid(PSID pSid,WELL_KNOWN_SID_TYPE WellKnownSidType);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateWellKnownSid(WELL_KNOWN_SID_TYPE WellKnownSidType,PSID DomainSid,PSID pSid,DWORD *cbSid);
  DECLSPEC_IMPORT WINBOOL WINAPI EqualDomainSid(PSID pSid1,PSID pSid2,WINBOOL *pfEqual);
  DECLSPEC_IMPORT WINBOOL WINAPI GetWindowsAccountDomainSid(PSID pSid,PSID pDomainSid,DWORD *cbDomainSid);
  DECLSPEC_IMPORT WINBOOL WINAPI IsValidSid(PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI EqualSid(PSID pSid1,PSID pSid2);
  DECLSPEC_IMPORT WINBOOL WINAPI EqualPrefixSid(PSID pSid1,PSID pSid2);
  DECLSPEC_IMPORT DWORD WINAPI GetSidLengthRequired (UCHAR nSubAuthorityCount);
  DECLSPEC_IMPORT WINBOOL WINAPI AllocateAndInitializeSid(PSID_IDENTIFIER_AUTHORITY pIdentifierAuthority,BYTE nSubAuthorityCount,DWORD nSubAuthority0,DWORD nSubAuthority1,DWORD nSubAuthority2,DWORD nSubAuthority3,DWORD nSubAuthority4,DWORD nSubAuthority5,DWORD nSubAuthority6,DWORD nSubAuthority7,PSID *pSid);
  DECLSPEC_IMPORT PVOID WINAPI FreeSid(PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI InitializeSid(PSID Sid,PSID_IDENTIFIER_AUTHORITY pIdentifierAuthority,BYTE nSubAuthorityCount);
  DECLSPEC_IMPORT PSID_IDENTIFIER_AUTHORITY WINAPI GetSidIdentifierAuthority(PSID pSid);
  DECLSPEC_IMPORT PDWORD WINAPI GetSidSubAuthority(PSID pSid,DWORD nSubAuthority);
  DECLSPEC_IMPORT PUCHAR WINAPI GetSidSubAuthorityCount(PSID pSid);
  DECLSPEC_IMPORT DWORD WINAPI GetLengthSid(PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI CopySid(DWORD nDestinationSidLength,PSID pDestinationSid,PSID pSourceSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AreAllAccessesGranted(DWORD GrantedAccess,DWORD DesiredAccess);
  DECLSPEC_IMPORT WINBOOL WINAPI AreAnyAccessesGranted(DWORD GrantedAccess,DWORD DesiredAccess);
  DECLSPEC_IMPORT VOID WINAPI MapGenericMask(PDWORD AccessMask,PGENERIC_MAPPING GenericMapping);
  DECLSPEC_IMPORT WINBOOL WINAPI IsValidAcl(PACL pAcl);
  DECLSPEC_IMPORT WINBOOL WINAPI InitializeAcl(PACL pAcl,DWORD nAclLength,DWORD dwAclRevision);
  DECLSPEC_IMPORT WINBOOL WINAPI GetAclInformation(PACL pAcl,LPVOID pAclInformation,DWORD nAclInformationLength,ACL_INFORMATION_CLASS dwAclInformationClass);
  DECLSPEC_IMPORT WINBOOL WINAPI SetAclInformation(PACL pAcl,LPVOID pAclInformation,DWORD nAclInformationLength,ACL_INFORMATION_CLASS dwAclInformationClass);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAce(PACL pAcl,DWORD dwAceRevision,DWORD dwStartingAceIndex,LPVOID pAceList,DWORD nAceListLength);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteAce(PACL pAcl,DWORD dwAceIndex);
  DECLSPEC_IMPORT WINBOOL WINAPI GetAce(PACL pAcl,DWORD dwAceIndex,LPVOID *pAce);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAccessAllowedAce(PACL pAcl,DWORD dwAceRevision,DWORD AccessMask,PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAccessAllowedAceEx(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD AccessMask,PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAccessDeniedAce(PACL pAcl,DWORD dwAceRevision,DWORD AccessMask,PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAccessDeniedAceEx(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD AccessMask,PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAuditAccessAce(PACL pAcl,DWORD dwAceRevision,DWORD dwAccessMask,PSID pSid,WINBOOL bAuditSuccess,WINBOOL bAuditFailure);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAuditAccessAceEx(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD dwAccessMask,PSID pSid,WINBOOL bAuditSuccess,WINBOOL bAuditFailure);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAccessAllowedObjectAce(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD AccessMask,GUID *ObjectTypeGuid,GUID *InheritedObjectTypeGuid,PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAccessDeniedObjectAce(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD AccessMask,GUID *ObjectTypeGuid,GUID *InheritedObjectTypeGuid,PSID pSid);
  DECLSPEC_IMPORT WINBOOL WINAPI AddAuditAccessObjectAce(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD AccessMask,GUID *ObjectTypeGuid,GUID *InheritedObjectTypeGuid,PSID pSid,WINBOOL bAuditSuccess,WINBOOL bAuditFailure);
  DECLSPEC_IMPORT WINBOOL WINAPI FindFirstFreeAce(PACL pAcl,LPVOID *pAce);
  DECLSPEC_IMPORT WINBOOL WINAPI InitializeSecurityDescriptor(PSECURITY_DESCRIPTOR pSecurityDescriptor,DWORD dwRevision);
  DECLSPEC_IMPORT WINBOOL WINAPI IsValidSecurityDescriptor(PSECURITY_DESCRIPTOR pSecurityDescriptor);
  DECLSPEC_IMPORT DWORD WINAPI GetSecurityDescriptorLength(PSECURITY_DESCRIPTOR pSecurityDescriptor);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSecurityDescriptorControl(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSECURITY_DESCRIPTOR_CONTROL pControl,LPDWORD lpdwRevision);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSecurityDescriptorControl(PSECURITY_DESCRIPTOR pSecurityDescriptor,SECURITY_DESCRIPTOR_CONTROL ControlBitsOfInterest,SECURITY_DESCRIPTOR_CONTROL ControlBitsToSet);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSecurityDescriptorDacl(PSECURITY_DESCRIPTOR pSecurityDescriptor,WINBOOL bDaclPresent,PACL pDacl,WINBOOL bDaclDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSecurityDescriptorDacl(PSECURITY_DESCRIPTOR pSecurityDescriptor,LPBOOL lpbDaclPresent,PACL *pDacl,LPBOOL lpbDaclDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSecurityDescriptorSacl(PSECURITY_DESCRIPTOR pSecurityDescriptor,WINBOOL bSaclPresent,PACL pSacl,WINBOOL bSaclDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSecurityDescriptorSacl(PSECURITY_DESCRIPTOR pSecurityDescriptor,LPBOOL lpbSaclPresent,PACL *pSacl,LPBOOL lpbSaclDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSecurityDescriptorOwner(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSID pOwner,WINBOOL bOwnerDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSecurityDescriptorOwner(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSID *pOwner,LPBOOL lpbOwnerDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI SetSecurityDescriptorGroup(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSID pGroup,WINBOOL bGroupDefaulted);
  DECLSPEC_IMPORT WINBOOL WINAPI GetSecurityDescriptorGroup(PSECURITY_DESCRIPTOR pSecurityDescriptor,PSID *pGroup,LPBOOL lpbGroupDefaulted);
  DECLSPEC_IMPORT DWORD WINAPI SetSecurityDescriptorRMControl(PSECURITY_DESCRIPTOR SecurityDescriptor,PUCHAR RMControl);
  DECLSPEC_IMPORT DWORD WINAPI GetSecurityDescriptorRMControl(PSECURITY_DESCRIPTOR SecurityDescriptor,PUCHAR RMControl);
  DECLSPEC_IMPORT WINBOOL WINAPI CreatePrivateObjectSecurity(PSECURITY_DESCRIPTOR ParentDescriptor,PSECURITY_DESCRIPTOR CreatorDescriptor,PSECURITY_DESCRIPTOR *NewDescriptor,WINBOOL IsDirectoryObject,HANDLE Token,PGENERIC_MAPPING GenericMapping);
  DECLSPEC_IMPORT WINBOOL WINAPI ConvertToAutoInheritPrivateObjectSecurity(PSECURITY_DESCRIPTOR ParentDescriptor,PSECURITY_DESCRIPTOR CurrentSecurityDescriptor,PSECURITY_DESCRIPTOR *NewSecurityDescriptor,GUID *ObjectType,BOOLEAN IsDirectoryObject,PGENERIC_MAPPING GenericMapping);
  DECLSPEC_IMPORT WINBOOL WINAPI CreatePrivateObjectSecurityEx(PSECURITY_DESCRIPTOR ParentDescriptor,PSECURITY_DESCRIPTOR CreatorDescriptor,PSECURITY_DESCRIPTOR *NewDescriptor,GUID *ObjectType,WINBOOL IsContainerObject,ULONG AutoInheritFlags,HANDLE Token,PGENERIC_MAPPING GenericMapping);
  DECLSPEC_IMPORT WINBOOL WINAPI CreatePrivateObjectSecurityWithMultipleInheritance(PSECURITY_DESCRIPTOR ParentDescriptor,PSECURITY_DESCRIPTOR CreatorDescriptor,PSECURITY_DESCRIPTOR *NewDescriptor,GUID **ObjectTypes,ULONG GuidCount,WINBOOL IsContainerObject,ULONG AutoInheritFlags,HANDLE Token,PGENERIC_MAPPING GenericMapping);
  DECLSPEC_IMPORT WINBOOL WINAPI SetPrivateObjectSecurity (SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR ModificationDescriptor,PSECURITY_DESCRIPTOR *ObjectsSecurityDescriptor,PGENERIC_MAPPING GenericMapping,HANDLE Token);
  DECLSPEC_IMPORT WINBOOL WINAPI SetPrivateObjectSecurityEx (SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR ModificationDescriptor,PSECURITY_DESCRIPTOR *ObjectsSecurityDescriptor,ULONG AutoInheritFlags,PGENERIC_MAPPING GenericMapping,HANDLE Token);
  DECLSPEC_IMPORT WINBOOL WINAPI GetPrivateObjectSecurity(PSECURITY_DESCRIPTOR ObjectDescriptor,SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR ResultantDescriptor,DWORD DescriptorLength,PDWORD ReturnLength);
  DECLSPEC_IMPORT WINBOOL WINAPI DestroyPrivateObjectSecurity(PSECURITY_DESCRIPTOR *ObjectDescriptor);
  DECLSPEC_IMPORT WINBOOL WINAPI MakeSelfRelativeSD(PSECURITY_DESCRIPTOR pAbsoluteSecurityDescriptor,PSECURITY_DESCRIPTOR pSelfRelativeSecurityDescriptor,LPDWORD lpdwBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI MakeAbsoluteSD(PSECURITY_DESCRIPTOR pSelfRelativeSecurityDescriptor,PSECURITY_DESCRIPTOR pAbsoluteSecurityDescriptor,LPDWORD lpdwAbsoluteSecurityDescriptorSize,PACL pDacl,LPDWORD lpdwDaclSize,PACL pSacl,LPDWORD lpdwSaclSize,PSID pOwner,LPDWORD lpdwOwnerSize,PSID pPrimaryGroup,LPDWORD lpdwPrimaryGroupSize);
  DECLSPEC_IMPORT WINBOOL WINAPI MakeAbsoluteSD2(PSECURITY_DESCRIPTOR pSelfRelativeSecurityDescriptor,LPDWORD lpdwBufferSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileSecurityA(LPCSTR lpFileName,SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor);
  DECLSPEC_IMPORT WINBOOL WINAPI SetFileSecurityW(LPCWSTR lpFileName,SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor);
  DECLSPEC_IMPORT WINBOOL WINAPI GetFileSecurityA(LPCSTR lpFileName,SECURITY_INFORMATION RequestedInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor,DWORD nLength,LPDWORD lpnLengthNeeded);
  DECLSPEC_IMPORT WINBOOL WINAPI GetFileSecurityW(LPCWSTR lpFileName,SECURITY_INFORMATION RequestedInformation,PSECURITY_DESCRIPTOR pSecurityDescriptor,DWORD nLength,LPDWORD lpnLengthNeeded);
  DECLSPEC_IMPORT WINBOOL WINAPI SetKernelObjectSecurity(HANDLE Handle,SECURITY_INFORMATION SecurityInformation,PSECURITY_DESCRIPTOR SecurityDescriptor);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstChangeNotificationA(LPCSTR lpPathName,WINBOOL bWatchSubtree,DWORD dwNotifyFilter);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstChangeNotificationW(LPCWSTR lpPathName,WINBOOL bWatchSubtree,DWORD dwNotifyFilter);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextChangeNotification(HANDLE hChangeHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI FindCloseChangeNotification(HANDLE hChangeHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI ReadDirectoryChangesW(HANDLE hDirectory,LPVOID lpBuffer,DWORD nBufferLength,WINBOOL bWatchSubtree,DWORD dwNotifyFilter,LPDWORD lpBytesReturned,LPOVERLAPPED lpOverlapped,LPOVERLAPPED_COMPLETION_ROUTINE lpCompletionRoutine);
  DECLSPEC_IMPORT WINBOOL WINAPI VirtualLock(LPVOID lpAddress,SIZE_T dwSize);
  DECLSPEC_IMPORT WINBOOL WINAPI VirtualUnlock(LPVOID lpAddress,SIZE_T dwSize);
  DECLSPEC_IMPORT LPVOID WINAPI MapViewOfFileEx(HANDLE hFileMappingObject,DWORD dwDesiredAccess,DWORD dwFileOffsetHigh,DWORD dwFileOffsetLow,SIZE_T dwNumberOfBytesToMap,LPVOID lpBaseAddress);
  DECLSPEC_IMPORT WINBOOL WINAPI SetPriorityClass(HANDLE hProcess,DWORD dwPriorityClass);
  DECLSPEC_IMPORT DWORD WINAPI GetPriorityClass(HANDLE hProcess);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadReadPtr(CONST VOID *lp,UINT_PTR ucb);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadWritePtr(LPVOID lp,UINT_PTR ucb);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadHugeReadPtr(CONST VOID *lp,UINT_PTR ucb);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadHugeWritePtr(LPVOID lp,UINT_PTR ucb);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadCodePtr(FARPROC lpfn);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadStringPtrA(LPCSTR lpsz,UINT_PTR ucchMax);
  DECLSPEC_IMPORT WINBOOL WINAPI IsBadStringPtrW(LPCWSTR lpsz,UINT_PTR ucchMax);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupAccountSidA(LPCSTR lpSystemName,PSID Sid,LPSTR Name,LPDWORD cchName,LPSTR ReferencedDomainName,LPDWORD cchReferencedDomainName,PSID_NAME_USE peUse);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupAccountSidW(LPCWSTR lpSystemName,PSID Sid,LPWSTR Name,LPDWORD cchName,LPWSTR ReferencedDomainName,LPDWORD cchReferencedDomainName,PSID_NAME_USE peUse);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupAccountNameA(LPCSTR lpSystemName,LPCSTR lpAccountName,PSID Sid,LPDWORD cbSid,LPSTR ReferencedDomainName,LPDWORD cchReferencedDomainName,PSID_NAME_USE peUse);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupAccountNameW(LPCWSTR lpSystemName,LPCWSTR lpAccountName,PSID Sid,LPDWORD cbSid,LPWSTR ReferencedDomainName,LPDWORD cchReferencedDomainName,PSID_NAME_USE peUse);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupPrivilegeValueA(LPCSTR lpSystemName,LPCSTR lpName,PLUID lpLuid);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupPrivilegeValueW(LPCWSTR lpSystemName,LPCWSTR lpName,PLUID lpLuid);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupPrivilegeNameA(LPCSTR lpSystemName,PLUID lpLuid,LPSTR lpName,LPDWORD cchName);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupPrivilegeNameW(LPCWSTR lpSystemName,PLUID lpLuid,LPWSTR lpName,LPDWORD cchName);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupPrivilegeDisplayNameA(LPCSTR lpSystemName,LPCSTR lpName,LPSTR lpDisplayName,LPDWORD cchDisplayName,LPDWORD lpLanguageId);
  DECLSPEC_IMPORT WINBOOL WINAPI LookupPrivilegeDisplayNameW(LPCWSTR lpSystemName,LPCWSTR lpName,LPWSTR lpDisplayName,LPDWORD cchDisplayName,LPDWORD lpLanguageId);
  DECLSPEC_IMPORT WINBOOL WINAPI AllocateLocallyUniqueId(PLUID Luid);
  DECLSPEC_IMPORT WINBOOL WINAPI BuildCommDCBA(LPCSTR lpDef,LPDCB lpDCB);
  DECLSPEC_IMPORT WINBOOL WINAPI BuildCommDCBW(LPCWSTR lpDef,LPDCB lpDCB);
  DECLSPEC_IMPORT WINBOOL WINAPI BuildCommDCBAndTimeoutsA(LPCSTR lpDef,LPDCB lpDCB,LPCOMMTIMEOUTS lpCommTimeouts);
  DECLSPEC_IMPORT WINBOOL WINAPI BuildCommDCBAndTimeoutsW(LPCWSTR lpDef,LPDCB lpDCB,LPCOMMTIMEOUTS lpCommTimeouts);
  DECLSPEC_IMPORT WINBOOL WINAPI CommConfigDialogA(LPCSTR lpszName,HWND hWnd,LPCOMMCONFIG lpCC);
  DECLSPEC_IMPORT WINBOOL WINAPI CommConfigDialogW(LPCWSTR lpszName,HWND hWnd,LPCOMMCONFIG lpCC);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDefaultCommConfigA(LPCSTR lpszName,LPCOMMCONFIG lpCC,LPDWORD lpdwSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetDefaultCommConfigW(LPCWSTR lpszName,LPCOMMCONFIG lpCC,LPDWORD lpdwSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetDefaultCommConfigA(LPCSTR lpszName,LPCOMMCONFIG lpCC,DWORD dwSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetDefaultCommConfigW(LPCWSTR lpszName,LPCOMMCONFIG lpCC,DWORD dwSize);

#define MAX_COMPUTERNAME_LENGTH 15

  DECLSPEC_IMPORT WINBOOL WINAPI GetComputerNameA(LPSTR lpBuffer,LPDWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetComputerNameW(LPWSTR lpBuffer,LPDWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetComputerNameA(LPCSTR lpComputerName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetComputerNameW(LPCWSTR lpComputerName);

  typedef enum _COMPUTER_NAME_FORMAT {
    ComputerNameNetBIOS,ComputerNameDnsHostname,ComputerNameDnsDomain,ComputerNameDnsFullyQualified,ComputerNamePhysicalNetBIOS,ComputerNamePhysicalDnsHostname,ComputerNamePhysicalDnsDomain,ComputerNamePhysicalDnsFullyQualified,ComputerNameMax
  } COMPUTER_NAME_FORMAT;

  DECLSPEC_IMPORT WINBOOL WINAPI GetComputerNameExA(COMPUTER_NAME_FORMAT NameType,LPSTR lpBuffer,LPDWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetComputerNameExW(COMPUTER_NAME_FORMAT NameType,LPWSTR lpBuffer,LPDWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI SetComputerNameExA(COMPUTER_NAME_FORMAT NameType,LPCSTR lpBuffer);
  DECLSPEC_IMPORT WINBOOL WINAPI SetComputerNameExW(COMPUTER_NAME_FORMAT NameType,LPCWSTR lpBuffer);
  DECLSPEC_IMPORT WINBOOL WINAPI DnsHostnameToComputerNameA(LPCSTR Hostname,LPSTR ComputerName,LPDWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI DnsHostnameToComputerNameW(LPCWSTR Hostname,LPWSTR ComputerName,LPDWORD nSize);
  DECLSPEC_IMPORT WINBOOL WINAPI GetUserNameA(LPSTR lpBuffer,LPDWORD pcbBuffer);
  DECLSPEC_IMPORT WINBOOL WINAPI GetUserNameW(LPWSTR lpBuffer,LPDWORD pcbBuffer);

#define LOGON32_LOGON_INTERACTIVE 2
#define LOGON32_LOGON_NETWORK 3
#define LOGON32_LOGON_BATCH 4
#define LOGON32_LOGON_SERVICE 5
#define LOGON32_LOGON_UNLOCK 7
#define LOGON32_LOGON_NETWORK_CLEARTEXT 8
#define LOGON32_LOGON_NEW_CREDENTIALS 9

#define LOGON32_PROVIDER_DEFAULT 0
#define LOGON32_PROVIDER_WINNT35 1
#define LOGON32_PROVIDER_WINNT40 2
#define LOGON32_PROVIDER_WINNT50 3

#define LogonUser __MINGW_NAME_AW(LogonUser)
#define LogonUserEx __MINGW_NAME_AW(LogonUserEx)
#define CreateProcessAsUser __MINGW_NAME_AW(CreateProcessAsUser)

  DECLSPEC_IMPORT WINBOOL WINAPI LogonUserA(LPCSTR lpszUsername,LPCSTR lpszDomain,LPCSTR lpszPassword,DWORD dwLogonType,DWORD dwLogonProvider,PHANDLE phToken);
  DECLSPEC_IMPORT WINBOOL WINAPI LogonUserW(LPCWSTR lpszUsername,LPCWSTR lpszDomain,LPCWSTR lpszPassword,DWORD dwLogonType,DWORD dwLogonProvider,PHANDLE phToken);
  DECLSPEC_IMPORT WINBOOL WINAPI LogonUserExA(LPCSTR lpszUsername,LPCSTR lpszDomain,LPCSTR lpszPassword,DWORD dwLogonType,DWORD dwLogonProvider,PHANDLE phToken,PSID *ppLogonSid,PVOID *ppProfileBuffer,LPDWORD pdwProfileLength,PQUOTA_LIMITS pQuotaLimits);
  DECLSPEC_IMPORT WINBOOL WINAPI LogonUserExW(LPCWSTR lpszUsername,LPCWSTR lpszDomain,LPCWSTR lpszPassword,DWORD dwLogonType,DWORD dwLogonProvider,PHANDLE phToken,PSID *ppLogonSid,PVOID *ppProfileBuffer,LPDWORD pdwProfileLength,PQUOTA_LIMITS pQuotaLimits);
  DECLSPEC_IMPORT WINBOOL WINAPI ImpersonateLoggedOnUser(HANDLE hToken);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateProcessAsUserA(HANDLE hToken,LPCSTR lpApplicationName,LPSTR lpCommandLine,LPSECURITY_ATTRIBUTES lpProcessAttributes,LPSECURITY_ATTRIBUTES lpThreadAttributes,WINBOOL bInheritHandles,DWORD dwCreationFlags,LPVOID lpEnvironment,LPCSTR lpCurrentDirectory,LPSTARTUPINFOA lpStartupInfo,LPPROCESS_INFORMATION lpProcessInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateProcessAsUserW(HANDLE hToken,LPCWSTR lpApplicationName,LPWSTR lpCommandLine,LPSECURITY_ATTRIBUTES lpProcessAttributes,LPSECURITY_ATTRIBUTES lpThreadAttributes,WINBOOL bInheritHandles,DWORD dwCreationFlags,LPVOID lpEnvironment,LPCWSTR lpCurrentDirectory,LPSTARTUPINFOW lpStartupInfo,LPPROCESS_INFORMATION lpProcessInformation);

#define LOGON_WITH_PROFILE 0x00000001
#define LOGON_NETCREDENTIALS_ONLY 0x00000002
#define LOGON_ZERO_PASSWORD_BUFFER 0x80000000

  DECLSPEC_IMPORT WINBOOL WINAPI CreateProcessWithLogonW(LPCWSTR lpUsername,LPCWSTR lpDomain,LPCWSTR lpPassword,DWORD dwLogonFlags,LPCWSTR lpApplicationName,LPWSTR lpCommandLine,DWORD dwCreationFlags,LPVOID lpEnvironment,LPCWSTR lpCurrentDirectory,LPSTARTUPINFOW lpStartupInfo,LPPROCESS_INFORMATION lpProcessInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateProcessWithTokenW(HANDLE hToken,DWORD dwLogonFlags,LPCWSTR lpApplicationName,LPWSTR lpCommandLine,DWORD dwCreationFlags,LPVOID lpEnvironment,LPCWSTR lpCurrentDirectory,LPSTARTUPINFOW lpStartupInfo,LPPROCESS_INFORMATION lpProcessInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI ImpersonateAnonymousToken(HANDLE ThreadHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI DuplicateTokenEx(HANDLE hExistingToken,DWORD dwDesiredAccess,LPSECURITY_ATTRIBUTES lpTokenAttributes,SECURITY_IMPERSONATION_LEVEL ImpersonationLevel,TOKEN_TYPE TokenType,PHANDLE phNewToken);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateRestrictedToken(HANDLE ExistingTokenHandle,DWORD Flags,DWORD DisableSidCount,PSID_AND_ATTRIBUTES SidsToDisable,DWORD DeletePrivilegeCount,PLUID_AND_ATTRIBUTES PrivilegesToDelete,DWORD RestrictedSidCount,PSID_AND_ATTRIBUTES SidsToRestrict,PHANDLE NewTokenHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI IsTokenRestricted(HANDLE TokenHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI IsTokenUntrusted(HANDLE TokenHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI CheckTokenMembership(HANDLE TokenHandle,PSID SidToCheck,PBOOL IsMember);

  typedef WAITORTIMERCALLBACKFUNC WAITORTIMERCALLBACK;

  DECLSPEC_IMPORT WINBOOL WINAPI RegisterWaitForSingleObject(PHANDLE phNewWaitObject,HANDLE hObject,WAITORTIMERCALLBACK Callback,PVOID Context,ULONG dwMilliseconds,ULONG dwFlags);
  DECLSPEC_IMPORT HANDLE WINAPI RegisterWaitForSingleObjectEx(HANDLE hObject,WAITORTIMERCALLBACK Callback,PVOID Context,ULONG dwMilliseconds,ULONG dwFlags);
  DECLSPEC_IMPORT WINBOOL WINAPI UnregisterWait(HANDLE WaitHandle);
  DECLSPEC_IMPORT WINBOOL WINAPI UnregisterWaitEx(HANDLE WaitHandle,HANDLE CompletionEvent);
  DECLSPEC_IMPORT WINBOOL WINAPI QueueUserWorkItem(LPTHREAD_START_ROUTINE Function,PVOID Context,ULONG Flags);
  DECLSPEC_IMPORT WINBOOL WINAPI BindIoCompletionCallback(HANDLE FileHandle,LPOVERLAPPED_COMPLETION_ROUTINE Function,ULONG Flags);
  DECLSPEC_IMPORT HANDLE WINAPI CreateTimerQueue(VOID);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateTimerQueueTimer(PHANDLE phNewTimer,HANDLE TimerQueue,WAITORTIMERCALLBACK Callback,PVOID Parameter,DWORD DueTime,DWORD Period,ULONG Flags);
  DECLSPEC_IMPORT WINBOOL WINAPI ChangeTimerQueueTimer(HANDLE TimerQueue,HANDLE Timer,ULONG DueTime,ULONG Period);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteTimerQueueTimer(HANDLE TimerQueue,HANDLE Timer,HANDLE CompletionEvent);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteTimerQueueEx(HANDLE TimerQueue,HANDLE CompletionEvent);
  DECLSPEC_IMPORT HANDLE WINAPI SetTimerQueueTimer(HANDLE TimerQueue,WAITORTIMERCALLBACK Callback,PVOID Parameter,DWORD DueTime,DWORD Period,WINBOOL PreferIo);
  DECLSPEC_IMPORT WINBOOL WINAPI CancelTimerQueueTimer(HANDLE TimerQueue,HANDLE Timer);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteTimerQueue(HANDLE TimerQueue);

#define HW_PROFILE_GUIDLEN 39
#define MAX_PROFILE_LEN 80

#define DOCKINFO_UNDOCKED (0x1)
#define DOCKINFO_DOCKED (0x2)
#define DOCKINFO_USER_SUPPLIED (0x4)
#define DOCKINFO_USER_UNDOCKED (DOCKINFO_USER_SUPPLIED | DOCKINFO_UNDOCKED)
#define DOCKINFO_USER_DOCKED (DOCKINFO_USER_SUPPLIED | DOCKINFO_DOCKED)

  typedef struct tagHW_PROFILE_INFOA {
    DWORD dwDockInfo;
    CHAR szHwProfileGuid[39];
    CHAR szHwProfileName[80];
  } HW_PROFILE_INFOA,*LPHW_PROFILE_INFOA;

  typedef struct tagHW_PROFILE_INFOW {
    DWORD dwDockInfo;
    WCHAR szHwProfileGuid[39];
    WCHAR szHwProfileName[80];
  } HW_PROFILE_INFOW,*LPHW_PROFILE_INFOW;

  typedef HW_PROFILE_INFOA HW_PROFILE_INFO;
  typedef LPHW_PROFILE_INFOA LPHW_PROFILE_INFO;

#define GetCurrentHwProfile __MINGW_NAME_AW(GetCurrentHwProfile)
#define GetVersionEx __MINGW_NAME_AW(GetVersionEx)
#define VerifyVersionInfo __MINGW_NAME_AW(VerifyVersionInfo)

  DECLSPEC_IMPORT WINBOOL WINAPI GetCurrentHwProfileA (LPHW_PROFILE_INFOA lpHwProfileInfo);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCurrentHwProfileW (LPHW_PROFILE_INFOW lpHwProfileInfo);
  DECLSPEC_IMPORT WINBOOL WINAPI QueryPerformanceCounter(LARGE_INTEGER *lpPerformanceCount);
  DECLSPEC_IMPORT WINBOOL WINAPI QueryPerformanceFrequency(LARGE_INTEGER *lpFrequency);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVersionExA(LPOSVERSIONINFOA lpVersionInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVersionExW(LPOSVERSIONINFOW lpVersionInformation);
  DECLSPEC_IMPORT WINBOOL WINAPI VerifyVersionInfoA(LPOSVERSIONINFOEXA lpVersionInformation,DWORD dwTypeMask,DWORDLONG dwlConditionMask);
  DECLSPEC_IMPORT WINBOOL WINAPI VerifyVersionInfoW(LPOSVERSIONINFOEXW lpVersionInformation,DWORD dwTypeMask,DWORDLONG dwlConditionMask);

# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\winerror.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */

#define _WINERROR_ 

#define __IN__WINERROR_ 1

#define FACILITY_WINDOWSUPDATE 36
#define FACILITY_WINDOWS_CE 24
#define FACILITY_WINDOWS 8
#define FACILITY_URT 19
#define FACILITY_UMI 22
#define FACILITY_SXS 23
#define FACILITY_STORAGE 3
#define FACILITY_STATE_MANAGEMENT 34
#define FACILITY_SSPI 9
#define FACILITY_SCARD 16
#define FACILITY_SETUPAPI 15
#define FACILITY_SECURITY 9
#define FACILITY_RPC 1
#define FACILITY_WIN32 7
#define FACILITY_CONTROL 10
#define FACILITY_NULL 0
#define FACILITY_METADIRECTORY 35
#define FACILITY_MSMQ 14
#define FACILITY_MEDIASERVER 13
#define FACILITY_INTERNET 12
#define FACILITY_ITF 4
#define FACILITY_HTTP 25
#define FACILITY_DPLAY 21
#define FACILITY_DISPATCH 2
#define FACILITY_DIRECTORYSERVICE 37
#define FACILITY_CONFIGURATION 33
#define FACILITY_COMPLUS 17
#define FACILITY_CERT 11
#define FACILITY_BACKGROUNDCOPY 32
#define FACILITY_ACS 20
#define FACILITY_AAF 18
#define ERROR_SUCCESS __MSABI_LONG(0)
#define NO_ERROR __MSABI_LONG(0)
#define SEC_E_OK ((HRESULT)0x00000000)
#define ERROR_INVALID_FUNCTION __MSABI_LONG(1)
#define ERROR_FILE_NOT_FOUND __MSABI_LONG(2)
#define ERROR_PATH_NOT_FOUND __MSABI_LONG(3)
#define ERROR_TOO_MANY_OPEN_FILES __MSABI_LONG(4)
#define ERROR_ACCESS_DENIED __MSABI_LONG(5)
#define ERROR_INVALID_HANDLE __MSABI_LONG(6)
#define ERROR_ARENA_TRASHED __MSABI_LONG(7)
#define ERROR_NOT_ENOUGH_MEMORY __MSABI_LONG(8)
#define ERROR_INVALID_BLOCK __MSABI_LONG(9)
#define ERROR_BAD_ENVIRONMENT __MSABI_LONG(10)
#define ERROR_BAD_FORMAT __MSABI_LONG(11)
#define ERROR_INVALID_ACCESS __MSABI_LONG(12)
#define ERROR_INVALID_DATA __MSABI_LONG(13)
#define ERROR_OUTOFMEMORY __MSABI_LONG(14)
#define ERROR_INVALID_DRIVE __MSABI_LONG(15)
#define ERROR_CURRENT_DIRECTORY __MSABI_LONG(16)
#define ERROR_NOT_SAME_DEVICE __MSABI_LONG(17)
#define ERROR_NO_MORE_FILES __MSABI_LONG(18)
#define ERROR_WRITE_PROTECT __MSABI_LONG(19)
#define ERROR_BAD_UNIT __MSABI_LONG(20)
#define ERROR_NOT_READY __MSABI_LONG(21)
#define ERROR_BAD_COMMAND __MSABI_LONG(22)
#define ERROR_CRC __MSABI_LONG(23)
#define ERROR_BAD_LENGTH __MSABI_LONG(24)
#define ERROR_SEEK __MSABI_LONG(25)
#define ERROR_NOT_DOS_DISK __MSABI_LONG(26)
#define ERROR_SECTOR_NOT_FOUND __MSABI_LONG(27)
#define ERROR_OUT_OF_PAPER __MSABI_LONG(28)
#define ERROR_WRITE_FAULT __MSABI_LONG(29)
#define ERROR_READ_FAULT __MSABI_LONG(30)
#define ERROR_GEN_FAILURE __MSABI_LONG(31)
#define ERROR_SHARING_VIOLATION __MSABI_LONG(32)
#define ERROR_LOCK_VIOLATION __MSABI_LONG(33)
#define ERROR_WRONG_DISK __MSABI_LONG(34)
#define ERROR_SHARING_BUFFER_EXCEEDED __MSABI_LONG(36)
#define ERROR_HANDLE_EOF __MSABI_LONG(38)
#define ERROR_HANDLE_DISK_FULL __MSABI_LONG(39)
#define ERROR_NOT_SUPPORTED __MSABI_LONG(50)
#define ERROR_REM_NOT_LIST __MSABI_LONG(51)
#define ERROR_DUP_NAME __MSABI_LONG(52)
#define ERROR_BAD_NETPATH __MSABI_LONG(53)
#define ERROR_NETWORK_BUSY __MSABI_LONG(54)
#define ERROR_DEV_NOT_EXIST __MSABI_LONG(55)
#define ERROR_TOO_MANY_CMDS __MSABI_LONG(56)
#define ERROR_ADAP_HDW_ERR __MSABI_LONG(57)
#define ERROR_BAD_NET_RESP __MSABI_LONG(58)
#define ERROR_UNEXP_NET_ERR __MSABI_LONG(59)
#define ERROR_BAD_REM_ADAP __MSABI_LONG(60)
#define ERROR_PRINTQ_FULL __MSABI_LONG(61)
#define ERROR_NO_SPOOL_SPACE __MSABI_LONG(62)
#define ERROR_PRINT_CANCELLED __MSABI_LONG(63)
#define ERROR_NETNAME_DELETED __MSABI_LONG(64)
#define ERROR_NETWORK_ACCESS_DENIED __MSABI_LONG(65)
#define ERROR_BAD_DEV_TYPE __MSABI_LONG(66)
#define ERROR_BAD_NET_NAME __MSABI_LONG(67)
#define ERROR_TOO_MANY_NAMES __MSABI_LONG(68)
#define ERROR_TOO_MANY_SESS __MSABI_LONG(69)
#define ERROR_SHARING_PAUSED __MSABI_LONG(70)
#define ERROR_REQ_NOT_ACCEP __MSABI_LONG(71)
#define ERROR_REDIR_PAUSED __MSABI_LONG(72)
#define ERROR_FILE_EXISTS __MSABI_LONG(80)
#define ERROR_CANNOT_MAKE __MSABI_LONG(82)
#define ERROR_FAIL_I24 __MSABI_LONG(83)
#define ERROR_OUT_OF_STRUCTURES __MSABI_LONG(84)
#define ERROR_ALREADY_ASSIGNED __MSABI_LONG(85)
#define ERROR_INVALID_PASSWORD __MSABI_LONG(86)
#define ERROR_INVALID_PARAMETER __MSABI_LONG(87)
#define ERROR_NET_WRITE_FAULT __MSABI_LONG(88)
#define ERROR_NO_PROC_SLOTS __MSABI_LONG(89)
#define ERROR_TOO_MANY_SEMAPHORES __MSABI_LONG(100)
#define ERROR_EXCL_SEM_ALREADY_OWNED __MSABI_LONG(101)
#define ERROR_SEM_IS_SET __MSABI_LONG(102)
#define ERROR_TOO_MANY_SEM_REQUESTS __MSABI_LONG(103)
#define ERROR_INVALID_AT_INTERRUPT_TIME __MSABI_LONG(104)
#define ERROR_SEM_OWNER_DIED __MSABI_LONG(105)
#define ERROR_SEM_USER_LIMIT __MSABI_LONG(106)
#define ERROR_DISK_CHANGE __MSABI_LONG(107)
#define ERROR_DRIVE_LOCKED __MSABI_LONG(108)
#define ERROR_BROKEN_PIPE __MSABI_LONG(109)
#define ERROR_OPEN_FAILED __MSABI_LONG(110)
#define ERROR_BUFFER_OVERFLOW __MSABI_LONG(111)
#define ERROR_DISK_FULL __MSABI_LONG(112)
#define ERROR_NO_MORE_SEARCH_HANDLES __MSABI_LONG(113)
#define ERROR_INVALID_TARGET_HANDLE __MSABI_LONG(114)
#define ERROR_INVALID_CATEGORY __MSABI_LONG(117)
#define ERROR_INVALID_VERIFY_SWITCH __MSABI_LONG(118)
#define ERROR_BAD_DRIVER_LEVEL __MSABI_LONG(119)
#define ERROR_CALL_NOT_IMPLEMENTED __MSABI_LONG(120)
#define ERROR_SEM_TIMEOUT __MSABI_LONG(121)
#define ERROR_INSUFFICIENT_BUFFER __MSABI_LONG(122)
#define ERROR_INVALID_NAME __MSABI_LONG(123)
#define ERROR_INVALID_LEVEL __MSABI_LONG(124)
#define ERROR_NO_VOLUME_LABEL __MSABI_LONG(125)
#define ERROR_MOD_NOT_FOUND __MSABI_LONG(126)
#define ERROR_PROC_NOT_FOUND __MSABI_LONG(127)
#define ERROR_WAIT_NO_CHILDREN __MSABI_LONG(128)
#define ERROR_CHILD_NOT_COMPLETE __MSABI_LONG(129)
#define ERROR_DIRECT_ACCESS_HANDLE __MSABI_LONG(130)
#define ERROR_NEGATIVE_SEEK __MSABI_LONG(131)
#define ERROR_SEEK_ON_DEVICE __MSABI_LONG(132)
#define ERROR_IS_JOIN_TARGET __MSABI_LONG(133)
#define ERROR_IS_JOINED __MSABI_LONG(134)
#define ERROR_IS_SUBSTED __MSABI_LONG(135)
#define ERROR_NOT_JOINED __MSABI_LONG(136)
#define ERROR_NOT_SUBSTED __MSABI_LONG(137)
#define ERROR_JOIN_TO_JOIN __MSABI_LONG(138)
#define ERROR_SUBST_TO_SUBST __MSABI_LONG(139)
#define ERROR_JOIN_TO_SUBST __MSABI_LONG(140)
#define ERROR_SUBST_TO_JOIN __MSABI_LONG(141)
#define ERROR_BUSY_DRIVE __MSABI_LONG(142)
#define ERROR_SAME_DRIVE __MSABI_LONG(143)
#define ERROR_DIR_NOT_ROOT __MSABI_LONG(144)
#define ERROR_DIR_NOT_EMPTY __MSABI_LONG(145)
#define ERROR_IS_SUBST_PATH __MSABI_LONG(146)
#define ERROR_IS_JOIN_PATH __MSABI_LONG(147)
#define ERROR_PATH_BUSY __MSABI_LONG(148)
#define ERROR_IS_SUBST_TARGET __MSABI_LONG(149)
#define ERROR_SYSTEM_TRACE __MSABI_LONG(150)
#define ERROR_INVALID_EVENT_COUNT __MSABI_LONG(151)
#define ERROR_TOO_MANY_MUXWAITERS __MSABI_LONG(152)
#define ERROR_INVALID_LIST_FORMAT __MSABI_LONG(153)
#define ERROR_LABEL_TOO_LONG __MSABI_LONG(154)
#define ERROR_TOO_MANY_TCBS __MSABI_LONG(155)
#define ERROR_SIGNAL_REFUSED __MSABI_LONG(156)
#define ERROR_DISCARDED __MSABI_LONG(157)
#define ERROR_NOT_LOCKED __MSABI_LONG(158)
#define ERROR_BAD_THREADID_ADDR __MSABI_LONG(159)
#define ERROR_BAD_ARGUMENTS __MSABI_LONG(160)
#define ERROR_BAD_PATHNAME __MSABI_LONG(161)
#define ERROR_SIGNAL_PENDING __MSABI_LONG(162)
#define ERROR_MAX_THRDS_REACHED __MSABI_LONG(164)
#define ERROR_LOCK_FAILED __MSABI_LONG(167)
#define ERROR_BUSY __MSABI_LONG(170)
#define ERROR_CANCEL_VIOLATION __MSABI_LONG(173)
#define ERROR_ATOMIC_LOCKS_NOT_SUPPORTED __MSABI_LONG(174)
#define ERROR_INVALID_SEGMENT_NUMBER __MSABI_LONG(180)
#define ERROR_INVALID_ORDINAL __MSABI_LONG(182)
#define ERROR_ALREADY_EXISTS __MSABI_LONG(183)
#define ERROR_INVALID_FLAG_NUMBER __MSABI_LONG(186)
#define ERROR_SEM_NOT_FOUND __MSABI_LONG(187)
#define ERROR_INVALID_STARTING_CODESEG __MSABI_LONG(188)
#define ERROR_INVALID_STACKSEG __MSABI_LONG(189)
#define ERROR_INVALID_MODULETYPE __MSABI_LONG(190)
#define ERROR_INVALID_EXE_SIGNATURE __MSABI_LONG(191)
#define ERROR_EXE_MARKED_INVALID __MSABI_LONG(192)
#define ERROR_BAD_EXE_FORMAT __MSABI_LONG(193)
#define ERROR_ITERATED_DATA_EXCEEDS_64k __MSABI_LONG(194)
#define ERROR_INVALID_MINALLOCSIZE __MSABI_LONG(195)
#define ERROR_DYNLINK_FROM_INVALID_RING __MSABI_LONG(196)
#define ERROR_IOPL_NOT_ENABLED __MSABI_LONG(197)
#define ERROR_INVALID_SEGDPL __MSABI_LONG(198)
#define ERROR_AUTODATASEG_EXCEEDS_64k __MSABI_LONG(199)
#define ERROR_RING2SEG_MUST_BE_MOVABLE __MSABI_LONG(200)
#define ERROR_RELOC_CHAIN_XEEDS_SEGLIM __MSABI_LONG(201)
#define ERROR_INFLOOP_IN_RELOC_CHAIN __MSABI_LONG(202)
#define ERROR_ENVVAR_NOT_FOUND __MSABI_LONG(203)
#define ERROR_NO_SIGNAL_SENT __MSABI_LONG(205)
#define ERROR_FILENAME_EXCED_RANGE __MSABI_LONG(206)
#define ERROR_RING2_STACK_IN_USE __MSABI_LONG(207)
#define ERROR_META_EXPANSION_TOO_LONG __MSABI_LONG(208)
#define ERROR_INVALID_SIGNAL_NUMBER __MSABI_LONG(209)
#define ERROR_THREAD_1_INACTIVE __MSABI_LONG(210)
#define ERROR_LOCKED __MSABI_LONG(212)
#define ERROR_TOO_MANY_MODULES __MSABI_LONG(214)
#define ERROR_NESTING_NOT_ALLOWED __MSABI_LONG(215)
#define ERROR_EXE_MACHINE_TYPE_MISMATCH __MSABI_LONG(216)
#define ERROR_EXE_CANNOT_MODIFY_SIGNED_BINARY __MSABI_LONG(217)
#define ERROR_EXE_CANNOT_MODIFY_STRONG_SIGNED_BINARY __MSABI_LONG(218)
#define ERROR_BAD_PIPE __MSABI_LONG(230)
#define ERROR_PIPE_BUSY __MSABI_LONG(231)
#define ERROR_NO_DATA __MSABI_LONG(232)
#define ERROR_PIPE_NOT_CONNECTED __MSABI_LONG(233)
#define ERROR_MORE_DATA __MSABI_LONG(234)
#define ERROR_VC_DISCONNECTED __MSABI_LONG(240)
#define ERROR_INVALID_EA_NAME __MSABI_LONG(254)
#define ERROR_EA_LIST_INCONSISTENT __MSABI_LONG(255)
#define WAIT_TIMEOUT __MSABI_LONG(258)
#define ERROR_NO_MORE_ITEMS __MSABI_LONG(259)
#define ERROR_CANNOT_COPY __MSABI_LONG(266)
#define ERROR_DIRECTORY __MSABI_LONG(267)
#define ERROR_EAS_DIDNT_FIT __MSABI_LONG(275)
#define ERROR_EA_FILE_CORRUPT __MSABI_LONG(276)
#define ERROR_EA_TABLE_FULL __MSABI_LONG(277)
#define ERROR_INVALID_EA_HANDLE __MSABI_LONG(278)
#define ERROR_EAS_NOT_SUPPORTED __MSABI_LONG(282)
#define ERROR_NOT_OWNER __MSABI_LONG(288)
#define ERROR_TOO_MANY_POSTS __MSABI_LONG(298)
#define ERROR_PARTIAL_COPY __MSABI_LONG(299)
#define ERROR_OPLOCK_NOT_GRANTED __MSABI_LONG(300)
#define ERROR_INVALID_OPLOCK_PROTOCOL __MSABI_LONG(301)
#define ERROR_DISK_TOO_FRAGMENTED __MSABI_LONG(302)
#define ERROR_DELETE_PENDING __MSABI_LONG(303)
#define ERROR_MR_MID_NOT_FOUND __MSABI_LONG(317)
#define ERROR_SCOPE_NOT_FOUND __MSABI_LONG(318)
#define ERROR_INVALID_ADDRESS __MSABI_LONG(487)
#define ERROR_ARITHMETIC_OVERFLOW __MSABI_LONG(534)
#define ERROR_PIPE_CONNECTED __MSABI_LONG(535)
#define ERROR_PIPE_LISTENING __MSABI_LONG(536)
#define ERROR_EA_ACCESS_DENIED __MSABI_LONG(994)
#define ERROR_OPERATION_ABORTED __MSABI_LONG(995)
#define ERROR_IO_INCOMPLETE __MSABI_LONG(996)
#define ERROR_IO_PENDING __MSABI_LONG(997)
#define ERROR_NOACCESS __MSABI_LONG(998)
#define ERROR_SWAPERROR __MSABI_LONG(999)
#define ERROR_STACK_OVERFLOW __MSABI_LONG(1001)
#define ERROR_INVALID_MESSAGE __MSABI_LONG(1002)
#define ERROR_CAN_NOT_COMPLETE __MSABI_LONG(1003)
#define ERROR_INVALID_FLAGS __MSABI_LONG(1004)
#define ERROR_UNRECOGNIZED_VOLUME __MSABI_LONG(1005)
#define ERROR_FILE_INVALID __MSABI_LONG(1006)
#define ERROR_FULLSCREEN_MODE __MSABI_LONG(1007)
#define ERROR_NO_TOKEN __MSABI_LONG(1008)
#define ERROR_BADDB __MSABI_LONG(1009)
#define ERROR_BADKEY __MSABI_LONG(1010)
#define ERROR_CANTOPEN __MSABI_LONG(1011)
#define ERROR_CANTREAD __MSABI_LONG(1012)
#define ERROR_CANTWRITE __MSABI_LONG(1013)
#define ERROR_REGISTRY_RECOVERED __MSABI_LONG(1014)
#define ERROR_REGISTRY_CORRUPT __MSABI_LONG(1015)
#define ERROR_REGISTRY_IO_FAILED __MSABI_LONG(1016)
#define ERROR_NOT_REGISTRY_FILE __MSABI_LONG(1017)
#define ERROR_KEY_DELETED __MSABI_LONG(1018)
#define ERROR_NO_LOG_SPACE __MSABI_LONG(1019)
#define ERROR_KEY_HAS_CHILDREN __MSABI_LONG(1020)
#define ERROR_CHILD_MUST_BE_VOLATILE __MSABI_LONG(1021)
#define ERROR_NOTIFY_ENUM_DIR __MSABI_LONG(1022)
#define ERROR_DEPENDENT_SERVICES_RUNNING __MSABI_LONG(1051)
#define ERROR_INVALID_SERVICE_CONTROL __MSABI_LONG(1052)
#define ERROR_SERVICE_REQUEST_TIMEOUT __MSABI_LONG(1053)
#define ERROR_SERVICE_NO_THREAD __MSABI_LONG(1054)
#define ERROR_SERVICE_DATABASE_LOCKED __MSABI_LONG(1055)
#define ERROR_SERVICE_ALREADY_RUNNING __MSABI_LONG(1056)
#define ERROR_INVALID_SERVICE_ACCOUNT __MSABI_LONG(1057)
#define ERROR_SERVICE_DISABLED __MSABI_LONG(1058)
#define ERROR_CIRCULAR_DEPENDENCY __MSABI_LONG(1059)
#define ERROR_SERVICE_DOES_NOT_EXIST __MSABI_LONG(1060)
#define ERROR_SERVICE_CANNOT_ACCEPT_CTRL __MSABI_LONG(1061)
#define ERROR_SERVICE_NOT_ACTIVE __MSABI_LONG(1062)
#define ERROR_FAILED_SERVICE_CONTROLLER_CONNECT __MSABI_LONG(1063)
#define ERROR_EXCEPTION_IN_SERVICE __MSABI_LONG(1064)
#define ERROR_DATABASE_DOES_NOT_EXIST __MSABI_LONG(1065)
#define ERROR_SERVICE_SPECIFIC_ERROR __MSABI_LONG(1066)
#define ERROR_PROCESS_ABORTED __MSABI_LONG(1067)
#define ERROR_SERVICE_DEPENDENCY_FAIL __MSABI_LONG(1068)
#define ERROR_SERVICE_LOGON_FAILED __MSABI_LONG(1069)
#define ERROR_SERVICE_START_HANG __MSABI_LONG(1070)
#define ERROR_INVALID_SERVICE_LOCK __MSABI_LONG(1071)
#define ERROR_SERVICE_MARKED_FOR_DELETE __MSABI_LONG(1072)
#define ERROR_SERVICE_EXISTS __MSABI_LONG(1073)
#define ERROR_ALREADY_RUNNING_LKG __MSABI_LONG(1074)
#define ERROR_SERVICE_DEPENDENCY_DELETED __MSABI_LONG(1075)
#define ERROR_BOOT_ALREADY_ACCEPTED __MSABI_LONG(1076)
#define ERROR_SERVICE_NEVER_STARTED __MSABI_LONG(1077)
#define ERROR_DUPLICATE_SERVICE_NAME __MSABI_LONG(1078)
#define ERROR_DIFFERENT_SERVICE_ACCOUNT __MSABI_LONG(1079)
#define ERROR_CANNOT_DETECT_DRIVER_FAILURE __MSABI_LONG(1080)
#define ERROR_CANNOT_DETECT_PROCESS_ABORT __MSABI_LONG(1081)
#define ERROR_NO_RECOVERY_PROGRAM __MSABI_LONG(1082)
#define ERROR_SERVICE_NOT_IN_EXE __MSABI_LONG(1083)
#define ERROR_NOT_SAFEBOOT_SERVICE __MSABI_LONG(1084)
#define ERROR_END_OF_MEDIA __MSABI_LONG(1100)
#define ERROR_FILEMARK_DETECTED __MSABI_LONG(1101)
#define ERROR_BEGINNING_OF_MEDIA __MSABI_LONG(1102)
#define ERROR_SETMARK_DETECTED __MSABI_LONG(1103)
#define ERROR_NO_DATA_DETECTED __MSABI_LONG(1104)
#define ERROR_PARTITION_FAILURE __MSABI_LONG(1105)
#define ERROR_INVALID_BLOCK_LENGTH __MSABI_LONG(1106)
#define ERROR_DEVICE_NOT_PARTITIONED __MSABI_LONG(1107)
#define ERROR_UNABLE_TO_LOCK_MEDIA __MSABI_LONG(1108)
#define ERROR_UNABLE_TO_UNLOAD_MEDIA __MSABI_LONG(1109)
#define ERROR_MEDIA_CHANGED __MSABI_LONG(1110)
#define ERROR_BUS_RESET __MSABI_LONG(1111)
#define ERROR_NO_MEDIA_IN_DRIVE __MSABI_LONG(1112)
#define ERROR_NO_UNICODE_TRANSLATION __MSABI_LONG(1113)
#define ERROR_DLL_INIT_FAILED __MSABI_LONG(1114)
#define ERROR_SHUTDOWN_IN_PROGRESS __MSABI_LONG(1115)
#define ERROR_NO_SHUTDOWN_IN_PROGRESS __MSABI_LONG(1116)
#define ERROR_IO_DEVICE __MSABI_LONG(1117)
#define ERROR_SERIAL_NO_DEVICE __MSABI_LONG(1118)
#define ERROR_IRQ_BUSY __MSABI_LONG(1119)
#define ERROR_MORE_WRITES __MSABI_LONG(1120)
#define ERROR_COUNTER_TIMEOUT __MSABI_LONG(1121)
#define ERROR_FLOPPY_ID_MARK_NOT_FOUND __MSABI_LONG(1122)
#define ERROR_FLOPPY_WRONG_CYLINDER __MSABI_LONG(1123)
#define ERROR_FLOPPY_UNKNOWN_ERROR __MSABI_LONG(1124)
#define ERROR_FLOPPY_BAD_REGISTERS __MSABI_LONG(1125)
#define ERROR_DISK_RECALIBRATE_FAILED __MSABI_LONG(1126)
#define ERROR_DISK_OPERATION_FAILED __MSABI_LONG(1127)
#define ERROR_DISK_RESET_FAILED __MSABI_LONG(1128)
#define ERROR_EOM_OVERFLOW __MSABI_LONG(1129)
#define ERROR_NOT_ENOUGH_SERVER_MEMORY __MSABI_LONG(1130)
#define ERROR_POSSIBLE_DEADLOCK __MSABI_LONG(1131)
#define ERROR_MAPPED_ALIGNMENT __MSABI_LONG(1132)
#define ERROR_SET_POWER_STATE_VETOED __MSABI_LONG(1140)
#define ERROR_SET_POWER_STATE_FAILED __MSABI_LONG(1141)
#define ERROR_TOO_MANY_LINKS __MSABI_LONG(1142)
#define ERROR_OLD_WIN_VERSION __MSABI_LONG(1150)
#define ERROR_APP_WRONG_OS __MSABI_LONG(1151)
#define ERROR_SINGLE_INSTANCE_APP __MSABI_LONG(1152)
#define ERROR_RMODE_APP __MSABI_LONG(1153)
#define ERROR_INVALID_DLL __MSABI_LONG(1154)
#define ERROR_NO_ASSOCIATION __MSABI_LONG(1155)
#define ERROR_DDE_FAIL __MSABI_LONG(1156)
#define ERROR_DLL_NOT_FOUND __MSABI_LONG(1157)
#define ERROR_NO_MORE_USER_HANDLES __MSABI_LONG(1158)
#define ERROR_MESSAGE_SYNC_ONLY __MSABI_LONG(1159)
#define ERROR_SOURCE_ELEMENT_EMPTY __MSABI_LONG(1160)
#define ERROR_DESTINATION_ELEMENT_FULL __MSABI_LONG(1161)
#define ERROR_ILLEGAL_ELEMENT_ADDRESS __MSABI_LONG(1162)
#define ERROR_MAGAZINE_NOT_PRESENT __MSABI_LONG(1163)
#define ERROR_DEVICE_REINITIALIZATION_NEEDED __MSABI_LONG(1164)
#define ERROR_DEVICE_REQUIRES_CLEANING __MSABI_LONG(1165)
#define ERROR_DEVICE_DOOR_OPEN __MSABI_LONG(1166)
#define ERROR_DEVICE_NOT_CONNECTED __MSABI_LONG(1167)
#define ERROR_NOT_FOUND __MSABI_LONG(1168)
#define ERROR_NO_MATCH __MSABI_LONG(1169)
#define ERROR_SET_NOT_FOUND __MSABI_LONG(1170)
#define ERROR_POINT_NOT_FOUND __MSABI_LONG(1171)
#define ERROR_NO_TRACKING_SERVICE __MSABI_LONG(1172)
#define ERROR_NO_VOLUME_ID __MSABI_LONG(1173)
#define ERROR_UNABLE_TO_REMOVE_REPLACED __MSABI_LONG(1175)
#define ERROR_UNABLE_TO_MOVE_REPLACEMENT __MSABI_LONG(1176)
#define ERROR_UNABLE_TO_MOVE_REPLACEMENT_2 __MSABI_LONG(1177)
#define ERROR_JOURNAL_DELETE_IN_PROGRESS __MSABI_LONG(1178)
#define ERROR_JOURNAL_NOT_ACTIVE __MSABI_LONG(1179)
#define ERROR_POTENTIAL_FILE_FOUND __MSABI_LONG(1180)
#define ERROR_JOURNAL_ENTRY_DELETED __MSABI_LONG(1181)
#define ERROR_BAD_DEVICE __MSABI_LONG(1200)
#define ERROR_CONNECTION_UNAVAIL __MSABI_LONG(1201)
#define ERROR_DEVICE_ALREADY_REMEMBERED __MSABI_LONG(1202)
#define ERROR_NO_NET_OR_BAD_PATH __MSABI_LONG(1203)
#define ERROR_BAD_PROVIDER __MSABI_LONG(1204)
#define ERROR_CANNOT_OPEN_PROFILE __MSABI_LONG(1205)
#define ERROR_BAD_PROFILE __MSABI_LONG(1206)
#define ERROR_NOT_CONTAINER __MSABI_LONG(1207)
#define ERROR_EXTENDED_ERROR __MSABI_LONG(1208)
#define ERROR_INVALID_GROUPNAME __MSABI_LONG(1209)
#define ERROR_INVALID_COMPUTERNAME __MSABI_LONG(1210)
#define ERROR_INVALID_EVENTNAME __MSABI_LONG(1211)
#define ERROR_INVALID_DOMAINNAME __MSABI_LONG(1212)
#define ERROR_INVALID_SERVICENAME __MSABI_LONG(1213)
#define ERROR_INVALID_NETNAME __MSABI_LONG(1214)
#define ERROR_INVALID_SHARENAME __MSABI_LONG(1215)
#define ERROR_INVALID_PASSWORDNAME __MSABI_LONG(1216)
#define ERROR_INVALID_MESSAGENAME __MSABI_LONG(1217)
#define ERROR_INVALID_MESSAGEDEST __MSABI_LONG(1218)
#define ERROR_SESSION_CREDENTIAL_CONFLICT __MSABI_LONG(1219)
#define ERROR_REMOTE_SESSION_LIMIT_EXCEEDED __MSABI_LONG(1220)
#define ERROR_DUP_DOMAINNAME __MSABI_LONG(1221)
#define ERROR_NO_NETWORK __MSABI_LONG(1222)
#define ERROR_CANCELLED __MSABI_LONG(1223)
#define ERROR_USER_MAPPED_FILE __MSABI_LONG(1224)
#define ERROR_CONNECTION_REFUSED __MSABI_LONG(1225)
#define ERROR_GRACEFUL_DISCONNECT __MSABI_LONG(1226)
#define ERROR_ADDRESS_ALREADY_ASSOCIATED __MSABI_LONG(1227)
#define ERROR_ADDRESS_NOT_ASSOCIATED __MSABI_LONG(1228)
#define ERROR_CONNECTION_INVALID __MSABI_LONG(1229)
#define ERROR_CONNECTION_ACTIVE __MSABI_LONG(1230)
#define ERROR_NETWORK_UNREACHABLE __MSABI_LONG(1231)
#define ERROR_HOST_UNREACHABLE __MSABI_LONG(1232)
#define ERROR_PROTOCOL_UNREACHABLE __MSABI_LONG(1233)
#define ERROR_PORT_UNREACHABLE __MSABI_LONG(1234)
#define ERROR_REQUEST_ABORTED __MSABI_LONG(1235)
#define ERROR_CONNECTION_ABORTED __MSABI_LONG(1236)
#define ERROR_RETRY __MSABI_LONG(1237)
#define ERROR_CONNECTION_COUNT_LIMIT __MSABI_LONG(1238)
#define ERROR_LOGIN_TIME_RESTRICTION __MSABI_LONG(1239)
#define ERROR_LOGIN_WKSTA_RESTRICTION __MSABI_LONG(1240)
#define ERROR_INCORRECT_ADDRESS __MSABI_LONG(1241)
#define ERROR_ALREADY_REGISTERED __MSABI_LONG(1242)
#define ERROR_SERVICE_NOT_FOUND __MSABI_LONG(1243)
#define ERROR_NOT_AUTHENTICATED __MSABI_LONG(1244)
#define ERROR_NOT_LOGGED_ON __MSABI_LONG(1245)
#define ERROR_CONTINUE __MSABI_LONG(1246)
#define ERROR_ALREADY_INITIALIZED __MSABI_LONG(1247)
#define ERROR_NO_MORE_DEVICES __MSABI_LONG(1248)
#define ERROR_NO_SUCH_SITE __MSABI_LONG(1249)
#define ERROR_DOMAIN_CONTROLLER_EXISTS __MSABI_LONG(1250)
#define ERROR_ONLY_IF_CONNECTED __MSABI_LONG(1251)
#define ERROR_OVERRIDE_NOCHANGES __MSABI_LONG(1252)
#define ERROR_BAD_USER_PROFILE __MSABI_LONG(1253)
#define ERROR_NOT_SUPPORTED_ON_SBS __MSABI_LONG(1254)
#define ERROR_SERVER_SHUTDOWN_IN_PROGRESS __MSABI_LONG(1255)
#define ERROR_HOST_DOWN __MSABI_LONG(1256)
#define ERROR_NON_ACCOUNT_SID __MSABI_LONG(1257)
#define ERROR_NON_DOMAIN_SID __MSABI_LONG(1258)
#define ERROR_APPHELP_BLOCK __MSABI_LONG(1259)
#define ERROR_ACCESS_DISABLED_BY_POLICY __MSABI_LONG(1260)
#define ERROR_REG_NAT_CONSUMPTION __MSABI_LONG(1261)
#define ERROR_CSCSHARE_OFFLINE __MSABI_LONG(1262)
#define ERROR_PKINIT_FAILURE __MSABI_LONG(1263)
#define ERROR_SMARTCARD_SUBSYSTEM_FAILURE __MSABI_LONG(1264)
#define ERROR_DOWNGRADE_DETECTED __MSABI_LONG(1265)
#define ERROR_MACHINE_LOCKED __MSABI_LONG(1271)
#define ERROR_CALLBACK_SUPPLIED_INVALID_DATA __MSABI_LONG(1273)
#define ERROR_SYNC_FOREGROUND_REFRESH_REQUIRED __MSABI_LONG(1274)
#define ERROR_DRIVER_BLOCKED __MSABI_LONG(1275)
#define ERROR_INVALID_IMPORT_OF_NON_DLL __MSABI_LONG(1276)
#define ERROR_ACCESS_DISABLED_WEBBLADE __MSABI_LONG(1277)
#define ERROR_ACCESS_DISABLED_WEBBLADE_TAMPER __MSABI_LONG(1278)
#define ERROR_RECOVERY_FAILURE __MSABI_LONG(1279)
#define ERROR_ALREADY_FIBER __MSABI_LONG(1280)
#define ERROR_ALREADY_THREAD __MSABI_LONG(1281)
#define ERROR_STACK_BUFFER_OVERRUN __MSABI_LONG(1282)
#define ERROR_PARAMETER_QUOTA_EXCEEDED __MSABI_LONG(1283)
#define ERROR_DEBUGGER_INACTIVE __MSABI_LONG(1284)
#define ERROR_DELAY_LOAD_FAILED __MSABI_LONG(1285)
#define ERROR_VDM_DISALLOWED __MSABI_LONG(1286)
#define ERROR_UNIDENTIFIED_ERROR __MSABI_LONG(1287)
#define ERROR_NOT_ALL_ASSIGNED __MSABI_LONG(1300)
#define ERROR_SOME_NOT_MAPPED __MSABI_LONG(1301)
#define ERROR_NO_QUOTAS_FOR_ACCOUNT __MSABI_LONG(1302)
#define ERROR_LOCAL_USER_SESSION_KEY __MSABI_LONG(1303)
#define ERROR_NULL_LM_PASSWORD __MSABI_LONG(1304)
#define ERROR_UNKNOWN_REVISION __MSABI_LONG(1305)
#define ERROR_REVISION_MISMATCH __MSABI_LONG(1306)
#define ERROR_INVALID_OWNER __MSABI_LONG(1307)
#define ERROR_INVALID_PRIMARY_GROUP __MSABI_LONG(1308)
#define ERROR_NO_IMPERSONATION_TOKEN __MSABI_LONG(1309)
#define ERROR_CANT_DISABLE_MANDATORY __MSABI_LONG(1310)
#define ERROR_NO_LOGON_SERVERS __MSABI_LONG(1311)
#define ERROR_NO_SUCH_LOGON_SESSION __MSABI_LONG(1312)
#define ERROR_NO_SUCH_PRIVILEGE __MSABI_LONG(1313)
#define ERROR_PRIVILEGE_NOT_HELD __MSABI_LONG(1314)
#define ERROR_INVALID_ACCOUNT_NAME __MSABI_LONG(1315)
#define ERROR_USER_EXISTS __MSABI_LONG(1316)
#define ERROR_NO_SUCH_USER __MSABI_LONG(1317)
#define ERROR_GROUP_EXISTS __MSABI_LONG(1318)
#define ERROR_NO_SUCH_GROUP __MSABI_LONG(1319)
#define ERROR_MEMBER_IN_GROUP __MSABI_LONG(1320)
#define ERROR_MEMBER_NOT_IN_GROUP __MSABI_LONG(1321)
#define ERROR_LAST_ADMIN __MSABI_LONG(1322)
#define ERROR_WRONG_PASSWORD __MSABI_LONG(1323)
#define ERROR_ILL_FORMED_PASSWORD __MSABI_LONG(1324)
#define ERROR_PASSWORD_RESTRICTION __MSABI_LONG(1325)
#define ERROR_LOGON_FAILURE __MSABI_LONG(1326)
#define ERROR_ACCOUNT_RESTRICTION __MSABI_LONG(1327)
#define ERROR_INVALID_LOGON_HOURS __MSABI_LONG(1328)
#define ERROR_INVALID_WORKSTATION __MSABI_LONG(1329)
#define ERROR_PASSWORD_EXPIRED __MSABI_LONG(1330)
#define ERROR_ACCOUNT_DISABLED __MSABI_LONG(1331)
#define ERROR_NONE_MAPPED __MSABI_LONG(1332)
#define ERROR_TOO_MANY_LUIDS_REQUESTED __MSABI_LONG(1333)
#define ERROR_LUIDS_EXHAUSTED __MSABI_LONG(1334)
#define ERROR_INVALID_SUB_AUTHORITY __MSABI_LONG(1335)
#define ERROR_INVALID_ACL __MSABI_LONG(1336)
#define ERROR_INVALID_SID __MSABI_LONG(1337)
#define ERROR_INVALID_SECURITY_DESCR __MSABI_LONG(1338)
#define ERROR_BAD_INHERITANCE_ACL __MSABI_LONG(1340)
#define ERROR_SERVER_DISABLED __MSABI_LONG(1341)
#define ERROR_SERVER_NOT_DISABLED __MSABI_LONG(1342)
#define ERROR_INVALID_ID_AUTHORITY __MSABI_LONG(1343)
#define ERROR_ALLOTTED_SPACE_EXCEEDED __MSABI_LONG(1344)
#define ERROR_INVALID_GROUP_ATTRIBUTES __MSABI_LONG(1345)
#define ERROR_BAD_IMPERSONATION_LEVEL __MSABI_LONG(1346)
#define ERROR_CANT_OPEN_ANONYMOUS __MSABI_LONG(1347)
#define ERROR_BAD_VALIDATION_CLASS __MSABI_LONG(1348)
#define ERROR_BAD_TOKEN_TYPE __MSABI_LONG(1349)
#define ERROR_NO_SECURITY_ON_OBJECT __MSABI_LONG(1350)
#define ERROR_CANT_ACCESS_DOMAIN_INFO __MSABI_LONG(1351)
#define ERROR_INVALID_SERVER_STATE __MSABI_LONG(1352)
#define ERROR_INVALID_DOMAIN_STATE __MSABI_LONG(1353)
#define ERROR_INVALID_DOMAIN_ROLE __MSABI_LONG(1354)
#define ERROR_NO_SUCH_DOMAIN __MSABI_LONG(1355)
#define ERROR_DOMAIN_EXISTS __MSABI_LONG(1356)
#define ERROR_DOMAIN_LIMIT_EXCEEDED __MSABI_LONG(1357)
#define ERROR_INTERNAL_DB_CORRUPTION __MSABI_LONG(1358)
#define ERROR_INTERNAL_ERROR __MSABI_LONG(1359)
#define ERROR_GENERIC_NOT_MAPPED __MSABI_LONG(1360)
#define ERROR_BAD_DESCRIPTOR_FORMAT __MSABI_LONG(1361)
#define ERROR_NOT_LOGON_PROCESS __MSABI_LONG(1362)
#define ERROR_LOGON_SESSION_EXISTS __MSABI_LONG(1363)
#define ERROR_NO_SUCH_PACKAGE __MSABI_LONG(1364)
#define ERROR_BAD_LOGON_SESSION_STATE __MSABI_LONG(1365)
#define ERROR_LOGON_SESSION_COLLISION __MSABI_LONG(1366)
#define ERROR_INVALID_LOGON_TYPE __MSABI_LONG(1367)
#define ERROR_CANNOT_IMPERSONATE __MSABI_LONG(1368)
#define ERROR_RXACT_INVALID_STATE __MSABI_LONG(1369)
#define ERROR_RXACT_COMMIT_FAILURE __MSABI_LONG(1370)
#define ERROR_SPECIAL_ACCOUNT __MSABI_LONG(1371)
#define ERROR_SPECIAL_GROUP __MSABI_LONG(1372)
#define ERROR_SPECIAL_USER __MSABI_LONG(1373)
#define ERROR_MEMBERS_PRIMARY_GROUP __MSABI_LONG(1374)
#define ERROR_TOKEN_ALREADY_IN_USE __MSABI_LONG(1375)
#define ERROR_NO_SUCH_ALIAS __MSABI_LONG(1376)
#define ERROR_MEMBER_NOT_IN_ALIAS __MSABI_LONG(1377)
#define ERROR_MEMBER_IN_ALIAS __MSABI_LONG(1378)
#define ERROR_ALIAS_EXISTS __MSABI_LONG(1379)
#define ERROR_LOGON_NOT_GRANTED __MSABI_LONG(1380)
#define ERROR_TOO_MANY_SECRETS __MSABI_LONG(1381)
#define ERROR_SECRET_TOO_LONG __MSABI_LONG(1382)
#define ERROR_INTERNAL_DB_ERROR __MSABI_LONG(1383)
#define ERROR_TOO_MANY_CONTEXT_IDS __MSABI_LONG(1384)
#define ERROR_LOGON_TYPE_NOT_GRANTED __MSABI_LONG(1385)
#define ERROR_NT_CROSS_ENCRYPTION_REQUIRED __MSABI_LONG(1386)
#define ERROR_NO_SUCH_MEMBER __MSABI_LONG(1387)
#define ERROR_INVALID_MEMBER __MSABI_LONG(1388)
#define ERROR_TOO_MANY_SIDS __MSABI_LONG(1389)
#define ERROR_LM_CROSS_ENCRYPTION_REQUIRED __MSABI_LONG(1390)
#define ERROR_NO_INHERITANCE __MSABI_LONG(1391)
#define ERROR_FILE_CORRUPT __MSABI_LONG(1392)
#define ERROR_DISK_CORRUPT __MSABI_LONG(1393)
#define ERROR_NO_USER_SESSION_KEY __MSABI_LONG(1394)
#define ERROR_LICENSE_QUOTA_EXCEEDED __MSABI_LONG(1395)
#define ERROR_WRONG_TARGET_NAME __MSABI_LONG(1396)
#define ERROR_MUTUAL_AUTH_FAILED __MSABI_LONG(1397)
#define ERROR_TIME_SKEW __MSABI_LONG(1398)
#define ERROR_CURRENT_DOMAIN_NOT_ALLOWED __MSABI_LONG(1399)
#define ERROR_INVALID_WINDOW_HANDLE __MSABI_LONG(1400)
#define ERROR_INVALID_MENU_HANDLE __MSABI_LONG(1401)
#define ERROR_INVALID_CURSOR_HANDLE __MSABI_LONG(1402)
#define ERROR_INVALID_ACCEL_HANDLE __MSABI_LONG(1403)
#define ERROR_INVALID_HOOK_HANDLE __MSABI_LONG(1404)
#define ERROR_INVALID_DWP_HANDLE __MSABI_LONG(1405)
#define ERROR_TLW_WITH_WSCHILD __MSABI_LONG(1406)
#define ERROR_CANNOT_FIND_WND_CLASS __MSABI_LONG(1407)
#define ERROR_WINDOW_OF_OTHER_THREAD __MSABI_LONG(1408)
#define ERROR_HOTKEY_ALREADY_REGISTERED __MSABI_LONG(1409)
#define ERROR_CLASS_ALREADY_EXISTS __MSABI_LONG(1410)
#define ERROR_CLASS_DOES_NOT_EXIST __MSABI_LONG(1411)
#define ERROR_CLASS_HAS_WINDOWS __MSABI_LONG(1412)
#define ERROR_INVALID_INDEX __MSABI_LONG(1413)
#define ERROR_INVALID_ICON_HANDLE __MSABI_LONG(1414)
#define ERROR_PRIVATE_DIALOG_INDEX __MSABI_LONG(1415)
#define ERROR_LISTBOX_ID_NOT_FOUND __MSABI_LONG(1416)
#define ERROR_NO_WILDCARD_CHARACTERS __MSABI_LONG(1417)
#define ERROR_CLIPBOARD_NOT_OPEN __MSABI_LONG(1418)
#define ERROR_HOTKEY_NOT_REGISTERED __MSABI_LONG(1419)
#define ERROR_WINDOW_NOT_DIALOG __MSABI_LONG(1420)
#define ERROR_CONTROL_ID_NOT_FOUND __MSABI_LONG(1421)
#define ERROR_INVALID_COMBOBOX_MESSAGE __MSABI_LONG(1422)
#define ERROR_WINDOW_NOT_COMBOBOX __MSABI_LONG(1423)
#define ERROR_INVALID_EDIT_HEIGHT __MSABI_LONG(1424)
#define ERROR_DC_NOT_FOUND __MSABI_LONG(1425)
#define ERROR_INVALID_HOOK_FILTER __MSABI_LONG(1426)
#define ERROR_INVALID_FILTER_PROC __MSABI_LONG(1427)
#define ERROR_HOOK_NEEDS_HMOD __MSABI_LONG(1428)
#define ERROR_GLOBAL_ONLY_HOOK __MSABI_LONG(1429)
#define ERROR_JOURNAL_HOOK_SET __MSABI_LONG(1430)
#define ERROR_HOOK_NOT_INSTALLED __MSABI_LONG(1431)
#define ERROR_INVALID_LB_MESSAGE __MSABI_LONG(1432)
#define ERROR_SETCOUNT_ON_BAD_LB __MSABI_LONG(1433)
#define ERROR_LB_WITHOUT_TABSTOPS __MSABI_LONG(1434)
#define ERROR_DESTROY_OBJECT_OF_OTHER_THREAD __MSABI_LONG(1435)
#define ERROR_CHILD_WINDOW_MENU __MSABI_LONG(1436)
#define ERROR_NO_SYSTEM_MENU __MSABI_LONG(1437)
#define ERROR_INVALID_MSGBOX_STYLE __MSABI_LONG(1438)
#define ERROR_INVALID_SPI_VALUE __MSABI_LONG(1439)
#define ERROR_SCREEN_ALREADY_LOCKED __MSABI_LONG(1440)
#define ERROR_HWNDS_HAVE_DIFF_PARENT __MSABI_LONG(1441)
#define ERROR_NOT_CHILD_WINDOW __MSABI_LONG(1442)
#define ERROR_INVALID_GW_COMMAND __MSABI_LONG(1443)
#define ERROR_INVALID_THREAD_ID __MSABI_LONG(1444)
#define ERROR_NON_MDICHILD_WINDOW __MSABI_LONG(1445)
#define ERROR_POPUP_ALREADY_ACTIVE __MSABI_LONG(1446)
#define ERROR_NO_SCROLLBARS __MSABI_LONG(1447)
#define ERROR_INVALID_SCROLLBAR_RANGE __MSABI_LONG(1448)
#define ERROR_INVALID_SHOWWIN_COMMAND __MSABI_LONG(1449)
#define ERROR_NO_SYSTEM_RESOURCES __MSABI_LONG(1450)
#define ERROR_NONPAGED_SYSTEM_RESOURCES __MSABI_LONG(1451)
#define ERROR_PAGED_SYSTEM_RESOURCES __MSABI_LONG(1452)
#define ERROR_WORKING_SET_QUOTA __MSABI_LONG(1453)
#define ERROR_PAGEFILE_QUOTA __MSABI_LONG(1454)
#define ERROR_COMMITMENT_LIMIT __MSABI_LONG(1455)
#define ERROR_MENU_ITEM_NOT_FOUND __MSABI_LONG(1456)
#define ERROR_INVALID_KEYBOARD_HANDLE __MSABI_LONG(1457)
#define ERROR_HOOK_TYPE_NOT_ALLOWED __MSABI_LONG(1458)
#define ERROR_REQUIRES_INTERACTIVE_WINDOWSTATION __MSABI_LONG(1459)
#define ERROR_TIMEOUT __MSABI_LONG(1460)
#define ERROR_INVALID_MONITOR_HANDLE __MSABI_LONG(1461)
#define ERROR_INCORRECT_SIZE __MSABI_LONG(1462)
#define ERROR_EVENTLOG_FILE_CORRUPT __MSABI_LONG(1500)
#define ERROR_EVENTLOG_CANT_START __MSABI_LONG(1501)
#define ERROR_LOG_FILE_FULL __MSABI_LONG(1502)
#define ERROR_EVENTLOG_FILE_CHANGED __MSABI_LONG(1503)
#define ERROR_INSTALL_SERVICE_FAILURE __MSABI_LONG(1601)
#define ERROR_INSTALL_USEREXIT __MSABI_LONG(1602)
#define ERROR_INSTALL_FAILURE __MSABI_LONG(1603)
#define ERROR_INSTALL_SUSPEND __MSABI_LONG(1604)
#define ERROR_UNKNOWN_PRODUCT __MSABI_LONG(1605)
#define ERROR_UNKNOWN_FEATURE __MSABI_LONG(1606)
#define ERROR_UNKNOWN_COMPONENT __MSABI_LONG(1607)
#define ERROR_UNKNOWN_PROPERTY __MSABI_LONG(1608)
#define ERROR_INVALID_HANDLE_STATE __MSABI_LONG(1609)
#define ERROR_BAD_CONFIGURATION __MSABI_LONG(1610)
#define ERROR_INDEX_ABSENT __MSABI_LONG(1611)
#define ERROR_INSTALL_SOURCE_ABSENT __MSABI_LONG(1612)
#define ERROR_INSTALL_PACKAGE_VERSION __MSABI_LONG(1613)
#define ERROR_PRODUCT_UNINSTALLED __MSABI_LONG(1614)
#define ERROR_BAD_QUERY_SYNTAX __MSABI_LONG(1615)
#define ERROR_INVALID_FIELD __MSABI_LONG(1616)
#define ERROR_DEVICE_REMOVED __MSABI_LONG(1617)
#define ERROR_INSTALL_ALREADY_RUNNING __MSABI_LONG(1618)
#define ERROR_INSTALL_PACKAGE_OPEN_FAILED __MSABI_LONG(1619)
#define ERROR_INSTALL_PACKAGE_INVALID __MSABI_LONG(1620)
#define ERROR_INSTALL_UI_FAILURE __MSABI_LONG(1621)
#define ERROR_INSTALL_LOG_FAILURE __MSABI_LONG(1622)
#define ERROR_INSTALL_LANGUAGE_UNSUPPORTED __MSABI_LONG(1623)
#define ERROR_INSTALL_TRANSFORM_FAILURE __MSABI_LONG(1624)
#define ERROR_INSTALL_PACKAGE_REJECTED __MSABI_LONG(1625)
#define ERROR_FUNCTION_NOT_CALLED __MSABI_LONG(1626)
#define ERROR_FUNCTION_FAILED __MSABI_LONG(1627)
#define ERROR_INVALID_TABLE __MSABI_LONG(1628)
#define ERROR_DATATYPE_MISMATCH __MSABI_LONG(1629)
#define ERROR_UNSUPPORTED_TYPE __MSABI_LONG(1630)
#define ERROR_CREATE_FAILED __MSABI_LONG(1631)
#define ERROR_INSTALL_TEMP_UNWRITABLE __MSABI_LONG(1632)
#define ERROR_INSTALL_PLATFORM_UNSUPPORTED __MSABI_LONG(1633)
#define ERROR_INSTALL_NOTUSED __MSABI_LONG(1634)
#define ERROR_PATCH_PACKAGE_OPEN_FAILED __MSABI_LONG(1635)
#define ERROR_PATCH_PACKAGE_INVALID __MSABI_LONG(1636)
#define ERROR_PATCH_PACKAGE_UNSUPPORTED __MSABI_LONG(1637)
#define ERROR_PRODUCT_VERSION __MSABI_LONG(1638)
#define ERROR_INVALID_COMMAND_LINE __MSABI_LONG(1639)
#define ERROR_INSTALL_REMOTE_DISALLOWED __MSABI_LONG(1640)
#define ERROR_SUCCESS_REBOOT_INITIATED __MSABI_LONG(1641)
#define ERROR_PATCH_TARGET_NOT_FOUND __MSABI_LONG(1642)
#define ERROR_PATCH_PACKAGE_REJECTED __MSABI_LONG(1643)
#define ERROR_INSTALL_TRANSFORM_REJECTED __MSABI_LONG(1644)
#define ERROR_INSTALL_REMOTE_PROHIBITED __MSABI_LONG(1645)
#define RPC_S_INVALID_STRING_BINDING __MSABI_LONG(1700)
#define RPC_S_WRONG_KIND_OF_BINDING __MSABI_LONG(1701)
#define RPC_S_INVALID_BINDING __MSABI_LONG(1702)
#define RPC_S_PROTSEQ_NOT_SUPPORTED __MSABI_LONG(1703)
#define RPC_S_INVALID_RPC_PROTSEQ __MSABI_LONG(1704)
#define RPC_S_INVALID_STRING_UUID __MSABI_LONG(1705)
#define RPC_S_INVALID_ENDPOINT_FORMAT __MSABI_LONG(1706)
#define RPC_S_INVALID_NET_ADDR __MSABI_LONG(1707)
#define RPC_S_NO_ENDPOINT_FOUND __MSABI_LONG(1708)
#define RPC_S_INVALID_TIMEOUT __MSABI_LONG(1709)
#define RPC_S_OBJECT_NOT_FOUND __MSABI_LONG(1710)
#define RPC_S_ALREADY_REGISTERED __MSABI_LONG(1711)
#define RPC_S_TYPE_ALREADY_REGISTERED __MSABI_LONG(1712)
#define RPC_S_ALREADY_LISTENING __MSABI_LONG(1713)
#define RPC_S_NO_PROTSEQS_REGISTERED __MSABI_LONG(1714)
#define RPC_S_NOT_LISTENING __MSABI_LONG(1715)
#define RPC_S_UNKNOWN_MGR_TYPE __MSABI_LONG(1716)
#define RPC_S_UNKNOWN_IF __MSABI_LONG(1717)
#define RPC_S_NO_BINDINGS __MSABI_LONG(1718)
#define RPC_S_NO_PROTSEQS __MSABI_LONG(1719)
#define RPC_S_CANT_CREATE_ENDPOINT __MSABI_LONG(1720)
#define RPC_S_OUT_OF_RESOURCES __MSABI_LONG(1721)
#define RPC_S_SERVER_UNAVAILABLE __MSABI_LONG(1722)
#define RPC_S_SERVER_TOO_BUSY __MSABI_LONG(1723)
#define RPC_S_INVALID_NETWORK_OPTIONS __MSABI_LONG(1724)
#define RPC_S_NO_CALL_ACTIVE __MSABI_LONG(1725)
#define RPC_S_CALL_FAILED __MSABI_LONG(1726)
#define RPC_S_CALL_FAILED_DNE __MSABI_LONG(1727)
#define RPC_S_PROTOCOL_ERROR __MSABI_LONG(1728)
#define RPC_S_UNSUPPORTED_TRANS_SYN __MSABI_LONG(1730)
#define RPC_S_UNSUPPORTED_TYPE __MSABI_LONG(1732)
#define RPC_S_INVALID_TAG __MSABI_LONG(1733)
#define RPC_S_INVALID_BOUND __MSABI_LONG(1734)
#define RPC_S_NO_ENTRY_NAME __MSABI_LONG(1735)
#define RPC_S_INVALID_NAME_SYNTAX __MSABI_LONG(1736)
#define RPC_S_UNSUPPORTED_NAME_SYNTAX __MSABI_LONG(1737)
#define RPC_S_UUID_NO_ADDRESS __MSABI_LONG(1739)
#define RPC_S_DUPLICATE_ENDPOINT __MSABI_LONG(1740)
#define RPC_S_UNKNOWN_AUTHN_TYPE __MSABI_LONG(1741)
#define RPC_S_MAX_CALLS_TOO_SMALL __MSABI_LONG(1742)
#define RPC_S_STRING_TOO_LONG __MSABI_LONG(1743)
#define RPC_S_PROTSEQ_NOT_FOUND __MSABI_LONG(1744)
#define RPC_S_PROCNUM_OUT_OF_RANGE __MSABI_LONG(1745)
#define RPC_S_BINDING_HAS_NO_AUTH __MSABI_LONG(1746)
#define RPC_S_UNKNOWN_AUTHN_SERVICE __MSABI_LONG(1747)
#define RPC_S_UNKNOWN_AUTHN_LEVEL __MSABI_LONG(1748)
#define RPC_S_INVALID_AUTH_IDENTITY __MSABI_LONG(1749)
#define RPC_S_UNKNOWN_AUTHZ_SERVICE __MSABI_LONG(1750)
#define EPT_S_INVALID_ENTRY __MSABI_LONG(1751)
#define EPT_S_CANT_PERFORM_OP __MSABI_LONG(1752)
#define EPT_S_NOT_REGISTERED __MSABI_LONG(1753)
#define RPC_S_NOTHING_TO_EXPORT __MSABI_LONG(1754)
#define RPC_S_INCOMPLETE_NAME __MSABI_LONG(1755)
#define RPC_S_INVALID_VERS_OPTION __MSABI_LONG(1756)
#define RPC_S_NO_MORE_MEMBERS __MSABI_LONG(1757)
#define RPC_S_NOT_ALL_OBJS_UNEXPORTED __MSABI_LONG(1758)
#define RPC_S_INTERFACE_NOT_FOUND __MSABI_LONG(1759)
#define RPC_S_ENTRY_ALREADY_EXISTS __MSABI_LONG(1760)
#define RPC_S_ENTRY_NOT_FOUND __MSABI_LONG(1761)
#define RPC_S_NAME_SERVICE_UNAVAILABLE __MSABI_LONG(1762)
#define RPC_S_INVALID_NAF_ID __MSABI_LONG(1763)
#define RPC_S_CANNOT_SUPPORT __MSABI_LONG(1764)
#define RPC_S_NO_CONTEXT_AVAILABLE __MSABI_LONG(1765)
#define RPC_S_INTERNAL_ERROR __MSABI_LONG(1766)
#define RPC_S_ZERO_DIVIDE __MSABI_LONG(1767)
#define RPC_S_ADDRESS_ERROR __MSABI_LONG(1768)
#define RPC_S_FP_DIV_ZERO __MSABI_LONG(1769)
#define RPC_S_FP_UNDERFLOW __MSABI_LONG(1770)
#define RPC_S_FP_OVERFLOW __MSABI_LONG(1771)
#define RPC_X_NO_MORE_ENTRIES __MSABI_LONG(1772)
#define RPC_X_SS_CHAR_TRANS_OPEN_FAIL __MSABI_LONG(1773)
#define RPC_X_SS_CHAR_TRANS_SHORT_FILE __MSABI_LONG(1774)
#define RPC_X_SS_IN_NULL_CONTEXT __MSABI_LONG(1775)
#define RPC_X_SS_CONTEXT_DAMAGED __MSABI_LONG(1777)
#define RPC_X_SS_HANDLES_MISMATCH __MSABI_LONG(1778)
#define RPC_X_SS_CANNOT_GET_CALL_HANDLE __MSABI_LONG(1779)
#define RPC_X_NULL_REF_POINTER __MSABI_LONG(1780)
#define RPC_X_ENUM_VALUE_OUT_OF_RANGE __MSABI_LONG(1781)
#define RPC_X_BYTE_COUNT_TOO_SMALL __MSABI_LONG(1782)
#define RPC_X_BAD_STUB_DATA __MSABI_LONG(1783)
#define ERROR_INVALID_USER_BUFFER __MSABI_LONG(1784)
#define ERROR_UNRECOGNIZED_MEDIA __MSABI_LONG(1785)
#define ERROR_NO_TRUST_LSA_SECRET __MSABI_LONG(1786)
#define ERROR_NO_TRUST_SAM_ACCOUNT __MSABI_LONG(1787)
#define ERROR_TRUSTED_DOMAIN_FAILURE __MSABI_LONG(1788)
#define ERROR_TRUSTED_RELATIONSHIP_FAILURE __MSABI_LONG(1789)
#define ERROR_TRUST_FAILURE __MSABI_LONG(1790)
#define RPC_S_CALL_IN_PROGRESS __MSABI_LONG(1791)
#define ERROR_NETLOGON_NOT_STARTED __MSABI_LONG(1792)
#define ERROR_ACCOUNT_EXPIRED __MSABI_LONG(1793)
#define ERROR_REDIRECTOR_HAS_OPEN_HANDLES __MSABI_LONG(1794)
#define ERROR_PRINTER_DRIVER_ALREADY_INSTALLED __MSABI_LONG(1795)
#define ERROR_UNKNOWN_PORT __MSABI_LONG(1796)
#define ERROR_UNKNOWN_PRINTER_DRIVER __MSABI_LONG(1797)
#define ERROR_UNKNOWN_PRINTPROCESSOR __MSABI_LONG(1798)
#define ERROR_INVALID_SEPARATOR_FILE __MSABI_LONG(1799)
#define ERROR_INVALID_PRIORITY __MSABI_LONG(1800)
#define ERROR_INVALID_PRINTER_NAME __MSABI_LONG(1801)
#define ERROR_PRINTER_ALREADY_EXISTS __MSABI_LONG(1802)
#define ERROR_INVALID_PRINTER_COMMAND __MSABI_LONG(1803)
#define ERROR_INVALID_DATATYPE __MSABI_LONG(1804)
#define ERROR_INVALID_ENVIRONMENT __MSABI_LONG(1805)
#define RPC_S_NO_MORE_BINDINGS __MSABI_LONG(1806)
#define ERROR_NOLOGON_INTERDOMAIN_TRUST_ACCOUNT __MSABI_LONG(1807)
#define ERROR_NOLOGON_WORKSTATION_TRUST_ACCOUNT __MSABI_LONG(1808)
#define ERROR_NOLOGON_SERVER_TRUST_ACCOUNT __MSABI_LONG(1809)
#define ERROR_DOMAIN_TRUST_INCONSISTENT __MSABI_LONG(1810)
#define ERROR_SERVER_HAS_OPEN_HANDLES __MSABI_LONG(1811)
#define ERROR_RESOURCE_DATA_NOT_FOUND __MSABI_LONG(1812)
#define ERROR_RESOURCE_TYPE_NOT_FOUND __MSABI_LONG(1813)
#define ERROR_RESOURCE_NAME_NOT_FOUND __MSABI_LONG(1814)
#define ERROR_RESOURCE_LANG_NOT_FOUND __MSABI_LONG(1815)
#define ERROR_NOT_ENOUGH_QUOTA __MSABI_LONG(1816)
#define RPC_S_NO_INTERFACES __MSABI_LONG(1817)
#define RPC_S_CALL_CANCELLED __MSABI_LONG(1818)
#define RPC_S_BINDING_INCOMPLETE __MSABI_LONG(1819)
#define RPC_S_COMM_FAILURE __MSABI_LONG(1820)
#define RPC_S_UNSUPPORTED_AUTHN_LEVEL __MSABI_LONG(1821)
#define RPC_S_NO_PRINC_NAME __MSABI_LONG(1822)
#define RPC_S_NOT_RPC_ERROR __MSABI_LONG(1823)
#define RPC_S_UUID_LOCAL_ONLY __MSABI_LONG(1824)
#define RPC_S_SEC_PKG_ERROR __MSABI_LONG(1825)
#define RPC_S_NOT_CANCELLED __MSABI_LONG(1826)
#define RPC_X_INVALID_ES_ACTION __MSABI_LONG(1827)
#define RPC_X_WRONG_ES_VERSION __MSABI_LONG(1828)
#define RPC_X_WRONG_STUB_VERSION __MSABI_LONG(1829)
#define RPC_X_INVALID_PIPE_OBJECT __MSABI_LONG(1830)
#define RPC_X_WRONG_PIPE_ORDER __MSABI_LONG(1831)
#define RPC_X_WRONG_PIPE_VERSION __MSABI_LONG(1832)
#define RPC_S_GROUP_MEMBER_NOT_FOUND __MSABI_LONG(1898)
#define EPT_S_CANT_CREATE __MSABI_LONG(1899)
#define RPC_S_INVALID_OBJECT __MSABI_LONG(1900)
#define ERROR_INVALID_TIME __MSABI_LONG(1901)
#define ERROR_INVALID_FORM_NAME __MSABI_LONG(1902)
#define ERROR_INVALID_FORM_SIZE __MSABI_LONG(1903)
#define ERROR_ALREADY_WAITING __MSABI_LONG(1904)
#define ERROR_PRINTER_DELETED __MSABI_LONG(1905)
#define ERROR_INVALID_PRINTER_STATE __MSABI_LONG(1906)
#define ERROR_PASSWORD_MUST_CHANGE __MSABI_LONG(1907)
#define ERROR_DOMAIN_CONTROLLER_NOT_FOUND __MSABI_LONG(1908)
#define ERROR_ACCOUNT_LOCKED_OUT __MSABI_LONG(1909)
#define OR_INVALID_OXID __MSABI_LONG(1910)
#define OR_INVALID_OID __MSABI_LONG(1911)
#define OR_INVALID_SET __MSABI_LONG(1912)
#define RPC_S_SEND_INCOMPLETE __MSABI_LONG(1913)
#define RPC_S_INVALID_ASYNC_HANDLE __MSABI_LONG(1914)
#define RPC_S_INVALID_ASYNC_CALL __MSABI_LONG(1915)
#define RPC_X_PIPE_CLOSED __MSABI_LONG(1916)
#define RPC_X_PIPE_DISCIPLINE_ERROR __MSABI_LONG(1917)
#define RPC_X_PIPE_EMPTY __MSABI_LONG(1918)
#define ERROR_NO_SITENAME __MSABI_LONG(1919)
#define ERROR_CANT_ACCESS_FILE __MSABI_LONG(1920)
#define ERROR_CANT_RESOLVE_FILENAME __MSABI_LONG(1921)
#define RPC_S_ENTRY_TYPE_MISMATCH __MSABI_LONG(1922)
#define RPC_S_NOT_ALL_OBJS_EXPORTED __MSABI_LONG(1923)
#define RPC_S_INTERFACE_NOT_EXPORTED __MSABI_LONG(1924)
#define RPC_S_PROFILE_NOT_ADDED __MSABI_LONG(1925)
#define RPC_S_PRF_ELT_NOT_ADDED __MSABI_LONG(1926)
#define RPC_S_PRF_ELT_NOT_REMOVED __MSABI_LONG(1927)
#define RPC_S_GRP_ELT_NOT_ADDED __MSABI_LONG(1928)
#define RPC_S_GRP_ELT_NOT_REMOVED __MSABI_LONG(1929)
#define ERROR_KM_DRIVER_BLOCKED __MSABI_LONG(1930)
#define ERROR_CONTEXT_EXPIRED __MSABI_LONG(1931)
#define ERROR_PER_USER_TRUST_QUOTA_EXCEEDED __MSABI_LONG(1932)
#define ERROR_ALL_USER_TRUST_QUOTA_EXCEEDED __MSABI_LONG(1933)
#define ERROR_USER_DELETE_TRUST_QUOTA_EXCEEDED __MSABI_LONG(1934)
#define ERROR_AUTHENTICATION_FIREWALL_FAILED __MSABI_LONG(1935)
#define ERROR_REMOTE_PRINT_CONNECTIONS_BLOCKED __MSABI_LONG(1936)
#define ERROR_INVALID_PIXEL_FORMAT __MSABI_LONG(2000)
#define ERROR_BAD_DRIVER __MSABI_LONG(2001)
#define ERROR_INVALID_WINDOW_STYLE __MSABI_LONG(2002)
#define ERROR_METAFILE_NOT_SUPPORTED __MSABI_LONG(2003)
#define ERROR_TRANSFORM_NOT_SUPPORTED __MSABI_LONG(2004)
#define ERROR_CLIPPING_NOT_SUPPORTED __MSABI_LONG(2005)
#define ERROR_INVALID_CMM __MSABI_LONG(2010)
#define ERROR_INVALID_PROFILE __MSABI_LONG(2011)
#define ERROR_TAG_NOT_FOUND __MSABI_LONG(2012)
#define ERROR_TAG_NOT_PRESENT __MSABI_LONG(2013)
#define ERROR_DUPLICATE_TAG __MSABI_LONG(2014)
#define ERROR_PROFILE_NOT_ASSOCIATED_WITH_DEVICE __MSABI_LONG(2015)
#define ERROR_PROFILE_NOT_FOUND __MSABI_LONG(2016)
#define ERROR_INVALID_COLORSPACE __MSABI_LONG(2017)
#define ERROR_ICM_NOT_ENABLED __MSABI_LONG(2018)
#define ERROR_DELETING_ICM_XFORM __MSABI_LONG(2019)
#define ERROR_INVALID_TRANSFORM __MSABI_LONG(2020)
#define ERROR_COLORSPACE_MISMATCH __MSABI_LONG(2021)
#define ERROR_INVALID_COLORINDEX __MSABI_LONG(2022)
#define ERROR_CONNECTED_OTHER_PASSWORD __MSABI_LONG(2108)
#define ERROR_CONNECTED_OTHER_PASSWORD_DEFAULT __MSABI_LONG(2109)
#define ERROR_BAD_USERNAME __MSABI_LONG(2202)
#define ERROR_NOT_CONNECTED __MSABI_LONG(2250)
#define ERROR_OPEN_FILES __MSABI_LONG(2401)
#define ERROR_ACTIVE_CONNECTIONS __MSABI_LONG(2402)
#define ERROR_DEVICE_IN_USE __MSABI_LONG(2404)
#define ERROR_UNKNOWN_PRINT_MONITOR __MSABI_LONG(3000)
#define ERROR_PRINTER_DRIVER_IN_USE __MSABI_LONG(3001)
#define ERROR_SPOOL_FILE_NOT_FOUND __MSABI_LONG(3002)
#define ERROR_SPL_NO_STARTDOC __MSABI_LONG(3003)
#define ERROR_SPL_NO_ADDJOB __MSABI_LONG(3004)
#define ERROR_PRINT_PROCESSOR_ALREADY_INSTALLED __MSABI_LONG(3005)
#define ERROR_PRINT_MONITOR_ALREADY_INSTALLED __MSABI_LONG(3006)
#define ERROR_INVALID_PRINT_MONITOR __MSABI_LONG(3007)
#define ERROR_PRINT_MONITOR_IN_USE __MSABI_LONG(3008)
#define ERROR_PRINTER_HAS_JOBS_QUEUED __MSABI_LONG(3009)
#define ERROR_SUCCESS_REBOOT_REQUIRED __MSABI_LONG(3010)
#define ERROR_SUCCESS_RESTART_REQUIRED __MSABI_LONG(3011)
#define ERROR_PRINTER_NOT_FOUND __MSABI_LONG(3012)
#define ERROR_PRINTER_DRIVER_WARNED __MSABI_LONG(3013)
#define ERROR_PRINTER_DRIVER_BLOCKED __MSABI_LONG(3014)
#define ERROR_WINS_INTERNAL __MSABI_LONG(4000)
#define ERROR_CAN_NOT_DEL_LOCAL_WINS __MSABI_LONG(4001)
#define ERROR_STATIC_INIT __MSABI_LONG(4002)
#define ERROR_INC_BACKUP __MSABI_LONG(4003)
#define ERROR_FULL_BACKUP __MSABI_LONG(4004)
#define ERROR_REC_NON_EXISTENT __MSABI_LONG(4005)
#define ERROR_RPL_NOT_ALLOWED __MSABI_LONG(4006)
#define ERROR_DHCP_ADDRESS_CONFLICT __MSABI_LONG(4100)
#define ERROR_WMI_GUID_NOT_FOUND __MSABI_LONG(4200)
#define ERROR_WMI_INSTANCE_NOT_FOUND __MSABI_LONG(4201)
#define ERROR_WMI_ITEMID_NOT_FOUND __MSABI_LONG(4202)
#define ERROR_WMI_TRY_AGAIN __MSABI_LONG(4203)
#define ERROR_WMI_DP_NOT_FOUND __MSABI_LONG(4204)
#define ERROR_WMI_UNRESOLVED_INSTANCE_REF __MSABI_LONG(4205)
#define ERROR_WMI_ALREADY_ENABLED __MSABI_LONG(4206)
#define ERROR_WMI_GUID_DISCONNECTED __MSABI_LONG(4207)
#define ERROR_WMI_SERVER_UNAVAILABLE __MSABI_LONG(4208)
#define ERROR_WMI_DP_FAILED __MSABI_LONG(4209)
#define ERROR_WMI_INVALID_MOF __MSABI_LONG(4210)
#define ERROR_WMI_INVALID_REGINFO __MSABI_LONG(4211)
#define ERROR_WMI_ALREADY_DISABLED __MSABI_LONG(4212)
#define ERROR_WMI_READ_ONLY __MSABI_LONG(4213)
#define ERROR_WMI_SET_FAILURE __MSABI_LONG(4214)
#define ERROR_INVALID_MEDIA __MSABI_LONG(4300)
#define ERROR_INVALID_LIBRARY __MSABI_LONG(4301)
#define ERROR_INVALID_MEDIA_POOL __MSABI_LONG(4302)
#define ERROR_DRIVE_MEDIA_MISMATCH __MSABI_LONG(4303)
#define ERROR_MEDIA_OFFLINE __MSABI_LONG(4304)
#define ERROR_LIBRARY_OFFLINE __MSABI_LONG(4305)
#define ERROR_EMPTY __MSABI_LONG(4306)
#define ERROR_NOT_EMPTY __MSABI_LONG(4307)
#define ERROR_MEDIA_UNAVAILABLE __MSABI_LONG(4308)
#define ERROR_RESOURCE_DISABLED __MSABI_LONG(4309)
#define ERROR_INVALID_CLEANER __MSABI_LONG(4310)
#define ERROR_UNABLE_TO_CLEAN __MSABI_LONG(4311)
#define ERROR_OBJECT_NOT_FOUND __MSABI_LONG(4312)
#define ERROR_DATABASE_FAILURE __MSABI_LONG(4313)
#define ERROR_DATABASE_FULL __MSABI_LONG(4314)
#define ERROR_MEDIA_INCOMPATIBLE __MSABI_LONG(4315)
#define ERROR_RESOURCE_NOT_PRESENT __MSABI_LONG(4316)
#define ERROR_INVALID_OPERATION __MSABI_LONG(4317)
#define ERROR_MEDIA_NOT_AVAILABLE __MSABI_LONG(4318)
#define ERROR_DEVICE_NOT_AVAILABLE __MSABI_LONG(4319)
#define ERROR_REQUEST_REFUSED __MSABI_LONG(4320)
#define ERROR_INVALID_DRIVE_OBJECT __MSABI_LONG(4321)
#define ERROR_LIBRARY_FULL __MSABI_LONG(4322)
#define ERROR_MEDIUM_NOT_ACCESSIBLE __MSABI_LONG(4323)
#define ERROR_UNABLE_TO_LOAD_MEDIUM __MSABI_LONG(4324)
#define ERROR_UNABLE_TO_INVENTORY_DRIVE __MSABI_LONG(4325)
#define ERROR_UNABLE_TO_INVENTORY_SLOT __MSABI_LONG(4326)
#define ERROR_UNABLE_TO_INVENTORY_TRANSPORT __MSABI_LONG(4327)
#define ERROR_TRANSPORT_FULL __MSABI_LONG(4328)
#define ERROR_CONTROLLING_IEPORT __MSABI_LONG(4329)
#define ERROR_UNABLE_TO_EJECT_MOUNTED_MEDIA __MSABI_LONG(4330)
#define ERROR_CLEANER_SLOT_SET __MSABI_LONG(4331)
#define ERROR_CLEANER_SLOT_NOT_SET __MSABI_LONG(4332)
#define ERROR_CLEANER_CARTRIDGE_SPENT __MSABI_LONG(4333)
#define ERROR_UNEXPECTED_OMID __MSABI_LONG(4334)
#define ERROR_CANT_DELETE_LAST_ITEM __MSABI_LONG(4335)
#define ERROR_MESSAGE_EXCEEDS_MAX_SIZE __MSABI_LONG(4336)
#define ERROR_VOLUME_CONTAINS_SYS_FILES __MSABI_LONG(4337)
#define ERROR_INDIGENOUS_TYPE __MSABI_LONG(4338)
#define ERROR_NO_SUPPORTING_DRIVES __MSABI_LONG(4339)
#define ERROR_CLEANER_CARTRIDGE_INSTALLED __MSABI_LONG(4340)
#define ERROR_IEPORT_FULL __MSABI_LONG(4341)
#define ERROR_FILE_OFFLINE __MSABI_LONG(4350)
#define ERROR_REMOTE_STORAGE_NOT_ACTIVE __MSABI_LONG(4351)
#define ERROR_REMOTE_STORAGE_MEDIA_ERROR __MSABI_LONG(4352)
#define ERROR_NOT_A_REPARSE_POINT __MSABI_LONG(4390)
#define ERROR_REPARSE_ATTRIBUTE_CONFLICT __MSABI_LONG(4391)
#define ERROR_INVALID_REPARSE_DATA __MSABI_LONG(4392)
#define ERROR_REPARSE_TAG_INVALID __MSABI_LONG(4393)
#define ERROR_REPARSE_TAG_MISMATCH __MSABI_LONG(4394)
#define ERROR_VOLUME_NOT_SIS_ENABLED __MSABI_LONG(4500)
#define ERROR_DEPENDENT_RESOURCE_EXISTS __MSABI_LONG(5001)
#define ERROR_DEPENDENCY_NOT_FOUND __MSABI_LONG(5002)
#define ERROR_DEPENDENCY_ALREADY_EXISTS __MSABI_LONG(5003)
#define ERROR_RESOURCE_NOT_ONLINE __MSABI_LONG(5004)
#define ERROR_HOST_NODE_NOT_AVAILABLE __MSABI_LONG(5005)
#define ERROR_RESOURCE_NOT_AVAILABLE __MSABI_LONG(5006)
#define ERROR_RESOURCE_NOT_FOUND __MSABI_LONG(5007)
#define ERROR_SHUTDOWN_CLUSTER __MSABI_LONG(5008)
#define ERROR_CANT_EVICT_ACTIVE_NODE __MSABI_LONG(5009)
#define ERROR_OBJECT_ALREADY_EXISTS __MSABI_LONG(5010)
#define ERROR_OBJECT_IN_LIST __MSABI_LONG(5011)
#define ERROR_GROUP_NOT_AVAILABLE __MSABI_LONG(5012)
#define ERROR_GROUP_NOT_FOUND __MSABI_LONG(5013)
#define ERROR_GROUP_NOT_ONLINE __MSABI_LONG(5014)
#define ERROR_HOST_NODE_NOT_RESOURCE_OWNER __MSABI_LONG(5015)
#define ERROR_HOST_NODE_NOT_GROUP_OWNER __MSABI_LONG(5016)
#define ERROR_RESMON_CREATE_FAILED __MSABI_LONG(5017)
#define ERROR_RESMON_ONLINE_FAILED __MSABI_LONG(5018)
#define ERROR_RESOURCE_ONLINE __MSABI_LONG(5019)
#define ERROR_QUORUM_RESOURCE __MSABI_LONG(5020)
#define ERROR_NOT_QUORUM_CAPABLE __MSABI_LONG(5021)
#define ERROR_CLUSTER_SHUTTING_DOWN __MSABI_LONG(5022)
#define ERROR_INVALID_STATE __MSABI_LONG(5023)
#define ERROR_RESOURCE_PROPERTIES_STORED __MSABI_LONG(5024)
#define ERROR_NOT_QUORUM_CLASS __MSABI_LONG(5025)
#define ERROR_CORE_RESOURCE __MSABI_LONG(5026)
#define ERROR_QUORUM_RESOURCE_ONLINE_FAILED __MSABI_LONG(5027)
#define ERROR_QUORUMLOG_OPEN_FAILED __MSABI_LONG(5028)
#define ERROR_CLUSTERLOG_CORRUPT __MSABI_LONG(5029)
#define ERROR_CLUSTERLOG_RECORD_EXCEEDS_MAXSIZE __MSABI_LONG(5030)
#define ERROR_CLUSTERLOG_EXCEEDS_MAXSIZE __MSABI_LONG(5031)
#define ERROR_CLUSTERLOG_CHKPOINT_NOT_FOUND __MSABI_LONG(5032)
#define ERROR_CLUSTERLOG_NOT_ENOUGH_SPACE __MSABI_LONG(5033)
#define ERROR_QUORUM_OWNER_ALIVE __MSABI_LONG(5034)
#define ERROR_NETWORK_NOT_AVAILABLE __MSABI_LONG(5035)
#define ERROR_NODE_NOT_AVAILABLE __MSABI_LONG(5036)
#define ERROR_ALL_NODES_NOT_AVAILABLE __MSABI_LONG(5037)
#define ERROR_RESOURCE_FAILED __MSABI_LONG(5038)
#define ERROR_CLUSTER_INVALID_NODE __MSABI_LONG(5039)
#define ERROR_CLUSTER_NODE_EXISTS __MSABI_LONG(5040)
#define ERROR_CLUSTER_JOIN_IN_PROGRESS __MSABI_LONG(5041)
#define ERROR_CLUSTER_NODE_NOT_FOUND __MSABI_LONG(5042)
#define ERROR_CLUSTER_LOCAL_NODE_NOT_FOUND __MSABI_LONG(5043)
#define ERROR_CLUSTER_NETWORK_EXISTS __MSABI_LONG(5044)
#define ERROR_CLUSTER_NETWORK_NOT_FOUND __MSABI_LONG(5045)
#define ERROR_CLUSTER_NETINTERFACE_EXISTS __MSABI_LONG(5046)
#define ERROR_CLUSTER_NETINTERFACE_NOT_FOUND __MSABI_LONG(5047)
#define ERROR_CLUSTER_INVALID_REQUEST __MSABI_LONG(5048)
#define ERROR_CLUSTER_INVALID_NETWORK_PROVIDER __MSABI_LONG(5049)
#define ERROR_CLUSTER_NODE_DOWN __MSABI_LONG(5050)
#define ERROR_CLUSTER_NODE_UNREACHABLE __MSABI_LONG(5051)
#define ERROR_CLUSTER_NODE_NOT_MEMBER __MSABI_LONG(5052)
#define ERROR_CLUSTER_JOIN_NOT_IN_PROGRESS __MSABI_LONG(5053)
#define ERROR_CLUSTER_INVALID_NETWORK __MSABI_LONG(5054)
#define ERROR_CLUSTER_NODE_UP __MSABI_LONG(5056)
#define ERROR_CLUSTER_IPADDR_IN_USE __MSABI_LONG(5057)
#define ERROR_CLUSTER_NODE_NOT_PAUSED __MSABI_LONG(5058)
#define ERROR_CLUSTER_NO_SECURITY_CONTEXT __MSABI_LONG(5059)
#define ERROR_CLUSTER_NETWORK_NOT_INTERNAL __MSABI_LONG(5060)
#define ERROR_CLUSTER_NODE_ALREADY_UP __MSABI_LONG(5061)
#define ERROR_CLUSTER_NODE_ALREADY_DOWN __MSABI_LONG(5062)
#define ERROR_CLUSTER_NETWORK_ALREADY_ONLINE __MSABI_LONG(5063)
#define ERROR_CLUSTER_NETWORK_ALREADY_OFFLINE __MSABI_LONG(5064)
#define ERROR_CLUSTER_NODE_ALREADY_MEMBER __MSABI_LONG(5065)
#define ERROR_CLUSTER_LAST_INTERNAL_NETWORK __MSABI_LONG(5066)
#define ERROR_CLUSTER_NETWORK_HAS_DEPENDENTS __MSABI_LONG(5067)
#define ERROR_INVALID_OPERATION_ON_QUORUM __MSABI_LONG(5068)
#define ERROR_DEPENDENCY_NOT_ALLOWED __MSABI_LONG(5069)
#define ERROR_CLUSTER_NODE_PAUSED __MSABI_LONG(5070)
#define ERROR_NODE_CANT_HOST_RESOURCE __MSABI_LONG(5071)
#define ERROR_CLUSTER_NODE_NOT_READY __MSABI_LONG(5072)
#define ERROR_CLUSTER_NODE_SHUTTING_DOWN __MSABI_LONG(5073)
#define ERROR_CLUSTER_JOIN_ABORTED __MSABI_LONG(5074)
#define ERROR_CLUSTER_INCOMPATIBLE_VERSIONS __MSABI_LONG(5075)
#define ERROR_CLUSTER_MAXNUM_OF_RESOURCES_EXCEEDED __MSABI_LONG(5076)
#define ERROR_CLUSTER_SYSTEM_CONFIG_CHANGED __MSABI_LONG(5077)
#define ERROR_CLUSTER_RESOURCE_TYPE_NOT_FOUND __MSABI_LONG(5078)
#define ERROR_CLUSTER_RESTYPE_NOT_SUPPORTED __MSABI_LONG(5079)
#define ERROR_CLUSTER_RESNAME_NOT_FOUND __MSABI_LONG(5080)
#define ERROR_CLUSTER_NO_RPC_PACKAGES_REGISTERED __MSABI_LONG(5081)
#define ERROR_CLUSTER_OWNER_NOT_IN_PREFLIST __MSABI_LONG(5082)
#define ERROR_CLUSTER_DATABASE_SEQMISMATCH __MSABI_LONG(5083)
#define ERROR_RESMON_INVALID_STATE __MSABI_LONG(5084)
#define ERROR_CLUSTER_GUM_NOT_LOCKER __MSABI_LONG(5085)
#define ERROR_QUORUM_DISK_NOT_FOUND __MSABI_LONG(5086)
#define ERROR_DATABASE_BACKUP_CORRUPT __MSABI_LONG(5087)
#define ERROR_CLUSTER_NODE_ALREADY_HAS_DFS_ROOT __MSABI_LONG(5088)
#define ERROR_RESOURCE_PROPERTY_UNCHANGEABLE __MSABI_LONG(5089)
#define ERROR_CLUSTER_MEMBERSHIP_INVALID_STATE __MSABI_LONG(5890)
#define ERROR_CLUSTER_QUORUMLOG_NOT_FOUND __MSABI_LONG(5891)
#define ERROR_CLUSTER_MEMBERSHIP_HALT __MSABI_LONG(5892)
#define ERROR_CLUSTER_INSTANCE_ID_MISMATCH __MSABI_LONG(5893)
#define ERROR_CLUSTER_NETWORK_NOT_FOUND_FOR_IP __MSABI_LONG(5894)
#define ERROR_CLUSTER_PROPERTY_DATA_TYPE_MISMATCH __MSABI_LONG(5895)
#define ERROR_CLUSTER_EVICT_WITHOUT_CLEANUP __MSABI_LONG(5896)
#define ERROR_CLUSTER_PARAMETER_MISMATCH __MSABI_LONG(5897)
#define ERROR_NODE_CANNOT_BE_CLUSTERED __MSABI_LONG(5898)
#define ERROR_CLUSTER_WRONG_OS_VERSION __MSABI_LONG(5899)
#define ERROR_CLUSTER_CANT_CREATE_DUP_CLUSTER_NAME __MSABI_LONG(5900)
#define ERROR_CLUSCFG_ALREADY_COMMITTED __MSABI_LONG(5901)
#define ERROR_CLUSCFG_ROLLBACK_FAILED __MSABI_LONG(5902)
#define ERROR_CLUSCFG_SYSTEM_DISK_DRIVE_LETTER_CONFLICT __MSABI_LONG(5903)
#define ERROR_CLUSTER_OLD_VERSION __MSABI_LONG(5904)
#define ERROR_CLUSTER_MISMATCHED_COMPUTER_ACCT_NAME __MSABI_LONG(5905)
#define ERROR_ENCRYPTION_FAILED __MSABI_LONG(6000)
#define ERROR_DECRYPTION_FAILED __MSABI_LONG(6001)
#define ERROR_FILE_ENCRYPTED __MSABI_LONG(6002)
#define ERROR_NO_RECOVERY_POLICY __MSABI_LONG(6003)
#define ERROR_NO_EFS __MSABI_LONG(6004)
#define ERROR_WRONG_EFS __MSABI_LONG(6005)
#define ERROR_NO_USER_KEYS __MSABI_LONG(6006)
#define ERROR_FILE_NOT_ENCRYPTED __MSABI_LONG(6007)
#define ERROR_NOT_EXPORT_FORMAT __MSABI_LONG(6008)
#define ERROR_FILE_READ_ONLY __MSABI_LONG(6009)
#define ERROR_DIR_EFS_DISALLOWED __MSABI_LONG(6010)
#define ERROR_EFS_SERVER_NOT_TRUSTED __MSABI_LONG(6011)
#define ERROR_BAD_RECOVERY_POLICY __MSABI_LONG(6012)
#define ERROR_EFS_ALG_BLOB_TOO_BIG __MSABI_LONG(6013)
#define ERROR_VOLUME_NOT_SUPPORT_EFS __MSABI_LONG(6014)
#define ERROR_EFS_DISABLED __MSABI_LONG(6015)
#define ERROR_EFS_VERSION_NOT_SUPPORT __MSABI_LONG(6016)
#define ERROR_NO_BROWSER_SERVERS_FOUND __MSABI_LONG(6118)
#define SCHED_E_SERVICE_NOT_LOCALSYSTEM __MSABI_LONG(6200)
#define ERROR_CTX_WINSTATION_NAME_INVALID __MSABI_LONG(7001)
#define ERROR_CTX_INVALID_PD __MSABI_LONG(7002)
#define ERROR_CTX_PD_NOT_FOUND __MSABI_LONG(7003)
#define ERROR_CTX_WD_NOT_FOUND __MSABI_LONG(7004)
#define ERROR_CTX_CANNOT_MAKE_EVENTLOG_ENTRY __MSABI_LONG(7005)
#define ERROR_CTX_SERVICE_NAME_COLLISION __MSABI_LONG(7006)
#define ERROR_CTX_CLOSE_PENDING __MSABI_LONG(7007)
#define ERROR_CTX_NO_OUTBUF __MSABI_LONG(7008)
#define ERROR_CTX_MODEM_INF_NOT_FOUND __MSABI_LONG(7009)
#define ERROR_CTX_INVALID_MODEMNAME __MSABI_LONG(7010)
#define ERROR_CTX_MODEM_RESPONSE_ERROR __MSABI_LONG(7011)
#define ERROR_CTX_MODEM_RESPONSE_TIMEOUT __MSABI_LONG(7012)
#define ERROR_CTX_MODEM_RESPONSE_NO_CARRIER __MSABI_LONG(7013)
#define ERROR_CTX_MODEM_RESPONSE_NO_DIALTONE __MSABI_LONG(7014)
#define ERROR_CTX_MODEM_RESPONSE_BUSY __MSABI_LONG(7015)
#define ERROR_CTX_MODEM_RESPONSE_VOICE __MSABI_LONG(7016)
#define ERROR_CTX_TD_ERROR __MSABI_LONG(7017)
#define ERROR_CTX_WINSTATION_NOT_FOUND __MSABI_LONG(7022)
#define ERROR_CTX_WINSTATION_ALREADY_EXISTS __MSABI_LONG(7023)
#define ERROR_CTX_WINSTATION_BUSY __MSABI_LONG(7024)
#define ERROR_CTX_BAD_VIDEO_MODE __MSABI_LONG(7025)
#define ERROR_CTX_GRAPHICS_INVALID __MSABI_LONG(7035)
#define ERROR_CTX_LOGON_DISABLED __MSABI_LONG(7037)
#define ERROR_CTX_NOT_CONSOLE __MSABI_LONG(7038)
#define ERROR_CTX_CLIENT_QUERY_TIMEOUT __MSABI_LONG(7040)
#define ERROR_CTX_CONSOLE_DISCONNECT __MSABI_LONG(7041)
#define ERROR_CTX_CONSOLE_CONNECT __MSABI_LONG(7042)
#define ERROR_CTX_SHADOW_DENIED __MSABI_LONG(7044)
#define ERROR_CTX_WINSTATION_ACCESS_DENIED __MSABI_LONG(7045)
#define ERROR_CTX_INVALID_WD __MSABI_LONG(7049)
#define ERROR_CTX_SHADOW_INVALID __MSABI_LONG(7050)
#define ERROR_CTX_SHADOW_DISABLED __MSABI_LONG(7051)
#define ERROR_CTX_CLIENT_LICENSE_IN_USE __MSABI_LONG(7052)
#define ERROR_CTX_CLIENT_LICENSE_NOT_SET __MSABI_LONG(7053)
#define ERROR_CTX_LICENSE_NOT_AVAILABLE __MSABI_LONG(7054)
#define ERROR_CTX_LICENSE_CLIENT_INVALID __MSABI_LONG(7055)
#define ERROR_CTX_LICENSE_EXPIRED __MSABI_LONG(7056)
#define ERROR_CTX_SHADOW_NOT_RUNNING __MSABI_LONG(7057)
#define ERROR_CTX_SHADOW_ENDED_BY_MODE_CHANGE __MSABI_LONG(7058)
#define ERROR_ACTIVATION_COUNT_EXCEEDED __MSABI_LONG(7059)
#define FRS_ERR_INVALID_API_SEQUENCE __MSABI_LONG(8001)
#define FRS_ERR_STARTING_SERVICE __MSABI_LONG(8002)
#define FRS_ERR_STOPPING_SERVICE __MSABI_LONG(8003)
#define FRS_ERR_INTERNAL_API __MSABI_LONG(8004)
#define FRS_ERR_INTERNAL __MSABI_LONG(8005)
#define FRS_ERR_SERVICE_COMM __MSABI_LONG(8006)
#define FRS_ERR_INSUFFICIENT_PRIV __MSABI_LONG(8007)
#define FRS_ERR_AUTHENTICATION __MSABI_LONG(8008)
#define FRS_ERR_PARENT_INSUFFICIENT_PRIV __MSABI_LONG(8009)
#define FRS_ERR_PARENT_AUTHENTICATION __MSABI_LONG(8010)
#define FRS_ERR_CHILD_TO_PARENT_COMM __MSABI_LONG(8011)
#define FRS_ERR_PARENT_TO_CHILD_COMM __MSABI_LONG(8012)
#define FRS_ERR_SYSVOL_POPULATE __MSABI_LONG(8013)
#define FRS_ERR_SYSVOL_POPULATE_TIMEOUT __MSABI_LONG(8014)
#define FRS_ERR_SYSVOL_IS_BUSY __MSABI_LONG(8015)
#define FRS_ERR_SYSVOL_DEMOTE __MSABI_LONG(8016)
#define FRS_ERR_INVALID_SERVICE_PARAMETER __MSABI_LONG(8017)
#define DS_S_SUCCESS NO_ERROR
#define ERROR_DS_NOT_INSTALLED __MSABI_LONG(8200)
#define ERROR_DS_MEMBERSHIP_EVALUATED_LOCALLY __MSABI_LONG(8201)
#define ERROR_DS_NO_ATTRIBUTE_OR_VALUE __MSABI_LONG(8202)
#define ERROR_DS_INVALID_ATTRIBUTE_SYNTAX __MSABI_LONG(8203)
#define ERROR_DS_ATTRIBUTE_TYPE_UNDEFINED __MSABI_LONG(8204)
#define ERROR_DS_ATTRIBUTE_OR_VALUE_EXISTS __MSABI_LONG(8205)
#define ERROR_DS_BUSY __MSABI_LONG(8206)
#define ERROR_DS_UNAVAILABLE __MSABI_LONG(8207)
#define ERROR_DS_NO_RIDS_ALLOCATED __MSABI_LONG(8208)
#define ERROR_DS_NO_MORE_RIDS __MSABI_LONG(8209)
#define ERROR_DS_INCORRECT_ROLE_OWNER __MSABI_LONG(8210)
#define ERROR_DS_RIDMGR_INIT_ERROR __MSABI_LONG(8211)
#define ERROR_DS_OBJ_CLASS_VIOLATION __MSABI_LONG(8212)
#define ERROR_DS_CANT_ON_NON_LEAF __MSABI_LONG(8213)
#define ERROR_DS_CANT_ON_RDN __MSABI_LONG(8214)
#define ERROR_DS_CANT_MOD_OBJ_CLASS __MSABI_LONG(8215)
#define ERROR_DS_CROSS_DOM_MOVE_ERROR __MSABI_LONG(8216)
#define ERROR_DS_GC_NOT_AVAILABLE __MSABI_LONG(8217)
#define ERROR_SHARED_POLICY __MSABI_LONG(8218)
#define ERROR_POLICY_OBJECT_NOT_FOUND __MSABI_LONG(8219)
#define ERROR_POLICY_ONLY_IN_DS __MSABI_LONG(8220)
#define ERROR_PROMOTION_ACTIVE __MSABI_LONG(8221)
#define ERROR_NO_PROMOTION_ACTIVE __MSABI_LONG(8222)
#define ERROR_DS_OPERATIONS_ERROR __MSABI_LONG(8224)
#define ERROR_DS_PROTOCOL_ERROR __MSABI_LONG(8225)
#define ERROR_DS_TIMELIMIT_EXCEEDED __MSABI_LONG(8226)
#define ERROR_DS_SIZELIMIT_EXCEEDED __MSABI_LONG(8227)
#define ERROR_DS_ADMIN_LIMIT_EXCEEDED __MSABI_LONG(8228)
#define ERROR_DS_COMPARE_FALSE __MSABI_LONG(8229)
#define ERROR_DS_COMPARE_TRUE __MSABI_LONG(8230)
#define ERROR_DS_AUTH_METHOD_NOT_SUPPORTED __MSABI_LONG(8231)
#define ERROR_DS_STRONG_AUTH_REQUIRED __MSABI_LONG(8232)
#define ERROR_DS_INAPPROPRIATE_AUTH __MSABI_LONG(8233)
#define ERROR_DS_AUTH_UNKNOWN __MSABI_LONG(8234)
#define ERROR_DS_REFERRAL __MSABI_LONG(8235)
#define ERROR_DS_UNAVAILABLE_CRIT_EXTENSION __MSABI_LONG(8236)
#define ERROR_DS_CONFIDENTIALITY_REQUIRED __MSABI_LONG(8237)
#define ERROR_DS_INAPPROPRIATE_MATCHING __MSABI_LONG(8238)
#define ERROR_DS_CONSTRAINT_VIOLATION __MSABI_LONG(8239)
#define ERROR_DS_NO_SUCH_OBJECT __MSABI_LONG(8240)
#define ERROR_DS_ALIAS_PROBLEM __MSABI_LONG(8241)
#define ERROR_DS_INVALID_DN_SYNTAX __MSABI_LONG(8242)
#define ERROR_DS_IS_LEAF __MSABI_LONG(8243)
#define ERROR_DS_ALIAS_DEREF_PROBLEM __MSABI_LONG(8244)
#define ERROR_DS_UNWILLING_TO_PERFORM __MSABI_LONG(8245)
#define ERROR_DS_LOOP_DETECT __MSABI_LONG(8246)
#define ERROR_DS_NAMING_VIOLATION __MSABI_LONG(8247)
#define ERROR_DS_OBJECT_RESULTS_TOO_LARGE __MSABI_LONG(8248)
#define ERROR_DS_AFFECTS_MULTIPLE_DSAS __MSABI_LONG(8249)
#define ERROR_DS_SERVER_DOWN __MSABI_LONG(8250)
#define ERROR_DS_LOCAL_ERROR __MSABI_LONG(8251)
#define ERROR_DS_ENCODING_ERROR __MSABI_LONG(8252)
#define ERROR_DS_DECODING_ERROR __MSABI_LONG(8253)
#define ERROR_DS_FILTER_UNKNOWN __MSABI_LONG(8254)
#define ERROR_DS_PARAM_ERROR __MSABI_LONG(8255)
#define ERROR_DS_NOT_SUPPORTED __MSABI_LONG(8256)
#define ERROR_DS_NO_RESULTS_RETURNED __MSABI_LONG(8257)
#define ERROR_DS_CONTROL_NOT_FOUND __MSABI_LONG(8258)
#define ERROR_DS_CLIENT_LOOP __MSABI_LONG(8259)
#define ERROR_DS_REFERRAL_LIMIT_EXCEEDED __MSABI_LONG(8260)
#define ERROR_DS_SORT_CONTROL_MISSING __MSABI_LONG(8261)
#define ERROR_DS_OFFSET_RANGE_ERROR __MSABI_LONG(8262)
#define ERROR_DS_ROOT_MUST_BE_NC __MSABI_LONG(8301)
#define ERROR_DS_ADD_REPLICA_INHIBITED __MSABI_LONG(8302)
#define ERROR_DS_ATT_NOT_DEF_IN_SCHEMA __MSABI_LONG(8303)
#define ERROR_DS_MAX_OBJ_SIZE_EXCEEDED __MSABI_LONG(8304)
#define ERROR_DS_OBJ_STRING_NAME_EXISTS __MSABI_LONG(8305)
#define ERROR_DS_NO_RDN_DEFINED_IN_SCHEMA __MSABI_LONG(8306)
#define ERROR_DS_RDN_DOESNT_MATCH_SCHEMA __MSABI_LONG(8307)
#define ERROR_DS_NO_REQUESTED_ATTS_FOUND __MSABI_LONG(8308)
#define ERROR_DS_USER_BUFFER_TO_SMALL __MSABI_LONG(8309)
#define ERROR_DS_ATT_IS_NOT_ON_OBJ __MSABI_LONG(8310)
#define ERROR_DS_ILLEGAL_MOD_OPERATION __MSABI_LONG(8311)
#define ERROR_DS_OBJ_TOO_LARGE __MSABI_LONG(8312)
#define ERROR_DS_BAD_INSTANCE_TYPE __MSABI_LONG(8313)
#define ERROR_DS_MASTERDSA_REQUIRED __MSABI_LONG(8314)
#define ERROR_DS_OBJECT_CLASS_REQUIRED __MSABI_LONG(8315)
#define ERROR_DS_MISSING_REQUIRED_ATT __MSABI_LONG(8316)
#define ERROR_DS_ATT_NOT_DEF_FOR_CLASS __MSABI_LONG(8317)
#define ERROR_DS_ATT_ALREADY_EXISTS __MSABI_LONG(8318)
#define ERROR_DS_CANT_ADD_ATT_VALUES __MSABI_LONG(8320)
#define ERROR_DS_SINGLE_VALUE_CONSTRAINT __MSABI_LONG(8321)
#define ERROR_DS_RANGE_CONSTRAINT __MSABI_LONG(8322)
#define ERROR_DS_ATT_VAL_ALREADY_EXISTS __MSABI_LONG(8323)
#define ERROR_DS_CANT_REM_MISSING_ATT __MSABI_LONG(8324)
#define ERROR_DS_CANT_REM_MISSING_ATT_VAL __MSABI_LONG(8325)
#define ERROR_DS_ROOT_CANT_BE_SUBREF __MSABI_LONG(8326)
#define ERROR_DS_NO_CHAINING __MSABI_LONG(8327)
#define ERROR_DS_NO_CHAINED_EVAL __MSABI_LONG(8328)
#define ERROR_DS_NO_PARENT_OBJECT __MSABI_LONG(8329)
#define ERROR_DS_PARENT_IS_AN_ALIAS __MSABI_LONG(8330)
#define ERROR_DS_CANT_MIX_MASTER_AND_REPS __MSABI_LONG(8331)
#define ERROR_DS_CHILDREN_EXIST __MSABI_LONG(8332)
#define ERROR_DS_OBJ_NOT_FOUND __MSABI_LONG(8333)
#define ERROR_DS_ALIASED_OBJ_MISSING __MSABI_LONG(8334)
#define ERROR_DS_BAD_NAME_SYNTAX __MSABI_LONG(8335)
#define ERROR_DS_ALIAS_POINTS_TO_ALIAS __MSABI_LONG(8336)
#define ERROR_DS_CANT_DEREF_ALIAS __MSABI_LONG(8337)
#define ERROR_DS_OUT_OF_SCOPE __MSABI_LONG(8338)
#define ERROR_DS_OBJECT_BEING_REMOVED __MSABI_LONG(8339)
#define ERROR_DS_CANT_DELETE_DSA_OBJ __MSABI_LONG(8340)
#define ERROR_DS_GENERIC_ERROR __MSABI_LONG(8341)
#define ERROR_DS_DSA_MUST_BE_INT_MASTER __MSABI_LONG(8342)
#define ERROR_DS_CLASS_NOT_DSA __MSABI_LONG(8343)
#define ERROR_DS_INSUFF_ACCESS_RIGHTS __MSABI_LONG(8344)
#define ERROR_DS_ILLEGAL_SUPERIOR __MSABI_LONG(8345)
#define ERROR_DS_ATTRIBUTE_OWNED_BY_SAM __MSABI_LONG(8346)
#define ERROR_DS_NAME_TOO_MANY_PARTS __MSABI_LONG(8347)
#define ERROR_DS_NAME_TOO_LONG __MSABI_LONG(8348)
#define ERROR_DS_NAME_VALUE_TOO_LONG __MSABI_LONG(8349)
#define ERROR_DS_NAME_UNPARSEABLE __MSABI_LONG(8350)
#define ERROR_DS_NAME_TYPE_UNKNOWN __MSABI_LONG(8351)
#define ERROR_DS_NOT_AN_OBJECT __MSABI_LONG(8352)
#define ERROR_DS_SEC_DESC_TOO_SHORT __MSABI_LONG(8353)
#define ERROR_DS_SEC_DESC_INVALID __MSABI_LONG(8354)
#define ERROR_DS_NO_DELETED_NAME __MSABI_LONG(8355)
#define ERROR_DS_SUBREF_MUST_HAVE_PARENT __MSABI_LONG(8356)
#define ERROR_DS_NCNAME_MUST_BE_NC __MSABI_LONG(8357)
#define ERROR_DS_CANT_ADD_SYSTEM_ONLY __MSABI_LONG(8358)
#define ERROR_DS_CLASS_MUST_BE_CONCRETE __MSABI_LONG(8359)
#define ERROR_DS_INVALID_DMD __MSABI_LONG(8360)
#define ERROR_DS_OBJ_GUID_EXISTS __MSABI_LONG(8361)
#define ERROR_DS_NOT_ON_BACKLINK __MSABI_LONG(8362)
#define ERROR_DS_NO_CROSSREF_FOR_NC __MSABI_LONG(8363)
#define ERROR_DS_SHUTTING_DOWN __MSABI_LONG(8364)
#define ERROR_DS_UNKNOWN_OPERATION __MSABI_LONG(8365)
#define ERROR_DS_INVALID_ROLE_OWNER __MSABI_LONG(8366)
#define ERROR_DS_COULDNT_CONTACT_FSMO __MSABI_LONG(8367)
#define ERROR_DS_CROSS_NC_DN_RENAME __MSABI_LONG(8368)
#define ERROR_DS_CANT_MOD_SYSTEM_ONLY __MSABI_LONG(8369)
#define ERROR_DS_REPLICATOR_ONLY __MSABI_LONG(8370)
#define ERROR_DS_OBJ_CLASS_NOT_DEFINED __MSABI_LONG(8371)
#define ERROR_DS_OBJ_CLASS_NOT_SUBCLASS __MSABI_LONG(8372)
#define ERROR_DS_NAME_REFERENCE_INVALID __MSABI_LONG(8373)
#define ERROR_DS_CROSS_REF_EXISTS __MSABI_LONG(8374)
#define ERROR_DS_CANT_DEL_MASTER_CROSSREF __MSABI_LONG(8375)
#define ERROR_DS_SUBTREE_NOTIFY_NOT_NC_HEAD __MSABI_LONG(8376)
#define ERROR_DS_NOTIFY_FILTER_TOO_COMPLEX __MSABI_LONG(8377)
#define ERROR_DS_DUP_RDN __MSABI_LONG(8378)
#define ERROR_DS_DUP_OID __MSABI_LONG(8379)
#define ERROR_DS_DUP_MAPI_ID __MSABI_LONG(8380)
#define ERROR_DS_DUP_SCHEMA_ID_GUID __MSABI_LONG(8381)
#define ERROR_DS_DUP_LDAP_DISPLAY_NAME __MSABI_LONG(8382)
#define ERROR_DS_SEMANTIC_ATT_TEST __MSABI_LONG(8383)
#define ERROR_DS_SYNTAX_MISMATCH __MSABI_LONG(8384)
#define ERROR_DS_EXISTS_IN_MUST_HAVE __MSABI_LONG(8385)
#define ERROR_DS_EXISTS_IN_MAY_HAVE __MSABI_LONG(8386)
#define ERROR_DS_NONEXISTENT_MAY_HAVE __MSABI_LONG(8387)
#define ERROR_DS_NONEXISTENT_MUST_HAVE __MSABI_LONG(8388)
#define ERROR_DS_AUX_CLS_TEST_FAIL __MSABI_LONG(8389)
#define ERROR_DS_NONEXISTENT_POSS_SUP __MSABI_LONG(8390)
#define ERROR_DS_SUB_CLS_TEST_FAIL __MSABI_LONG(8391)
#define ERROR_DS_BAD_RDN_ATT_ID_SYNTAX __MSABI_LONG(8392)
#define ERROR_DS_EXISTS_IN_AUX_CLS __MSABI_LONG(8393)
#define ERROR_DS_EXISTS_IN_SUB_CLS __MSABI_LONG(8394)
#define ERROR_DS_EXISTS_IN_POSS_SUP __MSABI_LONG(8395)
#define ERROR_DS_RECALCSCHEMA_FAILED __MSABI_LONG(8396)
#define ERROR_DS_TREE_DELETE_NOT_FINISHED __MSABI_LONG(8397)
#define ERROR_DS_CANT_DELETE __MSABI_LONG(8398)
#define ERROR_DS_ATT_SCHEMA_REQ_ID __MSABI_LONG(8399)
#define ERROR_DS_BAD_ATT_SCHEMA_SYNTAX __MSABI_LONG(8400)
#define ERROR_DS_CANT_CACHE_ATT __MSABI_LONG(8401)
#define ERROR_DS_CANT_CACHE_CLASS __MSABI_LONG(8402)
#define ERROR_DS_CANT_REMOVE_ATT_CACHE __MSABI_LONG(8403)
#define ERROR_DS_CANT_REMOVE_CLASS_CACHE __MSABI_LONG(8404)
#define ERROR_DS_CANT_RETRIEVE_DN __MSABI_LONG(8405)
#define ERROR_DS_MISSING_SUPREF __MSABI_LONG(8406)
#define ERROR_DS_CANT_RETRIEVE_INSTANCE __MSABI_LONG(8407)
#define ERROR_DS_CODE_INCONSISTENCY __MSABI_LONG(8408)
#define ERROR_DS_DATABASE_ERROR __MSABI_LONG(8409)
#define ERROR_DS_GOVERNSID_MISSING __MSABI_LONG(8410)
#define ERROR_DS_MISSING_EXPECTED_ATT __MSABI_LONG(8411)
#define ERROR_DS_NCNAME_MISSING_CR_REF __MSABI_LONG(8412)
#define ERROR_DS_SECURITY_CHECKING_ERROR __MSABI_LONG(8413)
#define ERROR_DS_SCHEMA_NOT_LOADED __MSABI_LONG(8414)
#define ERROR_DS_SCHEMA_ALLOC_FAILED __MSABI_LONG(8415)
#define ERROR_DS_ATT_SCHEMA_REQ_SYNTAX __MSABI_LONG(8416)
#define ERROR_DS_GCVERIFY_ERROR __MSABI_LONG(8417)
#define ERROR_DS_DRA_SCHEMA_MISMATCH __MSABI_LONG(8418)
#define ERROR_DS_CANT_FIND_DSA_OBJ __MSABI_LONG(8419)
#define ERROR_DS_CANT_FIND_EXPECTED_NC __MSABI_LONG(8420)
#define ERROR_DS_CANT_FIND_NC_IN_CACHE __MSABI_LONG(8421)
#define ERROR_DS_CANT_RETRIEVE_CHILD __MSABI_LONG(8422)
#define ERROR_DS_SECURITY_ILLEGAL_MODIFY __MSABI_LONG(8423)
#define ERROR_DS_CANT_REPLACE_HIDDEN_REC __MSABI_LONG(8424)
#define ERROR_DS_BAD_HIERARCHY_FILE __MSABI_LONG(8425)
#define ERROR_DS_BUILD_HIERARCHY_TABLE_FAILED __MSABI_LONG(8426)
#define ERROR_DS_CONFIG_PARAM_MISSING __MSABI_LONG(8427)
#define ERROR_DS_COUNTING_AB_INDICES_FAILED __MSABI_LONG(8428)
#define ERROR_DS_HIERARCHY_TABLE_MALLOC_FAILED __MSABI_LONG(8429)
#define ERROR_DS_INTERNAL_FAILURE __MSABI_LONG(8430)
#define ERROR_DS_UNKNOWN_ERROR __MSABI_LONG(8431)
#define ERROR_DS_ROOT_REQUIRES_CLASS_TOP __MSABI_LONG(8432)
#define ERROR_DS_REFUSING_FSMO_ROLES __MSABI_LONG(8433)
#define ERROR_DS_MISSING_FSMO_SETTINGS __MSABI_LONG(8434)
#define ERROR_DS_UNABLE_TO_SURRENDER_ROLES __MSABI_LONG(8435)
#define ERROR_DS_DRA_GENERIC __MSABI_LONG(8436)
#define ERROR_DS_DRA_INVALID_PARAMETER __MSABI_LONG(8437)
#define ERROR_DS_DRA_BUSY __MSABI_LONG(8438)
#define ERROR_DS_DRA_BAD_DN __MSABI_LONG(8439)
#define ERROR_DS_DRA_BAD_NC __MSABI_LONG(8440)
#define ERROR_DS_DRA_DN_EXISTS __MSABI_LONG(8441)
#define ERROR_DS_DRA_INTERNAL_ERROR __MSABI_LONG(8442)
#define ERROR_DS_DRA_INCONSISTENT_DIT __MSABI_LONG(8443)
#define ERROR_DS_DRA_CONNECTION_FAILED __MSABI_LONG(8444)
#define ERROR_DS_DRA_BAD_INSTANCE_TYPE __MSABI_LONG(8445)
#define ERROR_DS_DRA_OUT_OF_MEM __MSABI_LONG(8446)
#define ERROR_DS_DRA_MAIL_PROBLEM __MSABI_LONG(8447)
#define ERROR_DS_DRA_REF_ALREADY_EXISTS __MSABI_LONG(8448)
#define ERROR_DS_DRA_REF_NOT_FOUND __MSABI_LONG(8449)
#define ERROR_DS_DRA_OBJ_IS_REP_SOURCE __MSABI_LONG(8450)
#define ERROR_DS_DRA_DB_ERROR __MSABI_LONG(8451)
#define ERROR_DS_DRA_NO_REPLICA __MSABI_LONG(8452)
#define ERROR_DS_DRA_ACCESS_DENIED __MSABI_LONG(8453)
#define ERROR_DS_DRA_NOT_SUPPORTED __MSABI_LONG(8454)
#define ERROR_DS_DRA_RPC_CANCELLED __MSABI_LONG(8455)
#define ERROR_DS_DRA_SOURCE_DISABLED __MSABI_LONG(8456)
#define ERROR_DS_DRA_SINK_DISABLED __MSABI_LONG(8457)
#define ERROR_DS_DRA_NAME_COLLISION __MSABI_LONG(8458)
#define ERROR_DS_DRA_SOURCE_REINSTALLED __MSABI_LONG(8459)
#define ERROR_DS_DRA_MISSING_PARENT __MSABI_LONG(8460)
#define ERROR_DS_DRA_PREEMPTED __MSABI_LONG(8461)
#define ERROR_DS_DRA_ABANDON_SYNC __MSABI_LONG(8462)
#define ERROR_DS_DRA_SHUTDOWN __MSABI_LONG(8463)
#define ERROR_DS_DRA_INCOMPATIBLE_PARTIAL_SET __MSABI_LONG(8464)
#define ERROR_DS_DRA_SOURCE_IS_PARTIAL_REPLICA __MSABI_LONG(8465)
#define ERROR_DS_DRA_EXTN_CONNECTION_FAILED __MSABI_LONG(8466)
#define ERROR_DS_INSTALL_SCHEMA_MISMATCH __MSABI_LONG(8467)
#define ERROR_DS_DUP_LINK_ID __MSABI_LONG(8468)
#define ERROR_DS_NAME_ERROR_RESOLVING __MSABI_LONG(8469)
#define ERROR_DS_NAME_ERROR_NOT_FOUND __MSABI_LONG(8470)
#define ERROR_DS_NAME_ERROR_NOT_UNIQUE __MSABI_LONG(8471)
#define ERROR_DS_NAME_ERROR_NO_MAPPING __MSABI_LONG(8472)
#define ERROR_DS_NAME_ERROR_DOMAIN_ONLY __MSABI_LONG(8473)
#define ERROR_DS_NAME_ERROR_NO_SYNTACTICAL_MAPPING __MSABI_LONG(8474)
#define ERROR_DS_CONSTRUCTED_ATT_MOD __MSABI_LONG(8475)
#define ERROR_DS_WRONG_OM_OBJ_CLASS __MSABI_LONG(8476)
#define ERROR_DS_DRA_REPL_PENDING __MSABI_LONG(8477)
#define ERROR_DS_DS_REQUIRED __MSABI_LONG(8478)
#define ERROR_DS_INVALID_LDAP_DISPLAY_NAME __MSABI_LONG(8479)
#define ERROR_DS_NON_BASE_SEARCH __MSABI_LONG(8480)
#define ERROR_DS_CANT_RETRIEVE_ATTS __MSABI_LONG(8481)
#define ERROR_DS_BACKLINK_WITHOUT_LINK __MSABI_LONG(8482)
#define ERROR_DS_EPOCH_MISMATCH __MSABI_LONG(8483)
#define ERROR_DS_SRC_NAME_MISMATCH __MSABI_LONG(8484)
#define ERROR_DS_SRC_AND_DST_NC_IDENTICAL __MSABI_LONG(8485)
#define ERROR_DS_DST_NC_MISMATCH __MSABI_LONG(8486)
#define ERROR_DS_NOT_AUTHORITIVE_FOR_DST_NC __MSABI_LONG(8487)
#define ERROR_DS_SRC_GUID_MISMATCH __MSABI_LONG(8488)
#define ERROR_DS_CANT_MOVE_DELETED_OBJECT __MSABI_LONG(8489)
#define ERROR_DS_PDC_OPERATION_IN_PROGRESS __MSABI_LONG(8490)
#define ERROR_DS_CROSS_DOMAIN_CLEANUP_REQD __MSABI_LONG(8491)
#define ERROR_DS_ILLEGAL_XDOM_MOVE_OPERATION __MSABI_LONG(8492)
#define ERROR_DS_CANT_WITH_ACCT_GROUP_MEMBERSHPS __MSABI_LONG(8493)
#define ERROR_DS_NC_MUST_HAVE_NC_PARENT __MSABI_LONG(8494)
#define ERROR_DS_CR_IMPOSSIBLE_TO_VALIDATE __MSABI_LONG(8495)
#define ERROR_DS_DST_DOMAIN_NOT_NATIVE __MSABI_LONG(8496)
#define ERROR_DS_MISSING_INFRASTRUCTURE_CONTAINER __MSABI_LONG(8497)
#define ERROR_DS_CANT_MOVE_ACCOUNT_GROUP __MSABI_LONG(8498)
#define ERROR_DS_CANT_MOVE_RESOURCE_GROUP __MSABI_LONG(8499)
#define ERROR_DS_INVALID_SEARCH_FLAG __MSABI_LONG(8500)
#define ERROR_DS_NO_TREE_DELETE_ABOVE_NC __MSABI_LONG(8501)
#define ERROR_DS_COULDNT_LOCK_TREE_FOR_DELETE __MSABI_LONG(8502)
#define ERROR_DS_COULDNT_IDENTIFY_OBJECTS_FOR_TREE_DELETE __MSABI_LONG(8503)
#define ERROR_DS_SAM_INIT_FAILURE __MSABI_LONG(8504)
#define ERROR_DS_SENSITIVE_GROUP_VIOLATION __MSABI_LONG(8505)
#define ERROR_DS_CANT_MOD_PRIMARYGROUPID __MSABI_LONG(8506)
#define ERROR_DS_ILLEGAL_BASE_SCHEMA_MOD __MSABI_LONG(8507)
#define ERROR_DS_NONSAFE_SCHEMA_CHANGE __MSABI_LONG(8508)
#define ERROR_DS_SCHEMA_UPDATE_DISALLOWED __MSABI_LONG(8509)
#define ERROR_DS_CANT_CREATE_UNDER_SCHEMA __MSABI_LONG(8510)
#define ERROR_DS_INSTALL_NO_SRC_SCH_VERSION __MSABI_LONG(8511)
#define ERROR_DS_INSTALL_NO_SCH_VERSION_IN_INIFILE __MSABI_LONG(8512)
#define ERROR_DS_INVALID_GROUP_TYPE __MSABI_LONG(8513)
#define ERROR_DS_NO_NEST_GLOBALGROUP_IN_MIXEDDOMAIN __MSABI_LONG(8514)
#define ERROR_DS_NO_NEST_LOCALGROUP_IN_MIXEDDOMAIN __MSABI_LONG(8515)
#define ERROR_DS_GLOBAL_CANT_HAVE_LOCAL_MEMBER __MSABI_LONG(8516)
#define ERROR_DS_GLOBAL_CANT_HAVE_UNIVERSAL_MEMBER __MSABI_LONG(8517)
#define ERROR_DS_UNIVERSAL_CANT_HAVE_LOCAL_MEMBER __MSABI_LONG(8518)
#define ERROR_DS_GLOBAL_CANT_HAVE_CROSSDOMAIN_MEMBER __MSABI_LONG(8519)
#define ERROR_DS_LOCAL_CANT_HAVE_CROSSDOMAIN_LOCAL_MEMBER __MSABI_LONG(8520)
#define ERROR_DS_HAVE_PRIMARY_MEMBERS __MSABI_LONG(8521)
#define ERROR_DS_STRING_SD_CONVERSION_FAILED __MSABI_LONG(8522)
#define ERROR_DS_NAMING_MASTER_GC __MSABI_LONG(8523)
#define ERROR_DS_DNS_LOOKUP_FAILURE __MSABI_LONG(8524)
#define ERROR_DS_COULDNT_UPDATE_SPNS __MSABI_LONG(8525)
#define ERROR_DS_CANT_RETRIEVE_SD __MSABI_LONG(8526)
#define ERROR_DS_KEY_NOT_UNIQUE __MSABI_LONG(8527)
#define ERROR_DS_WRONG_LINKED_ATT_SYNTAX __MSABI_LONG(8528)
#define ERROR_DS_SAM_NEED_BOOTKEY_PASSWORD __MSABI_LONG(8529)
#define ERROR_DS_SAM_NEED_BOOTKEY_FLOPPY __MSABI_LONG(8530)
#define ERROR_DS_CANT_START __MSABI_LONG(8531)
#define ERROR_DS_INIT_FAILURE __MSABI_LONG(8532)
#define ERROR_DS_NO_PKT_PRIVACY_ON_CONNECTION __MSABI_LONG(8533)
#define ERROR_DS_SOURCE_DOMAIN_IN_FOREST __MSABI_LONG(8534)
#define ERROR_DS_DESTINATION_DOMAIN_NOT_IN_FOREST __MSABI_LONG(8535)
#define ERROR_DS_DESTINATION_AUDITING_NOT_ENABLED __MSABI_LONG(8536)
#define ERROR_DS_CANT_FIND_DC_FOR_SRC_DOMAIN __MSABI_LONG(8537)
#define ERROR_DS_SRC_OBJ_NOT_GROUP_OR_USER __MSABI_LONG(8538)
#define ERROR_DS_SRC_SID_EXISTS_IN_FOREST __MSABI_LONG(8539)
#define ERROR_DS_SRC_AND_DST_OBJECT_CLASS_MISMATCH __MSABI_LONG(8540)
#define ERROR_SAM_INIT_FAILURE __MSABI_LONG(8541)
#define ERROR_DS_DRA_SCHEMA_INFO_SHIP __MSABI_LONG(8542)
#define ERROR_DS_DRA_SCHEMA_CONFLICT __MSABI_LONG(8543)
#define ERROR_DS_DRA_EARLIER_SCHEMA_CONFLICT __MSABI_LONG(8544)
#define ERROR_DS_DRA_OBJ_NC_MISMATCH __MSABI_LONG(8545)
#define ERROR_DS_NC_STILL_HAS_DSAS __MSABI_LONG(8546)
#define ERROR_DS_GC_REQUIRED __MSABI_LONG(8547)
#define ERROR_DS_LOCAL_MEMBER_OF_LOCAL_ONLY __MSABI_LONG(8548)
#define ERROR_DS_NO_FPO_IN_UNIVERSAL_GROUPS __MSABI_LONG(8549)
#define ERROR_DS_CANT_ADD_TO_GC __MSABI_LONG(8550)
#define ERROR_DS_NO_CHECKPOINT_WITH_PDC __MSABI_LONG(8551)
#define ERROR_DS_SOURCE_AUDITING_NOT_ENABLED __MSABI_LONG(8552)
#define ERROR_DS_CANT_CREATE_IN_NONDOMAIN_NC __MSABI_LONG(8553)
#define ERROR_DS_INVALID_NAME_FOR_SPN __MSABI_LONG(8554)
#define ERROR_DS_FILTER_USES_CONTRUCTED_ATTRS __MSABI_LONG(8555)
#define ERROR_DS_UNICODEPWD_NOT_IN_QUOTES __MSABI_LONG(8556)
#define ERROR_DS_MACHINE_ACCOUNT_QUOTA_EXCEEDED __MSABI_LONG(8557)
#define ERROR_DS_MUST_BE_RUN_ON_DST_DC __MSABI_LONG(8558)
#define ERROR_DS_SRC_DC_MUST_BE_SP4_OR_GREATER __MSABI_LONG(8559)
#define ERROR_DS_CANT_TREE_DELETE_CRITICAL_OBJ __MSABI_LONG(8560)
#define ERROR_DS_INIT_FAILURE_CONSOLE __MSABI_LONG(8561)
#define ERROR_DS_SAM_INIT_FAILURE_CONSOLE __MSABI_LONG(8562)
#define ERROR_DS_FOREST_VERSION_TOO_HIGH __MSABI_LONG(8563)
#define ERROR_DS_DOMAIN_VERSION_TOO_HIGH __MSABI_LONG(8564)
#define ERROR_DS_FOREST_VERSION_TOO_LOW __MSABI_LONG(8565)
#define ERROR_DS_DOMAIN_VERSION_TOO_LOW __MSABI_LONG(8566)
#define ERROR_DS_INCOMPATIBLE_VERSION __MSABI_LONG(8567)
#define ERROR_DS_LOW_DSA_VERSION __MSABI_LONG(8568)
#define ERROR_DS_NO_BEHAVIOR_VERSION_IN_MIXEDDOMAIN __MSABI_LONG(8569)
#define ERROR_DS_NOT_SUPPORTED_SORT_ORDER __MSABI_LONG(8570)
#define ERROR_DS_NAME_NOT_UNIQUE __MSABI_LONG(8571)
#define ERROR_DS_MACHINE_ACCOUNT_CREATED_PRENT4 __MSABI_LONG(8572)
#define ERROR_DS_OUT_OF_VERSION_STORE __MSABI_LONG(8573)
#define ERROR_DS_INCOMPATIBLE_CONTROLS_USED __MSABI_LONG(8574)
#define ERROR_DS_NO_REF_DOMAIN __MSABI_LONG(8575)
#define ERROR_DS_RESERVED_LINK_ID __MSABI_LONG(8576)
#define ERROR_DS_LINK_ID_NOT_AVAILABLE __MSABI_LONG(8577)
#define ERROR_DS_AG_CANT_HAVE_UNIVERSAL_MEMBER __MSABI_LONG(8578)
#define ERROR_DS_MODIFYDN_DISALLOWED_BY_INSTANCE_TYPE __MSABI_LONG(8579)
#define ERROR_DS_NO_OBJECT_MOVE_IN_SCHEMA_NC __MSABI_LONG(8580)
#define ERROR_DS_MODIFYDN_DISALLOWED_BY_FLAG __MSABI_LONG(8581)
#define ERROR_DS_MODIFYDN_WRONG_GRANDPARENT __MSABI_LONG(8582)
#define ERROR_DS_NAME_ERROR_TRUST_REFERRAL __MSABI_LONG(8583)
#define ERROR_NOT_SUPPORTED_ON_STANDARD_SERVER __MSABI_LONG(8584)
#define ERROR_DS_CANT_ACCESS_REMOTE_PART_OF_AD __MSABI_LONG(8585)
#define ERROR_DS_CR_IMPOSSIBLE_TO_VALIDATE_V2 __MSABI_LONG(8586)
#define ERROR_DS_THREAD_LIMIT_EXCEEDED __MSABI_LONG(8587)
#define ERROR_DS_NOT_CLOSEST __MSABI_LONG(8588)
#define ERROR_DS_CANT_DERIVE_SPN_WITHOUT_SERVER_REF __MSABI_LONG(8589)
#define ERROR_DS_SINGLE_USER_MODE_FAILED __MSABI_LONG(8590)
#define ERROR_DS_NTDSCRIPT_SYNTAX_ERROR __MSABI_LONG(8591)
#define ERROR_DS_NTDSCRIPT_PROCESS_ERROR __MSABI_LONG(8592)
#define ERROR_DS_DIFFERENT_REPL_EPOCHS __MSABI_LONG(8593)
#define ERROR_DS_DRS_EXTENSIONS_CHANGED __MSABI_LONG(8594)
#define ERROR_DS_REPLICA_SET_CHANGE_NOT_ALLOWED_ON_DISABLED_CR __MSABI_LONG(8595)
#define ERROR_DS_NO_MSDS_INTID __MSABI_LONG(8596)
#define ERROR_DS_DUP_MSDS_INTID __MSABI_LONG(8597)
#define ERROR_DS_EXISTS_IN_RDNATTID __MSABI_LONG(8598)
#define ERROR_DS_AUTHORIZATION_FAILED __MSABI_LONG(8599)
#define ERROR_DS_INVALID_SCRIPT __MSABI_LONG(8600)
#define ERROR_DS_REMOTE_CROSSREF_OP_FAILED __MSABI_LONG(8601)
#define ERROR_DS_CROSS_REF_BUSY __MSABI_LONG(8602)
#define ERROR_DS_CANT_DERIVE_SPN_FOR_DELETED_DOMAIN __MSABI_LONG(8603)
#define ERROR_DS_CANT_DEMOTE_WITH_WRITEABLE_NC __MSABI_LONG(8604)
#define ERROR_DS_DUPLICATE_ID_FOUND __MSABI_LONG(8605)
#define ERROR_DS_INSUFFICIENT_ATTR_TO_CREATE_OBJECT __MSABI_LONG(8606)
#define ERROR_DS_GROUP_CONVERSION_ERROR __MSABI_LONG(8607)
#define ERROR_DS_CANT_MOVE_APP_BASIC_GROUP __MSABI_LONG(8608)
#define ERROR_DS_CANT_MOVE_APP_QUERY_GROUP __MSABI_LONG(8609)
#define ERROR_DS_ROLE_NOT_VERIFIED __MSABI_LONG(8610)
#define ERROR_DS_WKO_CONTAINER_CANNOT_BE_SPECIAL __MSABI_LONG(8611)
#define ERROR_DS_DOMAIN_RENAME_IN_PROGRESS __MSABI_LONG(8612)
#define ERROR_DS_EXISTING_AD_CHILD_NC __MSABI_LONG(8613)
#define ERROR_DS_REPL_LIFETIME_EXCEEDED __MSABI_LONG(8614)
#define ERROR_DS_DISALLOWED_IN_SYSTEM_CONTAINER __MSABI_LONG(8615)
#define ERROR_DS_LDAP_SEND_QUEUE_FULL __MSABI_LONG(8616)
#define ERROR_DS_DRA_OUT_SCHEDULE_WINDOW __MSABI_LONG(8617)
#define DNS_ERROR_RESPONSE_CODES_BASE 9000
#define DNS_ERROR_RCODE_NO_ERROR NO_ERROR
#define DNS_ERROR_MASK 0x00002328
#define DNS_ERROR_RCODE_FORMAT_ERROR __MSABI_LONG(9001)
#define DNS_ERROR_RCODE_SERVER_FAILURE __MSABI_LONG(9002)
#define DNS_ERROR_RCODE_NAME_ERROR __MSABI_LONG(9003)
#define DNS_ERROR_RCODE_NOT_IMPLEMENTED __MSABI_LONG(9004)
#define DNS_ERROR_RCODE_REFUSED __MSABI_LONG(9005)
#define DNS_ERROR_RCODE_YXDOMAIN __MSABI_LONG(9006)
#define DNS_ERROR_RCODE_YXRRSET __MSABI_LONG(9007)
#define DNS_ERROR_RCODE_NXRRSET __MSABI_LONG(9008)
#define DNS_ERROR_RCODE_NOTAUTH __MSABI_LONG(9009)
#define DNS_ERROR_RCODE_NOTZONE __MSABI_LONG(9010)
#define DNS_ERROR_RCODE_BADSIG __MSABI_LONG(9016)
#define DNS_ERROR_RCODE_BADKEY __MSABI_LONG(9017)
#define DNS_ERROR_RCODE_BADTIME __MSABI_LONG(9018)
#define DNS_ERROR_RCODE_LAST DNS_ERROR_RCODE_BADTIME
#define DNS_ERROR_PACKET_FMT_BASE 9500
#define DNS_INFO_NO_RECORDS __MSABI_LONG(9501)
#define DNS_ERROR_BAD_PACKET __MSABI_LONG(9502)
#define DNS_ERROR_NO_PACKET __MSABI_LONG(9503)
#define DNS_ERROR_RCODE __MSABI_LONG(9504)
#define DNS_ERROR_UNSECURE_PACKET __MSABI_LONG(9505)
#define DNS_STATUS_PACKET_UNSECURE DNS_ERROR_UNSECURE_PACKET
#define DNS_ERROR_NO_MEMORY ERROR_OUTOFMEMORY
#define DNS_ERROR_INVALID_NAME ERROR_INVALID_NAME
#define DNS_ERROR_INVALID_DATA ERROR_INVALID_DATA
#define DNS_ERROR_GENERAL_API_BASE 9550
#define DNS_ERROR_INVALID_TYPE __MSABI_LONG(9551)
#define DNS_ERROR_INVALID_IP_ADDRESS __MSABI_LONG(9552)
#define DNS_ERROR_INVALID_PROPERTY __MSABI_LONG(9553)
#define DNS_ERROR_TRY_AGAIN_LATER __MSABI_LONG(9554)
#define DNS_ERROR_NOT_UNIQUE __MSABI_LONG(9555)
#define DNS_ERROR_NON_RFC_NAME __MSABI_LONG(9556)
#define DNS_STATUS_FQDN __MSABI_LONG(9557)
#define DNS_STATUS_DOTTED_NAME __MSABI_LONG(9558)
#define DNS_STATUS_SINGLE_PART_NAME __MSABI_LONG(9559)
#define DNS_ERROR_INVALID_NAME_CHAR __MSABI_LONG(9560)
#define DNS_ERROR_NUMERIC_NAME __MSABI_LONG(9561)
#define DNS_ERROR_NOT_ALLOWED_ON_ROOT_SERVER __MSABI_LONG(9562)
#define DNS_ERROR_NOT_ALLOWED_UNDER_DELEGATION __MSABI_LONG(9563)
#define DNS_ERROR_CANNOT_FIND_ROOT_HINTS __MSABI_LONG(9564)
#define DNS_ERROR_INCONSISTENT_ROOT_HINTS __MSABI_LONG(9565)
#define DNS_ERROR_ZONE_BASE 9600
#define DNS_ERROR_ZONE_DOES_NOT_EXIST __MSABI_LONG(9601)
#define DNS_ERROR_NO_ZONE_INFO __MSABI_LONG(9602)
#define DNS_ERROR_INVALID_ZONE_OPERATION __MSABI_LONG(9603)
#define DNS_ERROR_ZONE_CONFIGURATION_ERROR __MSABI_LONG(9604)
#define DNS_ERROR_ZONE_HAS_NO_SOA_RECORD __MSABI_LONG(9605)
#define DNS_ERROR_ZONE_HAS_NO_NS_RECORDS __MSABI_LONG(9606)
#define DNS_ERROR_ZONE_LOCKED __MSABI_LONG(9607)
#define DNS_ERROR_ZONE_CREATION_FAILED __MSABI_LONG(9608)
#define DNS_ERROR_ZONE_ALREADY_EXISTS __MSABI_LONG(9609)
#define DNS_ERROR_AUTOZONE_ALREADY_EXISTS __MSABI_LONG(9610)
#define DNS_ERROR_INVALID_ZONE_TYPE __MSABI_LONG(9611)
#define DNS_ERROR_SECONDARY_REQUIRES_MASTER_IP __MSABI_LONG(9612)
#define DNS_ERROR_ZONE_NOT_SECONDARY __MSABI_LONG(9613)
#define DNS_ERROR_NEED_SECONDARY_ADDRESSES __MSABI_LONG(9614)
#define DNS_ERROR_WINS_INIT_FAILED __MSABI_LONG(9615)
#define DNS_ERROR_NEED_WINS_SERVERS __MSABI_LONG(9616)
#define DNS_ERROR_NBSTAT_INIT_FAILED __MSABI_LONG(9617)
#define DNS_ERROR_SOA_DELETE_INVALID __MSABI_LONG(9618)
#define DNS_ERROR_FORWARDER_ALREADY_EXISTS __MSABI_LONG(9619)
#define DNS_ERROR_ZONE_REQUIRES_MASTER_IP __MSABI_LONG(9620)
#define DNS_ERROR_ZONE_IS_SHUTDOWN __MSABI_LONG(9621)
#define DNS_ERROR_DATAFILE_BASE 9650
#define DNS_ERROR_PRIMARY_REQUIRES_DATAFILE __MSABI_LONG(9651)
#define DNS_ERROR_INVALID_DATAFILE_NAME __MSABI_LONG(9652)
#define DNS_ERROR_DATAFILE_OPEN_FAILURE __MSABI_LONG(9653)
#define DNS_ERROR_FILE_WRITEBACK_FAILED __MSABI_LONG(9654)
#define DNS_ERROR_DATAFILE_PARSING __MSABI_LONG(9655)
#define DNS_ERROR_DATABASE_BASE 9700
#define DNS_ERROR_RECORD_DOES_NOT_EXIST __MSABI_LONG(9701)
#define DNS_ERROR_RECORD_FORMAT __MSABI_LONG(9702)
#define DNS_ERROR_NODE_CREATION_FAILED __MSABI_LONG(9703)
#define DNS_ERROR_UNKNOWN_RECORD_TYPE __MSABI_LONG(9704)
#define DNS_ERROR_RECORD_TIMED_OUT __MSABI_LONG(9705)
#define DNS_ERROR_NAME_NOT_IN_ZONE __MSABI_LONG(9706)
#define DNS_ERROR_CNAME_LOOP __MSABI_LONG(9707)
#define DNS_ERROR_NODE_IS_CNAME __MSABI_LONG(9708)
#define DNS_ERROR_CNAME_COLLISION __MSABI_LONG(9709)
#define DNS_ERROR_RECORD_ONLY_AT_ZONE_ROOT __MSABI_LONG(9710)
#define DNS_ERROR_RECORD_ALREADY_EXISTS __MSABI_LONG(9711)
#define DNS_ERROR_SECONDARY_DATA __MSABI_LONG(9712)
#define DNS_ERROR_NO_CREATE_CACHE_DATA __MSABI_LONG(9713)
#define DNS_ERROR_NAME_DOES_NOT_EXIST __MSABI_LONG(9714)
#define DNS_WARNING_PTR_CREATE_FAILED __MSABI_LONG(9715)
#define DNS_WARNING_DOMAIN_UNDELETED __MSABI_LONG(9716)
#define DNS_ERROR_DS_UNAVAILABLE __MSABI_LONG(9717)
#define DNS_ERROR_DS_ZONE_ALREADY_EXISTS __MSABI_LONG(9718)
#define DNS_ERROR_NO_BOOTFILE_IF_DS_ZONE __MSABI_LONG(9719)
#define DNS_ERROR_OPERATION_BASE 9750
#define DNS_INFO_AXFR_COMPLETE __MSABI_LONG(9751)
#define DNS_ERROR_AXFR __MSABI_LONG(9752)
#define DNS_INFO_ADDED_LOCAL_WINS __MSABI_LONG(9753)
#define DNS_ERROR_SECURE_BASE 9800
#define DNS_STATUS_CONTINUE_NEEDED __MSABI_LONG(9801)
#define DNS_ERROR_SETUP_BASE 9850
#define DNS_ERROR_NO_TCPIP __MSABI_LONG(9851)
#define DNS_ERROR_NO_DNS_SERVERS __MSABI_LONG(9852)
#define DNS_ERROR_DP_BASE 9900
#define DNS_ERROR_DP_DOES_NOT_EXIST __MSABI_LONG(9901)
#define DNS_ERROR_DP_ALREADY_EXISTS __MSABI_LONG(9902)
#define DNS_ERROR_DP_NOT_ENLISTED __MSABI_LONG(9903)
#define DNS_ERROR_DP_ALREADY_ENLISTED __MSABI_LONG(9904)
#define DNS_ERROR_DP_NOT_AVAILABLE __MSABI_LONG(9905)
#define DNS_ERROR_DP_FSMO_ERROR __MSABI_LONG(9906)


#define WSABASEERR 10000
#define WSAEINTR (WSABASEERR + 4)
#define WSAEBADF (WSABASEERR + 9)
#define WSAEACCES (WSABASEERR + 13)
#define WSAEFAULT (WSABASEERR + 14)
#define WSAEINVAL (WSABASEERR + 22)
#define WSAEMFILE (WSABASEERR + 24)
#define WSAEWOULDBLOCK (WSABASEERR + 35)
#define WSAEINPROGRESS (WSABASEERR + 36)
#define WSAEALREADY (WSABASEERR + 37)
#define WSAENOTSOCK (WSABASEERR + 38)
#define WSAEDESTADDRREQ (WSABASEERR + 39)
#define WSAEMSGSIZE (WSABASEERR + 40)
#define WSAEPROTOTYPE (WSABASEERR + 41)
#define WSAENOPROTOOPT (WSABASEERR + 42)
#define WSAEPROTONOSUPPORT (WSABASEERR + 43)
#define WSAESOCKTNOSUPPORT (WSABASEERR + 44)
#define WSAEOPNOTSUPP (WSABASEERR + 45)
#define WSAEPFNOSUPPORT (WSABASEERR + 46)
#define WSAEAFNOSUPPORT (WSABASEERR + 47)
#define WSAEADDRINUSE (WSABASEERR + 48)
#define WSAEADDRNOTAVAIL (WSABASEERR + 49)
#define WSAENETDOWN (WSABASEERR + 50)
#define WSAENETUNREACH (WSABASEERR + 51)
#define WSAENETRESET (WSABASEERR + 52)
#define WSAECONNABORTED (WSABASEERR + 53)
#define WSAECONNRESET (WSABASEERR + 54)
#define WSAENOBUFS (WSABASEERR + 55)
#define WSAEISCONN (WSABASEERR + 56)
#define WSAENOTCONN (WSABASEERR + 57)
#define WSAESHUTDOWN (WSABASEERR + 58)
#define WSAETOOMANYREFS (WSABASEERR + 59)
#define WSAETIMEDOUT (WSABASEERR + 60)
#define WSAECONNREFUSED (WSABASEERR + 61)
#define WSAELOOP (WSABASEERR + 62)
#define WSAENAMETOOLONG (WSABASEERR + 63)
#define WSAEHOSTDOWN (WSABASEERR + 64)
#define WSAEHOSTUNREACH (WSABASEERR + 65)
#define WSAENOTEMPTY (WSABASEERR + 66)
#define WSAEPROCLIM (WSABASEERR + 67)
#define WSAEUSERS (WSABASEERR + 68)
#define WSAEDQUOT (WSABASEERR + 69)
#define WSAESTALE (WSABASEERR + 70)
#define WSAEREMOTE (WSABASEERR + 71)
#define WSASYSNOTREADY (WSABASEERR + 91)
#define WSAVERNOTSUPPORTED (WSABASEERR + 92)
#define WSANOTINITIALISED (WSABASEERR + 93)
#define WSAEDISCON (WSABASEERR + 101)
#define WSAENOMORE (WSABASEERR + 102)
#define WSAECANCELLED (WSABASEERR + 103)
#define WSAEINVALIDPROCTABLE (WSABASEERR + 104)
#define WSAEINVALIDPROVIDER (WSABASEERR + 105)
#define WSAEPROVIDERFAILEDINIT (WSABASEERR + 106)
#define WSASYSCALLFAILURE (WSABASEERR + 107)
#define WSASERVICE_NOT_FOUND (WSABASEERR + 108)
#define WSATYPE_NOT_FOUND (WSABASEERR + 109)
#define WSA_E_NO_MORE (WSABASEERR + 110)
#define WSA_E_CANCELLED (WSABASEERR + 111)
#define WSAEREFUSED (WSABASEERR + 112)

#define WSAHOST_NOT_FOUND (WSABASEERR + 1001)


#define WSATRY_AGAIN (WSABASEERR + 1002)


#define WSANO_RECOVERY (WSABASEERR + 1003)


#define WSANO_DATA (WSABASEERR + 1004)


#define WSA_QOS_RECEIVERS (WSABASEERR + 1005)


#define WSA_QOS_SENDERS (WSABASEERR + 1006)


#define WSA_QOS_NO_SENDERS (WSABASEERR + 1007)


#define WSA_QOS_NO_RECEIVERS (WSABASEERR + 1008)


#define WSA_QOS_REQUEST_CONFIRMED (WSABASEERR + 1009)


#define WSA_QOS_ADMISSION_FAILURE (WSABASEERR + 1010)


#define WSA_QOS_POLICY_FAILURE (WSABASEERR + 1011)


#define WSA_QOS_BAD_STYLE (WSABASEERR + 1012)


#define WSA_QOS_BAD_OBJECT (WSABASEERR + 1013)


#define WSA_QOS_TRAFFIC_CTRL_ERROR (WSABASEERR + 1014)


#define WSA_QOS_GENERIC_ERROR (WSABASEERR + 1015)


#define WSA_QOS_ESERVICETYPE (WSABASEERR + 1016)


#define WSA_QOS_EFLOWSPEC (WSABASEERR + 1017)


#define WSA_QOS_EPROVSPECBUF (WSABASEERR + 1018)


#define WSA_QOS_EFILTERSTYLE (WSABASEERR + 1019)


#define WSA_QOS_EFILTERTYPE (WSABASEERR + 1020)


#define WSA_QOS_EFILTERCOUNT (WSABASEERR + 1021)


#define WSA_QOS_EOBJLENGTH (WSABASEERR + 1022)


#define WSA_QOS_EFLOWCOUNT (WSABASEERR + 1023)


#define WSA_QOS_EUNKNOWNPSOBJ (WSABASEERR + 1024)


#define WSA_QOS_EUNKOWNPSOBJ WSA_QOS_EUNKNOWNPSOBJ


#define WSA_QOS_EPOLICYOBJ (WSABASEERR + 1025)


#define WSA_QOS_EFLOWDESC (WSABASEERR + 1026)


#define WSA_QOS_EPSFLOWSPEC (WSABASEERR + 1027)


#define WSA_QOS_EPSFILTERSPEC (WSABASEERR + 1028)


#define WSA_QOS_ESDMODEOBJ (WSABASEERR + 1029)


#define WSA_QOS_ESHAPERATEOBJ (WSABASEERR + 1030)


#define WSA_QOS_RESERVED_PETYPE (WSABASEERR + 1031)



#define ERROR_SXS_SECTION_NOT_FOUND __MSABI_LONG(14000)
#define ERROR_SXS_CANT_GEN_ACTCTX __MSABI_LONG(14001)
#define ERROR_SXS_INVALID_ACTCTXDATA_FORMAT __MSABI_LONG(14002)
#define ERROR_SXS_ASSEMBLY_NOT_FOUND __MSABI_LONG(14003)
#define ERROR_SXS_MANIFEST_FORMAT_ERROR __MSABI_LONG(14004)
#define ERROR_SXS_MANIFEST_PARSE_ERROR __MSABI_LONG(14005)
#define ERROR_SXS_ACTIVATION_CONTEXT_DISABLED __MSABI_LONG(14006)
#define ERROR_SXS_KEY_NOT_FOUND __MSABI_LONG(14007)
#define ERROR_SXS_VERSION_CONFLICT __MSABI_LONG(14008)
#define ERROR_SXS_WRONG_SECTION_TYPE __MSABI_LONG(14009)
#define ERROR_SXS_THREAD_QUERIES_DISABLED __MSABI_LONG(14010)
#define ERROR_SXS_PROCESS_DEFAULT_ALREADY_SET __MSABI_LONG(14011)
#define ERROR_SXS_UNKNOWN_ENCODING_GROUP __MSABI_LONG(14012)
#define ERROR_SXS_UNKNOWN_ENCODING __MSABI_LONG(14013)
#define ERROR_SXS_INVALID_XML_NAMESPACE_URI __MSABI_LONG(14014)
#define ERROR_SXS_ROOT_MANIFEST_DEPENDENCY_NOT_INSTALLED __MSABI_LONG(14015)
#define ERROR_SXS_LEAF_MANIFEST_DEPENDENCY_NOT_INSTALLED __MSABI_LONG(14016)
#define ERROR_SXS_INVALID_ASSEMBLY_IDENTITY_ATTRIBUTE __MSABI_LONG(14017)
#define ERROR_SXS_MANIFEST_MISSING_REQUIRED_DEFAULT_NAMESPACE __MSABI_LONG(14018)
#define ERROR_SXS_MANIFEST_INVALID_REQUIRED_DEFAULT_NAMESPACE __MSABI_LONG(14019)
#define ERROR_SXS_PRIVATE_MANIFEST_CROSS_PATH_WITH_REPARSE_POINT __MSABI_LONG(14020)
#define ERROR_SXS_DUPLICATE_DLL_NAME __MSABI_LONG(14021)
#define ERROR_SXS_DUPLICATE_WINDOWCLASS_NAME __MSABI_LONG(14022)
#define ERROR_SXS_DUPLICATE_CLSID __MSABI_LONG(14023)
#define ERROR_SXS_DUPLICATE_IID __MSABI_LONG(14024)
#define ERROR_SXS_DUPLICATE_TLBID __MSABI_LONG(14025)
#define ERROR_SXS_DUPLICATE_PROGID __MSABI_LONG(14026)
#define ERROR_SXS_DUPLICATE_ASSEMBLY_NAME __MSABI_LONG(14027)
#define ERROR_SXS_FILE_HASH_MISMATCH __MSABI_LONG(14028)
#define ERROR_SXS_POLICY_PARSE_ERROR __MSABI_LONG(14029)
#define ERROR_SXS_XML_E_MISSINGQUOTE __MSABI_LONG(14030)
#define ERROR_SXS_XML_E_COMMENTSYNTAX __MSABI_LONG(14031)
#define ERROR_SXS_XML_E_BADSTARTNAMECHAR __MSABI_LONG(14032)
#define ERROR_SXS_XML_E_BADNAMECHAR __MSABI_LONG(14033)
#define ERROR_SXS_XML_E_BADCHARINSTRING __MSABI_LONG(14034)
#define ERROR_SXS_XML_E_XMLDECLSYNTAX __MSABI_LONG(14035)
#define ERROR_SXS_XML_E_BADCHARDATA __MSABI_LONG(14036)
#define ERROR_SXS_XML_E_MISSINGWHITESPACE __MSABI_LONG(14037)
#define ERROR_SXS_XML_E_EXPECTINGTAGEND __MSABI_LONG(14038)
#define ERROR_SXS_XML_E_MISSINGSEMICOLON __MSABI_LONG(14039)
#define ERROR_SXS_XML_E_UNBALANCEDPAREN __MSABI_LONG(14040)
#define ERROR_SXS_XML_E_INTERNALERROR __MSABI_LONG(14041)
#define ERROR_SXS_XML_E_UNEXPECTED_WHITESPACE __MSABI_LONG(14042)
#define ERROR_SXS_XML_E_INCOMPLETE_ENCODING __MSABI_LONG(14043)
#define ERROR_SXS_XML_E_MISSING_PAREN __MSABI_LONG(14044)
#define ERROR_SXS_XML_E_EXPECTINGCLOSEQUOTE __MSABI_LONG(14045)
#define ERROR_SXS_XML_E_MULTIPLE_COLONS __MSABI_LONG(14046)
#define ERROR_SXS_XML_E_INVALID_DECIMAL __MSABI_LONG(14047)
#define ERROR_SXS_XML_E_INVALID_HEXIDECIMAL __MSABI_LONG(14048)
#define ERROR_SXS_XML_E_INVALID_UNICODE __MSABI_LONG(14049)
#define ERROR_SXS_XML_E_WHITESPACEORQUESTIONMARK __MSABI_LONG(14050)
#define ERROR_SXS_XML_E_UNEXPECTEDENDTAG __MSABI_LONG(14051)
#define ERROR_SXS_XML_E_UNCLOSEDTAG __MSABI_LONG(14052)
#define ERROR_SXS_XML_E_DUPLICATEATTRIBUTE __MSABI_LONG(14053)
#define ERROR_SXS_XML_E_MULTIPLEROOTS __MSABI_LONG(14054)
#define ERROR_SXS_XML_E_INVALIDATROOTLEVEL __MSABI_LONG(14055)
#define ERROR_SXS_XML_E_BADXMLDECL __MSABI_LONG(14056)
#define ERROR_SXS_XML_E_MISSINGROOT __MSABI_LONG(14057)
#define ERROR_SXS_XML_E_UNEXPECTEDEOF __MSABI_LONG(14058)
#define ERROR_SXS_XML_E_BADPEREFINSUBSET __MSABI_LONG(14059)
#define ERROR_SXS_XML_E_UNCLOSEDSTARTTAG __MSABI_LONG(14060)
#define ERROR_SXS_XML_E_UNCLOSEDENDTAG __MSABI_LONG(14061)
#define ERROR_SXS_XML_E_UNCLOSEDSTRING __MSABI_LONG(14062)
#define ERROR_SXS_XML_E_UNCLOSEDCOMMENT __MSABI_LONG(14063)
#define ERROR_SXS_XML_E_UNCLOSEDDECL __MSABI_LONG(14064)
#define ERROR_SXS_XML_E_UNCLOSEDCDATA __MSABI_LONG(14065)
#define ERROR_SXS_XML_E_RESERVEDNAMESPACE __MSABI_LONG(14066)
#define ERROR_SXS_XML_E_INVALIDENCODING __MSABI_LONG(14067)
#define ERROR_SXS_XML_E_INVALIDSWITCH __MSABI_LONG(14068)
#define ERROR_SXS_XML_E_BADXMLCASE __MSABI_LONG(14069)
#define ERROR_SXS_XML_E_INVALID_STANDALONE __MSABI_LONG(14070)
#define ERROR_SXS_XML_E_UNEXPECTED_STANDALONE __MSABI_LONG(14071)
#define ERROR_SXS_XML_E_INVALID_VERSION __MSABI_LONG(14072)
#define ERROR_SXS_XML_E_MISSINGEQUALS __MSABI_LONG(14073)
#define ERROR_SXS_PROTECTION_RECOVERY_FAILED __MSABI_LONG(14074)
#define ERROR_SXS_PROTECTION_PUBLIC_KEY_TOO_SHORT __MSABI_LONG(14075)
#define ERROR_SXS_PROTECTION_CATALOG_NOT_VALID __MSABI_LONG(14076)
#define ERROR_SXS_UNTRANSLATABLE_HRESULT __MSABI_LONG(14077)
#define ERROR_SXS_PROTECTION_CATALOG_FILE_MISSING __MSABI_LONG(14078)
#define ERROR_SXS_MISSING_ASSEMBLY_IDENTITY_ATTRIBUTE __MSABI_LONG(14079)
#define ERROR_SXS_INVALID_ASSEMBLY_IDENTITY_ATTRIBUTE_NAME __MSABI_LONG(14080)
#define ERROR_IPSEC_QM_POLICY_EXISTS __MSABI_LONG(13000)
#define ERROR_IPSEC_QM_POLICY_NOT_FOUND __MSABI_LONG(13001)
#define ERROR_IPSEC_QM_POLICY_IN_USE __MSABI_LONG(13002)
#define ERROR_IPSEC_MM_POLICY_EXISTS __MSABI_LONG(13003)
#define ERROR_IPSEC_MM_POLICY_NOT_FOUND __MSABI_LONG(13004)
#define ERROR_IPSEC_MM_POLICY_IN_USE __MSABI_LONG(13005)
#define ERROR_IPSEC_MM_FILTER_EXISTS __MSABI_LONG(13006)
#define ERROR_IPSEC_MM_FILTER_NOT_FOUND __MSABI_LONG(13007)
#define ERROR_IPSEC_TRANSPORT_FILTER_EXISTS __MSABI_LONG(13008)
#define ERROR_IPSEC_TRANSPORT_FILTER_NOT_FOUND __MSABI_LONG(13009)
#define ERROR_IPSEC_MM_AUTH_EXISTS __MSABI_LONG(13010)
#define ERROR_IPSEC_MM_AUTH_NOT_FOUND __MSABI_LONG(13011)
#define ERROR_IPSEC_MM_AUTH_IN_USE __MSABI_LONG(13012)
#define ERROR_IPSEC_DEFAULT_MM_POLICY_NOT_FOUND __MSABI_LONG(13013)
#define ERROR_IPSEC_DEFAULT_MM_AUTH_NOT_FOUND __MSABI_LONG(13014)
#define ERROR_IPSEC_DEFAULT_QM_POLICY_NOT_FOUND __MSABI_LONG(13015)
#define ERROR_IPSEC_TUNNEL_FILTER_EXISTS __MSABI_LONG(13016)
#define ERROR_IPSEC_TUNNEL_FILTER_NOT_FOUND __MSABI_LONG(13017)
#define ERROR_IPSEC_MM_FILTER_PENDING_DELETION __MSABI_LONG(13018)
#define ERROR_IPSEC_TRANSPORT_FILTER_PENDING_DELETION __MSABI_LONG(13019)
#define ERROR_IPSEC_TUNNEL_FILTER_PENDING_DELETION __MSABI_LONG(13020)
#define ERROR_IPSEC_MM_POLICY_PENDING_DELETION __MSABI_LONG(13021)
#define ERROR_IPSEC_MM_AUTH_PENDING_DELETION __MSABI_LONG(13022)
#define ERROR_IPSEC_QM_POLICY_PENDING_DELETION __MSABI_LONG(13023)
#define WARNING_IPSEC_MM_POLICY_PRUNED __MSABI_LONG(13024)
#define WARNING_IPSEC_QM_POLICY_PRUNED __MSABI_LONG(13025)
#define ERROR_IPSEC_IKE_NEG_STATUS_BEGIN __MSABI_LONG(13800)
#define ERROR_IPSEC_IKE_AUTH_FAIL __MSABI_LONG(13801)
#define ERROR_IPSEC_IKE_ATTRIB_FAIL __MSABI_LONG(13802)
#define ERROR_IPSEC_IKE_NEGOTIATION_PENDING __MSABI_LONG(13803)
#define ERROR_IPSEC_IKE_GENERAL_PROCESSING_ERROR __MSABI_LONG(13804)
#define ERROR_IPSEC_IKE_TIMED_OUT __MSABI_LONG(13805)
#define ERROR_IPSEC_IKE_NO_CERT __MSABI_LONG(13806)
#define ERROR_IPSEC_IKE_SA_DELETED __MSABI_LONG(13807)
#define ERROR_IPSEC_IKE_SA_REAPED __MSABI_LONG(13808)
#define ERROR_IPSEC_IKE_MM_ACQUIRE_DROP __MSABI_LONG(13809)
#define ERROR_IPSEC_IKE_QM_ACQUIRE_DROP __MSABI_LONG(13810)
#define ERROR_IPSEC_IKE_QUEUE_DROP_MM __MSABI_LONG(13811)
#define ERROR_IPSEC_IKE_QUEUE_DROP_NO_MM __MSABI_LONG(13812)
#define ERROR_IPSEC_IKE_DROP_NO_RESPONSE __MSABI_LONG(13813)
#define ERROR_IPSEC_IKE_MM_DELAY_DROP __MSABI_LONG(13814)
#define ERROR_IPSEC_IKE_QM_DELAY_DROP __MSABI_LONG(13815)
#define ERROR_IPSEC_IKE_ERROR __MSABI_LONG(13816)
#define ERROR_IPSEC_IKE_CRL_FAILED __MSABI_LONG(13817)
#define ERROR_IPSEC_IKE_INVALID_KEY_USAGE __MSABI_LONG(13818)
#define ERROR_IPSEC_IKE_INVALID_CERT_TYPE __MSABI_LONG(13819)
#define ERROR_IPSEC_IKE_NO_PRIVATE_KEY __MSABI_LONG(13820)
#define ERROR_IPSEC_IKE_DH_FAIL __MSABI_LONG(13822)
#define ERROR_IPSEC_IKE_INVALID_HEADER __MSABI_LONG(13824)
#define ERROR_IPSEC_IKE_NO_POLICY __MSABI_LONG(13825)
#define ERROR_IPSEC_IKE_INVALID_SIGNATURE __MSABI_LONG(13826)
#define ERROR_IPSEC_IKE_KERBEROS_ERROR __MSABI_LONG(13827)
#define ERROR_IPSEC_IKE_NO_PUBLIC_KEY __MSABI_LONG(13828)
#define ERROR_IPSEC_IKE_PROCESS_ERR __MSABI_LONG(13829)
#define ERROR_IPSEC_IKE_PROCESS_ERR_SA __MSABI_LONG(13830)
#define ERROR_IPSEC_IKE_PROCESS_ERR_PROP __MSABI_LONG(13831)
#define ERROR_IPSEC_IKE_PROCESS_ERR_TRANS __MSABI_LONG(13832)
#define ERROR_IPSEC_IKE_PROCESS_ERR_KE __MSABI_LONG(13833)
#define ERROR_IPSEC_IKE_PROCESS_ERR_ID __MSABI_LONG(13834)
#define ERROR_IPSEC_IKE_PROCESS_ERR_CERT __MSABI_LONG(13835)
#define ERROR_IPSEC_IKE_PROCESS_ERR_CERT_REQ __MSABI_LONG(13836)
#define ERROR_IPSEC_IKE_PROCESS_ERR_HASH __MSABI_LONG(13837)
#define ERROR_IPSEC_IKE_PROCESS_ERR_SIG __MSABI_LONG(13838)
#define ERROR_IPSEC_IKE_PROCESS_ERR_NONCE __MSABI_LONG(13839)
#define ERROR_IPSEC_IKE_PROCESS_ERR_NOTIFY __MSABI_LONG(13840)
#define ERROR_IPSEC_IKE_PROCESS_ERR_DELETE __MSABI_LONG(13841)
#define ERROR_IPSEC_IKE_PROCESS_ERR_VENDOR __MSABI_LONG(13842)
#define ERROR_IPSEC_IKE_INVALID_PAYLOAD __MSABI_LONG(13843)
#define ERROR_IPSEC_IKE_LOAD_SOFT_SA __MSABI_LONG(13844)
#define ERROR_IPSEC_IKE_SOFT_SA_TORN_DOWN __MSABI_LONG(13845)
#define ERROR_IPSEC_IKE_INVALID_COOKIE __MSABI_LONG(13846)
#define ERROR_IPSEC_IKE_NO_PEER_CERT __MSABI_LONG(13847)
#define ERROR_IPSEC_IKE_PEER_CRL_FAILED __MSABI_LONG(13848)
#define ERROR_IPSEC_IKE_POLICY_CHANGE __MSABI_LONG(13849)
#define ERROR_IPSEC_IKE_NO_MM_POLICY __MSABI_LONG(13850)
#define ERROR_IPSEC_IKE_NOTCBPRIV __MSABI_LONG(13851)
#define ERROR_IPSEC_IKE_SECLOADFAIL __MSABI_LONG(13852)
#define ERROR_IPSEC_IKE_FAILSSPINIT __MSABI_LONG(13853)
#define ERROR_IPSEC_IKE_FAILQUERYSSP __MSABI_LONG(13854)
#define ERROR_IPSEC_IKE_SRVACQFAIL __MSABI_LONG(13855)
#define ERROR_IPSEC_IKE_SRVQUERYCRED __MSABI_LONG(13856)
#define ERROR_IPSEC_IKE_GETSPIFAIL __MSABI_LONG(13857)
#define ERROR_IPSEC_IKE_INVALID_FILTER __MSABI_LONG(13858)
#define ERROR_IPSEC_IKE_OUT_OF_MEMORY __MSABI_LONG(13859)
#define ERROR_IPSEC_IKE_ADD_UPDATE_KEY_FAILED __MSABI_LONG(13860)
#define ERROR_IPSEC_IKE_INVALID_POLICY __MSABI_LONG(13861)
#define ERROR_IPSEC_IKE_UNKNOWN_DOI __MSABI_LONG(13862)
#define ERROR_IPSEC_IKE_INVALID_SITUATION __MSABI_LONG(13863)
#define ERROR_IPSEC_IKE_DH_FAILURE __MSABI_LONG(13864)
#define ERROR_IPSEC_IKE_INVALID_GROUP __MSABI_LONG(13865)
#define ERROR_IPSEC_IKE_ENCRYPT __MSABI_LONG(13866)
#define ERROR_IPSEC_IKE_DECRYPT __MSABI_LONG(13867)
#define ERROR_IPSEC_IKE_POLICY_MATCH __MSABI_LONG(13868)
#define ERROR_IPSEC_IKE_UNSUPPORTED_ID __MSABI_LONG(13869)
#define ERROR_IPSEC_IKE_INVALID_HASH __MSABI_LONG(13870)
#define ERROR_IPSEC_IKE_INVALID_HASH_ALG __MSABI_LONG(13871)
#define ERROR_IPSEC_IKE_INVALID_HASH_SIZE __MSABI_LONG(13872)
#define ERROR_IPSEC_IKE_INVALID_ENCRYPT_ALG __MSABI_LONG(13873)
#define ERROR_IPSEC_IKE_INVALID_AUTH_ALG __MSABI_LONG(13874)
#define ERROR_IPSEC_IKE_INVALID_SIG __MSABI_LONG(13875)
#define ERROR_IPSEC_IKE_LOAD_FAILED __MSABI_LONG(13876)
#define ERROR_IPSEC_IKE_RPC_DELETE __MSABI_LONG(13877)
#define ERROR_IPSEC_IKE_BENIGN_REINIT __MSABI_LONG(13878)
#define ERROR_IPSEC_IKE_INVALID_RESPONDER_LIFETIME_NOTIFY __MSABI_LONG(13879)
#define ERROR_IPSEC_IKE_INVALID_CERT_KEYLEN __MSABI_LONG(13881)
#define ERROR_IPSEC_IKE_MM_LIMIT __MSABI_LONG(13882)
#define ERROR_IPSEC_IKE_NEGOTIATION_DISABLED __MSABI_LONG(13883)
#define ERROR_IPSEC_IKE_NEG_STATUS_END __MSABI_LONG(13884)
#define SEVERITY_SUCCESS 0
#define SEVERITY_ERROR 1
#define SUCCEEDED(hr) ((HRESULT)(hr) >= 0)
#define FAILED(hr) ((HRESULT)(hr) < 0)
#define IS_ERROR(Status) ((unsigned __LONG32)(Status) >> 31==SEVERITY_ERROR)
#define HRESULT_CODE(hr) ((hr) & 0xFFFF)
#define SCODE_CODE(sc) ((sc) & 0xFFFF)
#define HRESULT_FACILITY(hr) (((hr) >> 16) & 0x1fff)
#define SCODE_FACILITY(sc) (((sc) >> 16) & 0x1fff)
#define HRESULT_SEVERITY(hr) (((hr) >> 31) & 0x1)
#define SCODE_SEVERITY(sc) (((sc) >> 31) & 0x1)
#define MAKE_HRESULT(sev,fac,code) ((HRESULT) (((unsigned __LONG32)(sev)<<31) | ((unsigned __LONG32)(fac)<<16) | ((unsigned __LONG32)(code))))
#define MAKE_SCODE(sev,fac,code) ((SCODE) (((unsigned __LONG32)(sev)<<31) | ((unsigned __LONG32)(fac)<<16) | ((unsigned __LONG32)(code))))
#define FACILITY_NT_BIT 0x10000000
#define __HRESULT_FROM_WIN32(x) ((HRESULT)(x) <= 0 ? ((HRESULT)(x)) : ((HRESULT) (((x) & 0x0000FFFF) | (FACILITY_WIN32 << 16) | 0x80000000)))
# 1986 "c:\\mingw64\\x86_64-w64-mingw32\\include\\winerror.h" 3
#define HRESULT_FROM_WIN32(x) __HRESULT_FROM_WIN32(x)

#define HRESULT_FROM_NT(x) ((HRESULT) ((x) | FACILITY_NT_BIT))
#define GetScode(hr) ((SCODE) (hr))
#define ResultFromScode(sc) ((HRESULT) (sc))
#define PropagateResult(hrPrevious,scBase) ((HRESULT) scBase)



#define _HRESULT_TYPEDEF_(_sc) ((HRESULT)_sc)

#define NOERROR 0
#define E_UNEXPECTED _HRESULT_TYPEDEF_(0x8000FFFF)
#define E_NOTIMPL _HRESULT_TYPEDEF_(0x80004001)
#define E_OUTOFMEMORY _HRESULT_TYPEDEF_(0x8007000E)
#define E_INVALIDARG _HRESULT_TYPEDEF_(0x80070057)
#define E_NOINTERFACE _HRESULT_TYPEDEF_(0x80004002)
#define E_POINTER _HRESULT_TYPEDEF_(0x80004003)
#define E_HANDLE _HRESULT_TYPEDEF_(0x80070006)
#define E_ABORT _HRESULT_TYPEDEF_(0x80004004)
#define E_FAIL _HRESULT_TYPEDEF_(0x80004005)
#define E_ACCESSDENIED _HRESULT_TYPEDEF_(0x80070005)
#define E_PENDING _HRESULT_TYPEDEF_(0x8000000A)
#define CO_E_INIT_TLS _HRESULT_TYPEDEF_(0x80004006)
#define CO_E_INIT_SHARED_ALLOCATOR _HRESULT_TYPEDEF_(0x80004007)
#define CO_E_INIT_MEMORY_ALLOCATOR _HRESULT_TYPEDEF_(0x80004008)
#define CO_E_INIT_CLASS_CACHE _HRESULT_TYPEDEF_(0x80004009)
#define CO_E_INIT_RPC_CHANNEL _HRESULT_TYPEDEF_(0x8000400A)
#define CO_E_INIT_TLS_SET_CHANNEL_CONTROL _HRESULT_TYPEDEF_(0x8000400B)
#define CO_E_INIT_TLS_CHANNEL_CONTROL _HRESULT_TYPEDEF_(0x8000400C)
#define CO_E_INIT_UNACCEPTED_USER_ALLOCATOR _HRESULT_TYPEDEF_(0x8000400D)
#define CO_E_INIT_SCM_MUTEX_EXISTS _HRESULT_TYPEDEF_(0x8000400E)
#define CO_E_INIT_SCM_FILE_MAPPING_EXISTS _HRESULT_TYPEDEF_(0x8000400F)
#define CO_E_INIT_SCM_MAP_VIEW_OF_FILE _HRESULT_TYPEDEF_(0x80004010)
#define CO_E_INIT_SCM_EXEC_FAILURE _HRESULT_TYPEDEF_(0x80004011)
#define CO_E_INIT_ONLY_SINGLE_THREADED _HRESULT_TYPEDEF_(0x80004012)
#define CO_E_CANT_REMOTE _HRESULT_TYPEDEF_(0x80004013)
#define CO_E_BAD_SERVER_NAME _HRESULT_TYPEDEF_(0x80004014)
#define CO_E_WRONG_SERVER_IDENTITY _HRESULT_TYPEDEF_(0x80004015)
#define CO_E_OLE1DDE_DISABLED _HRESULT_TYPEDEF_(0x80004016)
#define CO_E_RUNAS_SYNTAX _HRESULT_TYPEDEF_(0x80004017)
#define CO_E_CREATEPROCESS_FAILURE _HRESULT_TYPEDEF_(0x80004018)
#define CO_E_RUNAS_CREATEPROCESS_FAILURE _HRESULT_TYPEDEF_(0x80004019)
#define CO_E_RUNAS_LOGON_FAILURE _HRESULT_TYPEDEF_(0x8000401A)
#define CO_E_LAUNCH_PERMSSION_DENIED _HRESULT_TYPEDEF_(0x8000401B)
#define CO_E_START_SERVICE_FAILURE _HRESULT_TYPEDEF_(0x8000401C)
#define CO_E_REMOTE_COMMUNICATION_FAILURE _HRESULT_TYPEDEF_(0x8000401D)
#define CO_E_SERVER_START_TIMEOUT _HRESULT_TYPEDEF_(0x8000401E)
#define CO_E_CLSREG_INCONSISTENT _HRESULT_TYPEDEF_(0x8000401F)
#define CO_E_IIDREG_INCONSISTENT _HRESULT_TYPEDEF_(0x80004020)
#define CO_E_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x80004021)
#define CO_E_RELOAD_DLL _HRESULT_TYPEDEF_(0x80004022)
#define CO_E_MSI_ERROR _HRESULT_TYPEDEF_(0x80004023)
#define CO_E_ATTEMPT_TO_CREATE_OUTSIDE_CLIENT_CONTEXT _HRESULT_TYPEDEF_(0x80004024)
#define CO_E_SERVER_PAUSED _HRESULT_TYPEDEF_(0x80004025)
#define CO_E_SERVER_NOT_PAUSED _HRESULT_TYPEDEF_(0x80004026)
#define CO_E_CLASS_DISABLED _HRESULT_TYPEDEF_(0x80004027)
#define CO_E_CLRNOTAVAILABLE _HRESULT_TYPEDEF_(0x80004028)
#define CO_E_ASYNC_WORK_REJECTED _HRESULT_TYPEDEF_(0x80004029)
#define CO_E_SERVER_INIT_TIMEOUT _HRESULT_TYPEDEF_(0x8000402A)
#define CO_E_NO_SECCTX_IN_ACTIVATE _HRESULT_TYPEDEF_(0x8000402B)
#define CO_E_TRACKER_CONFIG _HRESULT_TYPEDEF_(0x80004030)
#define CO_E_THREADPOOL_CONFIG _HRESULT_TYPEDEF_(0x80004031)
#define CO_E_SXS_CONFIG _HRESULT_TYPEDEF_(0x80004032)
#define CO_E_MALFORMED_SPN _HRESULT_TYPEDEF_(0x80004033)
#define S_OK ((HRESULT)0x00000000)
#define S_FALSE ((HRESULT)0x00000001)
#define OLE_E_FIRST ((HRESULT)0x80040000)
#define OLE_E_LAST ((HRESULT)0x800400FF)
#define OLE_S_FIRST ((HRESULT)0x00040000)
#define OLE_S_LAST ((HRESULT)0x000400FF)
#define OLE_E_OLEVERB _HRESULT_TYPEDEF_(0x80040000)
#define OLE_E_ADVF _HRESULT_TYPEDEF_(0x80040001)
#define OLE_E_ENUM_NOMORE _HRESULT_TYPEDEF_(0x80040002)
#define OLE_E_ADVISENOTSUPPORTED _HRESULT_TYPEDEF_(0x80040003)
#define OLE_E_NOCONNECTION _HRESULT_TYPEDEF_(0x80040004)
#define OLE_E_NOTRUNNING _HRESULT_TYPEDEF_(0x80040005)
#define OLE_E_NOCACHE _HRESULT_TYPEDEF_(0x80040006)
#define OLE_E_BLANK _HRESULT_TYPEDEF_(0x80040007)
#define OLE_E_CLASSDIFF _HRESULT_TYPEDEF_(0x80040008)
#define OLE_E_CANT_GETMONIKER _HRESULT_TYPEDEF_(0x80040009)
#define OLE_E_CANT_BINDTOSOURCE _HRESULT_TYPEDEF_(0x8004000A)
#define OLE_E_STATIC _HRESULT_TYPEDEF_(0x8004000B)
#define OLE_E_PROMPTSAVECANCELLED _HRESULT_TYPEDEF_(0x8004000C)
#define OLE_E_INVALIDRECT _HRESULT_TYPEDEF_(0x8004000D)
#define OLE_E_WRONGCOMPOBJ _HRESULT_TYPEDEF_(0x8004000E)
#define OLE_E_INVALIDHWND _HRESULT_TYPEDEF_(0x8004000F)
#define OLE_E_NOT_INPLACEACTIVE _HRESULT_TYPEDEF_(0x80040010)
#define OLE_E_CANTCONVERT _HRESULT_TYPEDEF_(0x80040011)
#define OLE_E_NOSTORAGE _HRESULT_TYPEDEF_(0x80040012)
#define DV_E_FORMATETC _HRESULT_TYPEDEF_(0x80040064)
#define DV_E_DVTARGETDEVICE _HRESULT_TYPEDEF_(0x80040065)
#define DV_E_STGMEDIUM _HRESULT_TYPEDEF_(0x80040066)
#define DV_E_STATDATA _HRESULT_TYPEDEF_(0x80040067)
#define DV_E_LINDEX _HRESULT_TYPEDEF_(0x80040068)
#define DV_E_TYMED _HRESULT_TYPEDEF_(0x80040069)
#define DV_E_CLIPFORMAT _HRESULT_TYPEDEF_(0x8004006A)
#define DV_E_DVASPECT _HRESULT_TYPEDEF_(0x8004006B)
#define DV_E_DVTARGETDEVICE_SIZE _HRESULT_TYPEDEF_(0x8004006C)
#define DV_E_NOIVIEWOBJECT _HRESULT_TYPEDEF_(0x8004006D)
#define DRAGDROP_E_FIRST __MSABI_LONG(0x80040100)
#define DRAGDROP_E_LAST __MSABI_LONG(0x8004010F)
#define DRAGDROP_S_FIRST __MSABI_LONG(0x00040100)
#define DRAGDROP_S_LAST __MSABI_LONG(0x0004010F)
#define DRAGDROP_E_NOTREGISTERED _HRESULT_TYPEDEF_(0x80040100)
#define DRAGDROP_E_ALREADYREGISTERED _HRESULT_TYPEDEF_(0x80040101)
#define DRAGDROP_E_INVALIDHWND _HRESULT_TYPEDEF_(0x80040102)
#define CLASSFACTORY_E_FIRST __MSABI_LONG(0x80040110)
#define CLASSFACTORY_E_LAST __MSABI_LONG(0x8004011F)
#define CLASSFACTORY_S_FIRST __MSABI_LONG(0x00040110)
#define CLASSFACTORY_S_LAST __MSABI_LONG(0x0004011F)
#define CLASS_E_NOAGGREGATION _HRESULT_TYPEDEF_(0x80040110)
#define CLASS_E_CLASSNOTAVAILABLE _HRESULT_TYPEDEF_(0x80040111)
#define CLASS_E_NOTLICENSED _HRESULT_TYPEDEF_(0x80040112)
#define MARSHAL_E_FIRST __MSABI_LONG(0x80040120)
#define MARSHAL_E_LAST __MSABI_LONG(0x8004012F)
#define MARSHAL_S_FIRST __MSABI_LONG(0x00040120)
#define MARSHAL_S_LAST __MSABI_LONG(0x0004012F)
#define DATA_E_FIRST __MSABI_LONG(0x80040130)
#define DATA_E_LAST __MSABI_LONG(0x8004013F)
#define DATA_S_FIRST __MSABI_LONG(0x00040130)
#define DATA_S_LAST __MSABI_LONG(0x0004013F)
#define VIEW_E_FIRST __MSABI_LONG(0x80040140)
#define VIEW_E_LAST __MSABI_LONG(0x8004014F)
#define VIEW_S_FIRST __MSABI_LONG(0x00040140)
#define VIEW_S_LAST __MSABI_LONG(0x0004014F)
#define VIEW_E_DRAW _HRESULT_TYPEDEF_(0x80040140)
#define REGDB_E_FIRST __MSABI_LONG(0x80040150)
#define REGDB_E_LAST __MSABI_LONG(0x8004015F)
#define REGDB_S_FIRST __MSABI_LONG(0x00040150)
#define REGDB_S_LAST __MSABI_LONG(0x0004015F)
#define REGDB_E_READREGDB _HRESULT_TYPEDEF_(0x80040150)
#define REGDB_E_WRITEREGDB _HRESULT_TYPEDEF_(0x80040151)
#define REGDB_E_KEYMISSING _HRESULT_TYPEDEF_(0x80040152)
#define REGDB_E_INVALIDVALUE _HRESULT_TYPEDEF_(0x80040153)
#define REGDB_E_CLASSNOTREG _HRESULT_TYPEDEF_(0x80040154)
#define REGDB_E_IIDNOTREG _HRESULT_TYPEDEF_(0x80040155)
#define REGDB_E_BADTHREADINGMODEL _HRESULT_TYPEDEF_(0x80040156)
#define CAT_E_FIRST __MSABI_LONG(0x80040160)
#define CAT_E_LAST __MSABI_LONG(0x80040161)
#define CAT_E_CATIDNOEXIST _HRESULT_TYPEDEF_(0x80040160)
#define CAT_E_NODESCRIPTION _HRESULT_TYPEDEF_(0x80040161)
#define CS_E_FIRST __MSABI_LONG(0x80040164)
#define CS_E_LAST __MSABI_LONG(0x8004016F)
#define CS_E_PACKAGE_NOTFOUND _HRESULT_TYPEDEF_(0x80040164)
#define CS_E_NOT_DELETABLE _HRESULT_TYPEDEF_(0x80040165)
#define CS_E_CLASS_NOTFOUND _HRESULT_TYPEDEF_(0x80040166)
#define CS_E_INVALID_VERSION _HRESULT_TYPEDEF_(0x80040167)
#define CS_E_NO_CLASSSTORE _HRESULT_TYPEDEF_(0x80040168)
#define CS_E_OBJECT_NOTFOUND _HRESULT_TYPEDEF_(0x80040169)
#define CS_E_OBJECT_ALREADY_EXISTS _HRESULT_TYPEDEF_(0x8004016A)
#define CS_E_INVALID_PATH _HRESULT_TYPEDEF_(0x8004016B)
#define CS_E_NETWORK_ERROR _HRESULT_TYPEDEF_(0x8004016C)
#define CS_E_ADMIN_LIMIT_EXCEEDED _HRESULT_TYPEDEF_(0x8004016D)
#define CS_E_SCHEMA_MISMATCH _HRESULT_TYPEDEF_(0x8004016E)
#define CS_E_INTERNAL_ERROR _HRESULT_TYPEDEF_(0x8004016F)
#define CACHE_E_FIRST __MSABI_LONG(0x80040170)
#define CACHE_E_LAST __MSABI_LONG(0x8004017F)
#define CACHE_S_FIRST __MSABI_LONG(0x00040170)
#define CACHE_S_LAST __MSABI_LONG(0x0004017F)
#define CACHE_E_NOCACHE_UPDATED _HRESULT_TYPEDEF_(0x80040170)
#define OLEOBJ_E_FIRST __MSABI_LONG(0x80040180)
#define OLEOBJ_E_LAST __MSABI_LONG(0x8004018F)
#define OLEOBJ_S_FIRST __MSABI_LONG(0x00040180)
#define OLEOBJ_S_LAST __MSABI_LONG(0x0004018F)
#define OLEOBJ_E_NOVERBS _HRESULT_TYPEDEF_(0x80040180)
#define OLEOBJ_E_INVALIDVERB _HRESULT_TYPEDEF_(0x80040181)
#define CLIENTSITE_E_FIRST __MSABI_LONG(0x80040190)
#define CLIENTSITE_E_LAST __MSABI_LONG(0x8004019F)
#define CLIENTSITE_S_FIRST __MSABI_LONG(0x00040190)
#define CLIENTSITE_S_LAST __MSABI_LONG(0x0004019F)
#define INPLACE_E_NOTUNDOABLE _HRESULT_TYPEDEF_(0x800401A0)
#define INPLACE_E_NOTOOLSPACE _HRESULT_TYPEDEF_(0x800401A1)
#define INPLACE_E_FIRST __MSABI_LONG(0x800401A0)
#define INPLACE_E_LAST __MSABI_LONG(0x800401AF)
#define INPLACE_S_FIRST __MSABI_LONG(0x000401A0)
#define INPLACE_S_LAST __MSABI_LONG(0x000401AF)
#define ENUM_E_FIRST __MSABI_LONG(0x800401B0)
#define ENUM_E_LAST __MSABI_LONG(0x800401BF)
#define ENUM_S_FIRST __MSABI_LONG(0x000401B0)
#define ENUM_S_LAST __MSABI_LONG(0x000401BF)
#define CONVERT10_E_FIRST __MSABI_LONG(0x800401C0)
#define CONVERT10_E_LAST __MSABI_LONG(0x800401CF)
#define CONVERT10_S_FIRST __MSABI_LONG(0x000401C0)
#define CONVERT10_S_LAST __MSABI_LONG(0x000401CF)
#define CONVERT10_E_OLESTREAM_GET _HRESULT_TYPEDEF_(0x800401C0)
#define CONVERT10_E_OLESTREAM_PUT _HRESULT_TYPEDEF_(0x800401C1)
#define CONVERT10_E_OLESTREAM_FMT _HRESULT_TYPEDEF_(0x800401C2)
#define CONVERT10_E_OLESTREAM_BITMAP_TO_DIB _HRESULT_TYPEDEF_(0x800401C3)
#define CONVERT10_E_STG_FMT _HRESULT_TYPEDEF_(0x800401C4)
#define CONVERT10_E_STG_NO_STD_STREAM _HRESULT_TYPEDEF_(0x800401C5)
#define CONVERT10_E_STG_DIB_TO_BITMAP _HRESULT_TYPEDEF_(0x800401C6)
#define CLIPBRD_E_FIRST __MSABI_LONG(0x800401D0)
#define CLIPBRD_E_LAST __MSABI_LONG(0x800401DF)
#define CLIPBRD_S_FIRST __MSABI_LONG(0x000401D0)
#define CLIPBRD_S_LAST __MSABI_LONG(0x000401DF)
#define CLIPBRD_E_CANT_OPEN _HRESULT_TYPEDEF_(0x800401D0)
#define CLIPBRD_E_CANT_EMPTY _HRESULT_TYPEDEF_(0x800401D1)
#define CLIPBRD_E_CANT_SET _HRESULT_TYPEDEF_(0x800401D2)
#define CLIPBRD_E_BAD_DATA _HRESULT_TYPEDEF_(0x800401D3)
#define CLIPBRD_E_CANT_CLOSE _HRESULT_TYPEDEF_(0x800401D4)
#define MK_E_FIRST __MSABI_LONG(0x800401E0)
#define MK_E_LAST __MSABI_LONG(0x800401EF)
#define MK_S_FIRST __MSABI_LONG(0x000401E0)
#define MK_S_LAST __MSABI_LONG(0x000401EF)
#define MK_E_CONNECTMANUALLY _HRESULT_TYPEDEF_(0x800401E0)
#define MK_E_EXCEEDEDDEADLINE _HRESULT_TYPEDEF_(0x800401E1)
#define MK_E_NEEDGENERIC _HRESULT_TYPEDEF_(0x800401E2)
#define MK_E_UNAVAILABLE _HRESULT_TYPEDEF_(0x800401E3)
#define MK_E_SYNTAX _HRESULT_TYPEDEF_(0x800401E4)
#define MK_E_NOOBJECT _HRESULT_TYPEDEF_(0x800401E5)
#define MK_E_INVALIDEXTENSION _HRESULT_TYPEDEF_(0x800401E6)
#define MK_E_INTERMEDIATEINTERFACENOTSUPPORTED _HRESULT_TYPEDEF_(0x800401E7)
#define MK_E_NOTBINDABLE _HRESULT_TYPEDEF_(0x800401E8)
#define MK_E_NOTBOUND _HRESULT_TYPEDEF_(0x800401E9)
#define MK_E_CANTOPENFILE _HRESULT_TYPEDEF_(0x800401EA)
#define MK_E_MUSTBOTHERUSER _HRESULT_TYPEDEF_(0x800401EB)
#define MK_E_NOINVERSE _HRESULT_TYPEDEF_(0x800401EC)
#define MK_E_NOSTORAGE _HRESULT_TYPEDEF_(0x800401ED)
#define MK_E_NOPREFIX _HRESULT_TYPEDEF_(0x800401EE)
#define MK_E_ENUMERATION_FAILED _HRESULT_TYPEDEF_(0x800401EF)
#define CO_E_FIRST __MSABI_LONG(0x800401F0)
#define CO_E_LAST __MSABI_LONG(0x800401FF)
#define CO_S_FIRST __MSABI_LONG(0x000401F0)
#define CO_S_LAST __MSABI_LONG(0x000401FF)
#define CO_E_NOTINITIALIZED _HRESULT_TYPEDEF_(0x800401F0)
#define CO_E_ALREADYINITIALIZED _HRESULT_TYPEDEF_(0x800401F1)
#define CO_E_CANTDETERMINECLASS _HRESULT_TYPEDEF_(0x800401F2)
#define CO_E_CLASSSTRING _HRESULT_TYPEDEF_(0x800401F3)
#define CO_E_IIDSTRING _HRESULT_TYPEDEF_(0x800401F4)
#define CO_E_APPNOTFOUND _HRESULT_TYPEDEF_(0x800401F5)
#define CO_E_APPSINGLEUSE _HRESULT_TYPEDEF_(0x800401F6)
#define CO_E_ERRORINAPP _HRESULT_TYPEDEF_(0x800401F7)
#define CO_E_DLLNOTFOUND _HRESULT_TYPEDEF_(0x800401F8)
#define CO_E_ERRORINDLL _HRESULT_TYPEDEF_(0x800401F9)
#define CO_E_WRONGOSFORAPP _HRESULT_TYPEDEF_(0x800401FA)
#define CO_E_OBJNOTREG _HRESULT_TYPEDEF_(0x800401FB)
#define CO_E_OBJISREG _HRESULT_TYPEDEF_(0x800401FC)
#define CO_E_OBJNOTCONNECTED _HRESULT_TYPEDEF_(0x800401FD)
#define CO_E_APPDIDNTREG _HRESULT_TYPEDEF_(0x800401FE)
#define CO_E_RELEASED _HRESULT_TYPEDEF_(0x800401FF)
#define EVENT_E_FIRST __MSABI_LONG(0x80040200)
#define EVENT_E_LAST __MSABI_LONG(0x8004021F)
#define EVENT_S_FIRST __MSABI_LONG(0x00040200)
#define EVENT_S_LAST __MSABI_LONG(0x0004021F)
#define EVENT_S_SOME_SUBSCRIBERS_FAILED _HRESULT_TYPEDEF_(0x00040200)
#define EVENT_E_ALL_SUBSCRIBERS_FAILED _HRESULT_TYPEDEF_(0x80040201)
#define EVENT_S_NOSUBSCRIBERS _HRESULT_TYPEDEF_(0x00040202)
#define EVENT_E_QUERYSYNTAX _HRESULT_TYPEDEF_(0x80040203)
#define EVENT_E_QUERYFIELD _HRESULT_TYPEDEF_(0x80040204)
#define EVENT_E_INTERNALEXCEPTION _HRESULT_TYPEDEF_(0x80040205)
#define EVENT_E_INTERNALERROR _HRESULT_TYPEDEF_(0x80040206)
#define EVENT_E_INVALID_PER_USER_SID _HRESULT_TYPEDEF_(0x80040207)
#define EVENT_E_USER_EXCEPTION _HRESULT_TYPEDEF_(0x80040208)
#define EVENT_E_TOO_MANY_METHODS _HRESULT_TYPEDEF_(0x80040209)
#define EVENT_E_MISSING_EVENTCLASS _HRESULT_TYPEDEF_(0x8004020A)
#define EVENT_E_NOT_ALL_REMOVED _HRESULT_TYPEDEF_(0x8004020B)
#define EVENT_E_COMPLUS_NOT_INSTALLED _HRESULT_TYPEDEF_(0x8004020C)
#define EVENT_E_CANT_MODIFY_OR_DELETE_UNCONFIGURED_OBJECT _HRESULT_TYPEDEF_(0x8004020D)
#define EVENT_E_CANT_MODIFY_OR_DELETE_CONFIGURED_OBJECT _HRESULT_TYPEDEF_(0x8004020E)
#define EVENT_E_INVALID_EVENT_CLASS_PARTITION _HRESULT_TYPEDEF_(0x8004020F)
#define EVENT_E_PER_USER_SID_NOT_LOGGED_ON _HRESULT_TYPEDEF_(0x80040210)
#define XACT_E_FIRST 0x8004D000
#define XACT_E_LAST 0x8004D029
#define XACT_S_FIRST 0x0004D000
#define XACT_S_LAST 0x0004D010
#define XACT_E_ALREADYOTHERSINGLEPHASE _HRESULT_TYPEDEF_(0x8004D000)
#define XACT_E_CANTRETAIN _HRESULT_TYPEDEF_(0x8004D001)
#define XACT_E_COMMITFAILED _HRESULT_TYPEDEF_(0x8004D002)
#define XACT_E_COMMITPREVENTED _HRESULT_TYPEDEF_(0x8004D003)
#define XACT_E_HEURISTICABORT _HRESULT_TYPEDEF_(0x8004D004)
#define XACT_E_HEURISTICCOMMIT _HRESULT_TYPEDEF_(0x8004D005)
#define XACT_E_HEURISTICDAMAGE _HRESULT_TYPEDEF_(0x8004D006)
#define XACT_E_HEURISTICDANGER _HRESULT_TYPEDEF_(0x8004D007)
#define XACT_E_ISOLATIONLEVEL _HRESULT_TYPEDEF_(0x8004D008)
#define XACT_E_NOASYNC _HRESULT_TYPEDEF_(0x8004D009)
#define XACT_E_NOENLIST _HRESULT_TYPEDEF_(0x8004D00A)
#define XACT_E_NOISORETAIN _HRESULT_TYPEDEF_(0x8004D00B)
#define XACT_E_NORESOURCE _HRESULT_TYPEDEF_(0x8004D00C)
#define XACT_E_NOTCURRENT _HRESULT_TYPEDEF_(0x8004D00D)
#define XACT_E_NOTRANSACTION _HRESULT_TYPEDEF_(0x8004D00E)
#define XACT_E_NOTSUPPORTED _HRESULT_TYPEDEF_(0x8004D00F)
#define XACT_E_UNKNOWNRMGRID _HRESULT_TYPEDEF_(0x8004D010)
#define XACT_E_WRONGSTATE _HRESULT_TYPEDEF_(0x8004D011)
#define XACT_E_WRONGUOW _HRESULT_TYPEDEF_(0x8004D012)
#define XACT_E_XTIONEXISTS _HRESULT_TYPEDEF_(0x8004D013)
#define XACT_E_NOIMPORTOBJECT _HRESULT_TYPEDEF_(0x8004D014)
#define XACT_E_INVALIDCOOKIE _HRESULT_TYPEDEF_(0x8004D015)
#define XACT_E_INDOUBT _HRESULT_TYPEDEF_(0x8004D016)
#define XACT_E_NOTIMEOUT _HRESULT_TYPEDEF_(0x8004D017)
#define XACT_E_ALREADYINPROGRESS _HRESULT_TYPEDEF_(0x8004D018)
#define XACT_E_ABORTED _HRESULT_TYPEDEF_(0x8004D019)
#define XACT_E_LOGFULL _HRESULT_TYPEDEF_(0x8004D01A)
#define XACT_E_TMNOTAVAILABLE _HRESULT_TYPEDEF_(0x8004D01B)
#define XACT_E_CONNECTION_DOWN _HRESULT_TYPEDEF_(0x8004D01C)
#define XACT_E_CONNECTION_DENIED _HRESULT_TYPEDEF_(0x8004D01D)
#define XACT_E_REENLISTTIMEOUT _HRESULT_TYPEDEF_(0x8004D01E)
#define XACT_E_TIP_CONNECT_FAILED _HRESULT_TYPEDEF_(0x8004D01F)
#define XACT_E_TIP_PROTOCOL_ERROR _HRESULT_TYPEDEF_(0x8004D020)
#define XACT_E_TIP_PULL_FAILED _HRESULT_TYPEDEF_(0x8004D021)
#define XACT_E_DEST_TMNOTAVAILABLE _HRESULT_TYPEDEF_(0x8004D022)
#define XACT_E_TIP_DISABLED _HRESULT_TYPEDEF_(0x8004D023)
#define XACT_E_NETWORK_TX_DISABLED _HRESULT_TYPEDEF_(0x8004D024)
#define XACT_E_PARTNER_NETWORK_TX_DISABLED _HRESULT_TYPEDEF_(0x8004D025)
#define XACT_E_XA_TX_DISABLED _HRESULT_TYPEDEF_(0x8004D026)
#define XACT_E_UNABLE_TO_READ_DTC_CONFIG _HRESULT_TYPEDEF_(0x8004D027)
#define XACT_E_UNABLE_TO_LOAD_DTC_PROXY _HRESULT_TYPEDEF_(0x8004D028)
#define XACT_E_ABORTING _HRESULT_TYPEDEF_(0x8004D029)
#define XACT_E_CLERKNOTFOUND _HRESULT_TYPEDEF_(0x8004D080)
#define XACT_E_CLERKEXISTS _HRESULT_TYPEDEF_(0x8004D081)
#define XACT_E_RECOVERYINPROGRESS _HRESULT_TYPEDEF_(0x8004D082)
#define XACT_E_TRANSACTIONCLOSED _HRESULT_TYPEDEF_(0x8004D083)
#define XACT_E_INVALIDLSN _HRESULT_TYPEDEF_(0x8004D084)
#define XACT_E_REPLAYREQUEST _HRESULT_TYPEDEF_(0x8004D085)
#define XACT_S_ASYNC _HRESULT_TYPEDEF_(0x0004D000)
#define XACT_S_DEFECT _HRESULT_TYPEDEF_(0x0004D001)
#define XACT_S_READONLY _HRESULT_TYPEDEF_(0x0004D002)
#define XACT_S_SOMENORETAIN _HRESULT_TYPEDEF_(0x0004D003)
#define XACT_S_OKINFORM _HRESULT_TYPEDEF_(0x0004D004)
#define XACT_S_MADECHANGESCONTENT _HRESULT_TYPEDEF_(0x0004D005)
#define XACT_S_MADECHANGESINFORM _HRESULT_TYPEDEF_(0x0004D006)
#define XACT_S_ALLNORETAIN _HRESULT_TYPEDEF_(0x0004D007)
#define XACT_S_ABORTING _HRESULT_TYPEDEF_(0x0004D008)
#define XACT_S_SINGLEPHASE _HRESULT_TYPEDEF_(0x0004D009)
#define XACT_S_LOCALLY_OK _HRESULT_TYPEDEF_(0x0004D00A)
#define XACT_S_LASTRESOURCEMANAGER _HRESULT_TYPEDEF_(0x0004D010)
#define CONTEXT_E_FIRST __MSABI_LONG(0x8004E000)
#define CONTEXT_E_LAST __MSABI_LONG(0x8004E02F)
#define CONTEXT_S_FIRST __MSABI_LONG(0x0004E000)
#define CONTEXT_S_LAST __MSABI_LONG(0x0004E02F)
#define CONTEXT_E_ABORTED _HRESULT_TYPEDEF_(0x8004E002)
#define CONTEXT_E_ABORTING _HRESULT_TYPEDEF_(0x8004E003)
#define CONTEXT_E_NOCONTEXT _HRESULT_TYPEDEF_(0x8004E004)
#define CONTEXT_E_WOULD_DEADLOCK _HRESULT_TYPEDEF_(0x8004E005)
#define CONTEXT_E_SYNCH_TIMEOUT _HRESULT_TYPEDEF_(0x8004E006)
#define CONTEXT_E_OLDREF _HRESULT_TYPEDEF_(0x8004E007)
#define CONTEXT_E_ROLENOTFOUND _HRESULT_TYPEDEF_(0x8004E00C)
#define CONTEXT_E_TMNOTAVAILABLE _HRESULT_TYPEDEF_(0x8004E00F)
#define CO_E_ACTIVATIONFAILED _HRESULT_TYPEDEF_(0x8004E021)
#define CO_E_ACTIVATIONFAILED_EVENTLOGGED _HRESULT_TYPEDEF_(0x8004E022)
#define CO_E_ACTIVATIONFAILED_CATALOGERROR _HRESULT_TYPEDEF_(0x8004E023)
#define CO_E_ACTIVATIONFAILED_TIMEOUT _HRESULT_TYPEDEF_(0x8004E024)
#define CO_E_INITIALIZATIONFAILED _HRESULT_TYPEDEF_(0x8004E025)
#define CONTEXT_E_NOJIT _HRESULT_TYPEDEF_(0x8004E026)
#define CONTEXT_E_NOTRANSACTION _HRESULT_TYPEDEF_(0x8004E027)
#define CO_E_THREADINGMODEL_CHANGED _HRESULT_TYPEDEF_(0x8004E028)
#define CO_E_NOIISINTRINSICS _HRESULT_TYPEDEF_(0x8004E029)
#define CO_E_NOCOOKIES _HRESULT_TYPEDEF_(0x8004E02A)
#define CO_E_DBERROR _HRESULT_TYPEDEF_(0x8004E02B)
#define CO_E_NOTPOOLED _HRESULT_TYPEDEF_(0x8004E02C)
#define CO_E_NOTCONSTRUCTED _HRESULT_TYPEDEF_(0x8004E02D)
#define CO_E_NOSYNCHRONIZATION _HRESULT_TYPEDEF_(0x8004E02E)
#define CO_E_ISOLEVELMISMATCH _HRESULT_TYPEDEF_(0x8004E02F)
#define OLE_S_USEREG _HRESULT_TYPEDEF_(0x00040000)
#define OLE_S_STATIC _HRESULT_TYPEDEF_(0x00040001)
#define OLE_S_MAC_CLIPFORMAT _HRESULT_TYPEDEF_(0x00040002)
#define DRAGDROP_S_DROP _HRESULT_TYPEDEF_(0x00040100)
#define DRAGDROP_S_CANCEL _HRESULT_TYPEDEF_(0x00040101)
#define DRAGDROP_S_USEDEFAULTCURSORS _HRESULT_TYPEDEF_(0x00040102)
#define DATA_S_SAMEFORMATETC _HRESULT_TYPEDEF_(0x00040130)
#define VIEW_S_ALREADY_FROZEN _HRESULT_TYPEDEF_(0x00040140)
#define CACHE_S_FORMATETC_NOTSUPPORTED _HRESULT_TYPEDEF_(0x00040170)
#define CACHE_S_SAMECACHE _HRESULT_TYPEDEF_(0x00040171)
#define CACHE_S_SOMECACHES_NOTUPDATED _HRESULT_TYPEDEF_(0x00040172)
#define OLEOBJ_S_INVALIDVERB _HRESULT_TYPEDEF_(0x00040180)
#define OLEOBJ_S_CANNOT_DOVERB_NOW _HRESULT_TYPEDEF_(0x00040181)
#define OLEOBJ_S_INVALIDHWND _HRESULT_TYPEDEF_(0x00040182)
#define INPLACE_S_TRUNCATED _HRESULT_TYPEDEF_(0x000401A0)
#define CONVERT10_S_NO_PRESENTATION _HRESULT_TYPEDEF_(0x000401C0)
#define MK_S_REDUCED_TO_SELF _HRESULT_TYPEDEF_(0x000401E2)
#define MK_S_ME _HRESULT_TYPEDEF_(0x000401E4)
#define MK_S_HIM _HRESULT_TYPEDEF_(0x000401E5)
#define MK_S_US _HRESULT_TYPEDEF_(0x000401E6)
#define MK_S_MONIKERALREADYREGISTERED _HRESULT_TYPEDEF_(0x000401E7)
#define SCHED_S_TASK_READY _HRESULT_TYPEDEF_(0x00041300)
#define SCHED_S_TASK_RUNNING _HRESULT_TYPEDEF_(0x00041301)
#define SCHED_S_TASK_DISABLED _HRESULT_TYPEDEF_(0x00041302)
#define SCHED_S_TASK_HAS_NOT_RUN _HRESULT_TYPEDEF_(0x00041303)
#define SCHED_S_TASK_NO_MORE_RUNS _HRESULT_TYPEDEF_(0x00041304)
#define SCHED_S_TASK_NOT_SCHEDULED _HRESULT_TYPEDEF_(0x00041305)
#define SCHED_S_TASK_TERMINATED _HRESULT_TYPEDEF_(0x00041306)
#define SCHED_S_TASK_NO_VALID_TRIGGERS _HRESULT_TYPEDEF_(0x00041307)
#define SCHED_S_EVENT_TRIGGER _HRESULT_TYPEDEF_(0x00041308)
#define SCHED_E_TRIGGER_NOT_FOUND _HRESULT_TYPEDEF_(0x80041309)
#define SCHED_E_TASK_NOT_READY _HRESULT_TYPEDEF_(0x8004130A)
#define SCHED_E_TASK_NOT_RUNNING _HRESULT_TYPEDEF_(0x8004130B)
#define SCHED_E_SERVICE_NOT_INSTALLED _HRESULT_TYPEDEF_(0x8004130C)
#define SCHED_E_CANNOT_OPEN_TASK _HRESULT_TYPEDEF_(0x8004130D)
#define SCHED_E_INVALID_TASK _HRESULT_TYPEDEF_(0x8004130E)
#define SCHED_E_ACCOUNT_INFORMATION_NOT_SET _HRESULT_TYPEDEF_(0x8004130F)
#define SCHED_E_ACCOUNT_NAME_NOT_FOUND _HRESULT_TYPEDEF_(0x80041310)
#define SCHED_E_ACCOUNT_DBASE_CORRUPT _HRESULT_TYPEDEF_(0x80041311)
#define SCHED_E_NO_SECURITY_SERVICES _HRESULT_TYPEDEF_(0x80041312)
#define SCHED_E_UNKNOWN_OBJECT_VERSION _HRESULT_TYPEDEF_(0x80041313)
#define SCHED_E_UNSUPPORTED_ACCOUNT_OPTION _HRESULT_TYPEDEF_(0x80041314)
#define SCHED_E_SERVICE_NOT_RUNNING _HRESULT_TYPEDEF_(0x80041315)
#define CO_E_CLASS_CREATE_FAILED _HRESULT_TYPEDEF_(0x80080001)
#define CO_E_SCM_ERROR _HRESULT_TYPEDEF_(0x80080002)
#define CO_E_SCM_RPC_FAILURE _HRESULT_TYPEDEF_(0x80080003)
#define CO_E_BAD_PATH _HRESULT_TYPEDEF_(0x80080004)
#define CO_E_SERVER_EXEC_FAILURE _HRESULT_TYPEDEF_(0x80080005)
#define CO_E_OBJSRV_RPC_FAILURE _HRESULT_TYPEDEF_(0x80080006)
#define MK_E_NO_NORMALIZED _HRESULT_TYPEDEF_(0x80080007)
#define CO_E_SERVER_STOPPING _HRESULT_TYPEDEF_(0x80080008)
#define MEM_E_INVALID_ROOT _HRESULT_TYPEDEF_(0x80080009)
#define MEM_E_INVALID_LINK _HRESULT_TYPEDEF_(0x80080010)
#define MEM_E_INVALID_SIZE _HRESULT_TYPEDEF_(0x80080011)
#define CO_S_NOTALLINTERFACES _HRESULT_TYPEDEF_(0x00080012)
#define CO_S_MACHINENAMENOTFOUND _HRESULT_TYPEDEF_(0x00080013)
#define DISP_E_UNKNOWNINTERFACE _HRESULT_TYPEDEF_(0x80020001)
#define DISP_E_MEMBERNOTFOUND _HRESULT_TYPEDEF_(0x80020003)
#define DISP_E_PARAMNOTFOUND _HRESULT_TYPEDEF_(0x80020004)
#define DISP_E_TYPEMISMATCH _HRESULT_TYPEDEF_(0x80020005)
#define DISP_E_UNKNOWNNAME _HRESULT_TYPEDEF_(0x80020006)
#define DISP_E_NONAMEDARGS _HRESULT_TYPEDEF_(0x80020007)
#define DISP_E_BADVARTYPE _HRESULT_TYPEDEF_(0x80020008)
#define DISP_E_EXCEPTION _HRESULT_TYPEDEF_(0x80020009)
#define DISP_E_OVERFLOW _HRESULT_TYPEDEF_(0x8002000A)
#define DISP_E_BADINDEX _HRESULT_TYPEDEF_(0x8002000B)
#define DISP_E_UNKNOWNLCID _HRESULT_TYPEDEF_(0x8002000C)
#define DISP_E_ARRAYISLOCKED _HRESULT_TYPEDEF_(0x8002000D)
#define DISP_E_BADPARAMCOUNT _HRESULT_TYPEDEF_(0x8002000E)
#define DISP_E_PARAMNOTOPTIONAL _HRESULT_TYPEDEF_(0x8002000F)
#define DISP_E_BADCALLEE _HRESULT_TYPEDEF_(0x80020010)
#define DISP_E_NOTACOLLECTION _HRESULT_TYPEDEF_(0x80020011)
#define DISP_E_DIVBYZERO _HRESULT_TYPEDEF_(0x80020012)
#define DISP_E_BUFFERTOOSMALL _HRESULT_TYPEDEF_(0x80020013)
#define TYPE_E_BUFFERTOOSMALL _HRESULT_TYPEDEF_(0x80028016)
#define TYPE_E_FIELDNOTFOUND _HRESULT_TYPEDEF_(0x80028017)
#define TYPE_E_INVDATAREAD _HRESULT_TYPEDEF_(0x80028018)
#define TYPE_E_UNSUPFORMAT _HRESULT_TYPEDEF_(0x80028019)
#define TYPE_E_REGISTRYACCESS _HRESULT_TYPEDEF_(0x8002801C)
#define TYPE_E_LIBNOTREGISTERED _HRESULT_TYPEDEF_(0x8002801D)
#define TYPE_E_UNDEFINEDTYPE _HRESULT_TYPEDEF_(0x80028027)
#define TYPE_E_QUALIFIEDNAMEDISALLOWED _HRESULT_TYPEDEF_(0x80028028)
#define TYPE_E_INVALIDSTATE _HRESULT_TYPEDEF_(0x80028029)
#define TYPE_E_WRONGTYPEKIND _HRESULT_TYPEDEF_(0x8002802A)
#define TYPE_E_ELEMENTNOTFOUND _HRESULT_TYPEDEF_(0x8002802B)
#define TYPE_E_AMBIGUOUSNAME _HRESULT_TYPEDEF_(0x8002802C)
#define TYPE_E_NAMECONFLICT _HRESULT_TYPEDEF_(0x8002802D)
#define TYPE_E_UNKNOWNLCID _HRESULT_TYPEDEF_(0x8002802E)
#define TYPE_E_DLLFUNCTIONNOTFOUND _HRESULT_TYPEDEF_(0x8002802F)
#define TYPE_E_BADMODULEKIND _HRESULT_TYPEDEF_(0x800288BD)
#define TYPE_E_SIZETOOBIG _HRESULT_TYPEDEF_(0x800288C5)
#define TYPE_E_DUPLICATEID _HRESULT_TYPEDEF_(0x800288C6)
#define TYPE_E_INVALIDID _HRESULT_TYPEDEF_(0x800288CF)
#define TYPE_E_TYPEMISMATCH _HRESULT_TYPEDEF_(0x80028CA0)
#define TYPE_E_OUTOFBOUNDS _HRESULT_TYPEDEF_(0x80028CA1)
#define TYPE_E_IOERROR _HRESULT_TYPEDEF_(0x80028CA2)
#define TYPE_E_CANTCREATETMPFILE _HRESULT_TYPEDEF_(0x80028CA3)
#define TYPE_E_CANTLOADLIBRARY _HRESULT_TYPEDEF_(0x80029C4A)
#define TYPE_E_INCONSISTENTPROPFUNCS _HRESULT_TYPEDEF_(0x80029C83)
#define TYPE_E_CIRCULARTYPE _HRESULT_TYPEDEF_(0x80029C84)
#define STG_E_INVALIDFUNCTION _HRESULT_TYPEDEF_(0x80030001)
#define STG_E_FILENOTFOUND _HRESULT_TYPEDEF_(0x80030002)
#define STG_E_PATHNOTFOUND _HRESULT_TYPEDEF_(0x80030003)
#define STG_E_TOOMANYOPENFILES _HRESULT_TYPEDEF_(0x80030004)
#define STG_E_ACCESSDENIED _HRESULT_TYPEDEF_(0x80030005)
#define STG_E_INVALIDHANDLE _HRESULT_TYPEDEF_(0x80030006)
#define STG_E_INSUFFICIENTMEMORY _HRESULT_TYPEDEF_(0x80030008)
#define STG_E_INVALIDPOINTER _HRESULT_TYPEDEF_(0x80030009)
#define STG_E_NOMOREFILES _HRESULT_TYPEDEF_(0x80030012)
#define STG_E_DISKISWRITEPROTECTED _HRESULT_TYPEDEF_(0x80030013)
#define STG_E_SEEKERROR _HRESULT_TYPEDEF_(0x80030019)
#define STG_E_WRITEFAULT _HRESULT_TYPEDEF_(0x8003001D)
#define STG_E_READFAULT _HRESULT_TYPEDEF_(0x8003001E)
#define STG_E_SHAREVIOLATION _HRESULT_TYPEDEF_(0x80030020)
#define STG_E_LOCKVIOLATION _HRESULT_TYPEDEF_(0x80030021)
#define STG_E_FILEALREADYEXISTS _HRESULT_TYPEDEF_(0x80030050)
#define STG_E_INVALIDPARAMETER _HRESULT_TYPEDEF_(0x80030057)
#define STG_E_MEDIUMFULL _HRESULT_TYPEDEF_(0x80030070)
#define STG_E_PROPSETMISMATCHED _HRESULT_TYPEDEF_(0x800300F0)
#define STG_E_ABNORMALAPIEXIT _HRESULT_TYPEDEF_(0x800300FA)
#define STG_E_INVALIDHEADER _HRESULT_TYPEDEF_(0x800300FB)
#define STG_E_INVALIDNAME _HRESULT_TYPEDEF_(0x800300FC)
#define STG_E_UNKNOWN _HRESULT_TYPEDEF_(0x800300FD)
#define STG_E_UNIMPLEMENTEDFUNCTION _HRESULT_TYPEDEF_(0x800300FE)
#define STG_E_INVALIDFLAG _HRESULT_TYPEDEF_(0x800300FF)
#define STG_E_INUSE _HRESULT_TYPEDEF_(0x80030100)
#define STG_E_NOTCURRENT _HRESULT_TYPEDEF_(0x80030101)
#define STG_E_REVERTED _HRESULT_TYPEDEF_(0x80030102)
#define STG_E_CANTSAVE _HRESULT_TYPEDEF_(0x80030103)
#define STG_E_OLDFORMAT _HRESULT_TYPEDEF_(0x80030104)
#define STG_E_OLDDLL _HRESULT_TYPEDEF_(0x80030105)
#define STG_E_SHAREREQUIRED _HRESULT_TYPEDEF_(0x80030106)
#define STG_E_NOTFILEBASEDSTORAGE _HRESULT_TYPEDEF_(0x80030107)
#define STG_E_EXTANTMARSHALLINGS _HRESULT_TYPEDEF_(0x80030108)
#define STG_E_DOCFILECORRUPT _HRESULT_TYPEDEF_(0x80030109)
#define STG_E_BADBASEADDRESS _HRESULT_TYPEDEF_(0x80030110)
#define STG_E_DOCFILETOOLARGE _HRESULT_TYPEDEF_(0x80030111)
#define STG_E_NOTSIMPLEFORMAT _HRESULT_TYPEDEF_(0x80030112)
#define STG_E_INCOMPLETE _HRESULT_TYPEDEF_(0x80030201)
#define STG_E_TERMINATED _HRESULT_TYPEDEF_(0x80030202)
#define STG_S_CONVERTED _HRESULT_TYPEDEF_(0x00030200)
#define STG_S_BLOCK _HRESULT_TYPEDEF_(0x00030201)
#define STG_S_RETRYNOW _HRESULT_TYPEDEF_(0x00030202)
#define STG_S_MONITORING _HRESULT_TYPEDEF_(0x00030203)
#define STG_S_MULTIPLEOPENS _HRESULT_TYPEDEF_(0x00030204)
#define STG_S_CONSOLIDATIONFAILED _HRESULT_TYPEDEF_(0x00030205)
#define STG_S_CANNOTCONSOLIDATE _HRESULT_TYPEDEF_(0x00030206)
#define STG_E_STATUS_COPY_PROTECTION_FAILURE _HRESULT_TYPEDEF_(0x80030305)
#define STG_E_CSS_AUTHENTICATION_FAILURE _HRESULT_TYPEDEF_(0x80030306)
#define STG_E_CSS_KEY_NOT_PRESENT _HRESULT_TYPEDEF_(0x80030307)
#define STG_E_CSS_KEY_NOT_ESTABLISHED _HRESULT_TYPEDEF_(0x80030308)
#define STG_E_CSS_SCRAMBLED_SECTOR _HRESULT_TYPEDEF_(0x80030309)
#define STG_E_CSS_REGION_MISMATCH _HRESULT_TYPEDEF_(0x8003030A)
#define STG_E_RESETS_EXHAUSTED _HRESULT_TYPEDEF_(0x8003030B)
#define RPC_E_CALL_REJECTED _HRESULT_TYPEDEF_(0x80010001)
#define RPC_E_CALL_CANCELED _HRESULT_TYPEDEF_(0x80010002)
#define RPC_E_CANTPOST_INSENDCALL _HRESULT_TYPEDEF_(0x80010003)
#define RPC_E_CANTCALLOUT_INASYNCCALL _HRESULT_TYPEDEF_(0x80010004)
#define RPC_E_CANTCALLOUT_INEXTERNALCALL _HRESULT_TYPEDEF_(0x80010005)
#define RPC_E_CONNECTION_TERMINATED _HRESULT_TYPEDEF_(0x80010006)
#define RPC_E_SERVER_DIED _HRESULT_TYPEDEF_(0x80010007)
#define RPC_E_CLIENT_DIED _HRESULT_TYPEDEF_(0x80010008)
#define RPC_E_INVALID_DATAPACKET _HRESULT_TYPEDEF_(0x80010009)
#define RPC_E_CANTTRANSMIT_CALL _HRESULT_TYPEDEF_(0x8001000A)
#define RPC_E_CLIENT_CANTMARSHAL_DATA _HRESULT_TYPEDEF_(0x8001000B)
#define RPC_E_CLIENT_CANTUNMARSHAL_DATA _HRESULT_TYPEDEF_(0x8001000C)
#define RPC_E_SERVER_CANTMARSHAL_DATA _HRESULT_TYPEDEF_(0x8001000D)
#define RPC_E_SERVER_CANTUNMARSHAL_DATA _HRESULT_TYPEDEF_(0x8001000E)
#define RPC_E_INVALID_DATA _HRESULT_TYPEDEF_(0x8001000F)
#define RPC_E_INVALID_PARAMETER _HRESULT_TYPEDEF_(0x80010010)
#define RPC_E_CANTCALLOUT_AGAIN _HRESULT_TYPEDEF_(0x80010011)
#define RPC_E_SERVER_DIED_DNE _HRESULT_TYPEDEF_(0x80010012)
#define RPC_E_SYS_CALL_FAILED _HRESULT_TYPEDEF_(0x80010100)
#define RPC_E_OUT_OF_RESOURCES _HRESULT_TYPEDEF_(0x80010101)
#define RPC_E_ATTEMPTED_MULTITHREAD _HRESULT_TYPEDEF_(0x80010102)
#define RPC_E_NOT_REGISTERED _HRESULT_TYPEDEF_(0x80010103)
#define RPC_E_FAULT _HRESULT_TYPEDEF_(0x80010104)
#define RPC_E_SERVERFAULT _HRESULT_TYPEDEF_(0x80010105)
#define RPC_E_CHANGED_MODE _HRESULT_TYPEDEF_(0x80010106)
#define RPC_E_INVALIDMETHOD _HRESULT_TYPEDEF_(0x80010107)
#define RPC_E_DISCONNECTED _HRESULT_TYPEDEF_(0x80010108)
#define RPC_E_RETRY _HRESULT_TYPEDEF_(0x80010109)
#define RPC_E_SERVERCALL_RETRYLATER _HRESULT_TYPEDEF_(0x8001010A)
#define RPC_E_SERVERCALL_REJECTED _HRESULT_TYPEDEF_(0x8001010B)
#define RPC_E_INVALID_CALLDATA _HRESULT_TYPEDEF_(0x8001010C)
#define RPC_E_CANTCALLOUT_ININPUTSYNCCALL _HRESULT_TYPEDEF_(0x8001010D)
#define RPC_E_WRONG_THREAD _HRESULT_TYPEDEF_(0x8001010E)
#define RPC_E_THREAD_NOT_INIT _HRESULT_TYPEDEF_(0x8001010F)
#define RPC_E_VERSION_MISMATCH _HRESULT_TYPEDEF_(0x80010110)
#define RPC_E_INVALID_HEADER _HRESULT_TYPEDEF_(0x80010111)
#define RPC_E_INVALID_EXTENSION _HRESULT_TYPEDEF_(0x80010112)
#define RPC_E_INVALID_IPID _HRESULT_TYPEDEF_(0x80010113)
#define RPC_E_INVALID_OBJECT _HRESULT_TYPEDEF_(0x80010114)
#define RPC_S_CALLPENDING _HRESULT_TYPEDEF_(0x80010115)
#define RPC_S_WAITONTIMER _HRESULT_TYPEDEF_(0x80010116)
#define RPC_E_CALL_COMPLETE _HRESULT_TYPEDEF_(0x80010117)
#define RPC_E_UNSECURE_CALL _HRESULT_TYPEDEF_(0x80010118)
#define RPC_E_TOO_LATE _HRESULT_TYPEDEF_(0x80010119)
#define RPC_E_NO_GOOD_SECURITY_PACKAGES _HRESULT_TYPEDEF_(0x8001011A)
#define RPC_E_ACCESS_DENIED _HRESULT_TYPEDEF_(0x8001011B)
#define RPC_E_REMOTE_DISABLED _HRESULT_TYPEDEF_(0x8001011C)
#define RPC_E_INVALID_OBJREF _HRESULT_TYPEDEF_(0x8001011D)
#define RPC_E_NO_CONTEXT _HRESULT_TYPEDEF_(0x8001011E)
#define RPC_E_TIMEOUT _HRESULT_TYPEDEF_(0x8001011F)
#define RPC_E_NO_SYNC _HRESULT_TYPEDEF_(0x80010120)
#define RPC_E_FULLSIC_REQUIRED _HRESULT_TYPEDEF_(0x80010121)
#define RPC_E_INVALID_STD_NAME _HRESULT_TYPEDEF_(0x80010122)
#define CO_E_FAILEDTOIMPERSONATE _HRESULT_TYPEDEF_(0x80010123)
#define CO_E_FAILEDTOGETSECCTX _HRESULT_TYPEDEF_(0x80010124)
#define CO_E_FAILEDTOOPENTHREADTOKEN _HRESULT_TYPEDEF_(0x80010125)
#define CO_E_FAILEDTOGETTOKENINFO _HRESULT_TYPEDEF_(0x80010126)
#define CO_E_TRUSTEEDOESNTMATCHCLIENT _HRESULT_TYPEDEF_(0x80010127)
#define CO_E_FAILEDTOQUERYCLIENTBLANKET _HRESULT_TYPEDEF_(0x80010128)
#define CO_E_FAILEDTOSETDACL _HRESULT_TYPEDEF_(0x80010129)
#define CO_E_ACCESSCHECKFAILED _HRESULT_TYPEDEF_(0x8001012A)
#define CO_E_NETACCESSAPIFAILED _HRESULT_TYPEDEF_(0x8001012B)
#define CO_E_WRONGTRUSTEENAMESYNTAX _HRESULT_TYPEDEF_(0x8001012C)
#define CO_E_INVALIDSID _HRESULT_TYPEDEF_(0x8001012D)
#define CO_E_CONVERSIONFAILED _HRESULT_TYPEDEF_(0x8001012E)
#define CO_E_NOMATCHINGSIDFOUND _HRESULT_TYPEDEF_(0x8001012F)
#define CO_E_LOOKUPACCSIDFAILED _HRESULT_TYPEDEF_(0x80010130)
#define CO_E_NOMATCHINGNAMEFOUND _HRESULT_TYPEDEF_(0x80010131)
#define CO_E_LOOKUPACCNAMEFAILED _HRESULT_TYPEDEF_(0x80010132)
#define CO_E_SETSERLHNDLFAILED _HRESULT_TYPEDEF_(0x80010133)
#define CO_E_FAILEDTOGETWINDIR _HRESULT_TYPEDEF_(0x80010134)
#define CO_E_PATHTOOLONG _HRESULT_TYPEDEF_(0x80010135)
#define CO_E_FAILEDTOGENUUID _HRESULT_TYPEDEF_(0x80010136)
#define CO_E_FAILEDTOCREATEFILE _HRESULT_TYPEDEF_(0x80010137)
#define CO_E_FAILEDTOCLOSEHANDLE _HRESULT_TYPEDEF_(0x80010138)
#define CO_E_EXCEEDSYSACLLIMIT _HRESULT_TYPEDEF_(0x80010139)
#define CO_E_ACESINWRONGORDER _HRESULT_TYPEDEF_(0x8001013A)
#define CO_E_INCOMPATIBLESTREAMVERSION _HRESULT_TYPEDEF_(0x8001013B)
#define CO_E_FAILEDTOOPENPROCESSTOKEN _HRESULT_TYPEDEF_(0x8001013C)
#define CO_E_DECODEFAILED _HRESULT_TYPEDEF_(0x8001013D)
#define CO_E_ACNOTINITIALIZED _HRESULT_TYPEDEF_(0x8001013F)
#define CO_E_CANCEL_DISABLED _HRESULT_TYPEDEF_(0x80010140)
#define RPC_E_UNEXPECTED _HRESULT_TYPEDEF_(0x8001FFFF)
#define ERROR_AUDITING_DISABLED _HRESULT_TYPEDEF_(0xC0090001)
#define ERROR_ALL_SIDS_FILTERED _HRESULT_TYPEDEF_(0xC0090002)
#define NTE_BAD_UID _HRESULT_TYPEDEF_(0x80090001)
#define NTE_BAD_HASH _HRESULT_TYPEDEF_(0x80090002)
#define NTE_BAD_KEY _HRESULT_TYPEDEF_(0x80090003)
#define NTE_BAD_LEN _HRESULT_TYPEDEF_(0x80090004)
#define NTE_BAD_DATA _HRESULT_TYPEDEF_(0x80090005)
#define NTE_BAD_SIGNATURE _HRESULT_TYPEDEF_(0x80090006)
#define NTE_BAD_VER _HRESULT_TYPEDEF_(0x80090007)
#define NTE_BAD_ALGID _HRESULT_TYPEDEF_(0x80090008)
#define NTE_BAD_FLAGS _HRESULT_TYPEDEF_(0x80090009)
#define NTE_BAD_TYPE _HRESULT_TYPEDEF_(0x8009000A)
#define NTE_BAD_KEY_STATE _HRESULT_TYPEDEF_(0x8009000B)
#define NTE_BAD_HASH_STATE _HRESULT_TYPEDEF_(0x8009000C)
#define NTE_NO_KEY _HRESULT_TYPEDEF_(0x8009000D)
#define NTE_NO_MEMORY _HRESULT_TYPEDEF_(0x8009000E)
#define NTE_EXISTS _HRESULT_TYPEDEF_(0x8009000F)
#define NTE_PERM _HRESULT_TYPEDEF_(0x80090010)
#define NTE_NOT_FOUND _HRESULT_TYPEDEF_(0x80090011)
#define NTE_DOUBLE_ENCRYPT _HRESULT_TYPEDEF_(0x80090012)
#define NTE_BAD_PROVIDER _HRESULT_TYPEDEF_(0x80090013)
#define NTE_BAD_PROV_TYPE _HRESULT_TYPEDEF_(0x80090014)
#define NTE_BAD_PUBLIC_KEY _HRESULT_TYPEDEF_(0x80090015)
#define NTE_BAD_KEYSET _HRESULT_TYPEDEF_(0x80090016)
#define NTE_PROV_TYPE_NOT_DEF _HRESULT_TYPEDEF_(0x80090017)
#define NTE_PROV_TYPE_ENTRY_BAD _HRESULT_TYPEDEF_(0x80090018)
#define NTE_KEYSET_NOT_DEF _HRESULT_TYPEDEF_(0x80090019)
#define NTE_KEYSET_ENTRY_BAD _HRESULT_TYPEDEF_(0x8009001A)
#define NTE_PROV_TYPE_NO_MATCH _HRESULT_TYPEDEF_(0x8009001B)
#define NTE_SIGNATURE_FILE_BAD _HRESULT_TYPEDEF_(0x8009001C)
#define NTE_PROVIDER_DLL_FAIL _HRESULT_TYPEDEF_(0x8009001D)
#define NTE_PROV_DLL_NOT_FOUND _HRESULT_TYPEDEF_(0x8009001E)
#define NTE_BAD_KEYSET_PARAM _HRESULT_TYPEDEF_(0x8009001F)
#define NTE_FAIL _HRESULT_TYPEDEF_(0x80090020)
#define NTE_SYS_ERR _HRESULT_TYPEDEF_(0x80090021)
#define NTE_SILENT_CONTEXT _HRESULT_TYPEDEF_(0x80090022)
#define NTE_TOKEN_KEYSET_STORAGE_FULL _HRESULT_TYPEDEF_(0x80090023)
#define NTE_TEMPORARY_PROFILE _HRESULT_TYPEDEF_(0x80090024)
#define NTE_FIXEDPARAMETER _HRESULT_TYPEDEF_(0x80090025)
#define SEC_E_INSUFFICIENT_MEMORY _HRESULT_TYPEDEF_(0x80090300)
#define SEC_E_INVALID_HANDLE _HRESULT_TYPEDEF_(0x80090301)
#define SEC_E_UNSUPPORTED_FUNCTION _HRESULT_TYPEDEF_(0x80090302)
#define SEC_E_TARGET_UNKNOWN _HRESULT_TYPEDEF_(0x80090303)
#define SEC_E_INTERNAL_ERROR _HRESULT_TYPEDEF_(0x80090304)
#define SEC_E_SECPKG_NOT_FOUND _HRESULT_TYPEDEF_(0x80090305)
#define SEC_E_NOT_OWNER _HRESULT_TYPEDEF_(0x80090306)
#define SEC_E_CANNOT_INSTALL _HRESULT_TYPEDEF_(0x80090307)
#define SEC_E_INVALID_TOKEN _HRESULT_TYPEDEF_(0x80090308)
#define SEC_E_CANNOT_PACK _HRESULT_TYPEDEF_(0x80090309)
#define SEC_E_QOP_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x8009030A)
#define SEC_E_NO_IMPERSONATION _HRESULT_TYPEDEF_(0x8009030B)
#define SEC_E_LOGON_DENIED _HRESULT_TYPEDEF_(0x8009030C)
#define SEC_E_UNKNOWN_CREDENTIALS _HRESULT_TYPEDEF_(0x8009030D)
#define SEC_E_NO_CREDENTIALS _HRESULT_TYPEDEF_(0x8009030E)
#define SEC_E_MESSAGE_ALTERED _HRESULT_TYPEDEF_(0x8009030F)
#define SEC_E_OUT_OF_SEQUENCE _HRESULT_TYPEDEF_(0x80090310)
#define SEC_E_NO_AUTHENTICATING_AUTHORITY _HRESULT_TYPEDEF_(0x80090311)
#define SEC_I_CONTINUE_NEEDED _HRESULT_TYPEDEF_(0x00090312)
#define SEC_I_COMPLETE_NEEDED _HRESULT_TYPEDEF_(0x00090313)
#define SEC_I_COMPLETE_AND_CONTINUE _HRESULT_TYPEDEF_(0x00090314)
#define SEC_I_LOCAL_LOGON _HRESULT_TYPEDEF_(0x00090315)
#define SEC_E_BAD_PKGID _HRESULT_TYPEDEF_(0x80090316)
#define SEC_E_CONTEXT_EXPIRED _HRESULT_TYPEDEF_(0x80090317)
#define SEC_I_CONTEXT_EXPIRED _HRESULT_TYPEDEF_(0x00090317)
#define SEC_E_INCOMPLETE_MESSAGE _HRESULT_TYPEDEF_(0x80090318)
#define SEC_E_INCOMPLETE_CREDENTIALS _HRESULT_TYPEDEF_(0x80090320)
#define SEC_E_BUFFER_TOO_SMALL _HRESULT_TYPEDEF_(0x80090321)
#define SEC_I_INCOMPLETE_CREDENTIALS _HRESULT_TYPEDEF_(0x00090320)
#define SEC_I_RENEGOTIATE _HRESULT_TYPEDEF_(0x00090321)
#define SEC_E_WRONG_PRINCIPAL _HRESULT_TYPEDEF_(0x80090322)
#define SEC_I_NO_LSA_CONTEXT _HRESULT_TYPEDEF_(0x00090323)
#define SEC_E_TIME_SKEW _HRESULT_TYPEDEF_(0x80090324)
#define SEC_E_UNTRUSTED_ROOT _HRESULT_TYPEDEF_(0x80090325)
#define SEC_E_ILLEGAL_MESSAGE _HRESULT_TYPEDEF_(0x80090326)
#define SEC_E_CERT_UNKNOWN _HRESULT_TYPEDEF_(0x80090327)
#define SEC_E_CERT_EXPIRED _HRESULT_TYPEDEF_(0x80090328)
#define SEC_E_ENCRYPT_FAILURE _HRESULT_TYPEDEF_(0x80090329)
#define SEC_E_DECRYPT_FAILURE _HRESULT_TYPEDEF_(0x80090330)
#define SEC_E_ALGORITHM_MISMATCH _HRESULT_TYPEDEF_(0x80090331)
#define SEC_E_SECURITY_QOS_FAILED _HRESULT_TYPEDEF_(0x80090332)
#define SEC_E_UNFINISHED_CONTEXT_DELETED _HRESULT_TYPEDEF_(0x80090333)
#define SEC_E_NO_TGT_REPLY _HRESULT_TYPEDEF_(0x80090334)
#define SEC_E_NO_IP_ADDRESSES _HRESULT_TYPEDEF_(0x80090335)
#define SEC_E_WRONG_CREDENTIAL_HANDLE _HRESULT_TYPEDEF_(0x80090336)
#define SEC_E_CRYPTO_SYSTEM_INVALID _HRESULT_TYPEDEF_(0x80090337)
#define SEC_E_MAX_REFERRALS_EXCEEDED _HRESULT_TYPEDEF_(0x80090338)
#define SEC_E_MUST_BE_KDC _HRESULT_TYPEDEF_(0x80090339)
#define SEC_E_STRONG_CRYPTO_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x8009033A)
#define SEC_E_TOO_MANY_PRINCIPALS _HRESULT_TYPEDEF_(0x8009033B)
#define SEC_E_NO_PA_DATA _HRESULT_TYPEDEF_(0x8009033C)
#define SEC_E_PKINIT_NAME_MISMATCH _HRESULT_TYPEDEF_(0x8009033D)
#define SEC_E_SMARTCARD_LOGON_REQUIRED _HRESULT_TYPEDEF_(0x8009033E)
#define SEC_E_SHUTDOWN_IN_PROGRESS _HRESULT_TYPEDEF_(0x8009033F)
#define SEC_E_KDC_INVALID_REQUEST _HRESULT_TYPEDEF_(0x80090340)
#define SEC_E_KDC_UNABLE_TO_REFER _HRESULT_TYPEDEF_(0x80090341)
#define SEC_E_KDC_UNKNOWN_ETYPE _HRESULT_TYPEDEF_(0x80090342)
#define SEC_E_UNSUPPORTED_PREAUTH _HRESULT_TYPEDEF_(0x80090343)
#define SEC_E_DELEGATION_REQUIRED _HRESULT_TYPEDEF_(0x80090345)
#define SEC_E_BAD_BINDINGS _HRESULT_TYPEDEF_(0x80090346)
#define SEC_E_MULTIPLE_ACCOUNTS _HRESULT_TYPEDEF_(0x80090347)
#define SEC_E_NO_KERB_KEY _HRESULT_TYPEDEF_(0x80090348)
#define SEC_E_CERT_WRONG_USAGE _HRESULT_TYPEDEF_(0x80090349)
#define SEC_E_DOWNGRADE_DETECTED _HRESULT_TYPEDEF_(0x80090350)
#define SEC_E_SMARTCARD_CERT_REVOKED _HRESULT_TYPEDEF_(0x80090351)
#define SEC_E_ISSUING_CA_UNTRUSTED _HRESULT_TYPEDEF_(0x80090352)
#define SEC_E_REVOCATION_OFFLINE_C _HRESULT_TYPEDEF_(0x80090353)
#define SEC_E_PKINIT_CLIENT_FAILURE _HRESULT_TYPEDEF_(0x80090354)
#define SEC_E_SMARTCARD_CERT_EXPIRED _HRESULT_TYPEDEF_(0x80090355)
#define SEC_E_NO_S4U_PROT_SUPPORT _HRESULT_TYPEDEF_(0x80090356)
#define SEC_E_CROSSREALM_DELEGATION_FAILURE _HRESULT_TYPEDEF_(0x80090357)
#define SEC_E_REVOCATION_OFFLINE_KDC _HRESULT_TYPEDEF_(0x80090358)
#define SEC_E_ISSUING_CA_UNTRUSTED_KDC _HRESULT_TYPEDEF_(0x80090359)
#define SEC_E_KDC_CERT_EXPIRED _HRESULT_TYPEDEF_(0x8009035A)
#define SEC_E_KDC_CERT_REVOKED _HRESULT_TYPEDEF_(0x8009035B)
#define SEC_E_NO_SPM SEC_E_INTERNAL_ERROR
#define SEC_E_NOT_SUPPORTED SEC_E_UNSUPPORTED_FUNCTION
#define CRYPT_E_MSG_ERROR _HRESULT_TYPEDEF_(0x80091001)
#define CRYPT_E_UNKNOWN_ALGO _HRESULT_TYPEDEF_(0x80091002)
#define CRYPT_E_OID_FORMAT _HRESULT_TYPEDEF_(0x80091003)
#define CRYPT_E_INVALID_MSG_TYPE _HRESULT_TYPEDEF_(0x80091004)
#define CRYPT_E_UNEXPECTED_ENCODING _HRESULT_TYPEDEF_(0x80091005)
#define CRYPT_E_AUTH_ATTR_MISSING _HRESULT_TYPEDEF_(0x80091006)
#define CRYPT_E_HASH_VALUE _HRESULT_TYPEDEF_(0x80091007)
#define CRYPT_E_INVALID_INDEX _HRESULT_TYPEDEF_(0x80091008)
#define CRYPT_E_ALREADY_DECRYPTED _HRESULT_TYPEDEF_(0x80091009)
#define CRYPT_E_NOT_DECRYPTED _HRESULT_TYPEDEF_(0x8009100A)
#define CRYPT_E_RECIPIENT_NOT_FOUND _HRESULT_TYPEDEF_(0x8009100B)
#define CRYPT_E_CONTROL_TYPE _HRESULT_TYPEDEF_(0x8009100C)
#define CRYPT_E_ISSUER_SERIALNUMBER _HRESULT_TYPEDEF_(0x8009100D)
#define CRYPT_E_SIGNER_NOT_FOUND _HRESULT_TYPEDEF_(0x8009100E)
#define CRYPT_E_ATTRIBUTES_MISSING _HRESULT_TYPEDEF_(0x8009100F)
#define CRYPT_E_STREAM_MSG_NOT_READY _HRESULT_TYPEDEF_(0x80091010)
#define CRYPT_E_STREAM_INSUFFICIENT_DATA _HRESULT_TYPEDEF_(0x80091011)
#define CRYPT_I_NEW_PROTECTION_REQUIRED _HRESULT_TYPEDEF_(0x00091012)
#define CRYPT_E_BAD_LEN _HRESULT_TYPEDEF_(0x80092001)
#define CRYPT_E_BAD_ENCODE _HRESULT_TYPEDEF_(0x80092002)
#define CRYPT_E_FILE_ERROR _HRESULT_TYPEDEF_(0x80092003)
#define CRYPT_E_NOT_FOUND _HRESULT_TYPEDEF_(0x80092004)
#define CRYPT_E_EXISTS _HRESULT_TYPEDEF_(0x80092005)
#define CRYPT_E_NO_PROVIDER _HRESULT_TYPEDEF_(0x80092006)
#define CRYPT_E_SELF_SIGNED _HRESULT_TYPEDEF_(0x80092007)
#define CRYPT_E_DELETED_PREV _HRESULT_TYPEDEF_(0x80092008)
#define CRYPT_E_NO_MATCH _HRESULT_TYPEDEF_(0x80092009)
#define CRYPT_E_UNEXPECTED_MSG_TYPE _HRESULT_TYPEDEF_(0x8009200A)
#define CRYPT_E_NO_KEY_PROPERTY _HRESULT_TYPEDEF_(0x8009200B)
#define CRYPT_E_NO_DECRYPT_CERT _HRESULT_TYPEDEF_(0x8009200C)
#define CRYPT_E_BAD_MSG _HRESULT_TYPEDEF_(0x8009200D)
#define CRYPT_E_NO_SIGNER _HRESULT_TYPEDEF_(0x8009200E)
#define CRYPT_E_PENDING_CLOSE _HRESULT_TYPEDEF_(0x8009200F)
#define CRYPT_E_REVOKED _HRESULT_TYPEDEF_(0x80092010)
#define CRYPT_E_NO_REVOCATION_DLL _HRESULT_TYPEDEF_(0x80092011)
#define CRYPT_E_NO_REVOCATION_CHECK _HRESULT_TYPEDEF_(0x80092012)
#define CRYPT_E_REVOCATION_OFFLINE _HRESULT_TYPEDEF_(0x80092013)
#define CRYPT_E_NOT_IN_REVOCATION_DATABASE _HRESULT_TYPEDEF_(0x80092014)
#define CRYPT_E_INVALID_NUMERIC_STRING _HRESULT_TYPEDEF_(0x80092020)
#define CRYPT_E_INVALID_PRINTABLE_STRING _HRESULT_TYPEDEF_(0x80092021)
#define CRYPT_E_INVALID_IA5_STRING _HRESULT_TYPEDEF_(0x80092022)
#define CRYPT_E_INVALID_X500_STRING _HRESULT_TYPEDEF_(0x80092023)
#define CRYPT_E_NOT_CHAR_STRING _HRESULT_TYPEDEF_(0x80092024)
#define CRYPT_E_FILERESIZED _HRESULT_TYPEDEF_(0x80092025)
#define CRYPT_E_SECURITY_SETTINGS _HRESULT_TYPEDEF_(0x80092026)
#define CRYPT_E_NO_VERIFY_USAGE_DLL _HRESULT_TYPEDEF_(0x80092027)
#define CRYPT_E_NO_VERIFY_USAGE_CHECK _HRESULT_TYPEDEF_(0x80092028)
#define CRYPT_E_VERIFY_USAGE_OFFLINE _HRESULT_TYPEDEF_(0x80092029)
#define CRYPT_E_NOT_IN_CTL _HRESULT_TYPEDEF_(0x8009202A)
#define CRYPT_E_NO_TRUSTED_SIGNER _HRESULT_TYPEDEF_(0x8009202B)
#define CRYPT_E_MISSING_PUBKEY_PARA _HRESULT_TYPEDEF_(0x8009202C)
#define CRYPT_E_OSS_ERROR _HRESULT_TYPEDEF_(0x80093000)
#define OSS_MORE_BUF _HRESULT_TYPEDEF_(0x80093001)
#define OSS_NEGATIVE_UINTEGER _HRESULT_TYPEDEF_(0x80093002)
#define OSS_PDU_RANGE _HRESULT_TYPEDEF_(0x80093003)
#define OSS_MORE_INPUT _HRESULT_TYPEDEF_(0x80093004)
#define OSS_DATA_ERROR _HRESULT_TYPEDEF_(0x80093005)
#define OSS_BAD_ARG _HRESULT_TYPEDEF_(0x80093006)
#define OSS_BAD_VERSION _HRESULT_TYPEDEF_(0x80093007)
#define OSS_OUT_MEMORY _HRESULT_TYPEDEF_(0x80093008)
#define OSS_PDU_MISMATCH _HRESULT_TYPEDEF_(0x80093009)
#define OSS_LIMITED _HRESULT_TYPEDEF_(0x8009300A)
#define OSS_BAD_PTR _HRESULT_TYPEDEF_(0x8009300B)
#define OSS_BAD_TIME _HRESULT_TYPEDEF_(0x8009300C)
#define OSS_INDEFINITE_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x8009300D)
#define OSS_MEM_ERROR _HRESULT_TYPEDEF_(0x8009300E)
#define OSS_BAD_TABLE _HRESULT_TYPEDEF_(0x8009300F)
#define OSS_TOO_LONG _HRESULT_TYPEDEF_(0x80093010)
#define OSS_CONSTRAINT_VIOLATED _HRESULT_TYPEDEF_(0x80093011)
#define OSS_FATAL_ERROR _HRESULT_TYPEDEF_(0x80093012)
#define OSS_ACCESS_SERIALIZATION_ERROR _HRESULT_TYPEDEF_(0x80093013)
#define OSS_NULL_TBL _HRESULT_TYPEDEF_(0x80093014)
#define OSS_NULL_FCN _HRESULT_TYPEDEF_(0x80093015)
#define OSS_BAD_ENCRULES _HRESULT_TYPEDEF_(0x80093016)
#define OSS_UNAVAIL_ENCRULES _HRESULT_TYPEDEF_(0x80093017)
#define OSS_CANT_OPEN_TRACE_WINDOW _HRESULT_TYPEDEF_(0x80093018)
#define OSS_UNIMPLEMENTED _HRESULT_TYPEDEF_(0x80093019)
#define OSS_OID_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x8009301A)
#define OSS_CANT_OPEN_TRACE_FILE _HRESULT_TYPEDEF_(0x8009301B)
#define OSS_TRACE_FILE_ALREADY_OPEN _HRESULT_TYPEDEF_(0x8009301C)
#define OSS_TABLE_MISMATCH _HRESULT_TYPEDEF_(0x8009301D)
#define OSS_TYPE_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x8009301E)
#define OSS_REAL_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x8009301F)
#define OSS_REAL_CODE_NOT_LINKED _HRESULT_TYPEDEF_(0x80093020)
#define OSS_OUT_OF_RANGE _HRESULT_TYPEDEF_(0x80093021)
#define OSS_COPIER_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x80093022)
#define OSS_CONSTRAINT_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x80093023)
#define OSS_COMPARATOR_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x80093024)
#define OSS_COMPARATOR_CODE_NOT_LINKED _HRESULT_TYPEDEF_(0x80093025)
#define OSS_MEM_MGR_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x80093026)
#define OSS_PDV_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x80093027)
#define OSS_PDV_CODE_NOT_LINKED _HRESULT_TYPEDEF_(0x80093028)
#define OSS_API_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x80093029)
#define OSS_BERDER_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x8009302A)
#define OSS_PER_DLL_NOT_LINKED _HRESULT_TYPEDEF_(0x8009302B)
#define OSS_OPEN_TYPE_ERROR _HRESULT_TYPEDEF_(0x8009302C)
#define OSS_MUTEX_NOT_CREATED _HRESULT_TYPEDEF_(0x8009302D)
#define OSS_CANT_CLOSE_TRACE_FILE _HRESULT_TYPEDEF_(0x8009302E)
#define CRYPT_E_ASN1_ERROR _HRESULT_TYPEDEF_(0x80093100)
#define CRYPT_E_ASN1_INTERNAL _HRESULT_TYPEDEF_(0x80093101)
#define CRYPT_E_ASN1_EOD _HRESULT_TYPEDEF_(0x80093102)
#define CRYPT_E_ASN1_CORRUPT _HRESULT_TYPEDEF_(0x80093103)
#define CRYPT_E_ASN1_LARGE _HRESULT_TYPEDEF_(0x80093104)
#define CRYPT_E_ASN1_CONSTRAINT _HRESULT_TYPEDEF_(0x80093105)
#define CRYPT_E_ASN1_MEMORY _HRESULT_TYPEDEF_(0x80093106)
#define CRYPT_E_ASN1_OVERFLOW _HRESULT_TYPEDEF_(0x80093107)
#define CRYPT_E_ASN1_BADPDU _HRESULT_TYPEDEF_(0x80093108)
#define CRYPT_E_ASN1_BADARGS _HRESULT_TYPEDEF_(0x80093109)
#define CRYPT_E_ASN1_BADREAL _HRESULT_TYPEDEF_(0x8009310A)
#define CRYPT_E_ASN1_BADTAG _HRESULT_TYPEDEF_(0x8009310B)
#define CRYPT_E_ASN1_CHOICE _HRESULT_TYPEDEF_(0x8009310C)
#define CRYPT_E_ASN1_RULE _HRESULT_TYPEDEF_(0x8009310D)
#define CRYPT_E_ASN1_UTF8 _HRESULT_TYPEDEF_(0x8009310E)
#define CRYPT_E_ASN1_PDU_TYPE _HRESULT_TYPEDEF_(0x80093133)
#define CRYPT_E_ASN1_NYI _HRESULT_TYPEDEF_(0x80093134)
#define CRYPT_E_ASN1_EXTENDED _HRESULT_TYPEDEF_(0x80093201)
#define CRYPT_E_ASN1_NOEOD _HRESULT_TYPEDEF_(0x80093202)
#define CERTSRV_E_BAD_REQUESTSUBJECT _HRESULT_TYPEDEF_(0x80094001)
#define CERTSRV_E_NO_REQUEST _HRESULT_TYPEDEF_(0x80094002)
#define CERTSRV_E_BAD_REQUESTSTATUS _HRESULT_TYPEDEF_(0x80094003)
#define CERTSRV_E_PROPERTY_EMPTY _HRESULT_TYPEDEF_(0x80094004)
#define CERTSRV_E_INVALID_CA_CERTIFICATE _HRESULT_TYPEDEF_(0x80094005)
#define CERTSRV_E_SERVER_SUSPENDED _HRESULT_TYPEDEF_(0x80094006)
#define CERTSRV_E_ENCODING_LENGTH _HRESULT_TYPEDEF_(0x80094007)
#define CERTSRV_E_ROLECONFLICT _HRESULT_TYPEDEF_(0x80094008)
#define CERTSRV_E_RESTRICTEDOFFICER _HRESULT_TYPEDEF_(0x80094009)
#define CERTSRV_E_KEY_ARCHIVAL_NOT_CONFIGURED _HRESULT_TYPEDEF_(0x8009400A)
#define CERTSRV_E_NO_VALID_KRA _HRESULT_TYPEDEF_(0x8009400B)
#define CERTSRV_E_BAD_REQUEST_KEY_ARCHIVAL _HRESULT_TYPEDEF_(0x8009400C)
#define CERTSRV_E_NO_CAADMIN_DEFINED _HRESULT_TYPEDEF_(0x8009400D)
#define CERTSRV_E_BAD_RENEWAL_CERT_ATTRIBUTE _HRESULT_TYPEDEF_(0x8009400E)
#define CERTSRV_E_NO_DB_SESSIONS _HRESULT_TYPEDEF_(0x8009400F)
#define CERTSRV_E_ALIGNMENT_FAULT _HRESULT_TYPEDEF_(0x80094010)
#define CERTSRV_E_ENROLL_DENIED _HRESULT_TYPEDEF_(0x80094011)
#define CERTSRV_E_TEMPLATE_DENIED _HRESULT_TYPEDEF_(0x80094012)
#define CERTSRV_E_DOWNLEVEL_DC_SSL_OR_UPGRADE _HRESULT_TYPEDEF_(0x80094013)
#define CERTSRV_E_UNSUPPORTED_CERT_TYPE _HRESULT_TYPEDEF_(0x80094800)
#define CERTSRV_E_NO_CERT_TYPE _HRESULT_TYPEDEF_(0x80094801)
#define CERTSRV_E_TEMPLATE_CONFLICT _HRESULT_TYPEDEF_(0x80094802)
#define CERTSRV_E_SUBJECT_ALT_NAME_REQUIRED _HRESULT_TYPEDEF_(0x80094803)
#define CERTSRV_E_ARCHIVED_KEY_REQUIRED _HRESULT_TYPEDEF_(0x80094804)
#define CERTSRV_E_SMIME_REQUIRED _HRESULT_TYPEDEF_(0x80094805)
#define CERTSRV_E_BAD_RENEWAL_SUBJECT _HRESULT_TYPEDEF_(0x80094806)
#define CERTSRV_E_BAD_TEMPLATE_VERSION _HRESULT_TYPEDEF_(0x80094807)
#define CERTSRV_E_TEMPLATE_POLICY_REQUIRED _HRESULT_TYPEDEF_(0x80094808)
#define CERTSRV_E_SIGNATURE_POLICY_REQUIRED _HRESULT_TYPEDEF_(0x80094809)
#define CERTSRV_E_SIGNATURE_COUNT _HRESULT_TYPEDEF_(0x8009480A)
#define CERTSRV_E_SIGNATURE_REJECTED _HRESULT_TYPEDEF_(0x8009480B)
#define CERTSRV_E_ISSUANCE_POLICY_REQUIRED _HRESULT_TYPEDEF_(0x8009480C)
#define CERTSRV_E_SUBJECT_UPN_REQUIRED _HRESULT_TYPEDEF_(0x8009480D)
#define CERTSRV_E_SUBJECT_DIRECTORY_GUID_REQUIRED _HRESULT_TYPEDEF_(0x8009480E)
#define CERTSRV_E_SUBJECT_DNS_REQUIRED _HRESULT_TYPEDEF_(0x8009480F)
#define CERTSRV_E_ARCHIVED_KEY_UNEXPECTED _HRESULT_TYPEDEF_(0x80094810)
#define CERTSRV_E_KEY_LENGTH _HRESULT_TYPEDEF_(0x80094811)
#define CERTSRV_E_SUBJECT_EMAIL_REQUIRED _HRESULT_TYPEDEF_(0x80094812)
#define CERTSRV_E_UNKNOWN_CERT_TYPE _HRESULT_TYPEDEF_(0x80094813)
#define CERTSRV_E_CERT_TYPE_OVERLAP _HRESULT_TYPEDEF_(0x80094814)
#define XENROLL_E_KEY_NOT_EXPORTABLE _HRESULT_TYPEDEF_(0x80095000)
#define XENROLL_E_CANNOT_ADD_ROOT_CERT _HRESULT_TYPEDEF_(0x80095001)
#define XENROLL_E_RESPONSE_KA_HASH_NOT_FOUND _HRESULT_TYPEDEF_(0x80095002)
#define XENROLL_E_RESPONSE_UNEXPECTED_KA_HASH _HRESULT_TYPEDEF_(0x80095003)
#define XENROLL_E_RESPONSE_KA_HASH_MISMATCH _HRESULT_TYPEDEF_(0x80095004)
#define XENROLL_E_KEYSPEC_SMIME_MISMATCH _HRESULT_TYPEDEF_(0x80095005)
#define TRUST_E_SYSTEM_ERROR _HRESULT_TYPEDEF_(0x80096001)
#define TRUST_E_NO_SIGNER_CERT _HRESULT_TYPEDEF_(0x80096002)
#define TRUST_E_COUNTER_SIGNER _HRESULT_TYPEDEF_(0x80096003)
#define TRUST_E_CERT_SIGNATURE _HRESULT_TYPEDEF_(0x80096004)
#define TRUST_E_TIME_STAMP _HRESULT_TYPEDEF_(0x80096005)
#define TRUST_E_BAD_DIGEST _HRESULT_TYPEDEF_(0x80096010)
#define TRUST_E_BASIC_CONSTRAINTS _HRESULT_TYPEDEF_(0x80096019)
#define TRUST_E_FINANCIAL_CRITERIA _HRESULT_TYPEDEF_(0x8009601E)
#define MSSIPOTF_E_OUTOFMEMRANGE _HRESULT_TYPEDEF_(0x80097001)
#define MSSIPOTF_E_CANTGETOBJECT _HRESULT_TYPEDEF_(0x80097002)
#define MSSIPOTF_E_NOHEADTABLE _HRESULT_TYPEDEF_(0x80097003)
#define MSSIPOTF_E_BAD_MAGICNUMBER _HRESULT_TYPEDEF_(0x80097004)
#define MSSIPOTF_E_BAD_OFFSET_TABLE _HRESULT_TYPEDEF_(0x80097005)
#define MSSIPOTF_E_TABLE_TAGORDER _HRESULT_TYPEDEF_(0x80097006)
#define MSSIPOTF_E_TABLE_LONGWORD _HRESULT_TYPEDEF_(0x80097007)
#define MSSIPOTF_E_BAD_FIRST_TABLE_PLACEMENT _HRESULT_TYPEDEF_(0x80097008)
#define MSSIPOTF_E_TABLES_OVERLAP _HRESULT_TYPEDEF_(0x80097009)
#define MSSIPOTF_E_TABLE_PADBYTES _HRESULT_TYPEDEF_(0x8009700A)
#define MSSIPOTF_E_FILETOOSMALL _HRESULT_TYPEDEF_(0x8009700B)
#define MSSIPOTF_E_TABLE_CHECKSUM _HRESULT_TYPEDEF_(0x8009700C)
#define MSSIPOTF_E_FILE_CHECKSUM _HRESULT_TYPEDEF_(0x8009700D)
#define MSSIPOTF_E_FAILED_POLICY _HRESULT_TYPEDEF_(0x80097010)
#define MSSIPOTF_E_FAILED_HINTS_CHECK _HRESULT_TYPEDEF_(0x80097011)
#define MSSIPOTF_E_NOT_OPENTYPE _HRESULT_TYPEDEF_(0x80097012)
#define MSSIPOTF_E_FILE _HRESULT_TYPEDEF_(0x80097013)
#define MSSIPOTF_E_CRYPT _HRESULT_TYPEDEF_(0x80097014)
#define MSSIPOTF_E_BADVERSION _HRESULT_TYPEDEF_(0x80097015)
#define MSSIPOTF_E_DSIG_STRUCTURE _HRESULT_TYPEDEF_(0x80097016)
#define MSSIPOTF_E_PCONST_CHECK _HRESULT_TYPEDEF_(0x80097017)
#define MSSIPOTF_E_STRUCTURE _HRESULT_TYPEDEF_(0x80097018)
#define NTE_OP_OK 0
#define TRUST_E_PROVIDER_UNKNOWN _HRESULT_TYPEDEF_(0x800B0001)
#define TRUST_E_ACTION_UNKNOWN _HRESULT_TYPEDEF_(0x800B0002)
#define TRUST_E_SUBJECT_FORM_UNKNOWN _HRESULT_TYPEDEF_(0x800B0003)
#define TRUST_E_SUBJECT_NOT_TRUSTED _HRESULT_TYPEDEF_(0x800B0004)
#define DIGSIG_E_ENCODE _HRESULT_TYPEDEF_(0x800B0005)
#define DIGSIG_E_DECODE _HRESULT_TYPEDEF_(0x800B0006)
#define DIGSIG_E_EXTENSIBILITY _HRESULT_TYPEDEF_(0x800B0007)
#define DIGSIG_E_CRYPTO _HRESULT_TYPEDEF_(0x800B0008)
#define PERSIST_E_SIZEDEFINITE _HRESULT_TYPEDEF_(0x800B0009)
#define PERSIST_E_SIZEINDEFINITE _HRESULT_TYPEDEF_(0x800B000A)
#define PERSIST_E_NOTSELFSIZING _HRESULT_TYPEDEF_(0x800B000B)
#define TRUST_E_NOSIGNATURE _HRESULT_TYPEDEF_(0x800B0100)
#define CERT_E_EXPIRED _HRESULT_TYPEDEF_(0x800B0101)
#define CERT_E_VALIDITYPERIODNESTING _HRESULT_TYPEDEF_(0x800B0102)
#define CERT_E_ROLE _HRESULT_TYPEDEF_(0x800B0103)
#define CERT_E_PATHLENCONST _HRESULT_TYPEDEF_(0x800B0104)
#define CERT_E_CRITICAL _HRESULT_TYPEDEF_(0x800B0105)
#define CERT_E_PURPOSE _HRESULT_TYPEDEF_(0x800B0106)
#define CERT_E_ISSUERCHAINING _HRESULT_TYPEDEF_(0x800B0107)
#define CERT_E_MALFORMED _HRESULT_TYPEDEF_(0x800B0108)
#define CERT_E_UNTRUSTEDROOT _HRESULT_TYPEDEF_(0x800B0109)
#define CERT_E_CHAINING _HRESULT_TYPEDEF_(0x800B010A)
#define TRUST_E_FAIL _HRESULT_TYPEDEF_(0x800B010B)
#define CERT_E_REVOKED _HRESULT_TYPEDEF_(0x800B010C)
#define CERT_E_UNTRUSTEDTESTROOT _HRESULT_TYPEDEF_(0x800B010D)
#define CERT_E_REVOCATION_FAILURE _HRESULT_TYPEDEF_(0x800B010E)
#define CERT_E_CN_NO_MATCH _HRESULT_TYPEDEF_(0x800B010F)
#define CERT_E_WRONG_USAGE _HRESULT_TYPEDEF_(0x800B0110)
#define TRUST_E_EXPLICIT_DISTRUST _HRESULT_TYPEDEF_(0x800B0111)
#define CERT_E_UNTRUSTEDCA _HRESULT_TYPEDEF_(0x800B0112)
#define CERT_E_INVALID_POLICY _HRESULT_TYPEDEF_(0x800B0113)
#define CERT_E_INVALID_NAME _HRESULT_TYPEDEF_(0x800B0114)
#define HRESULT_FROM_SETUPAPI(x) ((((x) & (APPLICATION_ERROR_MASK|ERROR_SEVERITY_ERROR))==(APPLICATION_ERROR_MASK|ERROR_SEVERITY_ERROR)) ? ((HRESULT) (((x) & 0x0000FFFF) | (FACILITY_SETUPAPI << 16) | 0x80000000)) : HRESULT_FROM_WIN32(x))
#define SPAPI_E_EXPECTED_SECTION_NAME _HRESULT_TYPEDEF_(0x800F0000)
#define SPAPI_E_BAD_SECTION_NAME_LINE _HRESULT_TYPEDEF_(0x800F0001)
#define SPAPI_E_SECTION_NAME_TOO_LONG _HRESULT_TYPEDEF_(0x800F0002)
#define SPAPI_E_GENERAL_SYNTAX _HRESULT_TYPEDEF_(0x800F0003)
#define SPAPI_E_WRONG_INF_STYLE _HRESULT_TYPEDEF_(0x800F0100)
#define SPAPI_E_SECTION_NOT_FOUND _HRESULT_TYPEDEF_(0x800F0101)
#define SPAPI_E_LINE_NOT_FOUND _HRESULT_TYPEDEF_(0x800F0102)
#define SPAPI_E_NO_BACKUP _HRESULT_TYPEDEF_(0x800F0103)
#define SPAPI_E_NO_ASSOCIATED_CLASS _HRESULT_TYPEDEF_(0x800F0200)
#define SPAPI_E_CLASS_MISMATCH _HRESULT_TYPEDEF_(0x800F0201)
#define SPAPI_E_DUPLICATE_FOUND _HRESULT_TYPEDEF_(0x800F0202)
#define SPAPI_E_NO_DRIVER_SELECTED _HRESULT_TYPEDEF_(0x800F0203)
#define SPAPI_E_KEY_DOES_NOT_EXIST _HRESULT_TYPEDEF_(0x800F0204)
#define SPAPI_E_INVALID_DEVINST_NAME _HRESULT_TYPEDEF_(0x800F0205)
#define SPAPI_E_INVALID_CLASS _HRESULT_TYPEDEF_(0x800F0206)
#define SPAPI_E_DEVINST_ALREADY_EXISTS _HRESULT_TYPEDEF_(0x800F0207)
#define SPAPI_E_DEVINFO_NOT_REGISTERED _HRESULT_TYPEDEF_(0x800F0208)
#define SPAPI_E_INVALID_REG_PROPERTY _HRESULT_TYPEDEF_(0x800F0209)
#define SPAPI_E_NO_INF _HRESULT_TYPEDEF_(0x800F020A)
#define SPAPI_E_NO_SUCH_DEVINST _HRESULT_TYPEDEF_(0x800F020B)
#define SPAPI_E_CANT_LOAD_CLASS_ICON _HRESULT_TYPEDEF_(0x800F020C)
#define SPAPI_E_INVALID_CLASS_INSTALLER _HRESULT_TYPEDEF_(0x800F020D)
#define SPAPI_E_DI_DO_DEFAULT _HRESULT_TYPEDEF_(0x800F020E)
#define SPAPI_E_DI_NOFILECOPY _HRESULT_TYPEDEF_(0x800F020F)
#define SPAPI_E_INVALID_HWPROFILE _HRESULT_TYPEDEF_(0x800F0210)
#define SPAPI_E_NO_DEVICE_SELECTED _HRESULT_TYPEDEF_(0x800F0211)
#define SPAPI_E_DEVINFO_LIST_LOCKED _HRESULT_TYPEDEF_(0x800F0212)
#define SPAPI_E_DEVINFO_DATA_LOCKED _HRESULT_TYPEDEF_(0x800F0213)
#define SPAPI_E_DI_BAD_PATH _HRESULT_TYPEDEF_(0x800F0214)
#define SPAPI_E_NO_CLASSINSTALL_PARAMS _HRESULT_TYPEDEF_(0x800F0215)
#define SPAPI_E_FILEQUEUE_LOCKED _HRESULT_TYPEDEF_(0x800F0216)
#define SPAPI_E_BAD_SERVICE_INSTALLSECT _HRESULT_TYPEDEF_(0x800F0217)
#define SPAPI_E_NO_CLASS_DRIVER_LIST _HRESULT_TYPEDEF_(0x800F0218)
#define SPAPI_E_NO_ASSOCIATED_SERVICE _HRESULT_TYPEDEF_(0x800F0219)
#define SPAPI_E_NO_DEFAULT_DEVICE_INTERFACE _HRESULT_TYPEDEF_(0x800F021A)
#define SPAPI_E_DEVICE_INTERFACE_ACTIVE _HRESULT_TYPEDEF_(0x800F021B)
#define SPAPI_E_DEVICE_INTERFACE_REMOVED _HRESULT_TYPEDEF_(0x800F021C)
#define SPAPI_E_BAD_INTERFACE_INSTALLSECT _HRESULT_TYPEDEF_(0x800F021D)
#define SPAPI_E_NO_SUCH_INTERFACE_CLASS _HRESULT_TYPEDEF_(0x800F021E)
#define SPAPI_E_INVALID_REFERENCE_STRING _HRESULT_TYPEDEF_(0x800F021F)
#define SPAPI_E_INVALID_MACHINENAME _HRESULT_TYPEDEF_(0x800F0220)
#define SPAPI_E_REMOTE_COMM_FAILURE _HRESULT_TYPEDEF_(0x800F0221)
#define SPAPI_E_MACHINE_UNAVAILABLE _HRESULT_TYPEDEF_(0x800F0222)
#define SPAPI_E_NO_CONFIGMGR_SERVICES _HRESULT_TYPEDEF_(0x800F0223)
#define SPAPI_E_INVALID_PROPPAGE_PROVIDER _HRESULT_TYPEDEF_(0x800F0224)
#define SPAPI_E_NO_SUCH_DEVICE_INTERFACE _HRESULT_TYPEDEF_(0x800F0225)
#define SPAPI_E_DI_POSTPROCESSING_REQUIRED _HRESULT_TYPEDEF_(0x800F0226)
#define SPAPI_E_INVALID_COINSTALLER _HRESULT_TYPEDEF_(0x800F0227)
#define SPAPI_E_NO_COMPAT_DRIVERS _HRESULT_TYPEDEF_(0x800F0228)
#define SPAPI_E_NO_DEVICE_ICON _HRESULT_TYPEDEF_(0x800F0229)
#define SPAPI_E_INVALID_INF_LOGCONFIG _HRESULT_TYPEDEF_(0x800F022A)
#define SPAPI_E_DI_DONT_INSTALL _HRESULT_TYPEDEF_(0x800F022B)
#define SPAPI_E_INVALID_FILTER_DRIVER _HRESULT_TYPEDEF_(0x800F022C)
#define SPAPI_E_NON_WINDOWS_NT_DRIVER _HRESULT_TYPEDEF_(0x800F022D)
#define SPAPI_E_NON_WINDOWS_DRIVER _HRESULT_TYPEDEF_(0x800F022E)
#define SPAPI_E_NO_CATALOG_FOR_OEM_INF _HRESULT_TYPEDEF_(0x800F022F)
#define SPAPI_E_DEVINSTALL_QUEUE_NONNATIVE _HRESULT_TYPEDEF_(0x800F0230)
#define SPAPI_E_NOT_DISABLEABLE _HRESULT_TYPEDEF_(0x800F0231)
#define SPAPI_E_CANT_REMOVE_DEVINST _HRESULT_TYPEDEF_(0x800F0232)
#define SPAPI_E_INVALID_TARGET _HRESULT_TYPEDEF_(0x800F0233)
#define SPAPI_E_DRIVER_NONNATIVE _HRESULT_TYPEDEF_(0x800F0234)
#define SPAPI_E_IN_WOW64 _HRESULT_TYPEDEF_(0x800F0235)
#define SPAPI_E_SET_SYSTEM_RESTORE_POINT _HRESULT_TYPEDEF_(0x800F0236)
#define SPAPI_E_INCORRECTLY_COPIED_INF _HRESULT_TYPEDEF_(0x800F0237)
#define SPAPI_E_SCE_DISABLED _HRESULT_TYPEDEF_(0x800F0238)
#define SPAPI_E_UNKNOWN_EXCEPTION _HRESULT_TYPEDEF_(0x800F0239)
#define SPAPI_E_PNP_REGISTRY_ERROR _HRESULT_TYPEDEF_(0x800F023A)
#define SPAPI_E_REMOTE_REQUEST_UNSUPPORTED _HRESULT_TYPEDEF_(0x800F023B)
#define SPAPI_E_NOT_AN_INSTALLED_OEM_INF _HRESULT_TYPEDEF_(0x800F023C)
#define SPAPI_E_INF_IN_USE_BY_DEVICES _HRESULT_TYPEDEF_(0x800F023D)
#define SPAPI_E_DI_FUNCTION_OBSOLETE _HRESULT_TYPEDEF_(0x800F023E)
#define SPAPI_E_NO_AUTHENTICODE_CATALOG _HRESULT_TYPEDEF_(0x800F023F)
#define SPAPI_E_AUTHENTICODE_DISALLOWED _HRESULT_TYPEDEF_(0x800F0240)
#define SPAPI_E_AUTHENTICODE_TRUSTED_PUBLISHER _HRESULT_TYPEDEF_(0x800F0241)
#define SPAPI_E_AUTHENTICODE_TRUST_NOT_ESTABLISHED _HRESULT_TYPEDEF_(0x800F0242)
#define SPAPI_E_AUTHENTICODE_PUBLISHER_NOT_TRUSTED _HRESULT_TYPEDEF_(0x800F0243)
#define SPAPI_E_SIGNATURE_OSATTRIBUTE_MISMATCH _HRESULT_TYPEDEF_(0x800F0244)
#define SPAPI_E_ONLY_VALIDATE_VIA_AUTHENTICODE _HRESULT_TYPEDEF_(0x800F0245)
#define SPAPI_E_UNRECOVERABLE_STACK_OVERFLOW _HRESULT_TYPEDEF_(0x800F0300)
#define SPAPI_E_ERROR_NOT_INSTALLED _HRESULT_TYPEDEF_(0x800F1000)
#define SCARD_S_SUCCESS NO_ERROR
#define SCARD_F_INTERNAL_ERROR _HRESULT_TYPEDEF_(0x80100001)
#define SCARD_E_CANCELLED _HRESULT_TYPEDEF_(0x80100002)
#define SCARD_E_INVALID_HANDLE _HRESULT_TYPEDEF_(0x80100003)
#define SCARD_E_INVALID_PARAMETER _HRESULT_TYPEDEF_(0x80100004)
#define SCARD_E_INVALID_TARGET _HRESULT_TYPEDEF_(0x80100005)
#define SCARD_E_NO_MEMORY _HRESULT_TYPEDEF_(0x80100006)
#define SCARD_F_WAITED_TOO_LONG _HRESULT_TYPEDEF_(0x80100007)
#define SCARD_E_INSUFFICIENT_BUFFER _HRESULT_TYPEDEF_(0x80100008)
#define SCARD_E_UNKNOWN_READER _HRESULT_TYPEDEF_(0x80100009)
#define SCARD_E_TIMEOUT _HRESULT_TYPEDEF_(0x8010000A)
#define SCARD_E_SHARING_VIOLATION _HRESULT_TYPEDEF_(0x8010000B)
#define SCARD_E_NO_SMARTCARD _HRESULT_TYPEDEF_(0x8010000C)
#define SCARD_E_UNKNOWN_CARD _HRESULT_TYPEDEF_(0x8010000D)
#define SCARD_E_CANT_DISPOSE _HRESULT_TYPEDEF_(0x8010000E)
#define SCARD_E_PROTO_MISMATCH _HRESULT_TYPEDEF_(0x8010000F)
#define SCARD_E_NOT_READY _HRESULT_TYPEDEF_(0x80100010)
#define SCARD_E_INVALID_VALUE _HRESULT_TYPEDEF_(0x80100011)
#define SCARD_E_SYSTEM_CANCELLED _HRESULT_TYPEDEF_(0x80100012)
#define SCARD_F_COMM_ERROR _HRESULT_TYPEDEF_(0x80100013)
#define SCARD_F_UNKNOWN_ERROR _HRESULT_TYPEDEF_(0x80100014)
#define SCARD_E_INVALID_ATR _HRESULT_TYPEDEF_(0x80100015)
#define SCARD_E_NOT_TRANSACTED _HRESULT_TYPEDEF_(0x80100016)
#define SCARD_E_READER_UNAVAILABLE _HRESULT_TYPEDEF_(0x80100017)
#define SCARD_P_SHUTDOWN _HRESULT_TYPEDEF_(0x80100018)
#define SCARD_E_PCI_TOO_SMALL _HRESULT_TYPEDEF_(0x80100019)
#define SCARD_E_READER_UNSUPPORTED _HRESULT_TYPEDEF_(0x8010001A)
#define SCARD_E_DUPLICATE_READER _HRESULT_TYPEDEF_(0x8010001B)
#define SCARD_E_CARD_UNSUPPORTED _HRESULT_TYPEDEF_(0x8010001C)
#define SCARD_E_NO_SERVICE _HRESULT_TYPEDEF_(0x8010001D)
#define SCARD_E_SERVICE_STOPPED _HRESULT_TYPEDEF_(0x8010001E)
#define SCARD_E_UNEXPECTED _HRESULT_TYPEDEF_(0x8010001F)
#define SCARD_E_ICC_INSTALLATION _HRESULT_TYPEDEF_(0x80100020)
#define SCARD_E_ICC_CREATEORDER _HRESULT_TYPEDEF_(0x80100021)
#define SCARD_E_UNSUPPORTED_FEATURE _HRESULT_TYPEDEF_(0x80100022)
#define SCARD_E_DIR_NOT_FOUND _HRESULT_TYPEDEF_(0x80100023)
#define SCARD_E_FILE_NOT_FOUND _HRESULT_TYPEDEF_(0x80100024)
#define SCARD_E_NO_DIR _HRESULT_TYPEDEF_(0x80100025)
#define SCARD_E_NO_FILE _HRESULT_TYPEDEF_(0x80100026)
#define SCARD_E_NO_ACCESS _HRESULT_TYPEDEF_(0x80100027)
#define SCARD_E_WRITE_TOO_MANY _HRESULT_TYPEDEF_(0x80100028)
#define SCARD_E_BAD_SEEK _HRESULT_TYPEDEF_(0x80100029)
#define SCARD_E_INVALID_CHV _HRESULT_TYPEDEF_(0x8010002A)
#define SCARD_E_UNKNOWN_RES_MNG _HRESULT_TYPEDEF_(0x8010002B)
#define SCARD_E_NO_SUCH_CERTIFICATE _HRESULT_TYPEDEF_(0x8010002C)
#define SCARD_E_CERTIFICATE_UNAVAILABLE _HRESULT_TYPEDEF_(0x8010002D)
#define SCARD_E_NO_READERS_AVAILABLE _HRESULT_TYPEDEF_(0x8010002E)
#define SCARD_E_COMM_DATA_LOST _HRESULT_TYPEDEF_(0x8010002F)
#define SCARD_E_NO_KEY_CONTAINER _HRESULT_TYPEDEF_(0x80100030)
#define SCARD_E_SERVER_TOO_BUSY _HRESULT_TYPEDEF_(0x80100031)
#define SCARD_W_UNSUPPORTED_CARD _HRESULT_TYPEDEF_(0x80100065)
#define SCARD_W_UNRESPONSIVE_CARD _HRESULT_TYPEDEF_(0x80100066)
#define SCARD_W_UNPOWERED_CARD _HRESULT_TYPEDEF_(0x80100067)
#define SCARD_W_RESET_CARD _HRESULT_TYPEDEF_(0x80100068)
#define SCARD_W_REMOVED_CARD _HRESULT_TYPEDEF_(0x80100069)
#define SCARD_W_SECURITY_VIOLATION _HRESULT_TYPEDEF_(0x8010006A)
#define SCARD_W_WRONG_CHV _HRESULT_TYPEDEF_(0x8010006B)
#define SCARD_W_CHV_BLOCKED _HRESULT_TYPEDEF_(0x8010006C)
#define SCARD_W_EOF _HRESULT_TYPEDEF_(0x8010006D)
#define SCARD_W_CANCELLED_BY_USER _HRESULT_TYPEDEF_(0x8010006E)
#define SCARD_W_CARD_NOT_AUTHENTICATED _HRESULT_TYPEDEF_(0x8010006F)
#define SCARD_W_CACHE_ITEM_NOT_FOUND _HRESULT_TYPEDEF_(0x80100070)
#define SCARD_W_CACHE_ITEM_STALE _HRESULT_TYPEDEF_(0x80100071)
#define COMADMIN_E_OBJECTERRORS _HRESULT_TYPEDEF_(0x80110401)
#define COMADMIN_E_OBJECTINVALID _HRESULT_TYPEDEF_(0x80110402)
#define COMADMIN_E_KEYMISSING _HRESULT_TYPEDEF_(0x80110403)
#define COMADMIN_E_ALREADYINSTALLED _HRESULT_TYPEDEF_(0x80110404)
#define COMADMIN_E_APP_FILE_WRITEFAIL _HRESULT_TYPEDEF_(0x80110407)
#define COMADMIN_E_APP_FILE_READFAIL _HRESULT_TYPEDEF_(0x80110408)
#define COMADMIN_E_APP_FILE_VERSION _HRESULT_TYPEDEF_(0x80110409)
#define COMADMIN_E_BADPATH _HRESULT_TYPEDEF_(0x8011040A)
#define COMADMIN_E_APPLICATIONEXISTS _HRESULT_TYPEDEF_(0x8011040B)
#define COMADMIN_E_ROLEEXISTS _HRESULT_TYPEDEF_(0x8011040C)
#define COMADMIN_E_CANTCOPYFILE _HRESULT_TYPEDEF_(0x8011040D)
#define COMADMIN_E_NOUSER _HRESULT_TYPEDEF_(0x8011040F)
#define COMADMIN_E_INVALIDUSERIDS _HRESULT_TYPEDEF_(0x80110410)
#define COMADMIN_E_NOREGISTRYCLSID _HRESULT_TYPEDEF_(0x80110411)
#define COMADMIN_E_BADREGISTRYPROGID _HRESULT_TYPEDEF_(0x80110412)
#define COMADMIN_E_AUTHENTICATIONLEVEL _HRESULT_TYPEDEF_(0x80110413)
#define COMADMIN_E_USERPASSWDNOTVALID _HRESULT_TYPEDEF_(0x80110414)
#define COMADMIN_E_CLSIDORIIDMISMATCH _HRESULT_TYPEDEF_(0x80110418)
#define COMADMIN_E_REMOTEINTERFACE _HRESULT_TYPEDEF_(0x80110419)
#define COMADMIN_E_DLLREGISTERSERVER _HRESULT_TYPEDEF_(0x8011041A)
#define COMADMIN_E_NOSERVERSHARE _HRESULT_TYPEDEF_(0x8011041B)
#define COMADMIN_E_DLLLOADFAILED _HRESULT_TYPEDEF_(0x8011041D)
#define COMADMIN_E_BADREGISTRYLIBID _HRESULT_TYPEDEF_(0x8011041E)
#define COMADMIN_E_APPDIRNOTFOUND _HRESULT_TYPEDEF_(0x8011041F)
#define COMADMIN_E_REGISTRARFAILED _HRESULT_TYPEDEF_(0x80110423)
#define COMADMIN_E_COMPFILE_DOESNOTEXIST _HRESULT_TYPEDEF_(0x80110424)
#define COMADMIN_E_COMPFILE_LOADDLLFAIL _HRESULT_TYPEDEF_(0x80110425)
#define COMADMIN_E_COMPFILE_GETCLASSOBJ _HRESULT_TYPEDEF_(0x80110426)
#define COMADMIN_E_COMPFILE_CLASSNOTAVAIL _HRESULT_TYPEDEF_(0x80110427)
#define COMADMIN_E_COMPFILE_BADTLB _HRESULT_TYPEDEF_(0x80110428)
#define COMADMIN_E_COMPFILE_NOTINSTALLABLE _HRESULT_TYPEDEF_(0x80110429)
#define COMADMIN_E_NOTCHANGEABLE _HRESULT_TYPEDEF_(0x8011042A)
#define COMADMIN_E_NOTDELETEABLE _HRESULT_TYPEDEF_(0x8011042B)
#define COMADMIN_E_SESSION _HRESULT_TYPEDEF_(0x8011042C)
#define COMADMIN_E_COMP_MOVE_LOCKED _HRESULT_TYPEDEF_(0x8011042D)
#define COMADMIN_E_COMP_MOVE_BAD_DEST _HRESULT_TYPEDEF_(0x8011042E)
#define COMADMIN_E_REGISTERTLB _HRESULT_TYPEDEF_(0x80110430)
#define COMADMIN_E_SYSTEMAPP _HRESULT_TYPEDEF_(0x80110433)
#define COMADMIN_E_COMPFILE_NOREGISTRAR _HRESULT_TYPEDEF_(0x80110434)
#define COMADMIN_E_COREQCOMPINSTALLED _HRESULT_TYPEDEF_(0x80110435)
#define COMADMIN_E_SERVICENOTINSTALLED _HRESULT_TYPEDEF_(0x80110436)
#define COMADMIN_E_PROPERTYSAVEFAILED _HRESULT_TYPEDEF_(0x80110437)
#define COMADMIN_E_OBJECTEXISTS _HRESULT_TYPEDEF_(0x80110438)
#define COMADMIN_E_COMPONENTEXISTS _HRESULT_TYPEDEF_(0x80110439)
#define COMADMIN_E_REGFILE_CORRUPT _HRESULT_TYPEDEF_(0x8011043B)
#define COMADMIN_E_PROPERTY_OVERFLOW _HRESULT_TYPEDEF_(0x8011043C)
#define COMADMIN_E_NOTINREGISTRY _HRESULT_TYPEDEF_(0x8011043E)
#define COMADMIN_E_OBJECTNOTPOOLABLE _HRESULT_TYPEDEF_(0x8011043F)
#define COMADMIN_E_APPLID_MATCHES_CLSID _HRESULT_TYPEDEF_(0x80110446)
#define COMADMIN_E_ROLE_DOES_NOT_EXIST _HRESULT_TYPEDEF_(0x80110447)
#define COMADMIN_E_START_APP_NEEDS_COMPONENTS _HRESULT_TYPEDEF_(0x80110448)
#define COMADMIN_E_REQUIRES_DIFFERENT_PLATFORM _HRESULT_TYPEDEF_(0x80110449)
#define COMADMIN_E_CAN_NOT_EXPORT_APP_PROXY _HRESULT_TYPEDEF_(0x8011044A)
#define COMADMIN_E_CAN_NOT_START_APP _HRESULT_TYPEDEF_(0x8011044B)
#define COMADMIN_E_CAN_NOT_EXPORT_SYS_APP _HRESULT_TYPEDEF_(0x8011044C)
#define COMADMIN_E_CANT_SUBSCRIBE_TO_COMPONENT _HRESULT_TYPEDEF_(0x8011044D)
#define COMADMIN_E_EVENTCLASS_CANT_BE_SUBSCRIBER _HRESULT_TYPEDEF_(0x8011044E)
#define COMADMIN_E_LIB_APP_PROXY_INCOMPATIBLE _HRESULT_TYPEDEF_(0x8011044F)
#define COMADMIN_E_BASE_PARTITION_ONLY _HRESULT_TYPEDEF_(0x80110450)
#define COMADMIN_E_START_APP_DISABLED _HRESULT_TYPEDEF_(0x80110451)
#define COMADMIN_E_CAT_DUPLICATE_PARTITION_NAME _HRESULT_TYPEDEF_(0x80110457)
#define COMADMIN_E_CAT_INVALID_PARTITION_NAME _HRESULT_TYPEDEF_(0x80110458)
#define COMADMIN_E_CAT_PARTITION_IN_USE _HRESULT_TYPEDEF_(0x80110459)
#define COMADMIN_E_FILE_PARTITION_DUPLICATE_FILES _HRESULT_TYPEDEF_(0x8011045A)
#define COMADMIN_E_CAT_IMPORTED_COMPONENTS_NOT_ALLOWED _HRESULT_TYPEDEF_(0x8011045B)
#define COMADMIN_E_AMBIGUOUS_APPLICATION_NAME _HRESULT_TYPEDEF_(0x8011045C)
#define COMADMIN_E_AMBIGUOUS_PARTITION_NAME _HRESULT_TYPEDEF_(0x8011045D)
#define COMADMIN_E_REGDB_NOTINITIALIZED _HRESULT_TYPEDEF_(0x80110472)
#define COMADMIN_E_REGDB_NOTOPEN _HRESULT_TYPEDEF_(0x80110473)
#define COMADMIN_E_REGDB_SYSTEMERR _HRESULT_TYPEDEF_(0x80110474)
#define COMADMIN_E_REGDB_ALREADYRUNNING _HRESULT_TYPEDEF_(0x80110475)
#define COMADMIN_E_MIG_VERSIONNOTSUPPORTED _HRESULT_TYPEDEF_(0x80110480)
#define COMADMIN_E_MIG_SCHEMANOTFOUND _HRESULT_TYPEDEF_(0x80110481)
#define COMADMIN_E_CAT_BITNESSMISMATCH _HRESULT_TYPEDEF_(0x80110482)
#define COMADMIN_E_CAT_UNACCEPTABLEBITNESS _HRESULT_TYPEDEF_(0x80110483)
#define COMADMIN_E_CAT_WRONGAPPBITNESS _HRESULT_TYPEDEF_(0x80110484)
#define COMADMIN_E_CAT_PAUSE_RESUME_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x80110485)
#define COMADMIN_E_CAT_SERVERFAULT _HRESULT_TYPEDEF_(0x80110486)
#define COMQC_E_APPLICATION_NOT_QUEUED _HRESULT_TYPEDEF_(0x80110600)
#define COMQC_E_NO_QUEUEABLE_INTERFACES _HRESULT_TYPEDEF_(0x80110601)
#define COMQC_E_QUEUING_SERVICE_NOT_AVAILABLE _HRESULT_TYPEDEF_(0x80110602)
#define COMQC_E_NO_IPERSISTSTREAM _HRESULT_TYPEDEF_(0x80110603)
#define COMQC_E_BAD_MESSAGE _HRESULT_TYPEDEF_(0x80110604)
#define COMQC_E_UNAUTHENTICATED _HRESULT_TYPEDEF_(0x80110605)
#define COMQC_E_UNTRUSTED_ENQUEUER _HRESULT_TYPEDEF_(0x80110606)
#define MSDTC_E_DUPLICATE_RESOURCE _HRESULT_TYPEDEF_(0x80110701)
#define COMADMIN_E_OBJECT_PARENT_MISSING _HRESULT_TYPEDEF_(0x80110808)
#define COMADMIN_E_OBJECT_DOES_NOT_EXIST _HRESULT_TYPEDEF_(0x80110809)
#define COMADMIN_E_APP_NOT_RUNNING _HRESULT_TYPEDEF_(0x8011080A)
#define COMADMIN_E_INVALID_PARTITION _HRESULT_TYPEDEF_(0x8011080B)
#define COMADMIN_E_SVCAPP_NOT_POOLABLE_OR_RECYCLABLE _HRESULT_TYPEDEF_(0x8011080D)
#define COMADMIN_E_USER_IN_SET _HRESULT_TYPEDEF_(0x8011080E)
#define COMADMIN_E_CANTRECYCLELIBRARYAPPS _HRESULT_TYPEDEF_(0x8011080F)
#define COMADMIN_E_CANTRECYCLESERVICEAPPS _HRESULT_TYPEDEF_(0x80110811)
#define COMADMIN_E_PROCESSALREADYRECYCLED _HRESULT_TYPEDEF_(0x80110812)
#define COMADMIN_E_PAUSEDPROCESSMAYNOTBERECYCLED _HRESULT_TYPEDEF_(0x80110813)
#define COMADMIN_E_CANTMAKEINPROCSERVICE _HRESULT_TYPEDEF_(0x80110814)
#define COMADMIN_E_PROGIDINUSEBYCLSID _HRESULT_TYPEDEF_(0x80110815)
#define COMADMIN_E_DEFAULT_PARTITION_NOT_IN_SET _HRESULT_TYPEDEF_(0x80110816)
#define COMADMIN_E_RECYCLEDPROCESSMAYNOTBEPAUSED _HRESULT_TYPEDEF_(0x80110817)
#define COMADMIN_E_PARTITION_ACCESSDENIED _HRESULT_TYPEDEF_(0x80110818)
#define COMADMIN_E_PARTITION_MSI_ONLY _HRESULT_TYPEDEF_(0x80110819)
#define COMADMIN_E_LEGACYCOMPS_NOT_ALLOWED_IN_1_0_FORMAT _HRESULT_TYPEDEF_(0x8011081A)
#define COMADMIN_E_LEGACYCOMPS_NOT_ALLOWED_IN_NONBASE_PARTITIONS _HRESULT_TYPEDEF_(0x8011081B)
#define COMADMIN_E_COMP_MOVE_SOURCE _HRESULT_TYPEDEF_(0x8011081C)
#define COMADMIN_E_COMP_MOVE_DEST _HRESULT_TYPEDEF_(0x8011081D)
#define COMADMIN_E_COMP_MOVE_PRIVATE _HRESULT_TYPEDEF_(0x8011081E)
#define COMADMIN_E_BASEPARTITION_REQUIRED_IN_SET _HRESULT_TYPEDEF_(0x8011081F)
#define COMADMIN_E_CANNOT_ALIAS_EVENTCLASS _HRESULT_TYPEDEF_(0x80110820)
#define COMADMIN_E_PRIVATE_ACCESSDENIED _HRESULT_TYPEDEF_(0x80110821)
#define COMADMIN_E_SAFERINVALID _HRESULT_TYPEDEF_(0x80110822)
#define COMADMIN_E_REGISTRY_ACCESSDENIED _HRESULT_TYPEDEF_(0x80110823)
#define COMADMIN_E_PARTITIONS_DISABLED _HRESULT_TYPEDEF_(0x80110824)

#define VSS_E_BAD_STATE _HRESULT_TYPEDEF_(0x80042301)
#define VSS_E_LEGACY_PROVIDER _HRESULT_TYPEDEF_(0x800423F7)
#define VSS_E_RESYNC_IN_PROGRESS _HRESULT_TYPEDEF_(0x800423FF)
#define VSS_E_SNAPSHOT_NOT_IN_SET _HRESULT_TYPEDEF_(0x8004232B)
#define VSS_E_MAXIMUM_NUMBER_OF_VOLUMES_REACHED _HRESULT_TYPEDEF_(0x80042312)
#define VSS_E_MAXIMUM_NUMBER_OF_SNAPSHOTS_REACHED _HRESULT_TYPEDEF_(0x80042317)
#define VSS_E_NESTED_VOLUME_LIMIT _HRESULT_TYPEDEF_(0x8004232C)
#define VSS_E_OBJECT_NOT_FOUND _HRESULT_TYPEDEF_(0x80042308)
#define VSS_E_PROVIDER_NOT_REGISTERED _HRESULT_TYPEDEF_(0x80042304)
#define VSS_E_PROVIDER_VETO _HRESULT_TYPEDEF_(0x80042306)
#define VSS_E_VOLUME_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x8004230C)
#define VSS_E_VOLUME_NOT_SUPPORTED_BY_PROVIDER _HRESULT_TYPEDEF_(0x8004230E)
#define VSS_E_UNEXPECTED _HRESULT_TYPEDEF_(0x80042302)
#define VSS_E_UNEXPECTED_PROVIDER_ERROR _HRESULT_TYPEDEF_(0x8004230F)
#define VSS_E_UNSELECTED_VOLUME _HRESULT_TYPEDEF_(0x8004232A)
#define VSS_E_CANNOT_REVERT_DISKID _HRESULT_TYPEDEF_(0x800423FE)
#define VSS_E_INVALID_XML_DOCUMENT _HRESULT_TYPEDEF_(0x80042311)
#define VSS_E_OBJECT_ALREADY_EXISTS _HRESULT_TYPEDEF_(0x8004230D)


#define TBS_SUCCESS 0U
#define TBS_E_INTERNAL_ERROR _HRESULT_TYPEDEF_(0x80284001)
#define TBS_E_BAD_PARAMETER _HRESULT_TYPEDEF_(0x80284002)
#define TBS_E_INVALID_OUTPUT_POINTER _HRESULT_TYPEDEF_(0x80284003)
#define TBS_E_INSUFFICIENT_BUFFER _HRESULT_TYPEDEF_(0x80284005)
#define TBS_E_IOERROR _HRESULT_TYPEDEF_(0x80284006)
#define TBS_E_INVALID_CONTEXT_PARAM _HRESULT_TYPEDEF_(0x80284007)
#define TBS_E_SERVICE_NOT_RUNNING _HRESULT_TYPEDEF_(0x80284008)
#define TBS_E_TOO_MANY_TBS_CONTEXTS _HRESULT_TYPEDEF_(0x80284009)
#define TBS_E_SERVICE_START_PENDING _HRESULT_TYPEDEF_(0x8028400B)
#define TBS_E_BUFFER_TOO_LARGE _HRESULT_TYPEDEF_(0x8028400E)
#define TBS_E_TPM_NOT_FOUND _HRESULT_TYPEDEF_(0x8028400F)
#define TBS_E_SERVICE_DISABLED _HRESULT_TYPEDEF_(0x80284010)
#define TBS_E_DEACTIVATED _HRESULT_TYPEDEF_(0x80284016)

#define FWP_E_CALLOUT_NOT_FOUND _HRESULT_TYPEDEF_(0x80320001)
#define FWP_E_CONDITION_NOT_FOUND _HRESULT_TYPEDEF_(0x80320002)
#define FWP_E_FILTER_NOT_FOUND _HRESULT_TYPEDEF_(0x80320003)
#define FWP_E_LAYER_NOT_FOUND _HRESULT_TYPEDEF_(0x80320004)
#define FWP_E_PROVIDER_NOT_FOUND _HRESULT_TYPEDEF_(0x80320005)
#define FWP_E_PROVIDER_CONTEXT_NOT_FOUND _HRESULT_TYPEDEF_(0x80320006)
#define FWP_E_SUBLAYER_NOT_FOUND _HRESULT_TYPEDEF_(0x80320007)
#define FWP_E_NOT_FOUND _HRESULT_TYPEDEF_(0x80320008)
#define FWP_E_ALREADY_EXISTS _HRESULT_TYPEDEF_(0x80320009)
#define FWP_E_IN_USE _HRESULT_TYPEDEF_(0x8032000A)
#define FWP_E_DYNAMIC_SESSION_IN_PROGRESS _HRESULT_TYPEDEF_(0x8032000B)
#define FWP_E_WRONG_SESSION _HRESULT_TYPEDEF_(0x8032000C)
#define FWP_E_NO_TXN_IN_PROGRESS _HRESULT_TYPEDEF_(0x8032000D)
#define FWP_E_TXN_IN_PROGRESS _HRESULT_TYPEDEF_(0x8032000E)
#define FWP_E_TXN_ABORTED _HRESULT_TYPEDEF_(0x8032000F)
#define FWP_E_SESSION_ABORTED _HRESULT_TYPEDEF_(0x80320010)
#define FWP_E_INCOMPATIBLE_TXN _HRESULT_TYPEDEF_(0x80320011)
#define FWP_E_TIMEOUT _HRESULT_TYPEDEF_(0x80320012)
#define FWP_E_NET_EVENTS_DISABLED _HRESULT_TYPEDEF_(0x80320013)
#define FWP_E_INCOMPATIBLE_LAYER _HRESULT_TYPEDEF_(0x80320014)
#define FWP_E_KM_CLIENTS_ONLY _HRESULT_TYPEDEF_(0x80320015)
#define FWP_E_LIFETIME_MISMATCH _HRESULT_TYPEDEF_(0x80320016)
#define FWP_E_BUILTIN_OBJECT _HRESULT_TYPEDEF_(0x80320017)
#define FWP_E_TOO_MANY_CALLOUTS _HRESULT_TYPEDEF_(0x80320018)
#define FWP_E_NOTIFICATION_DROPPED _HRESULT_TYPEDEF_(0x80320019)
#define FWP_E_TRAFFIC_MISMATCH _HRESULT_TYPEDEF_(0x8032001A)
#define FWP_E_INCOMPATIBLE_SA_STATE _HRESULT_TYPEDEF_(0x8032001B)
#define FWP_E_NULL_POINTER _HRESULT_TYPEDEF_(0x8032001C)
#define FWP_E_INVALID_ENUMERATOR _HRESULT_TYPEDEF_(0x8032001D)
#define FWP_E_INVALID_FLAGS _HRESULT_TYPEDEF_(0x8032001E)
#define FWP_E_INVALID_NET_MASK _HRESULT_TYPEDEF_(0x8032001F)
#define FWP_E_INVALID_RANGE _HRESULT_TYPEDEF_(0x80320020)
#define FWP_E_INVALID_INTERVAL _HRESULT_TYPEDEF_(0x80320021)
#define FWP_E_ZERO_LENGTH_ARRAY _HRESULT_TYPEDEF_(0x80320022)
#define FWP_E_NULL_DISPLAY_NAME _HRESULT_TYPEDEF_(0x80320023)
#define FWP_E_INVALID_ACTION_TYPE _HRESULT_TYPEDEF_(0x80320024)
#define FWP_E_INVALID_WEIGHT _HRESULT_TYPEDEF_(0x80320025)
#define FWP_E_MATCH_TYPE_MISMATCH _HRESULT_TYPEDEF_(0x80320026)
#define FWP_E_TYPE_MISMATCH _HRESULT_TYPEDEF_(0x80320027)
#define FWP_E_OUT_OF_BOUNDS _HRESULT_TYPEDEF_(0x80320028)
#define FWP_E_RESERVED _HRESULT_TYPEDEF_(0x80320029)
#define FWP_E_DUPLICATE_CONDITION _HRESULT_TYPEDEF_(0x8032002A)
#define FWP_E_DUPLICATE_KEYMOD _HRESULT_TYPEDEF_(0x8032002B)
#define FWP_E_ACTION_INCOMPATIBLE_WITH_LAYER _HRESULT_TYPEDEF_(0x8032002C)
#define FWP_E_ACTION_INCOMPATIBLE_WITH_SUBLAYER _HRESULT_TYPEDEF_(0x8032002D)
#define FWP_E_CONTEXT_INCOMPATIBLE_WITH_LAYER _HRESULT_TYPEDEF_(0x8032002E)
#define FWP_E_CONTEXT_INCOMPATIBLE_WITH_CALLOUT _HRESULT_TYPEDEF_(0x8032002F)
#define FWP_E_INCOMPATIBLE_AUTH_METHOD _HRESULT_TYPEDEF_(0x80320030)
#define FWP_E_INCOMPATIBLE_DH_GROUP _HRESULT_TYPEDEF_(0x80320031)
#define FWP_E_EM_NOT_SUPPORTED _HRESULT_TYPEDEF_(0x80320032)
#define FWP_E_NEVER_MATCH _HRESULT_TYPEDEF_(0x80320033)
#define FWP_E_PROVIDER_CONTEXT_MISMATCH _HRESULT_TYPEDEF_(0x80320034)
#define FWP_E_INVALID_PARAMETER _HRESULT_TYPEDEF_(0x80320035)
#define FWP_E_TOO_MANY_SUBLAYERS _HRESULT_TYPEDEF_(0x80320036)
#define FWP_E_CALLOUT_NOTIFICATION_FAILED _HRESULT_TYPEDEF_(0x80320037)
#define FWP_E_INVALID_AUTH_TRANSFORM _HRESULT_TYPEDEF_(0x80320038)
#define FWP_E_INVALID_CIPHER_TRANSFORM _HRESULT_TYPEDEF_(0x80320039)



# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\fltwinerror.h" 1 3
/**
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER within this package.
 */


#define _FLT_WINERROR_ 



#define FILTER_HRESULT_FROM_FLT_NTSTATUS(x) (NT_ASSERT((x & 0xfff0000) == 0x001c0000),(HRESULT) (((x) & 0x8000ffff) | (FACILITY_USERMODE_FILTER_MANAGER << 16)))
#define FACILITY_USERMODE_FILTER_MANAGER 0x1f

#define ERROR_FLT_IO_COMPLETE ((HRESULT)0x001f0001)
#define ERROR_FLT_NO_HANDLER_DEFINED ((HRESULT)0x801f0001)
#define ERROR_FLT_CONTEXT_ALREADY_DEFINED ((HRESULT)0x801f0002)
#define ERROR_FLT_INVALID_ASYNCHRONOUS_REQUEST ((HRESULT)0x801f0003)
#define ERROR_FLT_DISALLOW_FAST_IO ((HRESULT)0x801f0004)
#define ERROR_FLT_INVALID_NAME_REQUEST ((HRESULT)0x801f0005)
#define ERROR_FLT_NOT_SAFE_TO_POST_OPERATION ((HRESULT)0x801f0006)
#define ERROR_FLT_NOT_INITIALIZED ((HRESULT)0x801f0007)
#define ERROR_FLT_FILTER_NOT_READY ((HRESULT)0x801f0008)
#define ERROR_FLT_POST_OPERATION_CLEANUP ((HRESULT)0x801f0009)
#define ERROR_FLT_INTERNAL_ERROR ((HRESULT)0x801f000a)
#define ERROR_FLT_DELETING_OBJECT ((HRESULT)0x801f000b)
#define ERROR_FLT_MUST_BE_NONPAGED_POOL ((HRESULT)0x801f000c)
#define ERROR_FLT_DUPLICATE_ENTRY ((HRESULT)0x801f000d)
#define ERROR_FLT_CBDQ_DISABLED ((HRESULT)0x801f000e)
#define ERROR_FLT_DO_NOT_ATTACH ((HRESULT)0x801f000f)
#define ERROR_FLT_DO_NOT_DETACH ((HRESULT)0x801f0010)
#define ERROR_FLT_INSTANCE_ALTITUDE_COLLISION ((HRESULT)0x801f0011)
#define ERROR_FLT_INSTANCE_NAME_COLLISION ((HRESULT)0x801f0012)
#define ERROR_FLT_FILTER_NOT_FOUND ((HRESULT)0x801f0013)
#define ERROR_FLT_VOLUME_NOT_FOUND ((HRESULT)0x801f0014)
#define ERROR_FLT_INSTANCE_NOT_FOUND ((HRESULT)0x801f0015)
#define ERROR_FLT_CONTEXT_ALLOCATION_NOT_FOUND ((HRESULT)0x801f0016)
#define ERROR_FLT_INVALID_CONTEXT_REGISTRATION ((HRESULT)0x801f0017)
#define ERROR_FLT_NAME_CACHE_MISS ((HRESULT)0x801f0018)
#define ERROR_FLT_NO_DEVICE_OBJECT ((HRESULT)0x801f0019)
#define ERROR_FLT_VOLUME_ALREADY_MOUNTED ((HRESULT)0x801f001a)
#define ERROR_FLT_ALREADY_ENLISTED ((HRESULT)0x801f001b)
#define ERROR_FLT_CONTEXT_ALREADY_LINKED ((HRESULT)0x801F001c)
#define ERROR_FLT_NO_WAITER_FOR_REPLY ((HRESULT)0x801f0020)
#define ERROR_FLT_REGISTRATION_BUSY ((HRESULT)0x801F0023)
# 3272 "c:\\mingw64\\x86_64-w64-mingw32\\include\\winerror.h" 2 3

#undef __IN__WINERROR_
# 2560 "c_include/windows/original/winbase.h" 2

#define TC_NORMAL 0
#define TC_HARDERR 1
#define TC_GP_TRAP 2
#define TC_SIGNAL 3

#define AC_LINE_OFFLINE 0x0
#define AC_LINE_ONLINE 0x1
#define AC_LINE_BACKUP_POWER 0x2
#define AC_LINE_UNKNOWN 0xff

#define BATTERY_FLAG_HIGH 0x1
#define BATTERY_FLAG_LOW 0x2
#define BATTERY_FLAG_CRITICAL 0x4
#define BATTERY_FLAG_CHARGING 0x8
#define BATTERY_FLAG_NO_BATTERY 0x80
#define BATTERY_FLAG_UNKNOWN 0xff

#define BATTERY_PERCENTAGE_UNKNOWN 0xff

#define BATTERY_LIFE_UNKNOWN 0xffffffff

  typedef struct _SYSTEM_POWER_STATUS {
    BYTE ACLineStatus;
    BYTE BatteryFlag;
    BYTE BatteryLifePercent;
    BYTE Reserved1;
    DWORD BatteryLifeTime;
    DWORD BatteryFullLifeTime;
  } SYSTEM_POWER_STATUS,*LPSYSTEM_POWER_STATUS;

#define CreateJobObject __MINGW_NAME_AW(CreateJobObject)
#define OpenJobObject __MINGW_NAME_AW(OpenJobObject)
#define FindFirstVolume __MINGW_NAME_AW(FindFirstVolume)
#define FindNextVolume __MINGW_NAME_AW(FindNextVolume)
#define FindFirstVolumeMountPoint __MINGW_NAME_AW(FindFirstVolumeMountPoint)
#define FindNextVolumeMountPoint __MINGW_NAME_AW(FindNextVolumeMountPoint)
#define SetVolumeMountPoint __MINGW_NAME_AW(SetVolumeMountPoint)
#define DeleteVolumeMountPoint __MINGW_NAME_AW(DeleteVolumeMountPoint)
#define GetVolumeNameForVolumeMountPoint __MINGW_NAME_AW(GetVolumeNameForVolumeMountPoint)
#define GetVolumePathName __MINGW_NAME_AW(GetVolumePathName)
#define GetVolumePathNamesForVolumeName __MINGW_NAME_AW(GetVolumePathNamesForVolumeName)

  WINBOOL WINAPI GetSystemPowerStatus(LPSYSTEM_POWER_STATUS lpSystemPowerStatus);
  WINBOOL WINAPI SetSystemPowerState(WINBOOL fSuspend,WINBOOL fForce);
  DECLSPEC_IMPORT WINBOOL WINAPI AllocateUserPhysicalPages(HANDLE hProcess,PULONG_PTR NumberOfPages,PULONG_PTR PageArray);
  DECLSPEC_IMPORT WINBOOL WINAPI FreeUserPhysicalPages(HANDLE hProcess,PULONG_PTR NumberOfPages,PULONG_PTR PageArray);
  DECLSPEC_IMPORT WINBOOL WINAPI MapUserPhysicalPages(PVOID VirtualAddress,ULONG_PTR NumberOfPages,PULONG_PTR PageArray);
  DECLSPEC_IMPORT WINBOOL WINAPI MapUserPhysicalPagesScatter(PVOID *VirtualAddresses,ULONG_PTR NumberOfPages,PULONG_PTR PageArray);
  DECLSPEC_IMPORT HANDLE WINAPI CreateJobObjectA(LPSECURITY_ATTRIBUTES lpJobAttributes,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI CreateJobObjectW(LPSECURITY_ATTRIBUTES lpJobAttributes,LPCWSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenJobObjectA(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCSTR lpName);
  DECLSPEC_IMPORT HANDLE WINAPI OpenJobObjectW(DWORD dwDesiredAccess,WINBOOL bInheritHandle,LPCWSTR lpName);
  DECLSPEC_IMPORT WINBOOL WINAPI AssignProcessToJobObject(HANDLE hJob,HANDLE hProcess);
  DECLSPEC_IMPORT WINBOOL WINAPI TerminateJobObject(HANDLE hJob,UINT uExitCode);
  DECLSPEC_IMPORT WINBOOL WINAPI QueryInformationJobObject(HANDLE hJob,JOBOBJECTINFOCLASS JobObjectInformationClass,LPVOID lpJobObjectInformation,DWORD cbJobObjectInformationLength,LPDWORD lpReturnLength);
  DECLSPEC_IMPORT WINBOOL WINAPI SetInformationJobObject(HANDLE hJob,JOBOBJECTINFOCLASS JobObjectInformationClass,LPVOID lpJobObjectInformation,DWORD cbJobObjectInformationLength);
  DECLSPEC_IMPORT WINBOOL WINAPI IsProcessInJob(HANDLE ProcessHandle,HANDLE JobHandle,PBOOL Result);
  DECLSPEC_IMPORT WINBOOL WINAPI CreateJobSet(ULONG NumJob,PJOB_SET_ARRAY UserJobSet,ULONG Flags);
  DECLSPEC_IMPORT PVOID WINAPI AddVectoredExceptionHandler (ULONG First,PVECTORED_EXCEPTION_HANDLER Handler);
  DECLSPEC_IMPORT ULONG WINAPI RemoveVectoredExceptionHandler(PVOID Handle);
  DECLSPEC_IMPORT PVOID WINAPI AddVectoredContinueHandler (ULONG First,PVECTORED_EXCEPTION_HANDLER Handler);
  DECLSPEC_IMPORT ULONG WINAPI RemoveVectoredContinueHandler(PVOID Handle);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstVolumeA(LPSTR lpszVolumeName,DWORD cchBufferLength);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstVolumeW(LPWSTR lpszVolumeName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextVolumeA(HANDLE hFindVolume,LPSTR lpszVolumeName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextVolumeW(HANDLE hFindVolume,LPWSTR lpszVolumeName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI FindVolumeClose(HANDLE hFindVolume);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstVolumeMountPointA(LPCSTR lpszRootPathName,LPSTR lpszVolumeMountPoint,DWORD cchBufferLength);
  DECLSPEC_IMPORT HANDLE WINAPI FindFirstVolumeMountPointW(LPCWSTR lpszRootPathName,LPWSTR lpszVolumeMountPoint,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextVolumeMountPointA(HANDLE hFindVolumeMountPoint,LPSTR lpszVolumeMountPoint,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI FindNextVolumeMountPointW(HANDLE hFindVolumeMountPoint,LPWSTR lpszVolumeMountPoint,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI FindVolumeMountPointClose(HANDLE hFindVolumeMountPoint);
  DECLSPEC_IMPORT WINBOOL WINAPI SetVolumeMountPointA(LPCSTR lpszVolumeMountPoint,LPCSTR lpszVolumeName);
  DECLSPEC_IMPORT WINBOOL WINAPI SetVolumeMountPointW(LPCWSTR lpszVolumeMountPoint,LPCWSTR lpszVolumeName);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteVolumeMountPointA(LPCSTR lpszVolumeMountPoint);
  DECLSPEC_IMPORT WINBOOL WINAPI DeleteVolumeMountPointW(LPCWSTR lpszVolumeMountPoint);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumeNameForVolumeMountPointA(LPCSTR lpszVolumeMountPoint,LPSTR lpszVolumeName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumeNameForVolumeMountPointW(LPCWSTR lpszVolumeMountPoint,LPWSTR lpszVolumeName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumePathNameA(LPCSTR lpszFileName,LPSTR lpszVolumePathName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumePathNameW(LPCWSTR lpszFileName,LPWSTR lpszVolumePathName,DWORD cchBufferLength);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumePathNamesForVolumeNameA(LPCSTR lpszVolumeName,LPCH lpszVolumePathNames,DWORD cchBufferLength,PDWORD lpcchReturnLength);
  DECLSPEC_IMPORT WINBOOL WINAPI GetVolumePathNamesForVolumeNameW(LPCWSTR lpszVolumeName,LPWCH lpszVolumePathNames,DWORD cchBufferLength,PDWORD lpcchReturnLength);

#define ACTCTX_FLAG_PROCESSOR_ARCHITECTURE_VALID 0x1
#define ACTCTX_FLAG_LANGID_VALID 0x2
#define ACTCTX_FLAG_ASSEMBLY_DIRECTORY_VALID 0x4
#define ACTCTX_FLAG_RESOURCE_NAME_VALID 0x8
#define ACTCTX_FLAG_SET_PROCESS_DEFAULT 0x10
#define ACTCTX_FLAG_APPLICATION_NAME_VALID 0x20
#define ACTCTX_FLAG_SOURCE_IS_ASSEMBLYREF 0x40
#define ACTCTX_FLAG_HMODULE_VALID 0x80

  typedef struct tagACTCTXA {
    ULONG cbSize;
    DWORD dwFlags;
    LPCSTR lpSource;
    USHORT wProcessorArchitecture;
    LANGID wLangId;
    LPCSTR lpAssemblyDirectory;
    LPCSTR lpResourceName;
    LPCSTR lpApplicationName;
    HMODULE hModule;
  } ACTCTXA,*PACTCTXA;

  typedef struct tagACTCTXW {
    ULONG cbSize;
    DWORD dwFlags;
    LPCWSTR lpSource;
    USHORT wProcessorArchitecture;
    LANGID wLangId;
    LPCWSTR lpAssemblyDirectory;
    LPCWSTR lpResourceName;
    LPCWSTR lpApplicationName;
    HMODULE hModule;
  } ACTCTXW,*PACTCTXW;

  typedef const ACTCTXA *PCACTCTXA;
  typedef const ACTCTXW *PCACTCTXW;

  typedef ACTCTXA ACTCTX;
  typedef PACTCTXA PACTCTX;
  typedef PCACTCTXA PCACTCTX;

#define CreateActCtx __MINGW_NAME_AW(CreateActCtx)

  DECLSPEC_IMPORT HANDLE WINAPI CreateActCtxA(PCACTCTXA pActCtx);
  DECLSPEC_IMPORT HANDLE WINAPI CreateActCtxW(PCACTCTXW pActCtx);
  DECLSPEC_IMPORT VOID WINAPI AddRefActCtx(HANDLE hActCtx);
  DECLSPEC_IMPORT VOID WINAPI ReleaseActCtx(HANDLE hActCtx);
  DECLSPEC_IMPORT WINBOOL WINAPI ZombifyActCtx(HANDLE hActCtx);
  DECLSPEC_IMPORT WINBOOL WINAPI ActivateActCtx(HANDLE hActCtx,ULONG_PTR *lpCookie);

#define DEACTIVATE_ACTCTX_FLAG_FORCE_EARLY_DEACTIVATION (0x1)

  DECLSPEC_IMPORT WINBOOL WINAPI DeactivateActCtx(DWORD dwFlags,ULONG_PTR ulCookie);
  DECLSPEC_IMPORT WINBOOL WINAPI GetCurrentActCtx(HANDLE *lphActCtx);

  typedef struct tagACTCTX_SECTION_KEYED_DATA_2600 {
    ULONG cbSize;
    ULONG ulDataFormatVersion;
    PVOID lpData;
    ULONG ulLength;
    PVOID lpSectionGlobalData;
    ULONG ulSectionGlobalDataLength;
    PVOID lpSectionBase;
    ULONG ulSectionTotalLength;
    HANDLE hActCtx;
    ULONG ulAssemblyRosterIndex;
  } ACTCTX_SECTION_KEYED_DATA_2600,*PACTCTX_SECTION_KEYED_DATA_2600;

  typedef const ACTCTX_SECTION_KEYED_DATA_2600 *PCACTCTX_SECTION_KEYED_DATA_2600;

  typedef struct tagACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA {
    PVOID lpInformation;
    PVOID lpSectionBase;
    ULONG ulSectionLength;
    PVOID lpSectionGlobalDataBase;
    ULONG ulSectionGlobalDataLength;
  } ACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA,*PACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA;

  typedef const ACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA *PCACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA;

  typedef struct tagACTCTX_SECTION_KEYED_DATA {
    ULONG cbSize;
    ULONG ulDataFormatVersion;
    PVOID lpData;
    ULONG ulLength;
    PVOID lpSectionGlobalData;
    ULONG ulSectionGlobalDataLength;
    PVOID lpSectionBase;
    ULONG ulSectionTotalLength;
    HANDLE hActCtx;
    ULONG ulAssemblyRosterIndex;

    ULONG ulFlags;
    ACTCTX_SECTION_KEYED_DATA_ASSEMBLY_METADATA AssemblyMetadata;
  } ACTCTX_SECTION_KEYED_DATA,*PACTCTX_SECTION_KEYED_DATA;

  typedef const ACTCTX_SECTION_KEYED_DATA *PCACTCTX_SECTION_KEYED_DATA;

#define FIND_ACTCTX_SECTION_KEY_RETURN_HACTCTX 0x1
#define FIND_ACTCTX_SECTION_KEY_RETURN_FLAGS 0x2
#define FIND_ACTCTX_SECTION_KEY_RETURN_ASSEMBLY_METADATA 0x4

#define FindActCtxSectionString __MINGW_NAME_AW(FindActCtxSectionString)

  DECLSPEC_IMPORT WINBOOL WINAPI FindActCtxSectionStringA(DWORD dwFlags,const GUID *lpExtensionGuid,ULONG ulSectionId,LPCSTR lpStringToFind,PACTCTX_SECTION_KEYED_DATA ReturnedData);
  DECLSPEC_IMPORT WINBOOL WINAPI FindActCtxSectionStringW(DWORD dwFlags,const GUID *lpExtensionGuid,ULONG ulSectionId,LPCWSTR lpStringToFind,PACTCTX_SECTION_KEYED_DATA ReturnedData);
  DECLSPEC_IMPORT WINBOOL WINAPI FindActCtxSectionGuid(DWORD dwFlags,const GUID *lpExtensionGuid,ULONG ulSectionId,const GUID *lpGuidToFind,PACTCTX_SECTION_KEYED_DATA ReturnedData);




  typedef struct _ACTIVATION_CONTEXT_BASIC_INFORMATION {
    HANDLE hActCtx;
    DWORD dwFlags;
  } ACTIVATION_CONTEXT_BASIC_INFORMATION,*PACTIVATION_CONTEXT_BASIC_INFORMATION;

  typedef const struct _ACTIVATION_CONTEXT_BASIC_INFORMATION *PCACTIVATION_CONTEXT_BASIC_INFORMATION;

#define ACTIVATION_CONTEXT_BASIC_INFORMATION_DEFINED 1



#define QUERY_ACTCTX_FLAG_USE_ACTIVE_ACTCTX 0x4
#define QUERY_ACTCTX_FLAG_ACTCTX_IS_HMODULE 0x8
#define QUERY_ACTCTX_FLAG_ACTCTX_IS_ADDRESS 0x10
#define QUERY_ACTCTX_FLAG_NO_ADDREF 0x80000000

  DECLSPEC_IMPORT WINBOOL WINAPI QueryActCtxW(DWORD dwFlags,HANDLE hActCtx,PVOID pvSubInstance,ULONG ulInfoClass,PVOID pvBuffer,SIZE_T cbBuffer,SIZE_T *pcbWrittenOrRequired);

  typedef WINBOOL (WINAPI *PQUERYACTCTXW_FUNC)(DWORD dwFlags,HANDLE hActCtx,PVOID pvSubInstance,ULONG ulInfoClass,PVOID pvBuffer,SIZE_T cbBuffer,SIZE_T *pcbWrittenOrRequired);

  DECLSPEC_IMPORT WINBOOL WINAPI ProcessIdToSessionId(DWORD dwProcessId,DWORD *pSessionId);
  DECLSPEC_IMPORT DWORD WINAPI WTSGetActiveConsoleSessionId();
  DECLSPEC_IMPORT WINBOOL WINAPI IsWow64Process(HANDLE hProcess,PBOOL Wow64Process);
  DECLSPEC_IMPORT WINBOOL WINAPI GetLogicalProcessorInformation(PSYSTEM_LOGICAL_PROCESSOR_INFORMATION Buffer,PDWORD ReturnedLength);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNumaHighestNodeNumber(PULONG HighestNodeNumber);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNumaProcessorNode(UCHAR Processor,PUCHAR NodeNumber);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNumaNodeProcessorMask(UCHAR Node,PULONGLONG ProcessorMask);
  DECLSPEC_IMPORT WINBOOL WINAPI GetNumaAvailableMemoryNode(UCHAR Node,PULONGLONG AvailableBytes);

  /* New Windows Vista API.  */

#define SYMBOLIC_LINK_FLAG_FILE 0x0
#define SYMBOLIC_LINK_FLAG_DIRECTORY 0x1
#define EXTENDED_STARTUPINFO_PRESENT 0x00080000
#define CREATE_MUTEX_INITIAL_OWNER 0x00000001

#define CreateSymbolicLink __MINGW_NAME_AW(CreateSymbolicLink)
#define CreateBoundaryDescriptor __MINGW_NAME_AW(CreateBoundaryDescriptor)
#define OpenPrivateNamespace __MINGW_NAME_AW(OpenPrivateNamespace)
#define CreatePrivateNamespace __MINGW_NAME_AW(CreatePrivateNamespace)
#define CopyFileTransacted __MINGW_NAME_AW(CopyFileTransacted)
#define CreateDirectoryTransacted __MINGW_NAME_AW(CreateDirectoryTransacted)
#define CreateEventEx __MINGW_NAME_AW(CreateEventEx)
#define CreateFileMappingNuma __MINGW_NAME_AW(CreateFileMappingNuma)
#define CreateFileTransacted __MINGW_NAME_AW(CreateFileTransacted)
#define CreateHardLinkTransacted __MINGW_NAME_AW(CreateHardLinkTransacted)
#define DeleteFileTransacted __MINGW_NAME_AW(DeleteFileTransacted)
#define CreateMutexEx __MINGW_NAME_AW(CreateMutexEx)
#define CreateSemaphoreEx __MINGW_NAME_AW(CreateSemaphoreEx)
#define CreateSymbolicLinkTransacted __MINGW_NAME_AW(CreateSymbolicLinkTransacted)
#define CreateWaitableTimerEx __MINGW_NAME_AW(CreateWaitableTimerEx)
#define FindFirstFileTransacted __MINGW_NAME_AW(FindFirstFileTransacted)

DECLSPEC_IMPORT BOOLEAN WINAPI CreateSymbolicLinkA (LPSTR lpSymLinkFileName, LPSTR lpTargetFileName, DWORD dwFlags);
DECLSPEC_IMPORT BOOLEAN WINAPI CreateSymbolicLinkW (LPWSTR lpSymLinkFileName, LPWSTR lpTargetFileName, DWORD dwFlags);

/* Condition Variables http://msdn.microsoft.com/en-us/library/ms682052%28VS.85%29.aspx  */
/* FIXME: These need their data types actually fixed in winnt.h !!! */
typedef RTL_CONDITION_VARIABLE CONDITION_VARIABLE, *PCONDITION_VARIABLE;
typedef RTL_SRWLOCK SRWLOCK, *PSRWLOCK;

DECLSPEC_IMPORT VOID WINAPI InitializeConditionVariable(PCONDITION_VARIABLE ConditionVariable);
DECLSPEC_IMPORT WINBOOL WINAPI SleepConditionVariableCS(PCONDITION_VARIABLE ConditionVariable, PCRITICAL_SECTION CriticalSection, DWORD dwMilliseconds);
DECLSPEC_IMPORT WINBOOL WINAPI SleepConditionVariableSRW(PCONDITION_VARIABLE ConditionVariable, PSRWLOCK SRWLock, DWORD dwMilliseconds, ULONG Flags);
DECLSPEC_IMPORT VOID WINAPI WakeAllConditionVariable(PCONDITION_VARIABLE ConditionVariable);
DECLSPEC_IMPORT VOID WINAPI WakeConditionVariable(PCONDITION_VARIABLE ConditionVariable);

/*Slim Reader/Writer (SRW) Locks http://msdn.microsoft.com/en-us/library/aa904937%28VS.85%29.aspx*/
/* FIXME: See above !!! */
DECLSPEC_IMPORT VOID WINAPI AcquireSRWLockExclusive(PSRWLOCK SRWLock);
DECLSPEC_IMPORT VOID WINAPI AcquireSRWLockShared(PSRWLOCK SRWLock);
DECLSPEC_IMPORT VOID WINAPI InitializeSRWLock(PSRWLOCK SRWLock);
DECLSPEC_IMPORT VOID WINAPI ReleaseSRWLockExclusive(PSRWLOCK SRWLock);
DECLSPEC_IMPORT VOID WINAPI ReleaseSRWLockShared(PSRWLOCK SRWLock);

DECLSPEC_IMPORT BOOLEAN TryAcquireSRWLockExclusive(PSRWLOCK SRWLock);
DECLSPEC_IMPORT BOOLEAN TryAcquireSRWLockShared(PSRWLOCK SRWLock);

/*One-Time Initialization http://msdn.microsoft.com/en-us/library/aa363808(VS.85).aspx*/
/* FIXME: See above !!! */
#define INIT_ONCE_ASYNC __MSABI_LONG(0x00000002U)
#define INIT_ONCE_INIT_FAILED __MSABI_LONG(0x00000004U)

typedef PRTL_RUN_ONCE PINIT_ONCE;
typedef PRTL_RUN_ONCE LPINIT_ONCE;
typedef WINBOOL CALLBACK (*PINIT_ONCE_FN) (PINIT_ONCE InitOnce, PVOID Parameter, PVOID *Context);

DECLSPEC_IMPORT WINBOOL WINAPI InitOnceBeginInitialize(LPINIT_ONCE lpInitOnce, DWORD dwFlags, PBOOL fPending, LPVOID *lpContext);
DECLSPEC_IMPORT WINBOOL WINAPI InitOnceComplete(LPINIT_ONCE lpInitOnce, DWORD dwFlags, LPVOID lpContext);
DECLSPEC_IMPORT WINBOOL WINAPI InitOnceExecuteOnce(PINIT_ONCE InitOnce, PINIT_ONCE_FN InitFn, PVOID Parameter, LPVOID *Context);

DECLSPEC_IMPORT WINBOOL WINAPI AddMandatoryAce(PACL pAcl,DWORD dwAceRevision,DWORD AceFlags,DWORD MandatoryPolicy,PSID pLabelSid);
DECLSPEC_IMPORT WINBOOL WINAPI AddSIDToBoundaryDescriptor(HANDLE *BoundaryDescriptor,PSID RequiredSid);
DECLSPEC_IMPORT HANDLE WINAPI CreateBoundaryDescriptorA(LPCSTR Name,ULONG Flags);
DECLSPEC_IMPORT HANDLE WINAPI CreateBoundaryDescriptorW(LPCWSTR Name,ULONG Flags);

DECLSPEC_IMPORT BOOLEAN WINAPI ClosePrivateNamespace(HANDLE Handle,ULONG Flags);
DECLSPEC_IMPORT HANDLE WINAPI OpenPrivateNamespaceA(LPVOID lpBoundaryDescriptor,LPCSTR lpAliasPrefix);
DECLSPEC_IMPORT HANDLE WINAPI OpenPrivateNamespaceW(LPVOID lpBoundaryDescriptor,LPCWSTR lpAliasPrefix);
DECLSPEC_IMPORT VOID WINAPI DeleteBoundaryDescriptor(HANDLE BoundaryDescriptor);
DECLSPEC_IMPORT HANDLE WINAPI CreatePrivateNamespaceA(LPSECURITY_ATTRIBUTES lpPrivateNamespaceAttributes,LPVOID lpBoundaryDescriptor,LPCSTR lpAliasPrefix);
DECLSPEC_IMPORT HANDLE WINAPI CreatePrivateNamespaceW(LPSECURITY_ATTRIBUTES lpPrivateNamespaceAttributes,LPVOID lpBoundaryDescriptor,LPCWSTR lpAliasPrefix);

typedef BOOLEAN CALLBACK (*PSECURE_MEMORY_CACHE_CALLBACK) (PVOID Addr,SIZE_T Range);

DECLSPEC_IMPORT WINBOOL WINAPI AddSecureMemoryCacheCallback(PSECURE_MEMORY_CACHE_CALLBACK pfnCallBack);
DECLSPEC_IMPORT WINBOOL WINAPI RemoveSecureMemoryCacheCallback(PSECURE_MEMORY_CACHE_CALLBACK pfnCallBack);

DECLSPEC_IMPORT WINBOOL WINAPI AllocateUserPhysicalPagesNuma(HANDLE hProcess,PULONG_PTR NumberOfPages,PULONG_PTR PageArray,DWORD nndPreferred);

typedef DWORD (WINAPI *APPLICATION_RECOVERY_CALLBACK)(PVOID pvParameter);
DECLSPEC_IMPORT HRESULT WINAPI RegisterApplicationRecoveryCallback(APPLICATION_RECOVERY_CALLBACK pRecoveryCallback,PVOID pvParameter,DWORD dwPingInterval,DWORD dwFlags);
DECLSPEC_IMPORT VOID WINAPI ApplicationRecoveryFinished(WINBOOL bSuccess);
DECLSPEC_IMPORT HRESULT WINAPI ApplicationRecoveryInProgress(PBOOL pbCanceled);

DECLSPEC_IMPORT WINBOOL WINAPI QueryIdleProcessorCycleTime(PULONG BufferLength,PULONG64 ProcessorIdleCycleTime);
DECLSPEC_IMPORT WINBOOL WINAPI QueryProcessCycleTime(HANDLE ProcessHandle,PULONG64 CycleTime);
DECLSPEC_IMPORT WINBOOL WINAPI QueryThreadCycleTime(HANDLE ThreadHandle,PULONG64 CycleTime);

DECLSPEC_IMPORT WINBOOL WINAPI QueryIdleProcessorCycleTimeEx(USHORT Group,PULONG BufferLength,PULONG64 ProcessorIdleCycleTime);


/* THREAD POOL stuff : */
/* FIXME: These thread pool callback data types and
 * func. pointer types actually belong in winnt.h !!!!
 * Not all data types need to be opaque, either !!! */
typedef struct _TP_IO *PTP_IO;
typedef struct _TP_CALLBACK_INSTANCE *PTP_CALLBACK_INSTANCE;
typedef struct _TP_WIN32_IO_CALLBACK *PTP_WIN32_IO_CALLBACK;
typedef struct _TP_CALLBACK_ENVIRON *PTP_CALLBACK_ENVIRON;
typedef struct _TP_CLEANUP_GROUP *PTP_CLEANUP_GROUP;
typedef struct _TP_TIMER *PTP_TIMER;
typedef struct _TP_WAIT *PTP_WAIT;
typedef struct _TP_WORK *PTP_WORK;
typedef struct _TP_POOL *PTP_POOL;

typedef DWORD TP_WAIT_RESULT;

typedef VOID (CALLBACK *PTP_WAIT_CALLBACK)(PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_WAIT Wait, TP_WAIT_RESULT WaitResult);
typedef VOID (CALLBACK *PTP_WORK_CALLBACK)(PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_WORK Work);
typedef VOID (CALLBACK *PTP_TIMER_CALLBACK)(PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_TIMER Timer);
typedef VOID (CALLBACK *PTP_SIMPLE_CALLBACK)(PTP_CALLBACK_INSTANCE Instance, PVOID Context);

#define PRIVATE_NAMESPACE_FLAG_DESTROY 0x00000001

DECLSPEC_IMPORT WINBOOL WINAPI CallbackMayRunLong(PTP_CALLBACK_INSTANCE pci);
DECLSPEC_IMPORT WINBOOL WINAPI CancelIoEx(HANDLE hFile,LPOVERLAPPED lpOverlapped);
DECLSPEC_IMPORT WINBOOL WINAPI CancelSynchronousIo(HANDLE hThread);
DECLSPEC_IMPORT VOID WINAPI CancelThreadpoolIo(PTP_IO pio);
DECLSPEC_IMPORT PTP_IO WINAPI CreateThreadpoolIo(HANDLE fl,PTP_WIN32_IO_CALLBACK pfnio,PVOID pv,PTP_CALLBACK_ENVIRON pcbe);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpool(PTP_POOL ptpp);
DECLSPEC_IMPORT PTP_POOL WINAPI CreateThreadpool(PVOID reserved);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpoolCleanupGroup(PTP_CLEANUP_GROUP ptpcg);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpoolCleanupGroupMembers(PTP_CLEANUP_GROUP ptpcg,WINBOOL fCancelPendingCallbacks,PVOID pvCleanupContext);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpoolIo(PTP_IO pio);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpoolTimer(PTP_TIMER pti);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpoolWait(PTP_WAIT pwa);
DECLSPEC_IMPORT VOID WINAPI CloseThreadpoolWork(PTP_WORK pwk);

DECLSPEC_IMPORT PTP_CLEANUP_GROUP WINAPI CreateThreadpoolCleanupGroup(void);
DECLSPEC_IMPORT PTP_WAIT WINAPI CreateThreadpoolWait(PTP_WAIT_CALLBACK pfnwa,PVOID pv,PTP_CALLBACK_ENVIRON pcbe);
DECLSPEC_IMPORT PTP_WORK WINAPI CreateThreadpoolWork(PTP_WORK_CALLBACK pfnwk,PVOID pv,PTP_CALLBACK_ENVIRON pcbe);
DECLSPEC_IMPORT PTP_TIMER WINAPI CreateThreadpoolTimer(PTP_TIMER_CALLBACK pfnti,PVOID pv,PTP_CALLBACK_ENVIRON pcbe);
DECLSPEC_IMPORT LPVOID WINAPI ConvertThreadToFiberEx(LPVOID lpParameter, DWORD dwFlags);
DECLSPEC_IMPORT VOID WINAPI SubmitThreadpoolWork(PTP_WORK pwk);

/* FIXME: These must be inlines and must call something
 *	  proper from winnt.h !!!!   See above for more
 *	  thread pool fixme notes.  */

/* INLINE - http://msdn.microsoft.com/en-us/library/ms686255%28v=VS.85%29.aspx */
VOID SetThreadpoolCallbackCleanupGroup(PTP_CALLBACK_ENVIRON pcbe, PTP_CLEANUP_GROUP ptpcg, PTP_CLEANUP_GROUP_CANCEL_CALLBACK pfng);
/* INLINE - http://msdn.microsoft.com/en-us/library/ms686258%28v=VS.85%29.aspx */
VOID SetThreadpoolCallbackLibrary(PTP_CALLBACK_ENVIRON pcbe, PVOID mod);
/* INLINE -  http://msdn.microsoft.com/en-us/library/ms686261%28v=VS.85%29.aspx */
VOID SetThreadpoolCallbackPool(PTP_CALLBACK_ENVIRON pcbe, PTP_POOL ptpp);
/* INLINE - http://msdn.microsoft.com/en-us/library/ms686263%28v=VS.85%29.aspx */
VOID SetThreadpoolCallbackRunsLong(PTP_CALLBACK_ENVIRON pcbe);

DECLSPEC_IMPORT VOID WINAPI SetThreadpoolThreadMaximum(PTP_POOL ptpp, DWORD cthrdMost);
DECLSPEC_IMPORT WINBOOL WINAPI SetThreadpoolThreadMinimum(PTP_POOL ptpp, DWORD cthrdMic);
DECLSPEC_IMPORT VOID WINAPI SetThreadpoolTimer(PTP_TIMER pti, PFILETIME pftDueTime, DWORD msPeriod, DWORD msWindowLength);
DECLSPEC_IMPORT VOID WINAPI SetThreadpoolWait(PTP_WAIT pwa, HANDLE h, PFILETIME pftTimeout);
DECLSPEC_IMPORT VOID WINAPI StartThreadpoolIo(PTP_IO pio);

/* End of THREAD POOL stuff */


DECLSPEC_IMPORT WINBOOL WINAPI CopyFileTransactedA(
  LPCSTR lpExistingFileName,
  LPCSTR lpNewFileName,
  LPPROGRESS_ROUTINE lpProgressRoutine,
  LPVOID lpData,
  LPBOOL pbCancel,
  DWORD dwCopyFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI CopyFileTransactedW(
  LPCWSTR lpExistingFileName,
  LPCWSTR lpNewFileName,
  LPPROGRESS_ROUTINE lpProgressRoutine,
  LPVOID lpData,
  LPBOOL pbCancel,
  DWORD dwCopyFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI CreateDirectoryTransactedA(
  LPCSTR lpTemplateDirectory,
  LPCSTR lpNewDirectory,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI CreateDirectoryTransactedW(
  LPCWSTR lpTemplateDirectory,
  LPCWSTR lpNewDirectory,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  HANDLE hTransaction
);

#define CREATE_EVENT_INITIAL_SET 0x00000002
#define CREATE_EVENT_MANUAL_RESET 0x00000001

DECLSPEC_IMPORT HANDLE WINAPI CreateEventExA(
  LPSECURITY_ATTRIBUTES lpEventAttributes,
  LPCSTR lpName,
  DWORD dwFlags,
  DWORD dwDesiredAccess
);

DECLSPEC_IMPORT HANDLE WINAPI CreateEventExW(
  LPSECURITY_ATTRIBUTES lpEventAttributes,
  LPCWSTR lpName,
  DWORD dwFlags,
  DWORD dwDesiredAccess
);

DECLSPEC_IMPORT HANDLE WINAPI CreateFileMappingNumaA(
  HANDLE hFile,
  LPSECURITY_ATTRIBUTES lpFileMappingAttributes,
  DWORD flProtect,
  DWORD dwMaximumSizeHigh,
  DWORD dwMaximumSizeLow,
  LPCSTR lpName,
  DWORD nndPreferred
);

DECLSPEC_IMPORT HANDLE WINAPI CreateFileMappingNumaW(
  HANDLE hFile,
  LPSECURITY_ATTRIBUTES lpFileMappingAttributes,
  DWORD flProtect,
  DWORD dwMaximumSizeHigh,
  DWORD dwMaximumSizeLow,
  LPCWSTR lpName,
  DWORD nndPreferred
);


#define TXFS_MINIVERSION_COMMITTED_VIEW 0x0000
#define TXFS_MINIVERSION_DIRTY_VIEW 0xFFFE
#define TXFS_MINIVERSION_DEFAULT_VIEW 0xFFFF

DECLSPEC_IMPORT HANDLE WINAPI CreateFileTransactedA(
  LPCSTR lpFileName,
  DWORD dwDesiredAccess,
  DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes,
  HANDLE hTemplateFile,
  HANDLE hTransaction,
  PUSHORT pusMiniVersion,
  PVOID pExtendedParameter
);

DECLSPEC_IMPORT HANDLE WINAPI CreateFileTransactedW(
  LPCWSTR lpFileName,
  DWORD dwDesiredAccess,
  DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  DWORD dwCreationDisposition,
  DWORD dwFlagsAndAttributes,
  HANDLE hTemplateFile,
  HANDLE hTransaction,
  PUSHORT pusMiniVersion,
  PVOID pExtendedParameter
);

DECLSPEC_IMPORT WINBOOL WINAPI CreateHardLinkTransactedA(
  LPCSTR lpFileName,
  LPCSTR lpExistingFileName,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI CreateHardLinkTransactedW(
  LPCWSTR lpFileName,
  LPCWSTR lpExistingFileName,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI CreateTransaction(
  LPSECURITY_ATTRIBUTES lpTransactionAttributes,
  LPGUID UOW,
  DWORD CreateOptions,
  DWORD IsolationLevel,
  DWORD IsolationFlags,
  DWORD Timeout,
  LPWSTR Description
);

DECLSPEC_IMPORT WINBOOL WINAPI DeleteFileTransactedA(
  LPCSTR lpFileName,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI DeleteFileTransactedW(
  LPCWSTR lpFileName,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI CreateMutexExA(LPSECURITY_ATTRIBUTES lpMutexAttributes, LPCTSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
DECLSPEC_IMPORT HANDLE WINAPI CreateMutexExW(LPSECURITY_ATTRIBUTES lpMutexAttributes, LPCWSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);

DECLSPEC_IMPORT HANDLE WINAPI CreateSemaphoreExA(LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount, LONG lMaximumCount, LPCSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);
DECLSPEC_IMPORT HANDLE WINAPI CreateSemaphoreExW(LPSECURITY_ATTRIBUTES lpSemaphoreAttributes, LONG lInitialCount, LONG lMaximumCount, LPCWSTR lpName, DWORD dwFlags, DWORD dwDesiredAccess);

DECLSPEC_IMPORT BOOLEAN WINAPI CreateSymbolicLinkTransactedW(LPWSTR lpSymlinkFileName, LPWSTR lpTargetFileName, DWORD dwFlags, HANDLE hTransaction);
DECLSPEC_IMPORT BOOLEAN WINAPI CreateSymbolicLinkTransactedA(LPSTR lpSymlinkFileName, LPSTR lpTargetFileName, DWORD dwFlags, HANDLE hTransaction);

DECLSPEC_IMPORT HANDLE WINAPI CreateWaitableTimerExA(LPSECURITY_ATTRIBUTES lpTimerAttributes, LPCSTR lpTimerName, DWORD dwFlags, DWORD dwDesiredAccess);
DECLSPEC_IMPORT HANDLE WINAPI CreateWaitableTimerExW(LPSECURITY_ATTRIBUTES lpTimerAttributes, LPCWSTR lpTimerName, DWORD dwFlags, DWORD dwDesiredAccess);

#define DeleteFileTransacted __MINGW_NAME_AW(DeleteFileTransacted)

DECLSPEC_IMPORT WINBOOL WINAPI DeleteFileTransactedW(LPCWSTR lpFileName, HANDLE hTransaction);
DECLSPEC_IMPORT WINBOOL WINAPI DeleteFileTransactedA(LPCSTR lpFileName, HANDLE hTransaction);

DECLSPEC_IMPORT VOID WINAPI DestroyThreadpoolEnvironment(PTP_CALLBACK_ENVIRON pcbe);

DECLSPEC_IMPORT VOID WINAPI DisassociateCurrentThreadFromCallback(PTP_CALLBACK_INSTANCE pci);

typedef enum _FILE_ID_TYPE {
  FileIdType,
  ObjectIdType,
  MaximumFileIdType
} FILE_ID_TYPE, *PFILE_ID_TYPE;

typedef struct _TIME_DYNAMIC_ZONE_INFORMATION {
  LONG Bias;
  WCHAR StandardName[32];
  SYSTEMTIME StandardDate;
  LONG StandardBias;
  WCHAR DaylightName[32];
  SYSTEMTIME DaylightDate;
  LONG DaylightBias;
  WCHAR TimeZoneKeyName[128];
  BOOLEAN DynamicDaylightTimeDisabled;
} DYNAMIC_TIME_ZONE_INFORMATION, *PDYNAMIC_TIME_ZONE_INFORMATION;

typedef struct _FILE_ALLOCATION_INFO {
  LARGE_INTEGER AllocationSize;
} FILE_ALLOCATION_INFO, *PFILE_ALLOCATION_INFO;

typedef struct _FILE_ATTRIBUTE_TAG_INFO {
  DWORD FileAttributes;
  DWORD ReparseTag;
} FILE_ATTRIBUTE_TAG_INFO, *PFILE_ATTRIBUTE_TAG_INFO;

typedef struct _FILE_BASIC_INFO {
  LARGE_INTEGER CreationTime;
  LARGE_INTEGER LastAccessTime;
  LARGE_INTEGER LastWriteTime;
  LARGE_INTEGER ChangeTime;
  DWORD FileAttributes;
} FILE_BASIC_INFO, *PFILE_BASIC_INFO;

typedef struct _FILE_COMPRESSION_INFO {
  LARGE_INTEGER CompressedFileSize;
  WORD CompressionFormat;
  UCHAR CompressionUnitShift;
  UCHAR ChunkShift;
  UCHAR ClusterShift;
  UCHAR Reserved[3];
} FILE_COMPRESSION_INFO, *PFILE_COMPRESSION_INFO;

typedef struct _FILE_DISPOSITION_INFO {
  WINBOOL DeleteFileA;
} FILE_DISPOSITION_INFO, *PFILE_DISPOSITION_INFO;

typedef struct _FILE_END_OF_FILE_INFO {
  LARGE_INTEGER EndOfFile;
} FILE_END_OF_FILE_INFO, *PFILE_END_OF_FILE_INFO;

typedef struct _FILE_ID_BOTH_DIR_INFO {
  DWORD NextEntryOffset;
  DWORD FileIndex;
  LARGE_INTEGER CreationTime;
  LARGE_INTEGER LastAccessTime;
  LARGE_INTEGER LastWriteTime;
  LARGE_INTEGER ChangeTime;
  LARGE_INTEGER EndOfFile;
  LARGE_INTEGER AllocationSize;
  DWORD FileAttributes;
  DWORD FileNameLength;
  DWORD EaSize;
  CCHAR ShortNameLength;
  WCHAR ShortName[12];
  LARGE_INTEGER FileId;
  WCHAR FileName[1];
} FILE_ID_BOTH_DIR_INFO, *PFILE_ID_BOTH_DIR_INFO;

typedef struct _FILE_ID_DESCRIPTOR{
  DWORD dwSize;
  FILE_ID_TYPE Type;
  __C89_NAMELESS union {
    LARGE_INTEGER FileId;
    GUID ObjectId;
  };
} FILE_ID_DESCRIPTOR, *LPFILE_ID_DESCRIPTOR;

typedef enum _FILE_INFO_BY_HANDLE_CLASS {
  FileBasicInfo = 0,
  FileStandardInfo = 1,
  FileNameInfo = 2,
  FileRenameInfo = 3,
  FileDispositionInfo = 4,
  FileAllocationInfo = 5,
  FileEndOfFileInfo = 6,
  FileStreamInfo = 7,
  FileCompressionInfo = 8,
  FileAttributeTagInfo = 9,
  FileIdBothDirectoryInfo = 10, // 0xA
  FileIdBothDirectoryRestartInfo = 11, // 0xB
  FileIoPriorityHintInfo = 12, // 0xC
  FileRemoteProtocolInfo = 13, // 0xD
  MaximumFileInfoByHandlesClass = 14 // 0xE
} FILE_INFO_BY_HANDLE_CLASS, *PFILE_INFO_BY_HANDLE_CLASS;

typedef enum _PRIORITY_HINT {
  IoPriorityHintVeryLow = 0,
  IoPriorityHintLow,
  IoPriorityHintNormal,
  MaximumIoPriorityHintType
} PRIORITY_HINT;

typedef struct _FILE_IO_PRIORITY_HINT_INFO {
  PRIORITY_HINT PriorityHint;
} FILE_IO_PRIORITY_HINT_INFO, *PFILE_IO_PRIORITY_HINT_INFO;

typedef struct _FILE_NAME_INFO {
  DWORD FileNameLength;
  WCHAR FileName[1];
} FILE_NAME_INFO, *PFILE_NAME_INFO;

typedef struct _FILE_RENAME_INFO {
  BOOL ReplaceIfExists;
  HANDLE RootDirectory;
  DWORD FileNameLength;
  WCHAR FileName[1];
} FILE_RENAME_INFO, *PFILE_RENAME_INFO;

typedef struct _FILE_STANDARD_INFO {
  LARGE_INTEGER AllocationSize;
  LARGE_INTEGER EndOfFile;
  DWORD NumberOfLinks;
  WINBOOL DeletePending;
  WINBOOL Directory;
} FILE_STANDARD_INFO, *PFILE_STANDARD_INFO;

typedef struct _FILE_STREAM_INFO {
  DWORD NextEntryOffset;
  DWORD StreamNameLength;
  LARGE_INTEGER StreamSize;
  LARGE_INTEGER StreamAllocationSize;
  WCHAR StreamName[1];
} FILE_STREAM_INFO, *PFILE_STREAM_INFO;

typedef struct _OVERLAPPED_ENTRY {
  ULONG_PTR lpCompletionKey;
  LPOVERLAPPED lpOverlapped;
  ULONG_PTR Internal;
  DWORD dwNumberOfBytesTransferred;
} OVERLAPPED_ENTRY, *LPOVERLAPPED_ENTRY;

DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileNameTransactedW(
  LPCWSTR lpFileName,
  DWORD dwFlags,
  LPDWORD StringLength,
  PWCHAR LinkName,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileNameW(
  LPCWSTR lpFileName,
  DWORD dwFlags,
  LPDWORD StringLength,
  PWCHAR LinkName
);

DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileTransactedA(
  LPCSTR lpFileName,
  FINDEX_INFO_LEVELS fInfoLevelId,
  LPVOID lpFindFileData,
  FINDEX_SEARCH_OPS fSearchOp,
  LPVOID lpSearchFilter,
  DWORD dwAdditionalFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI FindFirstFileTransactedW(
  LPCWSTR lpFileName,
  FINDEX_INFO_LEVELS fInfoLevelId,
  LPVOID lpFindFileData,
  FINDEX_SEARCH_OPS fSearchOp,
  LPVOID lpSearchFilter,
  DWORD dwAdditionalFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI FindFirstStreamTransactedW(
  LPCWSTR lpFileName,
  STREAM_INFO_LEVELS InfoLevel,
  LPVOID lpFindStreamData,
  DWORD dwFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI FindFirstStreamW(
  LPCWSTR lpFileName,
  STREAM_INFO_LEVELS InfoLevel,
  LPVOID lpFindStreamData,
  DWORD dwFlags
);

DECLSPEC_IMPORT WINBOOL WINAPI FindNextFileNameW(
  HANDLE hFindStream,
  LPDWORD StringLength,
  PWCHAR LinkName
);

DECLSPEC_IMPORT WINBOOL WINAPI FindNextStreamW(
  HANDLE hFindStream,
  LPVOID lpFindStreamData
);

DECLSPEC_IMPORT DWORD WINAPI FlsAlloc(
  PFLS_CALLBACK_FUNCTION lpCallback
);

DECLSPEC_IMPORT WINBOOL WINAPI FlsFree(
  DWORD dwFlsIndex
);

DECLSPEC_IMPORT PVOID WINAPI FlsGetValue(
  DWORD dwFlsIndex
);

DECLSPEC_IMPORT WINBOOL WINAPI FlsSetValue(
  DWORD dwFlsIndex,
  PVOID lpFlsData
);

DECLSPEC_IMPORT VOID WINAPI FlushProcessWriteBuffers(void);

DECLSPEC_IMPORT VOID WINAPI FreeLibraryWhenCallbackReturns(
  PTP_CALLBACK_INSTANCE pci,
  HMODULE mod
);

DECLSPEC_IMPORT HRESULT WINAPI GetApplicationRecoveryCallback(
  HANDLE hProcess,
  APPLICATION_RECOVERY_CALLBACK *pRecoveryCallback,
  PVOID *ppvParameter,
  DWORD dwPingInterval,
  DWORD dwFlags
);

DECLSPEC_IMPORT HRESULT WINAPI GetApplicationRestartSettings(
  HANDLE hProcess,
  PWSTR pwzCommandline,
  PDWORD pcchSize,
  PDWORD pdwFlags
);

#define RESTART_NO_CRASH 1
#define RESTART_NO_HANG 2
#define RESTART_NO_PATCH 4
#define RESTART_NO_REBOOT 8

#define RESTART_MAX_CMD_LINE 1024

DECLSPEC_IMPORT HRESULT WINAPI RegisterApplicationRestart(
  PCWSTR pwzCommandline,
  DWORD dwFlags
);

#define GetCompressedFileSizeTransacted __MINGW_NAME_AW(GetCompressedFileSizeTransacted)

DECLSPEC_IMPORT DWORD WINAPI GetCompressedFileSizeTransactedA(
  LPCTSTR lpFileName,
  LPDWORD lpFileSizeHigh,
  HANDLE hTransaction
);

DECLSPEC_IMPORT DWORD WINAPI GetCompressedFileSizeTransactedW(
  LPCWSTR lpFileName,
  LPDWORD lpFileSizeHigh,
  HANDLE hTransaction
);

DECLSPEC_IMPORT DWORD WINAPI GetDynamicTimeZoneInformation(
  PDYNAMIC_TIME_ZONE_INFORMATION pTimeZoneInformation
);

DECLSPEC_IMPORT UINT WINAPI GetErrorMode(void);

#define GetFileAttributesTransacted __MINGW_NAME_AW(GetFileAttributesTransacted)

DECLSPEC_IMPORT WINBOOL WINAPI GetFileAttributesTransactedA(
  LPCSTR lpFileName,
  GET_FILEEX_INFO_LEVELS fInfoLevelId,
  LPVOID lpFileInformation,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI GetFileAttributesTransactedW(
  LPCWSTR lpFileName,
  GET_FILEEX_INFO_LEVELS fInfoLevelId,
  LPVOID lpFileInformation,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI GetFileBandwidthReservation(
  HANDLE hFile,
  LPDWORD lpPeriodMilliseconds,
  LPDWORD lpBytesPerPeriod,
  LPBOOL pDiscardable,
  LPDWORD lpTransferSize,
  LPDWORD lpNumOutstandingRequests
);

DECLSPEC_IMPORT WINBOOL WINAPI GetFileInformationByHandleEx(
  HANDLE hFile,
  FILE_INFO_BY_HANDLE_CLASS FileInformationClass,
  LPVOID lpFileInformation,
  DWORD dwBufferSize
);

#define GetFinalPathNameByHandle __MINGW_NAME_AW(GetFinalPathNameByHandle)

#define VOLUME_NAME_DOS 0x0
#define VOLUME_NAME_GUID 0x1
#define VOLUME_NAME_NT 0x2
#define VOLUME_NAME_NONE 0x4

#define FILE_NAME_NORMALIZED 0x0
#define FILE_NAME_OPENED 0x8

DECLSPEC_IMPORT DWORD WINAPI GetFinalPathNameByHandleA(
  HANDLE hFile,
  LPSTR lpszFilePath,
  DWORD cchFilePath,
  DWORD dwFlags
);

DECLSPEC_IMPORT DWORD WINAPI GetFinalPathNameByHandleW(
  HANDLE hFile,
  LPWSTR lpszFilePath,
  DWORD cchFilePath,
  DWORD dwFlags
);

#define GetFullPathNameTransacted __MINGW_NAME_AW(GetFullPathNameTransacted)

DECLSPEC_IMPORT DWORD WINAPI GetFullPathNameTransactedA(
  LPCSTR lpFileName,
  DWORD nBufferLength,
  LPSTR lpBuffer,
  LPSTR *lpFilePart,
  HANDLE hTransaction
);

DECLSPEC_IMPORT DWORD WINAPI GetFullPathNameTransactedW(
  LPCWSTR lpFileName,
  DWORD nBufferLength,
  LPWSTR lpBuffer,
  LPWSTR *lpFilePart,
  HANDLE hTransaction
);

#define GetLongPathNameTransacted __MINGW_NAME_AW(GetLongPathNameTransacted)

DECLSPEC_IMPORT DWORD WINAPI GetLongPathNameTransactedA(
  LPCSTR lpszShortPath,
  LPSTR lpszLongPath,
  DWORD cchBuffer,
  HANDLE hTransaction
);

DECLSPEC_IMPORT DWORD WINAPI GetLongPathNameTransactedW(
  LPCWSTR lpszShortPath,
  LPWSTR lpszLongPath,
  DWORD cchBuffer,
  HANDLE hTransaction
);

#define GetNamedPipeClientComputerName __MINGW_NAME_AW(GetNamedPipeClientComputerName)

DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeClientComputerNameA(
  HANDLE Pipe,
  LPSTR ClientComputerName,
  ULONG ClientComputerNameLength
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeClientComputerNameW(
  HANDLE Pipe,
  LPWSTR ClientComputerName,
  ULONG ClientComputerNameLength
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeClientProcessId(
  HANDLE Pipe,
  PULONG ClientProcessId
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeClientSessionId(
  HANDLE Pipe,
  PULONG ClientSessionId
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeServerProcessId(
  HANDLE Pipe,
  PULONG ServerProcessId
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNamedPipeServerSessionId(
  HANDLE Pipe,
  PULONG ServerSessionId
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNumaProximityNode(
  ULONG ProximityId,
  PUCHAR NodeNumber
);

WINBOOL WINAPI GetPhysicallyInstalledSystemMemory(
  PULONGLONG TotalMemoryInKilobytes
);

typedef LPVOID PPROC_THREAD_ATTRIBUTE_LIST, LPPROC_THREAD_ATTRIBUTE_LIST;

DECLSPEC_IMPORT WINBOOL WINAPI UpdateProcThreadAttribute(
  LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList,
  DWORD dwFlags,
  DWORD_PTR Attribute,
  PVOID lpValue,
  SIZE_T cbSize,
  PVOID lpPreviousValue,
  PSIZE_T lpReturnSize
);

DECLSPEC_IMPORT WINBOOL WINAPI GetProductInfo(
  DWORD dwOSMajorVersion,
  DWORD dwOSMinorVersion,
  DWORD dwSpMajorVersion,
  DWORD dwSpMinorVersion,
  PDWORD pdwReturnedProductType
);

DECLSPEC_IMPORT WINBOOL WINAPI GetQueuedCompletionStatusEx(
  HANDLE CompletionPort,
  LPOVERLAPPED_ENTRY lpCompletionPortEntries,
  ULONG ulCount,
  PULONG ulNumEntriesRemoved,
  DWORD dwMilliseconds,
  WINBOOL fAlertable
);

DECLSPEC_IMPORT WINBOOL WINAPI GetSystemRegistryQuota(
  PDWORD pdwQuotaAllowed,
  PDWORD pdwQuotaUsed
);

DECLSPEC_IMPORT WINBOOL WINAPI GetSystemTimes(
  LPFILETIME lpIdleTime,
  LPFILETIME lpKernelTime,
  LPFILETIME lpUserTime
);

DECLSPEC_IMPORT ULONGLONG WINAPI GetTickCount64(void);

DECLSPEC_IMPORT WINBOOL WINAPI GetTimeZoneInformationForYear(
  USHORT wYear,
  PDYNAMIC_TIME_ZONE_INFORMATION pdtzi,
  LPTIME_ZONE_INFORMATION ptzi
);

DECLSPEC_IMPORT WINBOOL WINAPI GetVolumeInformationByHandleW(
  HANDLE hFile,
  LPWSTR lpVolumeNameBuffer,
  DWORD nVolumeNameSize,
  LPDWORD lpVolumeSerialNumber,
  LPDWORD lpMaximumComponentLength,
  LPDWORD lpFileSystemFlags,
  LPWSTR lpFileSystemNameBuffer,
  DWORD nFileSystemNameSize
);

DECLSPEC_IMPORT WINBOOL WINAPI InitializeCriticalSectionEx(
  LPCRITICAL_SECTION lpCriticalSection,
  DWORD dwSpinCount,
  DWORD Flags
);

DECLSPEC_IMPORT VOID WINAPI LeaveCriticalSectionWhenCallbackReturns(
  PTP_CALLBACK_INSTANCE pci,
  PCRITICAL_SECTION pcs
);

DECLSPEC_IMPORT LPVOID WINAPI MapViewOfFileExNuma(
  HANDLE hFileMappingObject,
  DWORD dwDesiredAccess,
  DWORD dwFileOffsetHigh,
  DWORD dwFileOffsetLow,
  SIZE_T dwNumberOfBytesToMap,
  LPVOID lpBaseAddress,
  DWORD nndPreferred
);

#define MoveFileTransacted __MINGW_NAME_AW(MoveFileTransacted)

DECLSPEC_IMPORT WINBOOL WINAPI MoveFileTransactedA(
  LPCSTR lpExistingFileName,
  LPCSTR lpNewFileName,
  LPPROGRESS_ROUTINE lpProgressRoutine,
  LPVOID lpData,
  DWORD dwFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI MoveFileTransactedW(
  LPCWSTR lpExistingFileName,
  LPCWSTR lpNewFileName,
  LPPROGRESS_ROUTINE lpProgressRoutine,
  LPVOID lpData,
  DWORD dwFlags,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI OpenFileById(
  HANDLE hFile,
  LPFILE_ID_DESCRIPTOR lpFileID,
  DWORD dwDesiredAccess,
  DWORD dwShareMode,
  LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  DWORD dwFlags
);

DECLSPEC_IMPORT WINBOOL WINAPI QueryActCtxSettingsW(
  DWORD dwFlags,
  HANDLE hActCtx,
  PCWSTR settingsNameSpace,
  PCWSTR settingName,
  PWSTR pvBuffer,
  SIZE_T dwBuffer,
  SIZE_T *pdwWrittenOrRequired
);

DECLSPEC_IMPORT WINBOOL WINAPI QueryFullProcessImageNameA(
  HANDLE hProcess,
  DWORD dwFlags,
  LPSTR lpExeName,
  PDWORD lpdwSize
);

DECLSPEC_IMPORT WINBOOL WINAPI QueryFullProcessImageNameW(
  HANDLE hProcess,
  DWORD dwFlags,
  LPWSTR lpExeName,
  PDWORD lpdwSize
);
#define QueryFullProcessImageName __MINGW_NAME_AW(QueryFullProcessImageName)

DECLSPEC_IMPORT WINBOOL WINAPI QueryProcessAffinityUpdateMode(
  HANDLE ProcessHandle,
  DWORD lpdwFlags
);

DECLSPEC_IMPORT VOID WINAPI QuerySecurityAccessMask(
  SECURITY_INFORMATION SecurityInformation,
  LPDWORD DesiredAccess
);

DECLSPEC_IMPORT VOID WINAPI ReleaseMutexWhenCallbackReturns(
  PTP_CALLBACK_INSTANCE pci,
  HANDLE mut
);

#define RemoveDirectoryTransacted __MINGW_NAME_AW(RemoveDirectoryTransacted)

DECLSPEC_IMPORT WINBOOL WINAPI RemoveDirectoryTransactedA(
  LPCSTR lpPathName,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI RemoveDirectoryTransactedW(
  LPCWSTR lpPathName,
  HANDLE hTransaction
);

DECLSPEC_IMPORT HANDLE WINAPI ReOpenFile(
  HANDLE hOriginalFile,
  DWORD dwDesiredAccess,
  DWORD dwShareMode,
  DWORD dwFlags
);

DECLSPEC_IMPORT WINBOOL WINAPI SetDynamicTimeZoneInformation(
  const DYNAMIC_TIME_ZONE_INFORMATION *lpTimeZoneInformation
);

DECLSPEC_IMPORT VOID WINAPI SetEventWhenCallbackReturns(
  PTP_CALLBACK_INSTANCE pci,
  HANDLE evt
);

DECLSPEC_IMPORT WINBOOL WINAPI SetFileAttributesTransactedA(
  LPCSTR lpFileName,
  DWORD dwFileAttributes,
  HANDLE hTransaction
);

DECLSPEC_IMPORT WINBOOL WINAPI SetFileAttributesTransactedW(
  LPCWSTR lpFileName,
  DWORD dwFileAttributes,
  HANDLE hTransaction
);

#define SetFileAttributesTransacted __MINGW_NAME_AW(SetFileAttributesTransacted)

DECLSPEC_IMPORT WINBOOL WINAPI SetFileBandwidthReservation(
  HANDLE hFile,
  DWORD nPeriodMilliseconds,
  DWORD nBytesPerPeriod,
  WINBOOL bDiscardable,
  LPDWORD lpTransferSize,
  LPDWORD lpNumOutstandingRequests
);

DECLSPEC_IMPORT WINBOOL WINAPI SetFileCompletionNotificationModes(
  HANDLE FileHandle,
  UCHAR Flags
);

DECLSPEC_IMPORT WINBOOL WINAPI SetFileInformationByHandle(
  HANDLE hFile,
  FILE_INFO_BY_HANDLE_CLASS FileInformationClass,
  LPVOID lpFileInformation,
  DWORD dwBufferSize
);

DECLSPEC_IMPORT WINBOOL WINAPI SetFileIoOverlappedRange(
  HANDLE FileHandle,
  PUCHAR OverlappedRangeStart,
  ULONG Length
);

#define PROCESS_AFFINITY_ENABLE_AUTO_UPDATE __MSABI_LONG(0x00000001U)

DECLSPEC_IMPORT WINBOOL WINAPI SetProcessAffinityUpdateMode(
  HANDLE ProcessHandle,
  DWORD dwFlags
);

DECLSPEC_IMPORT WINBOOL WINAPI SetProcessWorkingSetSizeEx(
  HANDLE hProcess,
  SIZE_T dwMinimumWorkingSetSize,
  SIZE_T dwMaximumWorkingSetSize,
  DWORD Flags
);

DECLSPEC_IMPORT VOID WINAPI SetSecurityAccessMask(
  SECURITY_INFORMATION SecurityInformation,
  LPDWORD DesiredAccess
);

typedef struct _STARTUPINFOEXA {
  STARTUPINFOA StartupInfo;
  PPROC_THREAD_ATTRIBUTE_LIST lpAttributeList;
} STARTUPINFOEXA, *LPSTARTUPINFOEXA;

typedef struct _STARTUPINFOEXAW {
  STARTUPINFOW StartupInfo;
  PPROC_THREAD_ATTRIBUTE_LIST lpAttributeList;
} STARTUPINFOEXW, *LPSTARTUPINFOEXW;

typedef STARTUPINFOEXA STARTUPINFOEX;
typedef LPSTARTUPINFOEXA LPSTARTUPINFOEX;

DECLSPEC_IMPORT WINBOOL WINAPI TrySubmitThreadpoolCallback(
  PTP_SIMPLE_CALLBACK pfns,
  PVOID pv,
  PTP_CALLBACK_ENVIRON pcbe
);

DECLSPEC_IMPORT HRESULT WINAPI UnregisterApplicationRestart(void);

DECLSPEC_IMPORT HRESULT WINAPI UnregisterApplicationRecoveryCallback(void);

DECLSPEC_IMPORT LPVOID WINAPI VirtualAllocExNuma(
  HANDLE hProcess,
  LPVOID lpAddress,
  SIZE_T dwSize,
  DWORD flAllocationType,
  DWORD flProtect,
  DWORD nndPreferred
);

DECLSPEC_IMPORT VOID WINAPI WaitForThreadpoolIoCallbacks(
  PTP_IO pio,
  WINBOOL fCancelPendingCallbacks
);

DECLSPEC_IMPORT VOID WINAPI WaitForThreadpoolTimerCallbacks(
  PTP_TIMER pti,
  WINBOOL fCancelPendingCallbacks
);

DECLSPEC_IMPORT VOID WINAPI WaitForThreadpoolWaitCallbacks(
  PTP_WAIT pwa,
  WINBOOL fCancelPendingCallbacks
);

DECLSPEC_IMPORT VOID WINAPI WaitForThreadpoolWorkCallbacks(
  PTP_WORK pwk,
  WINBOOL fCancelPendingCallbacks
);

DECLSPEC_IMPORT WINBOOL WINAPI Wow64GetThreadContext(
  HANDLE hThread,
  PWOW64_CONTEXT lpContext
);

DECLSPEC_IMPORT WINBOOL WINAPI Wow64RevertWow64FsRedirection(
  PVOID OldValue
);

DECLSPEC_IMPORT WINBOOL WINAPI Wow64SetThreadContext(
  HANDLE hThread,
  const WOW64_CONTEXT *lpContext
);

DECLSPEC_IMPORT DWORD WINAPI Wow64SuspendThread(
  HANDLE hThread
);




DECLSPEC_IMPORT VOID WINAPI GetCurrentProcessorNumberEx(
  PPROCESSOR_NUMBER ProcNumber
);

DECLSPEC_IMPORT WINBOOL WINAPI GetLogicalProcessorInformationEx(
  LOGICAL_PROCESSOR_RELATIONSHIP RelationshipType,
  PSYSTEM_LOGICAL_PROCESSOR_INFORMATION_EX Buffer,
  PDWORD ReturnedLength
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNumaAvailableMemoryNodeEx(
  USHORT Node,
  PULONGLONG AvailableBytes
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNumaNodeNumberFromHandle(
  HANDLE hFile,
  PUSHORT NodeNumber
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNumaNodeProcessorMaskEx(
  USHORT Node,
  PGROUP_AFFINITY ProcessorMask
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNumaProcessorNodeEx(
  PPROCESSOR_NUMBER Processor,
  PUSHORT NodeNumber
);

DECLSPEC_IMPORT WINBOOL WINAPI GetNumaProximityNodeEx(
  ULONG ProximityId,
  PUSHORT NodeNumber
);

DECLSPEC_IMPORT WINBOOL WINAPI GetProcessGroupAffinity(
  HANDLE hProcess,
  PUSHORT GroupCount,
  PUSHORT GroupArray
);

DECLSPEC_IMPORT WINBOOL WINAPI GetProcessorSystemCycleTime(
  USHORT Group,
  PSYSTEM_PROCESSOR_CYCLE_TIME_INFORMATION Buffer,
  PDWORD ReturnedLength
);

DECLSPEC_IMPORT DWORD WINAPI GetThreadErrorMode(void);

DECLSPEC_IMPORT DWORD WINAPI GetThreadGroupAffinity(
  HANDLE hThread,
  PGROUP_AFFINITY GroupAffinity
);

DECLSPEC_IMPORT WINBOOL WINAPI GetThreadIdealProcessorEx(
  HANDLE hThread,
  PPROCESSOR_NUMBER lpIdealProcessor
);

DECLSPEC_IMPORT HANDLE WINAPI CreateRemoteThreadEx(
  HANDLE hProcess,
  LPSECURITY_ATTRIBUTES lpThreadAttributes,
  SIZE_T dwStackSize,
  LPTHREAD_START_ROUTINE lpStartAddress,
  LPVOID lpParameter,
  DWORD dwCreationFlags,
  LPPROC_THREAD_ATTRIBUTE_LIST lpAttributeList,
  LPDWORD lpThreadId
);

DECLSPEC_IMPORT WINBOOL WINAPI QueryUnbiasedInterruptTime(
  PULONGLONG UnbiasedTime
);

DECLSPEC_IMPORT WINBOOL WINAPI AddConditionalAce(
  PACL pAcl,
  DWORD dwAceRevision,
  DWORD AceFlags,
  UCHAR AceType,
  DWORD AccessMask,
  PSID pSid,
  PWCHAR ConditionStr,
  DWORD *ReturnLength
);

DECLSPEC_IMPORT DWORD WINAPI GetActiveProcessorCount(
  WORD GroupNumber
);

DECLSPEC_IMPORT WORD WINAPI GetActiveProcessorGroupCount(void);

DECLSPEC_IMPORT VOID WINAPI GetCurrentProcessorNumberEx(
  PPROCESSOR_NUMBER ProcNumber
);

DECLSPEC_IMPORT DWORD WINAPI GetMaximumProcessorCount(
  WORD GroupNumber
);

DECLSPEC_IMPORT WORD WINAPI GetMaximumProcessorGroupCount(void);


typedef struct _UMS_COMPLETION_LIST *PUMS_COMPLETION_LIST;
typedef struct _UMS_CONTEXT *PUMS_CONTEXT;

typedef enum _UMS_SCHEDULER_REASON {
  UmsSchedulerStartup = 0,
  UmsSchedulerThreadBlocked = 1,
  UmsSchedulerThreadYield = 2
} UMS_SCHEDULER_REASON;

typedef VOID (*PUMS_SCHEDULER_ENTRY_POINT)(
  UMS_SCHEDULER_REASON Reason,
  ULONG_PTR ActivationPayload,
  PVOID SchedulerParam
);

typedef enum _UMS_THREAD_INFO_CLASS {
  UmsThreadInvalidInfoClass = 0,
  UmsThreadUserContext = 1,
  UmsThreadPriority = 2,
  UmsThreadAffinity = 3,
  UmsThreadTeb = 4,
  UmsThreadIsSuspended = 5,
  UmsThreadIsTerminated = 6,
  UmsThreadMaxInfoClass = 7
} UMS_THREAD_INFO_CLASS, *PUMS_THREAD_INFO_CLASS;

typedef struct _UMS_SCHEDULER_STARTUP_INFO {
  ULONG UmsVersion;
  PUMS_COMPLETION_LIST CompletionList;
  PUMS_SCHEDULER_ENTRY_POINT SchedulerProc;
  PVOID SchedulerParam;
} UMS_SCHEDULER_STARTUP_INFO, *PUMS_SCHEDULER_STARTUP_INFO;

DECLSPEC_IMPORT WINBOOL CreateUmsCompletionList(
  PUMS_COMPLETION_LIST *UmsCompletionList
);

DECLSPEC_IMPORT WINBOOL CreateUmsThreadContext(
  PUMS_CONTEXT *lpUmsThread
);

DECLSPEC_IMPORT WINBOOL EnterUmsSchedulingMode(
  PUMS_SCHEDULER_STARTUP_INFO SchedulerStartupInfo
);

DECLSPEC_IMPORT WINBOOL DequeueUmsCompletionListItems(
  PUMS_COMPLETION_LIST UmsCompletionList,
  DWORD WaitTimeOut,
  PUMS_CONTEXT *UmsThreadList
);

DECLSPEC_IMPORT WINBOOL GetUmsCompletionListEvent(
  PUMS_COMPLETION_LIST UmsCompletionList,
  PHANDLE UmsCompletionEvent
);

DECLSPEC_IMPORT WINBOOL DeleteUmsCompletionList(
  PUMS_COMPLETION_LIST UmsCompletionList
);

DECLSPEC_IMPORT WINBOOL DeleteUmsThreadContext(
  PUMS_CONTEXT UmsThread
);

DECLSPEC_IMPORT WINBOOL QueryUmsThreadInformation(
  PUMS_CONTEXT UmsThread,
  UMS_THREAD_INFO_CLASS UmsThreadInfoClass,
  PVOID UmsThreadInformation,
  ULONG UmsThreadInformationLength,
  PULONG ReturnLength
);

DECLSPEC_IMPORT WINBOOL SetUmsThreadInformation(
  PUMS_CONTEXT UmsThread,
  UMS_THREAD_INFO_CLASS UmsThreadInfoClass,
  PVOID UmsThreadInformation,
  ULONG UmsThreadInformationLength
);

DECLSPEC_IMPORT WINBOOL ExecuteUmsThread(
  PUMS_CONTEXT UmsThread
);

DECLSPEC_IMPORT WINBOOL UmsThreadYield(
  PVOID SchedulerParam
);

DECLSPEC_IMPORT PUMS_CONTEXT GetNextUmsListItem(
  PUMS_CONTEXT UmsContext
);

DECLSPEC_IMPORT PUMS_CONTEXT GetCurrentUmsThread(void);






typedef struct _CREATEFILE2_EXTENDED_PARAMETERS {
  DWORD dwSize;
  DWORD dwFileAttributes;
  DWORD dwFileFlags;
  DWORD dwSecurityQosFlags;
  LPSECURITY_ATTRIBUTES lpSecurityAttributes;
  HANDLE hTemplateFile;
} CREATEFILE2_EXTENDED_PARAMETERS, *PCREATEFILE2_EXTENDED_PARAMETERS, *LPCREATEFILE2_EXTENDED_PARAMETERS;

DECLSPEC_IMPORT HANDLE WINAPI CreateFile2(LPCWSTR lpFileName, DWORD dwDesiredAccess, DWORD dwShareMode, DWORD dwCreationDisposition, LPCREATEFILE2_EXTENDED_PARAMETERS pCreateExParams);

HMODULE WINAPI LoadPackagedLibrary(LPCWSTR lpwLibFileName, DWORD Reserved);

DECLSPEC_IMPORT VOID WINAPI GetSystemTimePreciseAsFileTime(LPFILETIME lpSystemTimeAsFileTime);
# 4041 "c_include/windows/original/winbase.h"
#define MICROSOFT_WINDOWS_WINBASE_INTERLOCKED_CPLUSPLUS_H_INCLUDED 
