# 1 "c_include/windows/original/wincon.h"
#define __STDC__ 1
# 1 "c_include/windows/original/wincon.h"
#define __STDC_HOSTED__ 1
# 1 "c_include/windows/original/wincon.h"
#define __GNUC__ 4
# 1 "c_include/windows/original/wincon.h"
#define __GNUC_MINOR__ 8
# 1 "c_include/windows/original/wincon.h"
#define __GNUC_PATCHLEVEL__ 1
# 1 "c_include/windows/original/wincon.h"
#define __VERSION__ "4.8.1 20130328 (prerelease)"
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_RELAXED 0
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_SEQ_CST 5
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_ACQUIRE 2
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_RELEASE 3
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_ACQ_REL 4
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_CONSUME 1
# 1 "c_include/windows/original/wincon.h"
#define __pic__ 1
# 1 "c_include/windows/original/wincon.h"
#define __PIC__ 1
# 1 "c_include/windows/original/wincon.h"
#define __FINITE_MATH_ONLY__ 0
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_INT__ 4
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_LONG__ 4
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_LONG_LONG__ 8
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_SHORT__ 2
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_FLOAT__ 4
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_DOUBLE__ 8
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_LONG_DOUBLE__ 16
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_SIZE_T__ 8
# 1 "c_include/windows/original/wincon.h"
#define __CHAR_BIT__ 8
# 1 "c_include/windows/original/wincon.h"
#define __BIGGEST_ALIGNMENT__ 16
# 1 "c_include/windows/original/wincon.h"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 1 "c_include/windows/original/wincon.h"
#define __ORDER_BIG_ENDIAN__ 4321
# 1 "c_include/windows/original/wincon.h"
#define __ORDER_PDP_ENDIAN__ 3412
# 1 "c_include/windows/original/wincon.h"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/wincon.h"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_POINTER__ 8
# 1 "c_include/windows/original/wincon.h"
#define __SIZE_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __PTRDIFF_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __WCHAR_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __WINT_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INTMAX_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINTMAX_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __CHAR16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __CHAR32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __SIG_ATOMIC_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT8_TYPE__ signed char
# 1 "c_include/windows/original/wincon.h"
#define __INT16_TYPE__ short int
# 1 "c_include/windows/original/wincon.h"
#define __INT32_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT64_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINT8_TYPE__ unsigned char
# 1 "c_include/windows/original/wincon.h"
#define __UINT16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST8_TYPE__ signed char
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST16_TYPE__ short int
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST32_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST64_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST8_TYPE__ signed char
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST16_TYPE__ short int
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST32_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST64_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INTPTR_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINTPTR_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __GXX_ABI_VERSION 1002
# 1 "c_include/windows/original/wincon.h"
#define __SCHAR_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __SHRT_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __LONG_MAX__ 2147483647L
# 1 "c_include/windows/original/wincon.h"
#define __LONG_LONG_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __WCHAR_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __WCHAR_MIN__ 0
# 1 "c_include/windows/original/wincon.h"
#define __WINT_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __WINT_MIN__ 0
# 1 "c_include/windows/original/wincon.h"
#define __PTRDIFF_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __SIZE_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __INTMAX_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __INTMAX_C(c) c ## LL
# 1 "c_include/windows/original/wincon.h"
#define __UINTMAX_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __UINTMAX_C(c) c ## ULL
# 1 "c_include/windows/original/wincon.h"
#define __SIG_ATOMIC_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 1 "c_include/windows/original/wincon.h"
#define __INT8_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __INT16_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT32_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __INT64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __UINT8_MAX__ 255
# 1 "c_include/windows/original/wincon.h"
#define __UINT16_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __UINT32_MAX__ 4294967295U
# 1 "c_include/windows/original/wincon.h"
#define __UINT64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST8_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __INT8_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST16_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT16_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST32_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __INT32_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __INT64_C(c) c ## LL
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST8_MAX__ 255
# 1 "c_include/windows/original/wincon.h"
#define __UINT8_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST16_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __UINT16_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/wincon.h"
#define __UINT32_C(c) c ## U
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __UINT64_C(c) c ## ULL
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST8_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST16_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST32_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST8_MAX__ 255
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST16_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __INTPTR_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __UINTPTR_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __FLT_EVAL_METHOD__ 0
# 1 "c_include/windows/original/wincon.h"
#define __DEC_EVAL_METHOD__ 2
# 1 "c_include/windows/original/wincon.h"
#define __FLT_RADIX__ 2
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MANT_DIG__ 24
# 1 "c_include/windows/original/wincon.h"
#define __FLT_DIG__ 6
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MIN_EXP__ (-125)
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MIN_10_EXP__ (-37)
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MAX_EXP__ 128
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MAX_10_EXP__ 38
# 1 "c_include/windows/original/wincon.h"
#define __FLT_DECIMAL_DIG__ 9
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MAX__ 3.40282346638528859812e+38F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MIN__ 1.17549435082228750797e-38F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_EPSILON__ 1.19209289550781250000e-7F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_DENORM_MIN__ 1.40129846432481707092e-45F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_HAS_DENORM__ 1
# 1 "c_include/windows/original/wincon.h"
#define __FLT_HAS_INFINITY__ 1
# 1 "c_include/windows/original/wincon.h"
#define __FLT_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MANT_DIG__ 53
# 1 "c_include/windows/original/wincon.h"
#define __DBL_DIG__ 15
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MIN_EXP__ (-1021)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MIN_10_EXP__ (-307)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MAX_EXP__ 1024
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MAX_10_EXP__ 308
# 1 "c_include/windows/original/wincon.h"
#define __DBL_DECIMAL_DIG__ 17
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MAX__ ((double)1.79769313486231570815e+308L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MIN__ ((double)2.22507385850720138309e-308L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_EPSILON__ ((double)2.22044604925031308085e-16L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_DENORM_MIN__ ((double)4.94065645841246544177e-324L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MANT_DIG__ 64
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_DIG__ 18
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MIN_EXP__ (-16381)
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MIN_10_EXP__ (-4931)
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MAX_EXP__ 16384
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MAX_10_EXP__ 4932
# 1 "c_include/windows/original/wincon.h"
#define __DECIMAL_DIG__ 21
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MANT_DIG__ 7
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MIN_EXP__ (-94)
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MAX_EXP__ 97
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MIN__ 1E-95DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MAX__ 9.999999E96DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_EPSILON__ 1E-6DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_SUBNORMAL_MIN__ 0.000001E-95DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MANT_DIG__ 16
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MIN_EXP__ (-382)
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MAX_EXP__ 385
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MIN__ 1E-383DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MAX__ 9.999999999999999E384DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_EPSILON__ 1E-15DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_SUBNORMAL_MIN__ 0.000000000000001E-383DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MANT_DIG__ 34
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MIN_EXP__ (-6142)
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MAX_EXP__ 6145
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MIN__ 1E-6143DL
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_EPSILON__ 1E-33DL
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_SUBNORMAL_MIN__ 0.000000000000000000000000000000001E-6143DL
# 1 "c_include/windows/original/wincon.h"
#define __REGISTER_PREFIX__ 
# 1 "c_include/windows/original/wincon.h"
#define __USER_LABEL_PREFIX__ 
# 1 "c_include/windows/original/wincon.h"
#define __GNUC_GNU_INLINE__ 1
# 1 "c_include/windows/original/wincon.h"
#define __NO_INLINE__ 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_INT128__ 16
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_WCHAR_T__ 2
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_WINT_T__ 2
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_PTRDIFF_T__ 8
# 1 "c_include/windows/original/wincon.h"
#define __amd64 1
# 1 "c_include/windows/original/wincon.h"
#define __amd64__ 1
# 1 "c_include/windows/original/wincon.h"
#define __x86_64 1
# 1 "c_include/windows/original/wincon.h"
#define __x86_64__ 1
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_HLE_ACQUIRE 65536
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_HLE_RELEASE 131072
# 1 "c_include/windows/original/wincon.h"
#define __k8 1
# 1 "c_include/windows/original/wincon.h"
#define __k8__ 1
# 1 "c_include/windows/original/wincon.h"
#define __code_model_small__ 1
# 1 "c_include/windows/original/wincon.h"
#define __MMX__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE2__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE_MATH__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE2_MATH__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SEH__ 1
# 1 "c_include/windows/original/wincon.h"
#define __stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/wincon.h"
#define __fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/wincon.h"
#define __thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/wincon.h"
#define __cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/wincon.h"
#define _stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/wincon.h"
#define _fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/wincon.h"
#define _thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/wincon.h"
#define _cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/wincon.h"
#define __GXX_MERGED_TYPEINFO_NAMES 0
# 1 "c_include/windows/original/wincon.h"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 1 "c_include/windows/original/wincon.h"
#define __MSVCRT__ 1
# 1 "c_include/windows/original/wincon.h"
#define __MINGW32__ 1
# 1 "c_include/windows/original/wincon.h"
#define _WIN32 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN32 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN32__ 1
# 1 "c_include/windows/original/wincon.h"
#define WIN32 1
# 1 "c_include/windows/original/wincon.h"
#define __WINNT 1
# 1 "c_include/windows/original/wincon.h"
#define __WINNT__ 1
# 1 "c_include/windows/original/wincon.h"
#define WINNT 1
# 1 "c_include/windows/original/wincon.h"
#define _INTEGRAL_MAX_BITS 64
# 1 "c_include/windows/original/wincon.h"
#define __MINGW64__ 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN64 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN64__ 1
# 1 "c_include/windows/original/wincon.h"
#define WIN64 1
# 1 "c_include/windows/original/wincon.h"
#define _WIN64 1
# 1 "c_include/windows/original/wincon.h"
#define __declspec(x) __attribute__((x))
# 1 "c_include/windows/original/wincon.h"
#define __DECIMAL_BID_FORMAT__ 1
# 1 "<command-line>"
#undef _REENTRANT
# 1 "c_include/windows/original/wincon.h"
#define _WIN32_WINNT 0x0602
#define WINVER _WIN32_WINNT

/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */

#define _WINCON_ 

# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_unicode.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */


/* _INC_CRT_UNICODE_MACROS defined based on UNICODE flag */
# 19 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_unicode.h" 3
#define _INC_CRT_UNICODE_MACROS 2
#define __MINGW_NAME_AW(func) func ##A
#define __MINGW_NAME_AW_EXT(func,ext) func ##A ##ext
#define __MINGW_NAME_UAW(func) func ##_A
#define __MINGW_NAME_UAW_EXT(func,ext) func ##_A_ ##ext
#define __MINGW_STRING_AW(str) str
#define __MINGW_PROCNAMEEXT_AW "A"


#define __MINGW_TYPEDEF_AW(type) typedef __MINGW_NAME_AW(type) type;

#define __MINGW_TYPEDEF_UAW(type) typedef __MINGW_NAME_UAW(type) type;
# 13 "c_include/windows/original/wincon.h" 2





  typedef struct _COORD {
    SHORT X;
    SHORT Y;
  } COORD,*PCOORD;

  typedef struct _SMALL_RECT {
    SHORT Left;
    SHORT Top;
    SHORT Right;
    SHORT Bottom;
  } SMALL_RECT,*PSMALL_RECT;

  typedef struct _KEY_EVENT_RECORD {
    WINBOOL bKeyDown;
    WORD wRepeatCount;
    WORD wVirtualKeyCode;
    WORD wVirtualScanCode;
    union {
      WCHAR UnicodeChar;
      CHAR AsciiChar;
    } uChar;
    DWORD dwControlKeyState;
  } KEY_EVENT_RECORD,*PKEY_EVENT_RECORD;

#define RIGHT_ALT_PRESSED 0x1
#define LEFT_ALT_PRESSED 0x2
#define RIGHT_CTRL_PRESSED 0x4
#define LEFT_CTRL_PRESSED 0x8
#define SHIFT_PRESSED 0x10
#define NUMLOCK_ON 0x20
#define SCROLLLOCK_ON 0x40
#define CAPSLOCK_ON 0x80
#define ENHANCED_KEY 0x100
#define NLS_DBCSCHAR 0x10000
#define NLS_ALPHANUMERIC 0x0
#define NLS_KATAKANA 0x20000
#define NLS_HIRAGANA 0x40000
#define NLS_ROMAN 0x400000
#define NLS_IME_CONVERSION 0x800000
#define NLS_IME_DISABLE 0x20000000

  typedef struct _MOUSE_EVENT_RECORD {
    COORD dwMousePosition;
    DWORD dwButtonState;
    DWORD dwControlKeyState;
    DWORD dwEventFlags;
  } MOUSE_EVENT_RECORD,*PMOUSE_EVENT_RECORD;

#define FROM_LEFT_1ST_BUTTON_PRESSED 0x1
#define RIGHTMOST_BUTTON_PRESSED 0x2
#define FROM_LEFT_2ND_BUTTON_PRESSED 0x4
#define FROM_LEFT_3RD_BUTTON_PRESSED 0x8
#define FROM_LEFT_4TH_BUTTON_PRESSED 0x10

#define MOUSE_MOVED 0x1
#define DOUBLE_CLICK 0x2
#define MOUSE_WHEELED 0x4

#define MOUSE_HWHEELED 0x8


  typedef struct _WINDOW_BUFFER_SIZE_RECORD {
    COORD dwSize;
  } WINDOW_BUFFER_SIZE_RECORD,*PWINDOW_BUFFER_SIZE_RECORD;

  typedef struct _MENU_EVENT_RECORD {
    UINT dwCommandId;
  } MENU_EVENT_RECORD,*PMENU_EVENT_RECORD;

  typedef struct _FOCUS_EVENT_RECORD {
    WINBOOL bSetFocus;
  } FOCUS_EVENT_RECORD,*PFOCUS_EVENT_RECORD;

  typedef struct _INPUT_RECORD {
    WORD EventType;
    union {
      KEY_EVENT_RECORD KeyEvent;
      MOUSE_EVENT_RECORD MouseEvent;
      WINDOW_BUFFER_SIZE_RECORD WindowBufferSizeEvent;
      MENU_EVENT_RECORD MenuEvent;
      FOCUS_EVENT_RECORD FocusEvent;
    } Event;
  } INPUT_RECORD,*PINPUT_RECORD;

#define KEY_EVENT 0x1
#define MOUSE_EVENT 0x2
#define WINDOW_BUFFER_SIZE_EVENT 0x4
#define MENU_EVENT 0x8
#define FOCUS_EVENT 0x10

  typedef struct _CHAR_INFO {
    union {
      WCHAR UnicodeChar;
      CHAR AsciiChar;
    } Char;
    WORD Attributes;
  } CHAR_INFO,*PCHAR_INFO;

#define FOREGROUND_BLUE 0x1
#define FOREGROUND_GREEN 0x2
#define FOREGROUND_RED 0x4
#define FOREGROUND_INTENSITY 0x8
#define BACKGROUND_BLUE 0x10
#define BACKGROUND_GREEN 0x20
#define BACKGROUND_RED 0x40
#define BACKGROUND_INTENSITY 0x80
#define COMMON_LVB_LEADING_BYTE 0x100
#define COMMON_LVB_TRAILING_BYTE 0x200
#define COMMON_LVB_GRID_HORIZONTAL 0x400
#define COMMON_LVB_GRID_LVERTICAL 0x800
#define COMMON_LVB_GRID_RVERTICAL 0x1000
#define COMMON_LVB_REVERSE_VIDEO 0x4000
#define COMMON_LVB_UNDERSCORE 0x8000

#define COMMON_LVB_SBCSDBCS 0x300

  typedef struct _CONSOLE_SCREEN_BUFFER_INFO {
    COORD dwSize;
    COORD dwCursorPosition;
    WORD wAttributes;
    SMALL_RECT srWindow;
    COORD dwMaximumWindowSize;
  } CONSOLE_SCREEN_BUFFER_INFO,*PCONSOLE_SCREEN_BUFFER_INFO;

  typedef struct _CONSOLE_CURSOR_INFO {
    DWORD dwSize;
    WINBOOL bVisible;
  } CONSOLE_CURSOR_INFO,*PCONSOLE_CURSOR_INFO;

  typedef struct _CONSOLE_FONT_INFO {
    DWORD nFont;
    COORD dwFontSize;
  } CONSOLE_FONT_INFO,*PCONSOLE_FONT_INFO;

  typedef struct _CONSOLE_SELECTION_INFO {
    DWORD dwFlags;
    COORD dwSelectionAnchor;
    SMALL_RECT srSelection;
  } CONSOLE_SELECTION_INFO,*PCONSOLE_SELECTION_INFO;

#define CONSOLE_NO_SELECTION 0x0
#define CONSOLE_SELECTION_IN_PROGRESS 0x1
#define CONSOLE_SELECTION_NOT_EMPTY 0x2
#define CONSOLE_MOUSE_SELECTION 0x4
#define CONSOLE_MOUSE_DOWN 0x8

  typedef WINBOOL (WINAPI *PHANDLER_ROUTINE)(DWORD CtrlType);

#define CTRL_C_EVENT 0
#define CTRL_BREAK_EVENT 1
#define CTRL_CLOSE_EVENT 2

#define CTRL_LOGOFF_EVENT 5
#define CTRL_SHUTDOWN_EVENT 6

#define ENABLE_PROCESSED_INPUT 0x1
#define ENABLE_LINE_INPUT 0x2
#define ENABLE_ECHO_INPUT 0x4
#define ENABLE_WINDOW_INPUT 0x8
#define ENABLE_MOUSE_INPUT 0x10
#define ENABLE_INSERT_MODE 0x20
#define ENABLE_QUICK_EDIT_MODE 0x40
#define ENABLE_EXTENDED_FLAGS 0x80
#define ENABLE_AUTO_POSITION 0x100

#define ENABLE_PROCESSED_OUTPUT 0x1
#define ENABLE_WRAP_AT_EOL_OUTPUT 0x2

#define PeekConsoleInput __MINGW_NAME_AW(PeekConsoleInput)
#define ReadConsoleInput __MINGW_NAME_AW(ReadConsoleInput)
#define WriteConsoleInput __MINGW_NAME_AW(WriteConsoleInput)
#define ReadConsoleOutput __MINGW_NAME_AW(ReadConsoleOutput)
#define WriteConsoleOutput __MINGW_NAME_AW(WriteConsoleOutput)
#define ReadConsoleOutputCharacter __MINGW_NAME_AW(ReadConsoleOutputCharacter)
#define WriteConsoleOutputCharacter __MINGW_NAME_AW(WriteConsoleOutputCharacter)
#define FillConsoleOutputCharacter __MINGW_NAME_AW(FillConsoleOutputCharacter)
#define ScrollConsoleScreenBuffer __MINGW_NAME_AW(ScrollConsoleScreenBuffer)
#define GetConsoleTitle __MINGW_NAME_AW(GetConsoleTitle)
#define SetConsoleTitle __MINGW_NAME_AW(SetConsoleTitle)
#define ReadConsole __MINGW_NAME_AW(ReadConsole)
#define WriteConsole __MINGW_NAME_AW(WriteConsole)
#define AddConsoleAlias __MINGW_NAME_AW(AddConsoleAlias)
#define GetConsoleAlias __MINGW_NAME_AW(GetConsoleAlias)
#define GetConsoleAliasesLength __MINGW_NAME_AW(GetConsoleAliasesLength)
#define GetConsoleAliasExesLength __MINGW_NAME_AW(GetConsoleAliasExesLength)
#define GetConsoleAliases __MINGW_NAME_AW(GetConsoleAliases)
#define GetConsoleAliasExes __MINGW_NAME_AW(GetConsoleAliasExes)

  WINBASEAPI WINBOOL WINAPI PeekConsoleInputA(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  WINBASEAPI WINBOOL WINAPI PeekConsoleInputW(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  WINBASEAPI WINBOOL WINAPI ReadConsoleInputA(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  WINBASEAPI WINBOOL WINAPI ReadConsoleInputW(HANDLE hConsoleInput,PINPUT_RECORD lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsRead);
  WINBASEAPI WINBOOL WINAPI WriteConsoleInputA(HANDLE hConsoleInput,CONST INPUT_RECORD *lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsWritten);
  WINBASEAPI WINBOOL WINAPI WriteConsoleInputW(HANDLE hConsoleInput,CONST INPUT_RECORD *lpBuffer,DWORD nLength,LPDWORD lpNumberOfEventsWritten);
  WINBASEAPI WINBOOL WINAPI ReadConsoleOutputA(HANDLE hConsoleOutput,PCHAR_INFO lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpReadRegion);
  WINBASEAPI WINBOOL WINAPI ReadConsoleOutputW(HANDLE hConsoleOutput,PCHAR_INFO lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpReadRegion);
  WINBASEAPI WINBOOL WINAPI WriteConsoleOutputA(HANDLE hConsoleOutput,CONST CHAR_INFO *lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpWriteRegion);
  WINBASEAPI WINBOOL WINAPI WriteConsoleOutputW(HANDLE hConsoleOutput,CONST CHAR_INFO *lpBuffer,COORD dwBufferSize,COORD dwBufferCoord,PSMALL_RECT lpWriteRegion);
  WINBASEAPI WINBOOL WINAPI ReadConsoleOutputCharacterA(HANDLE hConsoleOutput,LPSTR lpCharacter,DWORD nLength,COORD dwReadCoord,LPDWORD lpNumberOfCharsRead);
  WINBASEAPI WINBOOL WINAPI ReadConsoleOutputCharacterW(HANDLE hConsoleOutput,LPWSTR lpCharacter,DWORD nLength,COORD dwReadCoord,LPDWORD lpNumberOfCharsRead);
  WINBASEAPI WINBOOL WINAPI ReadConsoleOutputAttribute(HANDLE hConsoleOutput,LPWORD lpAttribute,DWORD nLength,COORD dwReadCoord,LPDWORD lpNumberOfAttrsRead);
  WINBASEAPI WINBOOL WINAPI WriteConsoleOutputCharacterA(HANDLE hConsoleOutput,LPCSTR lpCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  WINBASEAPI WINBOOL WINAPI WriteConsoleOutputCharacterW(HANDLE hConsoleOutput,LPCWSTR lpCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  WINBASEAPI WINBOOL WINAPI WriteConsoleOutputAttribute(HANDLE hConsoleOutput,CONST WORD *lpAttribute,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfAttrsWritten);
  WINBASEAPI WINBOOL WINAPI FillConsoleOutputCharacterA(HANDLE hConsoleOutput,CHAR cCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  WINBASEAPI WINBOOL WINAPI FillConsoleOutputCharacterW(HANDLE hConsoleOutput,WCHAR cCharacter,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfCharsWritten);
  WINBASEAPI WINBOOL WINAPI FillConsoleOutputAttribute(HANDLE hConsoleOutput,WORD wAttribute,DWORD nLength,COORD dwWriteCoord,LPDWORD lpNumberOfAttrsWritten);
  WINBASEAPI WINBOOL WINAPI GetConsoleMode(HANDLE hConsoleHandle,LPDWORD lpMode);
  WINBASEAPI WINBOOL WINAPI GetNumberOfConsoleInputEvents(HANDLE hConsoleInput,LPDWORD lpNumberOfEvents);
  WINBASEAPI WINBOOL WINAPI GetConsoleScreenBufferInfo(HANDLE hConsoleOutput,PCONSOLE_SCREEN_BUFFER_INFO lpConsoleScreenBufferInfo);
  WINBASEAPI COORD WINAPI GetLargestConsoleWindowSize(HANDLE hConsoleOutput);
  WINBASEAPI WINBOOL WINAPI GetConsoleCursorInfo(HANDLE hConsoleOutput,PCONSOLE_CURSOR_INFO lpConsoleCursorInfo);
  WINBASEAPI WINBOOL WINAPI GetCurrentConsoleFont(HANDLE hConsoleOutput,WINBOOL bMaximumWindow,PCONSOLE_FONT_INFO lpConsoleCurrentFont);
  WINBASEAPI COORD WINAPI GetConsoleFontSize(HANDLE hConsoleOutput,DWORD nFont);
  WINBASEAPI WINBOOL WINAPI GetConsoleSelectionInfo(PCONSOLE_SELECTION_INFO lpConsoleSelectionInfo);
  WINBASEAPI WINBOOL WINAPI GetNumberOfConsoleMouseButtons(LPDWORD lpNumberOfMouseButtons);
  WINBASEAPI WINBOOL WINAPI SetConsoleMode(HANDLE hConsoleHandle,DWORD dwMode);
  WINBASEAPI WINBOOL WINAPI SetConsoleActiveScreenBuffer(HANDLE hConsoleOutput);
  WINBASEAPI WINBOOL WINAPI FlushConsoleInputBuffer(HANDLE hConsoleInput);
  WINBASEAPI WINBOOL WINAPI SetConsoleScreenBufferSize(HANDLE hConsoleOutput,COORD dwSize);
  WINBASEAPI WINBOOL WINAPI SetConsoleCursorPosition(HANDLE hConsoleOutput,COORD dwCursorPosition);
  WINBASEAPI WINBOOL WINAPI SetConsoleCursorInfo(HANDLE hConsoleOutput,CONST CONSOLE_CURSOR_INFO *lpConsoleCursorInfo);
  WINBASEAPI WINBOOL WINAPI ScrollConsoleScreenBufferA(HANDLE hConsoleOutput,CONST SMALL_RECT *lpScrollRectangle,CONST SMALL_RECT *lpClipRectangle,COORD dwDestinationOrigin,CONST CHAR_INFO *lpFill);
  WINBASEAPI WINBOOL WINAPI ScrollConsoleScreenBufferW(HANDLE hConsoleOutput,CONST SMALL_RECT *lpScrollRectangle,CONST SMALL_RECT *lpClipRectangle,COORD dwDestinationOrigin,CONST CHAR_INFO *lpFill);
  WINBASEAPI WINBOOL WINAPI SetConsoleWindowInfo(HANDLE hConsoleOutput,WINBOOL bAbsolute,CONST SMALL_RECT *lpConsoleWindow);
  WINBASEAPI WINBOOL WINAPI SetConsoleTextAttribute(HANDLE hConsoleOutput,WORD wAttributes);
  WINBASEAPI WINBOOL WINAPI SetConsoleCtrlHandler(PHANDLER_ROUTINE HandlerRoutine,WINBOOL Add);
  WINBASEAPI WINBOOL WINAPI GenerateConsoleCtrlEvent(DWORD dwCtrlEvent,DWORD dwProcessGroupId);
  WINBASEAPI WINBOOL WINAPI AllocConsole(VOID);
  WINBASEAPI WINBOOL WINAPI FreeConsole(VOID);
  WINBASEAPI WINBOOL WINAPI AttachConsole(DWORD dwProcessId);

#define ATTACH_PARENT_PROCESS ((DWORD)-1)

  WINBASEAPI DWORD WINAPI GetConsoleTitleA(LPSTR lpConsoleTitle,DWORD nSize);
  WINBASEAPI DWORD WINAPI GetConsoleTitleW(LPWSTR lpConsoleTitle,DWORD nSize);
  WINBASEAPI WINBOOL WINAPI SetConsoleTitleA(LPCSTR lpConsoleTitle);
  WINBASEAPI WINBOOL WINAPI SetConsoleTitleW(LPCWSTR lpConsoleTitle);
  WINBASEAPI WINBOOL WINAPI ReadConsoleA(HANDLE hConsoleInput,LPVOID lpBuffer,DWORD nNumberOfCharsToRead,LPDWORD lpNumberOfCharsRead,LPVOID lpReserved);
  WINBASEAPI WINBOOL WINAPI ReadConsoleW(HANDLE hConsoleInput,LPVOID lpBuffer,DWORD nNumberOfCharsToRead,LPDWORD lpNumberOfCharsRead,LPVOID lpReserved);
  WINBASEAPI WINBOOL WINAPI WriteConsoleA(HANDLE hConsoleOutput,CONST VOID *lpBuffer,DWORD nNumberOfCharsToWrite,LPDWORD lpNumberOfCharsWritten,LPVOID lpReserved);
  WINBASEAPI WINBOOL WINAPI WriteConsoleW(HANDLE hConsoleOutput,CONST VOID *lpBuffer,DWORD nNumberOfCharsToWrite,LPDWORD lpNumberOfCharsWritten,LPVOID lpReserved);

#define CONSOLE_TEXTMODE_BUFFER 1

  WINBASEAPI HANDLE WINAPI CreateConsoleScreenBuffer(DWORD dwDesiredAccess,DWORD dwShareMode,CONST SECURITY_ATTRIBUTES *lpSecurityAttributes,DWORD dwFlags,LPVOID lpScreenBufferData);
  WINBASEAPI UINT WINAPI GetConsoleCP(VOID);
  WINBASEAPI WINBOOL WINAPI SetConsoleCP(UINT wCodePageID);
  WINBASEAPI UINT WINAPI GetConsoleOutputCP(VOID);
  WINBASEAPI WINBOOL WINAPI SetConsoleOutputCP(UINT wCodePageID);

#define CONSOLE_FULLSCREEN 1
#define CONSOLE_FULLSCREEN_HARDWARE 2
  WINBASEAPI WINBOOL WINAPI GetConsoleDisplayMode(LPDWORD lpModeFlags);

#define CONSOLE_FULLSCREEN_MODE 1
#define CONSOLE_WINDOWED_MODE 2
  WINBASEAPI WINBOOL WINAPI SetConsoleDisplayMode(HANDLE hConsoleOutput, DWORD dwFlags, PCOORD lpNewScreenBufferDimensions);

  WINBASEAPI HWND WINAPI GetConsoleWindow(VOID);
  WINBASEAPI DWORD WINAPI GetConsoleProcessList(LPDWORD lpdwProcessList,DWORD dwProcessCount);
  WINBASEAPI WINBOOL WINAPI AddConsoleAliasA(LPSTR Source,LPSTR Target,LPSTR ExeName);
  WINBASEAPI WINBOOL WINAPI AddConsoleAliasW(LPWSTR Source,LPWSTR Target,LPWSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasA(LPSTR Source,LPSTR TargetBuffer,DWORD TargetBufferLength,LPSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasW(LPWSTR Source,LPWSTR TargetBuffer,DWORD TargetBufferLength,LPWSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasesLengthA(LPSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasesLengthW(LPWSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasExesLengthA(VOID);
  WINBASEAPI DWORD WINAPI GetConsoleAliasExesLengthW(VOID);
  WINBASEAPI DWORD WINAPI GetConsoleAliasesA(LPSTR AliasBuffer,DWORD AliasBufferLength,LPSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasesW(LPWSTR AliasBuffer,DWORD AliasBufferLength,LPWSTR ExeName);
  WINBASEAPI DWORD WINAPI GetConsoleAliasExesA(LPSTR ExeNameBuffer,DWORD ExeNameBufferLength);
  WINBASEAPI DWORD WINAPI GetConsoleAliasExesW(LPWSTR ExeNameBuffer,DWORD ExeNameBufferLength);


#define LF_FACESIZE 32


typedef struct _CONSOLE_FONT_INFOEX {
  ULONG cbSize;
  DWORD nFont;
  COORD dwFontSize;
  UINT FontFamily;
  UINT FontWeight;
  WCHAR FaceName[32];
} CONSOLE_FONT_INFOEX, *PCONSOLE_FONT_INFOEX;

typedef struct _CONSOLE_HISTORY_INFO {
  UINT cbSize;
  UINT HistoryBufferSize;
  UINT NumberOfHistoryBuffers;
  DWORD dwFlags;
} CONSOLE_HISTORY_INFO, *PCONSOLE_HISTORY_INFO;

typedef struct _CONSOLE_READCONSOLE_CONTROL {
  ULONG nLength;
  ULONG nInitialChars;
  ULONG dwCtrlWakeupMask;
  ULONG dwControlKeyState;
} CONSOLE_READCONSOLE_CONTROL, *PCONSOLE_READCONSOLE_CONTROL;

typedef struct _CONSOLE_SCREEN_BUFFER_INFOEX {
  ULONG cbSize;
  COORD dwSize;
  COORD dwCursorPosition;
  WORD wAttributes;
  SMALL_RECT srWindow;
  COORD dwMaximumWindowSize;
  WORD wPopupAttributes;
  BOOL bFullscreenSupported;
  COLORREF ColorTable[16];
} CONSOLE_SCREEN_BUFFER_INFOEX, *PCONSOLE_SCREEN_BUFFER_INFOEX;

WINBOOL WINAPI GetConsoleHistoryInfo(
  PCONSOLE_HISTORY_INFO lpConsoleHistoryInfo
);


#define GetConsoleOriginalTitle __MINGW_NAME_AW(GetConsoleOriginalTitle)

WINBASEAPI DWORD WINAPI GetConsoleOriginalTitleA(
  LPSTR lpConsoleTitle,
  DWORD nSize
);

WINBASEAPI DWORD WINAPI GetConsoleOriginalTitleW(
  LPWSTR lpConsoleTitle,
  DWORD nSize
);


WINBASEAPI WINBOOL WINAPI GetConsoleScreenBufferInfoEx(
  HANDLE hConsoleOutput,
  PCONSOLE_SCREEN_BUFFER_INFOEX lpConsoleScreenBufferInfoEx
);

WINBASEAPI WINBOOL WINAPI GetCurrentConsoleFontEx(
  HANDLE hConsoleOutput,
  WINBOOL bMaximumWindow,
  PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx
);

WINBASEAPI WINBOOL WINAPI SetConsoleHistoryInfo(
  PCONSOLE_HISTORY_INFO lpConsoleHistoryInfo
);

WINBASEAPI WINBOOL WINAPI SetConsoleScreenBufferInfoEx(
  HANDLE hConsoleOutput,
  PCONSOLE_SCREEN_BUFFER_INFOEX lpConsoleScreenBufferInfoEx
);

WINBASEAPI WINBOOL WINAPI SetCurrentConsoleFontEx(
  HANDLE hConsoleOutput,
  WINBOOL bMaximumWindow,
  PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx
);
