# 1 "c_include/windows/original/ws2def.h"
#define __STDC__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __STDC_HOSTED__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __GNUC__ 4
# 1 "c_include/windows/original/ws2def.h"
#define __GNUC_MINOR__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __GNUC_PATCHLEVEL__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __VERSION__ "4.8.1 20130328 (prerelease)"
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_RELAXED 0
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_SEQ_CST 5
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_ACQUIRE 2
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_RELEASE 3
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_ACQ_REL 4
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_CONSUME 1
# 1 "c_include/windows/original/ws2def.h"
#define __pic__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __PIC__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __FINITE_MATH_ONLY__ 0
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_INT__ 4
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_LONG__ 4
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_LONG_LONG__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_SHORT__ 2
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_FLOAT__ 4
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_DOUBLE__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_LONG_DOUBLE__ 16
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_SIZE_T__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __CHAR_BIT__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __BIGGEST_ALIGNMENT__ 16
# 1 "c_include/windows/original/ws2def.h"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 1 "c_include/windows/original/ws2def.h"
#define __ORDER_BIG_ENDIAN__ 4321
# 1 "c_include/windows/original/ws2def.h"
#define __ORDER_PDP_ENDIAN__ 3412
# 1 "c_include/windows/original/ws2def.h"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/ws2def.h"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_POINTER__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __SIZE_TYPE__ long long unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __PTRDIFF_TYPE__ long long int
# 1 "c_include/windows/original/ws2def.h"
#define __WCHAR_TYPE__ short unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __WINT_TYPE__ short unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __INTMAX_TYPE__ long long int
# 1 "c_include/windows/original/ws2def.h"
#define __UINTMAX_TYPE__ long long unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __CHAR16_TYPE__ short unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __CHAR32_TYPE__ unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __SIG_ATOMIC_TYPE__ int
# 1 "c_include/windows/original/ws2def.h"
#define __INT8_TYPE__ signed char
# 1 "c_include/windows/original/ws2def.h"
#define __INT16_TYPE__ short int
# 1 "c_include/windows/original/ws2def.h"
#define __INT32_TYPE__ int
# 1 "c_include/windows/original/ws2def.h"
#define __INT64_TYPE__ long long int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT8_TYPE__ unsigned char
# 1 "c_include/windows/original/ws2def.h"
#define __UINT16_TYPE__ short unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT32_TYPE__ unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST8_TYPE__ signed char
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST16_TYPE__ short int
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST32_TYPE__ int
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST64_TYPE__ long long int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST8_TYPE__ signed char
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST16_TYPE__ short int
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST32_TYPE__ int
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST64_TYPE__ long long int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __INTPTR_TYPE__ long long int
# 1 "c_include/windows/original/ws2def.h"
#define __UINTPTR_TYPE__ long long unsigned int
# 1 "c_include/windows/original/ws2def.h"
#define __GXX_ABI_VERSION 1002
# 1 "c_include/windows/original/ws2def.h"
#define __SCHAR_MAX__ 127
# 1 "c_include/windows/original/ws2def.h"
#define __SHRT_MAX__ 32767
# 1 "c_include/windows/original/ws2def.h"
#define __INT_MAX__ 2147483647
# 1 "c_include/windows/original/ws2def.h"
#define __LONG_MAX__ 2147483647L
# 1 "c_include/windows/original/ws2def.h"
#define __LONG_LONG_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __WCHAR_MAX__ 65535
# 1 "c_include/windows/original/ws2def.h"
#define __WCHAR_MIN__ 0
# 1 "c_include/windows/original/ws2def.h"
#define __WINT_MAX__ 65535
# 1 "c_include/windows/original/ws2def.h"
#define __WINT_MIN__ 0
# 1 "c_include/windows/original/ws2def.h"
#define __PTRDIFF_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __SIZE_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/ws2def.h"
#define __INTMAX_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __INTMAX_C(c) c ## LL
# 1 "c_include/windows/original/ws2def.h"
#define __UINTMAX_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/ws2def.h"
#define __UINTMAX_C(c) c ## ULL
# 1 "c_include/windows/original/ws2def.h"
#define __SIG_ATOMIC_MAX__ 2147483647
# 1 "c_include/windows/original/ws2def.h"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 1 "c_include/windows/original/ws2def.h"
#define __INT8_MAX__ 127
# 1 "c_include/windows/original/ws2def.h"
#define __INT16_MAX__ 32767
# 1 "c_include/windows/original/ws2def.h"
#define __INT32_MAX__ 2147483647
# 1 "c_include/windows/original/ws2def.h"
#define __INT64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __UINT8_MAX__ 255
# 1 "c_include/windows/original/ws2def.h"
#define __UINT16_MAX__ 65535
# 1 "c_include/windows/original/ws2def.h"
#define __UINT32_MAX__ 4294967295U
# 1 "c_include/windows/original/ws2def.h"
#define __UINT64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST8_MAX__ 127
# 1 "c_include/windows/original/ws2def.h"
#define __INT8_C(c) c
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST16_MAX__ 32767
# 1 "c_include/windows/original/ws2def.h"
#define __INT16_C(c) c
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST32_MAX__ 2147483647
# 1 "c_include/windows/original/ws2def.h"
#define __INT32_C(c) c
# 1 "c_include/windows/original/ws2def.h"
#define __INT_LEAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __INT64_C(c) c ## LL
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST8_MAX__ 255
# 1 "c_include/windows/original/ws2def.h"
#define __UINT8_C(c) c
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST16_MAX__ 65535
# 1 "c_include/windows/original/ws2def.h"
#define __UINT16_C(c) c
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/ws2def.h"
#define __UINT32_C(c) c ## U
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/ws2def.h"
#define __UINT64_C(c) c ## ULL
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST8_MAX__ 127
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST16_MAX__ 32767
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST32_MAX__ 2147483647
# 1 "c_include/windows/original/ws2def.h"
#define __INT_FAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST8_MAX__ 255
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST16_MAX__ 65535
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/ws2def.h"
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/ws2def.h"
#define __INTPTR_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/ws2def.h"
#define __UINTPTR_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_EVAL_METHOD__ 0
# 1 "c_include/windows/original/ws2def.h"
#define __DEC_EVAL_METHOD__ 2
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_RADIX__ 2
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MANT_DIG__ 24
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_DIG__ 6
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MIN_EXP__ (-125)
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MIN_10_EXP__ (-37)
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MAX_EXP__ 128
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MAX_10_EXP__ 38
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_DECIMAL_DIG__ 9
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MAX__ 3.40282346638528859812e+38F
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_MIN__ 1.17549435082228750797e-38F
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_EPSILON__ 1.19209289550781250000e-7F
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_DENORM_MIN__ 1.40129846432481707092e-45F
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_HAS_DENORM__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_HAS_INFINITY__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __FLT_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MANT_DIG__ 53
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_DIG__ 15
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MIN_EXP__ (-1021)
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MIN_10_EXP__ (-307)
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MAX_EXP__ 1024
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MAX_10_EXP__ 308
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_DECIMAL_DIG__ 17
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MAX__ ((double)1.79769313486231570815e+308L)
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_MIN__ ((double)2.22507385850720138309e-308L)
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_EPSILON__ ((double)2.22044604925031308085e-16L)
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_DENORM_MIN__ ((double)4.94065645841246544177e-324L)
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __DBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MANT_DIG__ 64
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_DIG__ 18
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MIN_EXP__ (-16381)
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MIN_10_EXP__ (-4931)
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MAX_EXP__ 16384
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MAX_10_EXP__ 4932
# 1 "c_include/windows/original/ws2def.h"
#define __DECIMAL_DIG__ 21
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __LDBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_MANT_DIG__ 7
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_MIN_EXP__ (-94)
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_MAX_EXP__ 97
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_MIN__ 1E-95DF
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_MAX__ 9.999999E96DF
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_EPSILON__ 1E-6DF
# 1 "c_include/windows/original/ws2def.h"
#define __DEC32_SUBNORMAL_MIN__ 0.000001E-95DF
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_MANT_DIG__ 16
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_MIN_EXP__ (-382)
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_MAX_EXP__ 385
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_MIN__ 1E-383DD
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_MAX__ 9.999999999999999E384DD
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_EPSILON__ 1E-15DD
# 1 "c_include/windows/original/ws2def.h"
#define __DEC64_SUBNORMAL_MIN__ 0.000000000000001E-383DD
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_MANT_DIG__ 34
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_MIN_EXP__ (-6142)
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_MAX_EXP__ 6145
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_MIN__ 1E-6143DL
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_EPSILON__ 1E-33DL
# 1 "c_include/windows/original/ws2def.h"
#define __DEC128_SUBNORMAL_MIN__ 0.000000000000000000000000000000001E-6143DL
# 1 "c_include/windows/original/ws2def.h"
#define __REGISTER_PREFIX__ 
# 1 "c_include/windows/original/ws2def.h"
#define __USER_LABEL_PREFIX__ 
# 1 "c_include/windows/original/ws2def.h"
#define __GNUC_GNU_INLINE__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __NO_INLINE__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 1 "c_include/windows/original/ws2def.h"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 1 "c_include/windows/original/ws2def.h"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_INT128__ 16
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_WCHAR_T__ 2
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_WINT_T__ 2
# 1 "c_include/windows/original/ws2def.h"
#define __SIZEOF_PTRDIFF_T__ 8
# 1 "c_include/windows/original/ws2def.h"
#define __amd64 1
# 1 "c_include/windows/original/ws2def.h"
#define __amd64__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __x86_64 1
# 1 "c_include/windows/original/ws2def.h"
#define __x86_64__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_HLE_ACQUIRE 65536
# 1 "c_include/windows/original/ws2def.h"
#define __ATOMIC_HLE_RELEASE 131072
# 1 "c_include/windows/original/ws2def.h"
#define __k8 1
# 1 "c_include/windows/original/ws2def.h"
#define __k8__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __code_model_small__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __MMX__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __SSE__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __SSE2__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __SSE_MATH__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __SSE2_MATH__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __SEH__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/ws2def.h"
#define __fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/ws2def.h"
#define __thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/ws2def.h"
#define __cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/ws2def.h"
#define _stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/ws2def.h"
#define _fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/ws2def.h"
#define _thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/ws2def.h"
#define _cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/ws2def.h"
#define __GXX_MERGED_TYPEINFO_NAMES 0
# 1 "c_include/windows/original/ws2def.h"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 1 "c_include/windows/original/ws2def.h"
#define __MSVCRT__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __MINGW32__ 1
# 1 "c_include/windows/original/ws2def.h"
#define _WIN32 1
# 1 "c_include/windows/original/ws2def.h"
#define __WIN32 1
# 1 "c_include/windows/original/ws2def.h"
#define __WIN32__ 1
# 1 "c_include/windows/original/ws2def.h"
#define WIN32 1
# 1 "c_include/windows/original/ws2def.h"
#define __WINNT 1
# 1 "c_include/windows/original/ws2def.h"
#define __WINNT__ 1
# 1 "c_include/windows/original/ws2def.h"
#define WINNT 1
# 1 "c_include/windows/original/ws2def.h"
#define _INTEGRAL_MAX_BITS 64
# 1 "c_include/windows/original/ws2def.h"
#define __MINGW64__ 1
# 1 "c_include/windows/original/ws2def.h"
#define __WIN64 1
# 1 "c_include/windows/original/ws2def.h"
#define __WIN64__ 1
# 1 "c_include/windows/original/ws2def.h"
#define WIN64 1
# 1 "c_include/windows/original/ws2def.h"
#define _WIN64 1
# 1 "c_include/windows/original/ws2def.h"
#define __declspec(x) __attribute__((x))
# 1 "c_include/windows/original/ws2def.h"
#define __DECIMAL_BID_FORMAT__ 1
# 1 "<command-line>"
#undef _REENTRANT
# 1 "c_include/windows/original/ws2def.h"
#define _WIN32_WINNT 0x0602
#define WINVER _WIN32_WINNT

/**
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER within this package.
 */


#define _WS2DEF_ 

# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */


#define _INC__MINGW_H 



# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_mac.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */


#define _INC_CRTDEFS_MACRO 

#define __STRINGIFY(x) #x
#define __MINGW64_STRINGIFY(x) __STRINGIFY(x)

#define __MINGW64_VERSION_MAJOR 3
#define __MINGW64_VERSION_MINOR 0

/* This macro holds an monotonic increasing value, which indicates
   a specific fix/patch is present on trunk.  This value isn't related to
   minor/major version-macros.  It is increased on demand, if a big
   fix was applied to trunk.  This macro gets just increased on trunk.  For
   other branches its value won't be modified.  */

#define __MINGW64_VERSION_RC 1

#define __MINGW64_VERSION_STR __MINGW64_STRINGIFY(__MINGW64_VERSION_MAJOR) "." __MINGW64_STRINGIFY(__MINGW64_VERSION_MINOR)
#define __MINGW64_VERSION_STATE "alpha"

/* mingw.org's version macros: these make gcc to define
   MINGW32_SUPPORTS_MT_EH and to use the _CRT_MT global
   and the __mingwthr_key_dtor() function from the MinGW
   CRT in its private gthr-win32.h header. */
#define __MINGW32_MAJOR_VERSION 3
#define __MINGW32_MINOR_VERSION 11


/* MS does not prefix symbols by underscores for 64-bit.  */

/* As we have to support older gcc version, which are using underscores
   as symbol prefix for x64, we have to check here for the user label
   prefix defined by gcc.  */

       
#undef _
#define _ 1



#define __MINGW_USE_UNDERSCORE_PREFIX 0

#undef _
       
# 62 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_mac.h" 3
#define __MINGW_IMP_SYMBOL(sym) __imp_ ##sym
#define __MINGW_IMP_LSYMBOL(sym) __imp_ ##sym
#define __MINGW_USYMBOL(sym) sym
#define __MINGW_LSYMBOL(sym) _ ##sym







/* Use alias for msvcr80 export of get/set_output_format.  */

#define __USE_MINGW_OUTPUT_FORMAT_EMU 1


/* Set VC specific compiler target macros.  */
# 98 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_mac.h" 3
#define _M_AMD64 100
#define _M_X64 100
# 137 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_mac.h" 3
#undef __MINGW_EXTENSION

#define __MINGW_EXTENSION __extension__




/* Special case nameless struct/union.  */

#define __C89_NAMELESS __MINGW_EXTENSION

#define __C89_NAMELESSSTRUCTNAME 
#define __C89_NAMELESSSTRUCTNAME1 
#define __C89_NAMELESSSTRUCTNAME2 
#define __C89_NAMELESSSTRUCTNAME3 
#define __C89_NAMELESSSTRUCTNAME4 
#define __C89_NAMELESSSTRUCTNAME5 
#define __C89_NAMELESSUNIONNAME 
#define __C89_NAMELESSUNIONNAME1 
#define __C89_NAMELESSUNIONNAME2 
#define __C89_NAMELESSUNIONNAME3 
#define __C89_NAMELESSUNIONNAME4 
#define __C89_NAMELESSUNIONNAME5 
#define __C89_NAMELESSUNIONNAME6 
#define __C89_NAMELESSUNIONNAME7 
#define __C89_NAMELESSUNIONNAME8 



#define __GNU_EXTENSION __MINGW_EXTENSION


/* MinGW-w64 has some additional C99 printf/scanf feature support.
   So we add some helper macros to ease recognition of them.  */
#define __MINGW_HAVE_ANSI_C99_PRINTF 1
#define __MINGW_HAVE_WIDE_C99_PRINTF 1
#define __MINGW_HAVE_ANSI_C99_SCANF 1
#define __MINGW_HAVE_WIDE_C99_SCANF 1




#define __MINGW_POISON_NAME(__IFACE) __IFACE ##_layout_has_not_been_verified_and_its_declaration_is_most_likely_incorrect





#define __MSABI_LONG(x) x ## l






#define __MINGW_GCC_VERSION (__GNUC__ * 10000 + __GNUC_MINOR__ * 100 + __GNUC_PATCHLEVEL__)







#define __MINGW_GNUC_PREREQ(major,minor) (__GNUC__ > (major) || (__GNUC__ == (major) && __GNUC_MINOR__ >= (minor)))
# 211 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_mac.h" 3
#define __MINGW_MSC_PREREQ(major,minor) 0
# 221 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_mac.h" 3
#define __MINGW_ATTRIB_DEPRECATED_STR(X) 


#define __MINGW_SEC_WARN_STR "This function or variable may be unsafe, use _CRT_SECURE_NO_WARNINGS to disable deprecation"
#define __MINGW_MSVC2005_DEPREC_STR "This POSIX function is deprecated beginning in Visual C++ 2005, use _CRT_NONSTDC_NO_DEPRECATE to disable deprecation"


#define __MINGW_ATTRIB_DEPRECATED_MSVC2005 __MINGW_ATTRIB_DEPRECATED_STR (__MINGW_MSVC2005_DEPREC_STR)





#define __MINGW_ATTRIB_DEPRECATED_SEC_WARN __MINGW_ATTRIB_DEPRECATED_STR (__MINGW_SEC_WARN_STR)




#define __MINGW_MS_PRINTF(__format,__args) __attribute__((__format__(ms_printf, __format,__args)))
#define __MINGW_MS_SCANF(__format,__args) __attribute__((__format__(ms_scanf, __format,__args)))
#define __MINGW_GNU_PRINTF(__format,__args) __attribute__((__format__(gnu_printf,__format,__args)))
#define __MINGW_GNU_SCANF(__format,__args) __attribute__((__format__(gnu_scanf, __format,__args)))

#undef __mingw_ovr



#define __mingw_ovr static __attribute__ ((__unused__)) __inline__ __cdecl
# 13 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 2 3
# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */


#define _INC_MINGW_SECAPI 

/* http://msdn.microsoft.com/en-us/library/ms175759%28v=VS.100%29.aspx */
# 28 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 3
/* Templates won't work in C, will break if secure API is not enabled, disabled */
#undef _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES
#undef _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES_MEMORY
#undef _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES
#undef _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT
#undef _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_MEMORY
#define _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES 0
#define _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES_MEMORY 0
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 0
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT 0
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_MEMORY 0


#define __MINGW_CRT_NAME_CONCAT1(sym) ::sym
#define __MINGW_CRT_NAME_CONCAT2(sym) ::sym ##_s
#define __MINGW_CRT_NAME_INSECURE(sym) ::__insecure__ ##sym
#define __MINGW_CRT_NAME_INSECURE_DEF(sym) __insecure__ ##sym
# 69 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 3
#define __CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES_0_2_(__ret,__func,__type1,__attrib1,__arg1,__type2,__attrib2,__arg2,__type3,__attrib3,__arg3) _CRTIMP __ret __cdecl __func(__type1 * __attrib1 __arg1, __type2 __attrib2 __arg2, __type3 __attrib3 __arg3);
# 86 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 3
#define __CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES_MEMORY_0_3_(__ret,__func,__type1,__attrib1,__arg1,__type2,__attrib2,__arg2,__type3,__attrib3,__arg3,__type4,__attrib4,__arg4) _CRTIMP __ret __cdecl __func(__type1 * __attrib1 __arg1, __type2 __attrib2 __arg2, __type3 __attrib3 __arg3, __type4 __attrib4 __arg4);
# 113 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 3
#define __CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_0_2_(__ret,__func,__type1,__attrib1,__arg1,__type2,__attrib2,__arg2) _CRTIMP __ret __cdecl __func(__type1 * __attrib1 __arg1, __type2 __attrib2 __arg2) __MINGW_ATTRIB_DEPRECATED_SEC_WARN;



/*
  The macro _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT requires that _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES
  is also defined as 1. If _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT is defined as 1 and
  _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES is defined as 0, the application will not perform any template overloads.
*/
/* Fallback on insecure mode if not possible to know destination size at compile time, NULL is appended for strncpy */
# 176 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 3
#define __CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT_0_3_(__ret,__func,__type1,__attrib1,__arg1,__type2,__attrib2,__arg2,__type3,__attrib3,__arg3) _CRTIMP __ret __cdecl __func(__type1 * __attrib1 __arg1, __type2 __attrib2 __arg2, __type3 __attrib3 __arg3) __MINGW_ATTRIB_DEPRECATED_SEC_WARN;

#define __CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT_1_4_(__ret,__imp_attrib,__func,__real_func,__type1,__attrib1,__arg1,__type2,__attrib2,__arg2,__type3,__attrib3,__arg3,__type4,__attrib4,__arg4) __imp_attrib __ret __cdecl __func(__type1 * __attrib1 __arg1, __type2 __attrib2 __arg2, __type3 __attrib3 __arg3, __type4 __attrib4 __arg4) __MINGW_ATTRIB_DEPRECATED_SEC_WARN;



/* https://blogs.msdn.com/b/sdl/archive/2010/02/16/vc-2010-and-memcpy.aspx?Redirected=true */
/* fallback on default implementation if we can't know the size of the destination */
# 197 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw_secapi.h" 3
#define __CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_MEMORY_0_3_(__ret,__func,__type1,__attrib1,__arg1,__type2,__attrib2,__arg2,__type3,__attrib3,__arg3) _CRTIMP __ret __cdecl __func(__type1 * __attrib1 __arg1, __type2 __attrib2 __arg2, __type3 __attrib3 __arg3) __MINGW_ATTRIB_DEPRECATED_SEC_WARN;
# 14 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 2 3

/* Include _cygwin.h if we're building a Cygwin application. */




/* Target specific macro replacement for type "long".  In the Windows API,
   the type long is always 32 bit, even if the target is 64 bit (LLP64).
   On 64 bit Cygwin, the type long is 64 bit (LP64).  So, to get the right
   sized definitions and declarations, all usage of type long in the Windows
   headers have to be replaced by the below defined macro __LONG32. */

#define __LONG32 long




/* C/C++ specific language defines.  */


#undef __stdcall

#define __stdcall 
# 51 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
/* Note the extern. This is needed to work around GCC's
limitations in handling dllimport attribute.  */
#define __MINGW_IMPORT extern __attribute__ ((__dllimport__))


#undef __USE_CRTIMP

#define __USE_CRTIMP 1


#define _CRTIMP __attribute__ ((__dllimport__))




#define __DECLSPEC_SUPPORTED 
# 79 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define USE___UUIDOF 0
# 91 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __CRT_INLINE extern __inline__




#define __MINGW_INTRIN_INLINE extern __inline__ __attribute__((__always_inline__,__gnu_inline__))




#undef __CRT__NO_INLINE
#define __CRT__NO_INLINE 1







#define __UNUSED_PARAM(x) x __attribute__ ((__unused__))
# 125 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __restrict_arr __restrict
# 141 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __MINGW_ATTRIB_NORETURN __attribute__ ((__noreturn__))
#define __MINGW_ATTRIB_CONST __attribute__ ((__const__))
# 152 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __MINGW_ATTRIB_MALLOC __attribute__ ((__malloc__))
#define __MINGW_ATTRIB_PURE __attribute__ ((__pure__))
# 162 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
/* Attribute `nonnull' was valid as of gcc 3.3.  We don't use GCC's
   variadiac macro facility, because variadic macros cause syntax
   errors with  --traditional-cpp.  */

#define __MINGW_ATTRIB_NONNULL(arg) __attribute__ ((__nonnull__ (arg)))





#define __MINGW_ATTRIB_UNUSED __attribute__ ((__unused__))





#define __MINGW_ATTRIB_USED __attribute__ ((__used__))
#define __MINGW_ATTRIB_DEPRECATED __attribute__ ((__deprecated__))
# 189 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __MINGW_NOTHROW __attribute__ ((__nothrow__))







#define __MINGW_ATTRIB_NO_OPTIMIZE __attribute__((__optimize__ ("0")))





#define __MINGW_PRAGMA_PARAM(x) _Pragma (#x)






#define __MINGW_BROKEN_INTERFACE(x) __MINGW_PRAGMA_PARAM(message ("Interface " _CRT_STRINGIZE(x) " has unverified layout."))




/*  High byte is the major version, low byte is the minor. */
#define __MSVCRT_VERSION__ 0x0700
# 229 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define _INT128_DEFINED 

#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long
# 248 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __ptr32 
#define __ptr64 

#define __unaligned 


#define __w64 




#define __forceinline extern __inline__ __attribute__((__always_inline__,__gnu_inline__))
# 271 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __nothrow 



#undef _CRT_PACKING
#define _CRT_PACKING 8

# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\vadefs.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */

#define _INC_VADEFS 

# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 1 3
/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */
# 674 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define MINGW_SDK_INIT 







# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\sdks/_mingw_directx.h" 1 3


#define __MINGW_HAS_DXSDK 1


#define MINGW_HAS_DDRAW_H 1
#define MINGW_DDRAW_VERSION 7
# 683 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 2 3
# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\sdks/_mingw_ddk.h" 1 3

#define MINGW_DDK_H 
# 684 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 2 3
# 10 "c:\\mingw64\\x86_64-w64-mingw32\\include\\vadefs.h" 2 3


#pragma pack(push,_CRT_PACKING)
# 21 "c:\\mingw64\\x86_64-w64-mingw32\\include\\vadefs.h" 3
#define __GNUC_VA_LIST 
  typedef __builtin_va_list __gnuc_va_list;




#define _VA_LIST_DEFINED 

  typedef __gnuc_va_list va_list;
# 40 "c:\\mingw64\\x86_64-w64-mingw32\\include\\vadefs.h" 3
#define _ADDRESSOF(v) (&(v))



/* Use GCC builtins */

#define _crt_va_start(v,l) __builtin_va_start(v,l)
#define _crt_va_arg(v,l) __builtin_va_arg(v,l)
#define _crt_va_end(v) __builtin_va_end(v)
#define _crt_va_copy(d,s) __builtin_va_copy(d,s)
# 101 "c:\\mingw64\\x86_64-w64-mingw32\\include\\vadefs.h" 3
#pragma pack(pop)
# 279 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 2 3


#pragma pack(push,_CRT_PACKING)



#define __CRT_STRINGIZE(_Value) #_Value
#define _CRT_STRINGIZE(_Value) __CRT_STRINGIZE(_Value)



#define __CRT_WIDE(_String) L ## _String
#define _CRT_WIDE(_String) __CRT_WIDE(_String)



#define _W64 






#define _CRTIMP_NOIA64 _CRTIMP




#define _CRTIMP2 _CRTIMP



#define _CRTIMP_ALTERNATIVE _CRTIMP
#define _CRT_ALTERNATIVE_IMPORTED 



#define _MRTIMP2 _CRTIMP


/* We have to define _DLL for gcc based mingw version. This define is set
   by VC, when DLL-based runtime is used. So, gcc based runtime just have
   DLL-base runtime, therefore this define has to be set.
   As our headers are possibly used by windows compiler having a static
   C-runtime, we make this definition gnu compiler specific here.  */

#define _DLL 



#define _MT 



#define _MCRTIMP _CRTIMP



#define _CRTIMP_PURE _CRTIMP



#define _PGLOBAL 



#define _AGLOBAL 


#define _SECURECRT_FILL_BUFFER_PATTERN 0xFD
#define _CRT_DEPRECATE_TEXT(_Text) __declspec(deprecated)


#define _CRT_INSECURE_DEPRECATE_MEMORY(_Replacement) 



#define _CRT_INSECURE_DEPRECATE_GLOBALS(_Replacement) 



#define _CRT_MANAGED_HEAP_DEPRECATE 



#define _CRT_OBSOLETE(_NewItem) 





#define _SIZE_T_DEFINED 
#undef size_t

__extension__ typedef unsigned long long size_t;






#define _SSIZE_T_DEFINED 
#undef ssize_t

__extension__ typedef long long ssize_t;






#define _INTPTR_T_DEFINED 

#define __intptr_t_defined 
#undef intptr_t

__extension__ typedef long long intptr_t;







#define _UINTPTR_T_DEFINED 

#define __uintptr_t_defined 
#undef uintptr_t

__extension__ typedef unsigned long long uintptr_t;







#define _PTRDIFF_T_DEFINED 

#define _PTRDIFF_T_ 
#undef ptrdiff_t

__extension__ typedef long long ptrdiff_t;







#define _WCHAR_T_DEFINED 

typedef unsigned short wchar_t;




#define _WCTYPE_T_DEFINED 

#define _WINT_T 
typedef unsigned short wint_t;
typedef unsigned short wctype_t;
# 458 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define _ERRCODE_DEFINED 
typedef int errno_t;



#define _TIME32_T_DEFINED 
typedef long __time32_t;



#define _TIME64_T_DEFINED 
__extension__ typedef long long __time64_t;



#define _TIME_T_DEFINED 



typedef __time64_t time_t;




#define _CONST_RETURN 




#define UNALIGNED __unaligned
# 497 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define _CRT_ALIGN(x) __attribute__ ((__aligned__ (x)))






#define __CRTDECL __cdecl


#define _ARGMAX 100


#define _TRUNCATE ((size_t)-1)



#define _CRT_UNUSED(x) (void)x


/* MSVC defines _NATIVE_NULLPTR_SUPPORTED when nullptr is supported. We emulate it here for GCC. */






/* We are activating __USE_MINGW_ANSI_STDIO for various define indicators.
   Note that we enable it also for _GNU_SOURCE in C++, but not for C case. */
# 537 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
/* _dowildcard is an int that controls the globbing of the command line.
 * The MinGW32 (mingw.org) runtime calls it _CRT_glob, so we are adding
 * a compatibility definition here:  you can use either of _CRT_glob or
 * _dowildcard .
 * If _dowildcard is non-zero, the command line will be globbed:  *.*
 * will be expanded to be all files in the startup directory.
 * In the mingw-w64 library a _dowildcard variable is defined as being
 * 0, therefore command line globbing is DISABLED by default. To turn it
 * on and to leave wildcard command line processing MS's globbing code,
 * include a line in one of your source modules defining _dowildcard and
 * setting it to -1, like so:
 * int _dowildcard = -1;
 */
#undef _CRT_glob
#define _CRT_glob _dowildcard
# 567 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __ANONYMOUS_DEFINED 
#define _ANONYMOUS_UNION __MINGW_EXTENSION
#define _ANONYMOUS_STRUCT __MINGW_EXTENSION

#define _UNION_NAME(x) 
#define _STRUCT_NAME(x) 
# 592 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define DUMMYUNIONNAME 
#define DUMMYUNIONNAME1 
#define DUMMYUNIONNAME2 
#define DUMMYUNIONNAME3 
#define DUMMYUNIONNAME4 
#define DUMMYUNIONNAME5 
#define DUMMYUNIONNAME6 
#define DUMMYUNIONNAME7 
#define DUMMYUNIONNAME8 
#define DUMMYUNIONNAME9 
# 614 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define DUMMYSTRUCTNAME 
#define DUMMYSTRUCTNAME1 
#define DUMMYSTRUCTNAME2 
#define DUMMYSTRUCTNAME3 
#define DUMMYSTRUCTNAME4 
#define DUMMYSTRUCTNAME5 




/* Macros for __uuidof template-based emulation */
# 642 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
#define __CRT_UUID_DECL(type,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) 
# 652 "c:\\mingw64\\x86_64-w64-mingw32\\include\\_mingw.h" 3
void __attribute__((__cdecl__)) __debugbreak(void);
extern __inline__ __attribute__((__always_inline__,__gnu_inline__)) void __attribute__((__cdecl__)) __debugbreak(void)
{
  __asm__ __volatile__("int $3");
}



/* mingw-w64 specific functions: */
const char *__mingw_get_crt_info (void);






#pragma pack(pop)
# 13 "c_include/windows/original/ws2def.h" 2
# 1 "c:\\mingw64\\x86_64-w64-mingw32\\include\\winapifamily.h" 1 3
/**
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER within this package.
 */


#define _INC_WINAPIFAMILY 

#define WINAPI_PARTITION_DESKTOP 0x1
#define WINAPI_PARTITION_APP 0x2

#define WINAPI_FAMILY_APP WINAPI_PARTITION_APP
#define WINAPI_FAMILY_DESKTOP_APP (WINAPI_PARTITION_DESKTOP | WINAPI_PARTITION_APP)



#define WINAPI_FAMILY WINAPI_FAMILY_DESKTOP_APP


#define WINAPI_FAMILY_PARTITION(v) ((WINAPI_FAMILY & v) == v)
#define WINAPI_FAMILY_ONE_PARTITION(vset,v) ((WINAPI_FAMILY & vset) == v)
# 14 "c_include/windows/original/ws2def.h" 2



/* FIXME FIXME FIXME FIXME FIXME: Much more data need moving here.
 * This holds only SCOPE_LEVEL and SCOPE_ID so that compilations
 * do not fail.
 */

typedef enum _SCOPE_LEVEL {
  ScopeLevelInterface = 1,
  ScopeLevelLink = 2,
  ScopeLevelSubnet = 3,
  ScopeLevelAdmin = 4,
  ScopeLevelSite = 5,
  ScopeLevelOrganization = 8,
  ScopeLevelGlobal = 14,
  ScopeLevelCount = 16
} SCOPE_LEVEL;

typedef struct _SCOPE_ID {
  __extension__ union {
    __extension__ struct {
 ULONG Zone : 28;
 ULONG Level : 4;
    };
    ULONG Value;
  };
} SCOPE_ID, *PSCOPE_ID;
