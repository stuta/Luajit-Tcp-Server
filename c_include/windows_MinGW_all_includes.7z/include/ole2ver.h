/**
 * This file has no copyright assigned and is placed in the Public Domain.
 * This file is part of the mingw-w64 runtime package.
 * No warranty is given; refer to the file DISCLAIMER.PD within this package.
 */
#ifndef _OLE2VER_H_
#define _OLE2VER_H_

#define rmm 23
#define rup 639

#endif
