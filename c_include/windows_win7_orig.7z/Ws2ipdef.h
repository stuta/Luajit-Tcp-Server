# 1 "c_include/windows/original/Ws2ipdef.h"
#define __STDC__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __STDC_HOSTED__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GNUC__ 4
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GNUC_MINOR__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GNUC_PATCHLEVEL__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __VERSION__ "4.8.1 20130328 (prerelease)"
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_RELAXED 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_SEQ_CST 5
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_ACQUIRE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_RELEASE 3
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_ACQ_REL 4
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_CONSUME 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __pic__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __PIC__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FINITE_MATH_ONLY__ 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_INT__ 4
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_LONG__ 4
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_LONG_LONG__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_SHORT__ 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_FLOAT__ 4
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_DOUBLE__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_LONG_DOUBLE__ 16
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_SIZE_T__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __CHAR_BIT__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __BIGGEST_ALIGNMENT__ 16
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ORDER_BIG_ENDIAN__ 4321
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ORDER_PDP_ENDIAN__ 3412
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_POINTER__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZE_TYPE__ long long unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __PTRDIFF_TYPE__ long long int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WCHAR_TYPE__ short unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WINT_TYPE__ short unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INTMAX_TYPE__ long long int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINTMAX_TYPE__ long long unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __CHAR16_TYPE__ short unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __CHAR32_TYPE__ unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIG_ATOMIC_TYPE__ int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT8_TYPE__ signed char
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT16_TYPE__ short int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT32_TYPE__ int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT64_TYPE__ long long int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT8_TYPE__ unsigned char
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT16_TYPE__ short unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT32_TYPE__ unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST8_TYPE__ signed char
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST16_TYPE__ short int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST32_TYPE__ int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST64_TYPE__ long long int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST8_TYPE__ signed char
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST16_TYPE__ short int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST32_TYPE__ int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST64_TYPE__ long long int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INTPTR_TYPE__ long long int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINTPTR_TYPE__ long long unsigned int
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GXX_ABI_VERSION 1002
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SCHAR_MAX__ 127
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SHRT_MAX__ 32767
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_MAX__ 2147483647
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LONG_MAX__ 2147483647L
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LONG_LONG_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WCHAR_MAX__ 65535
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WCHAR_MIN__ 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WINT_MAX__ 65535
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WINT_MIN__ 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __PTRDIFF_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZE_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INTMAX_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INTMAX_C(c) c ## LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINTMAX_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINTMAX_C(c) c ## ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIG_ATOMIC_MAX__ 2147483647
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT8_MAX__ 127
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT16_MAX__ 32767
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT32_MAX__ 2147483647
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT8_MAX__ 255
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT16_MAX__ 65535
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT32_MAX__ 4294967295U
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST8_MAX__ 127
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT8_C(c) c
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST16_MAX__ 32767
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT16_C(c) c
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST32_MAX__ 2147483647
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT32_C(c) c
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_LEAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT64_C(c) c ## LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST8_MAX__ 255
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT8_C(c) c
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST16_MAX__ 65535
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT16_C(c) c
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT32_C(c) c ## U
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT64_C(c) c ## ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST8_MAX__ 127
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST16_MAX__ 32767
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST32_MAX__ 2147483647
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INT_FAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST8_MAX__ 255
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST16_MAX__ 65535
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __INTPTR_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __UINTPTR_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_EVAL_METHOD__ 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC_EVAL_METHOD__ 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_RADIX__ 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MANT_DIG__ 24
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_DIG__ 6
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MIN_EXP__ (-125)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MIN_10_EXP__ (-37)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MAX_EXP__ 128
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MAX_10_EXP__ 38
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_DECIMAL_DIG__ 9
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MAX__ 3.40282346638528859812e+38F
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_MIN__ 1.17549435082228750797e-38F
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_EPSILON__ 1.19209289550781250000e-7F
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_DENORM_MIN__ 1.40129846432481707092e-45F
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_HAS_DENORM__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_HAS_INFINITY__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __FLT_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MANT_DIG__ 53
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_DIG__ 15
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MIN_EXP__ (-1021)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MIN_10_EXP__ (-307)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MAX_EXP__ 1024
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MAX_10_EXP__ 308
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_DECIMAL_DIG__ 17
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MAX__ ((double)1.79769313486231570815e+308L)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_MIN__ ((double)2.22507385850720138309e-308L)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_EPSILON__ ((double)2.22044604925031308085e-16L)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_DENORM_MIN__ ((double)4.94065645841246544177e-324L)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MANT_DIG__ 64
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_DIG__ 18
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MIN_EXP__ (-16381)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MIN_10_EXP__ (-4931)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MAX_EXP__ 16384
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MAX_10_EXP__ 4932
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DECIMAL_DIG__ 21
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __LDBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_MANT_DIG__ 7
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_MIN_EXP__ (-94)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_MAX_EXP__ 97
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_MIN__ 1E-95DF
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_MAX__ 9.999999E96DF
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_EPSILON__ 1E-6DF
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC32_SUBNORMAL_MIN__ 0.000001E-95DF
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_MANT_DIG__ 16
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_MIN_EXP__ (-382)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_MAX_EXP__ 385
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_MIN__ 1E-383DD
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_MAX__ 9.999999999999999E384DD
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_EPSILON__ 1E-15DD
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC64_SUBNORMAL_MIN__ 0.000000000000001E-383DD
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_MANT_DIG__ 34
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_MIN_EXP__ (-6142)
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_MAX_EXP__ 6145
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_MIN__ 1E-6143DL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_EPSILON__ 1E-33DL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DEC128_SUBNORMAL_MIN__ 0.000000000000000000000000000000001E-6143DL
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __REGISTER_PREFIX__ 
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __USER_LABEL_PREFIX__ 
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GNUC_GNU_INLINE__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __NO_INLINE__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_INT128__ 16
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_WCHAR_T__ 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_WINT_T__ 2
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SIZEOF_PTRDIFF_T__ 8
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __amd64 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __amd64__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __x86_64 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __x86_64__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_HLE_ACQUIRE 65536
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __ATOMIC_HLE_RELEASE 131072
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __k8 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __k8__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __code_model_small__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __MMX__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SSE__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SSE2__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SSE_MATH__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SSE2_MATH__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __SEH__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GXX_MERGED_TYPEINFO_NAMES 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __MSVCRT__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __MINGW32__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _WIN32 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WIN32 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WIN32__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define WIN32 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WINNT 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WINNT__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define WINNT 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _INTEGRAL_MAX_BITS 64
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __MINGW64__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WIN64 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __WIN64__ 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define WIN64 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _WIN64 1
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __declspec(x) __attribute__((x))
# 1 "c_include/windows/original/Ws2ipdef.h"
#define __DECIMAL_BID_FORMAT__ 1
# 1 "<command-line>"
#undef _REENTRANT
# 1 "c_include/windows/original/Ws2ipdef.h"
#define _WIN32_WINNT 0x0602
#define WINVER _WIN32_WINNT
#define WIN32_LEAN_AND_MEAN 
#pragma comment (lib, "Ws2_32.lib")
/*++

Copyright (c) Microsoft Corporation. All rights reserved.

Module Name:

    ws2ipdef.h

Abstract:

    This file contains TCP/IP specific information for use
    by WinSock2 compatible applications.
  
   Copyright (c) Microsoft Corporation. All rights reserved.
  
    To provide the backward compatibility, all the TCP/IP
    specific definitions that were included in the WINSOCK.H
    file are now included in WINSOCK2.H file. WS2TCPIP.H
    file includes only the definitions  introduced in the
    "WinSock 2 Protocol-Specific Annex" document.
  
    Rev 0.3 Nov 13, 1995
        Rev 0.4 Dec 15, 1996

Environment:

    user mode or kernel mode

--*/


#define _WS2IPDEF_ 
# 46 "c_include/windows/original/Ws2ipdef.h"
#pragma warning(push)
#pragma warning(disable:4201)
#pragma warning(disable:4127)







#define WS2IPDEF_ASSERT(exp) ((VOID) 0)





#define WS2TCPIP_INLINE extern inline


# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/in6addr.h" 1
/*++



Copyright (c) Microsoft Corporation



Module Name:



    in6addr.h



Environment:



    user mode or kernel mode



--*/
# 16 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/in6addr.h"
       

//
// IPv6 Internet address (RFC 2553)
// This is an 'on-wire' format structure.
//
typedef struct in6_addr {
    union {
        UCHAR Byte[16];
        USHORT Word[8];
    } u;
} IN6_ADDR, *PIN6_ADDR, FAR *LPIN6_ADDR;

#define in_addr6 in6_addr

//
// Defines to match RFC 2553.
//
#define _S6_un u
#define _S6_u8 Byte
#define s6_addr _S6_un._S6_u8

//
// Defines for our implementation.
//
#define s6_bytes u.Byte
#define s6_words u.Word
# 66 "c_include/windows/original/Ws2ipdef.h" 2

//
// Old IPv6 socket address structure (retained for sockaddr_gen definition).
//

struct sockaddr_in6_old {
    SHORT sin6_family; // AF_INET6.
    USHORT sin6_port; // Transport level port number.
    ULONG sin6_flowinfo; // IPv6 flow information.
    IN6_ADDR sin6_addr; // IPv6 address.
};

typedef union sockaddr_gen {
    struct sockaddr Address;
    struct sockaddr_in AddressIn;
    struct sockaddr_in6_old AddressIn6;
} sockaddr_gen;

//
// Structure to keep interface specific information
//

typedef struct _INTERFACE_INFO {
    ULONG iiFlags; // Interface flags.
    sockaddr_gen iiAddress; // Interface address.
    sockaddr_gen iiBroadcastAddress; // Broadcast address.
    sockaddr_gen iiNetmask; // Network mask.
} INTERFACE_INFO, FAR *LPINTERFACE_INFO;

//
// New structure that does not have dependency on the address size.
//

typedef struct _INTERFACE_INFO_EX {
    ULONG iiFlags; // Interface flags.
    SOCKET_ADDRESS iiAddress; // Interface address.
    SOCKET_ADDRESS iiBroadcastAddress; // Broadcast address.
    SOCKET_ADDRESS iiNetmask; // Network mask.
} INTERFACE_INFO_EX, FAR *LPINTERFACE_INFO_EX;

//
// Possible flags for the  iiFlags - bitmask.
//

#define IFF_UP 0x00000001
#define IFF_BROADCAST 0x00000002
#define IFF_LOOPBACK 0x00000004
#define IFF_POINTTOPOINT 0x00000008
#define IFF_MULTICAST 0x00000010


//
// Options to use with [gs]etsockopt at the IPPROTO_IP level.
// The values should be consistent with the IPv6 equivalents.
//
#define IP_OPTIONS 1
#define IP_HDRINCL 2
#define IP_TOS 3
#define IP_TTL 4
#define IP_MULTICAST_IF 9
#define IP_MULTICAST_TTL 10
#define IP_MULTICAST_LOOP 11
#define IP_ADD_MEMBERSHIP 12
#define IP_DROP_MEMBERSHIP 13
#define IP_DONTFRAGMENT 14
#define IP_ADD_SOURCE_MEMBERSHIP 15
#define IP_DROP_SOURCE_MEMBERSHIP 16
#define IP_BLOCK_SOURCE 17
#define IP_UNBLOCK_SOURCE 18
#define IP_PKTINFO 19
#define IP_HOPLIMIT 21
#define IP_RECEIVE_BROADCAST 22
#define IP_RECVIF 24
#define IP_RECVDSTADDR 25
#define IP_IFLIST 28
#define IP_ADD_IFLIST 29
#define IP_DEL_IFLIST 30
#define IP_UNICAST_IF 31
#define IP_RTHDR 32
#define IP_RECVRTHDR 38
#define IP_TCLASS 39
#define IP_RECVTCLASS 40
#define IP_ORIGINAL_ARRIVAL_IF 47

#define IP_UNSPECIFIED_TYPE_OF_SERVICE -1

#define IPV6_ADDRESS_BITS RTL_BITS_OF(IN6_ADDR)

//
// IPv6 socket address structure, RFC 3493.
//

//
// NB: The LH version of sockaddr_in6 has the struct tag sockaddr_in6 rather
// than sockaddr_in6_lh.  This is to make sure that standard sockets apps
// that conform to RFC 2553 (Basic Socket Interface Extensions for IPv6).
//
typedef struct sockaddr_in6 {
    ADDRESS_FAMILY sin6_family; // AF_INET6.
    USHORT sin6_port; // Transport level port number.
    ULONG sin6_flowinfo; // IPv6 flow information.
    IN6_ADDR sin6_addr; // IPv6 address.
    union {
        ULONG sin6_scope_id; // Set of interfaces for a scope.
        SCOPE_ID sin6_scope_struct;
    };
} SOCKADDR_IN6_LH, *PSOCKADDR_IN6_LH, FAR *LPSOCKADDR_IN6_LH;

typedef struct sockaddr_in6_w2ksp1 {
    short sin6_family; /* AF_INET6 */
    USHORT sin6_port; /* Transport level port number */
    ULONG sin6_flowinfo; /* IPv6 flow information */
    struct in6_addr sin6_addr; /* IPv6 address */
    ULONG sin6_scope_id; /* set of interfaces for a scope */
} SOCKADDR_IN6_W2KSP1, *PSOCKADDR_IN6_W2KSP1, FAR *LPSOCKADDR_IN6_W2KSP1;


typedef SOCKADDR_IN6_LH SOCKADDR_IN6;
typedef SOCKADDR_IN6_LH *PSOCKADDR_IN6;
typedef SOCKADDR_IN6_LH FAR *LPSOCKADDR_IN6;
# 196 "c_include/windows/original/Ws2ipdef.h"
typedef union _SOCKADDR_INET {
    SOCKADDR_IN Ipv4;
    SOCKADDR_IN6 Ipv6;
    ADDRESS_FAMILY si_family;
} SOCKADDR_INET, *PSOCKADDR_INET;

//
// Structure to hold a pair of source, destination addresses.
//
typedef struct _sockaddr_in6_pair
{
    PSOCKADDR_IN6 SourceAddress;
    PSOCKADDR_IN6 DestinationAddress;
} SOCKADDR_IN6_PAIR, *PSOCKADDR_IN6_PAIR;

//
// Macro that works for both IPv4 and IPv6
//
#define SS_PORT(ssp) (((PSOCKADDR_IN)(ssp))->sin_port)


//
// N.B. These addresses are in network byte order.
//

#define IN6ADDR_ANY_INIT { 0 }

#define IN6ADDR_LOOPBACK_INIT { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 }

#define IN6ADDR_ALLNODESONNODE_INIT { 0xff, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 }




#define IN6ADDR_ALLNODESONLINK_INIT { 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01 }




#define IN6ADDR_ALLROUTERSONLINK_INIT { 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02 }




#define IN6ADDR_ALLMLDV2ROUTERSONLINK_INIT { 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16 }




#define IN6ADDR_TEREDOINITIALLINKLOCALADDRESS_INIT { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfe }




//
// The old link local address for XP-SP2/Win2K3 machines.
//
#define IN6ADDR_TEREDOOLDLINKLOCALADDRESSXP_INIT { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 'T', 'E', 'R', 'E', 'D', 'O' }




//
// The old link local address for Vista Beta-2 and earlier machines.
//
#define IN6ADDR_TEREDOOLDLINKLOCALADDRESSVISTA_INIT { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff }




#define IN6ADDR_LINKLOCALPREFIX_INIT { 0xfe, 0x80, }

#define IN6ADDR_MULTICASTPREFIX_INIT { 0xff, 0x00, }

#define IN6ADDR_SOLICITEDNODEMULTICASTPREFIX_INIT { 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0xff, }




#define IN6ADDR_V4MAPPEDPREFIX_INIT { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xff, }




#define IN6ADDR_6TO4PREFIX_INIT { 0x20, 0x02, }

#define IN6ADDR_TEREDOPREFIX_INIT { 0x20, 0x01, 0x00, 0x00, }

#define IN6ADDR_TEREDOPREFIX_INIT_OLD { 0x3f, 0xfe, 0x83, 0x1f, }

#define IN6ADDR_LINKLOCALPREFIX_LENGTH 64

#define IN6ADDR_MULTICASTPREFIX_LENGTH 8

#define IN6ADDR_SOLICITEDNODEMULTICASTPREFIX_LENGTH 104

#define IN6ADDR_V4MAPPEDPREFIX_LENGTH 96

#define IN6ADDR_6TO4PREFIX_LENGTH 16

#define IN6ADDR_TEREDOPREFIX_LENGTH 32





//
// N.B. These addresses are in network byte order.
//
extern CONST SCOPE_ID scopeid_unspecified;

extern CONST IN_ADDR in4addr_any;
extern CONST IN_ADDR in4addr_loopback;
extern CONST IN_ADDR in4addr_broadcast;
extern CONST IN_ADDR in4addr_allnodesonlink;
extern CONST IN_ADDR in4addr_allroutersonlink;
extern CONST IN_ADDR in4addr_alligmpv3routersonlink;
extern CONST IN_ADDR in4addr_allteredohostsonlink;
extern CONST IN_ADDR in4addr_linklocalprefix;
extern CONST IN_ADDR in4addr_multicastprefix;

extern CONST IN6_ADDR in6addr_any;
extern CONST IN6_ADDR in6addr_loopback;
extern CONST IN6_ADDR in6addr_allnodesonnode;
extern CONST IN6_ADDR in6addr_allnodesonlink;
extern CONST IN6_ADDR in6addr_allroutersonlink;
extern CONST IN6_ADDR in6addr_allmldv2routersonlink;
extern CONST IN6_ADDR in6addr_teredoinitiallinklocaladdress;
extern CONST IN6_ADDR in6addr_linklocalprefix;
extern CONST IN6_ADDR in6addr_multicastprefix;
extern CONST IN6_ADDR in6addr_solicitednodemulticastprefix;
extern CONST IN6_ADDR in6addr_v4mappedprefix;
extern CONST IN6_ADDR in6addr_6to4prefix;
extern CONST IN6_ADDR in6addr_teredoprefix;
extern CONST IN6_ADDR in6addr_teredoprefix_old;







extern inline
BOOLEAN
IN6_ADDR_EQUAL(CONST IN6_ADDR *x, CONST IN6_ADDR *y)
{
    __int64 UNALIGNED *a;
    __int64 UNALIGNED *b;

    a = (__int64 UNALIGNED *)x;
    b = (__int64 UNALIGNED *)y;

    return (BOOLEAN)((a[1] == b[1]) && (a[0] == b[0]));
}

//
// RFC 3542 uses IN6_ARE_ADDR_EQUAL().
//
#define IN6_ARE_ADDR_EQUAL IN6_ADDR_EQUAL

extern inline
BOOLEAN
IN6_IS_ADDR_UNSPECIFIED(CONST IN6_ADDR *a)
{
    //
    // We can't use the in6addr_any variable, since that would
    // require existing callers to link with a specific library.
    //
    return (BOOLEAN)((a->u.Word[0] == 0) &&
                     (a->u.Word[1] == 0) &&
                     (a->u.Word[2] == 0) &&
                     (a->u.Word[3] == 0) &&
                     (a->u.Word[4] == 0) &&
                     (a->u.Word[5] == 0) &&
                     (a->u.Word[6] == 0) &&
                     (a->u.Word[7] == 0));
}

extern inline
BOOLEAN
IN6_IS_ADDR_LOOPBACK(CONST IN6_ADDR *a)
{
    //
    // We can't use the in6addr_loopback variable, since that would
    // require existing callers to link with a specific library.
    //
    return (BOOLEAN)((a->u.Word[0] == 0) &&
                     (a->u.Word[1] == 0) &&
                     (a->u.Word[2] == 0) &&
                     (a->u.Word[3] == 0) &&
                     (a->u.Word[4] == 0) &&
                     (a->u.Word[5] == 0) &&
                     (a->u.Word[6] == 0) &&
                     (a->u.Word[7] == 0x0100));
}

extern inline
BOOLEAN
IN6_IS_ADDR_MULTICAST(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(a->u.Byte[0] == 0xff);
}

//
//  Does the address have a format prefix
//  that indicates it uses EUI-64 interface identifiers?
//
extern inline
BOOLEAN
IN6_IS_ADDR_EUI64(CONST IN6_ADDR *a)
{
    //
    // Format prefixes 001 through 111, except for multicast.
    //
    return (BOOLEAN)(((a->u.Byte[0] & 0xe0) != 0) &&
                     !IN6_IS_ADDR_MULTICAST(a));
}

//
//  Is this the subnet router anycast address?
//  See RFC 2373.
//
extern inline
BOOLEAN
IN6_IS_ADDR_SUBNET_ROUTER_ANYCAST(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_EUI64(a) &&
                     (a->u.Word[4] == 0) &&
                     (a->u.Word[5] == 0) &&
                     (a->u.Word[6] == 0) &&
                     (a->u.Word[7] == 0));
}

//
//  Is this a subnet reserved anycast address?
//  See RFC 2526. It talks about non-EUI-64
//  addresses as well, but IMHO that part
//  of the RFC doesn't make sense. For example,
//  it shouldn't apply to multicast or v4-compatible
//  addresses.
//
extern inline
BOOLEAN
IN6_IS_ADDR_SUBNET_RESERVED_ANYCAST(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_EUI64(a) &&
                     (a->u.Word[4] == 0xfffd) &&
                     (a->u.Word[5] == 0xffff) &&
                     (a->u.Word[6] == 0xffff) &&
                     ((a->u.Word[7] & 0x80ff) == 0x80ff));
}

//
//  As best we can tell from simple inspection,
//  is this an anycast address?
//
extern inline
BOOLEAN
IN6_IS_ADDR_ANYCAST(CONST IN6_ADDR *a)
{
    return (IN6_IS_ADDR_SUBNET_RESERVED_ANYCAST(a) ||
            IN6_IS_ADDR_SUBNET_ROUTER_ANYCAST(a));
}

extern inline
BOOLEAN
IN6_IS_ADDR_LINKLOCAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)((a->u.Byte[0] == 0xfe) &&
                     ((a->u.Byte[1] & 0xc0) == 0x80));
}

extern inline
BOOLEAN
IN6_IS_ADDR_SITELOCAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)((a->u.Byte[0] == 0xfe) &&
                     ((a->u.Byte[1] & 0xc0) == 0xc0));
}

extern inline
BOOLEAN
IN6_IS_ADDR_GLOBAL(CONST IN6_ADDR *a)
{
    //
    // Check the format prefix and exclude addresses
    // whose high 4 bits are all zero or all one.
    // This is a cheap way of excluding v4-compatible,
    // v4-mapped, loopback, multicast, link-local, site-local.
    //
    ULONG High = (a->u.Byte[0] & 0xf0);
    return (BOOLEAN)((High != 0) && (High != 0xf0));
}

extern inline
BOOLEAN
IN6_IS_ADDR_V4MAPPED(CONST IN6_ADDR *a)
{
    return (BOOLEAN)((a->u.Word[0] == 0) &&
                     (a->u.Word[1] == 0) &&
                     (a->u.Word[2] == 0) &&
                     (a->u.Word[3] == 0) &&
                     (a->u.Word[4] == 0) &&
                     (a->u.Word[5] == 0xffff));
}

extern inline
BOOLEAN
IN6_IS_ADDR_V4COMPAT(CONST IN6_ADDR *a)
{
    return (BOOLEAN)((a->u.Word[0] == 0) &&
                     (a->u.Word[1] == 0) &&
                     (a->u.Word[2] == 0) &&
                     (a->u.Word[3] == 0) &&
                     (a->u.Word[4] == 0) &&
                     (a->u.Word[5] == 0) &&
                     !((a->u.Word[6] == 0) &&
                       (a->u.Byte[14] == 0) &&
                       ((a->u.Byte[15] == 0) || (a->u.Byte[15] == 1))));
}

extern inline
BOOLEAN
IN6_IS_ADDR_V4TRANSLATED(CONST IN6_ADDR *a)
{
    return (BOOLEAN)((a->u.Word[0] == 0) &&
                     (a->u.Word[1] == 0) &&
                     (a->u.Word[2] == 0) &&
                     (a->u.Word[3] == 0) &&
                     (a->u.Word[4] == 0xffff) &&
                     (a->u.Word[5] == 0));
}

extern inline
BOOLEAN
IN6_IS_ADDR_MC_NODELOCAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_MULTICAST(a) &&
                     ((a->u.Byte[1] & 0xf) == 1));
}

extern inline
BOOLEAN
IN6_IS_ADDR_MC_LINKLOCAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_MULTICAST(a) &&
                     ((a->u.Byte[1] & 0xf) == 2));
}

extern inline
BOOLEAN
IN6_IS_ADDR_MC_SITELOCAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_MULTICAST(a) &&
                     ((a->u.Byte[1] & 0xf) == 5));
}

extern inline
BOOLEAN
IN6_IS_ADDR_MC_ORGLOCAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_MULTICAST(a) &&
                     ((a->u.Byte[1] & 0xf) == 8));
}

extern inline
BOOLEAN
IN6_IS_ADDR_MC_GLOBAL(CONST IN6_ADDR *a)
{
    return (BOOLEAN)(IN6_IS_ADDR_MULTICAST(a) &&
                     ((a->u.Byte[1] & 0xf) == 0xe));
}

extern inline
VOID
IN6_SET_ADDR_UNSPECIFIED(PIN6_ADDR a)
{
    //
    // We can't use the in6addr_any variable, since that would
    // require existing callers to link with a specific library.
    //
    memset(a->u.Byte, 0, sizeof(IN6_ADDR));
}

extern inline
VOID
IN6_SET_ADDR_LOOPBACK(PIN6_ADDR a)
{
    //
    // We can't use the in6addr_loopback variable, since that would
    // require existing callers to link with a specific library.
    //
    memset(a->u.Byte, 0, sizeof(IN6_ADDR));
    a->u.Byte[15] = 1;
}

extern inline
VOID
IN6ADDR_SETANY(PSOCKADDR_IN6 a)
{
    a->sin6_family = AF_INET6;
    a->sin6_port = 0;
    a->sin6_flowinfo = 0;
    IN6_SET_ADDR_UNSPECIFIED(&a->sin6_addr);
    a->sin6_scope_id = 0;
}

extern inline
VOID
IN6ADDR_SETLOOPBACK(PSOCKADDR_IN6 a)
{
    a->sin6_family = AF_INET6;
    a->sin6_port = 0;
    a->sin6_flowinfo = 0;
    IN6_SET_ADDR_LOOPBACK(&a->sin6_addr);
    a->sin6_scope_id = 0;
}

extern inline
BOOLEAN
IN6ADDR_ISANY(CONST SOCKADDR_IN6 *a)
{
    ((VOID) 0);
    return IN6_IS_ADDR_UNSPECIFIED(&a->sin6_addr);
}

extern inline
BOOLEAN
IN6ADDR_ISLOOPBACK(CONST SOCKADDR_IN6 *a)
{
    ((VOID) 0);
    return IN6_IS_ADDR_LOOPBACK(&a->sin6_addr);
}

extern inline
BOOLEAN
IN6ADDR_ISEQUAL(CONST SOCKADDR_IN6 *a, CONST SOCKADDR_IN6 *b)
{
    ((VOID) 0);
    return (BOOLEAN)(a->sin6_scope_id == b->sin6_scope_id &&
                     IN6_ADDR_EQUAL(&a->sin6_addr, &b->sin6_addr));
}

extern inline
BOOLEAN
IN6ADDR_ISUNSPECIFIED(CONST SOCKADDR_IN6 *a)
{
    ((VOID) 0);
    return (BOOLEAN)(a->sin6_scope_id == 0 &&
                     IN6_IS_ADDR_UNSPECIFIED(&a->sin6_addr));
}





//
// TCP/IP specific Ioctl codes.
//
#define SIO_GET_INTERFACE_LIST _IOR('t', 127, ULONG)
#define SIO_GET_INTERFACE_LIST_EX _IOR('t', 126, ULONG)
#define SIO_SET_MULTICAST_FILTER _IOW('t', 125, ULONG)
#define SIO_GET_MULTICAST_FILTER _IOW('t', 124 | IOC_IN, ULONG)
#define SIOCSIPMSFILTER SIO_SET_MULTICAST_FILTER
#define SIOCGIPMSFILTER SIO_GET_MULTICAST_FILTER

//
// Protocol independent ioctls for setting and retrieving multicast filters. 
//
#define SIOCSMSFILTER _IOW('t', 126, ULONG)
#define SIOCGMSFILTER _IOW('t', 127 | IOC_IN, ULONG)



#define IDEAL_SEND_BACKLOG_IOCTLS 

//
// Query and change notification ioctls for the ideal send backlog size
// for a given connection. Clients should use the wrappers defined in 
// ws2tcpip.h rather than using these ioctls directly.
//

#define SIO_IDEAL_SEND_BACKLOG_QUERY _IOR('t', 123, ULONG)
#define SIO_IDEAL_SEND_BACKLOG_CHANGE _IO('t', 122)



//
// Protocol independent multicast source filter options.
//
#define MCAST_JOIN_GROUP 41
#define MCAST_LEAVE_GROUP 42
#define MCAST_BLOCK_SOURCE 43
#define MCAST_UNBLOCK_SOURCE 44
#define MCAST_JOIN_SOURCE_GROUP 45
#define MCAST_LEAVE_SOURCE_GROUP 46

//
// Definitions of MCAST_INCLUDE and MCAST_EXCLUDE for multicast source filter. 
//
typedef enum {
    MCAST_INCLUDE = 0,
    MCAST_EXCLUDE
} MULTICAST_MODE_TYPE;

//
// Structure for IP_MREQ (used by IP_ADD_MEMBERSHIP and IP_DROP_MEMBERSHIP). 
//
typedef struct ip_mreq {
    IN_ADDR imr_multiaddr; // IP multicast address of group.
    IN_ADDR imr_interface; // Local IP address of interface.
} IP_MREQ, *PIP_MREQ;

//
// Structure for IP_MREQ_SOURCE (used by IP_BLOCK_SOURCE, IP_UNBLOCK_SOURCE
// etc.). 
//
typedef struct ip_mreq_source {
    IN_ADDR imr_multiaddr; // IP multicast address of group.
    IN_ADDR imr_sourceaddr; // IP address of source.
    IN_ADDR imr_interface; // Local IP address of interface.
} IP_MREQ_SOURCE, *PIP_MREQ_SOURCE;

//
// Structure for IP_MSFILTER (used by SIOCSIPMSFILTER and SIOCGIPMSFILTER). 
// 
typedef struct ip_msfilter {
    IN_ADDR imsf_multiaddr; // IP multicast address of group.
    IN_ADDR imsf_interface; // Local IP address of interface.
    MULTICAST_MODE_TYPE imsf_fmode; // Filter mode.
    ULONG imsf_numsrc; // Number of sources in src_list.
    IN_ADDR imsf_slist[1]; // Start of source list.
} IP_MSFILTER, *PIP_MSFILTER;

#define IP_MSFILTER_SIZE(NumSources) (sizeof(IP_MSFILTER) - sizeof(IN_ADDR) + (NumSources) * sizeof(IN_ADDR))


//
// Options to use with [gs]etsockopt at the IPPROTO_IPV6 level.
// These are specified in RFCs 3493 and 3542.
// The values should be consistent with the IPv6 equivalents.
//
#define IPV6_HOPOPTS 1
#define IPV6_HDRINCL 2
#define IPV6_UNICAST_HOPS 4
#define IPV6_MULTICAST_IF 9
#define IPV6_MULTICAST_HOPS 10
#define IPV6_MULTICAST_LOOP 11
#define IPV6_ADD_MEMBERSHIP 12
#define IPV6_JOIN_GROUP IPV6_ADD_MEMBERSHIP
#define IPV6_DROP_MEMBERSHIP 13
#define IPV6_LEAVE_GROUP IPV6_DROP_MEMBERSHIP
#define IPV6_DONTFRAG 14
#define IPV6_PKTINFO 19
#define IPV6_HOPLIMIT 21
#define IPV6_PROTECTION_LEVEL 23
#define IPV6_RECVIF 24
#define IPV6_RECVDSTADDR 25
#define IPV6_CHECKSUM 26
#define IPV6_V6ONLY 27
#define IPV6_IFLIST 28
#define IPV6_ADD_IFLIST 29
#define IPV6_DEL_IFLIST 30
#define IPV6_UNICAST_IF 31
#define IPV6_RTHDR 32
#define IPV6_RECVRTHDR 38
#define IPV6_TCLASS 39
#define IPV6_RECVTCLASS 40

#define IP_UNSPECIFIED_HOP_LIMIT -1

#define IP_PROTECTION_LEVEL IPV6_PROTECTION_LEVEL
//
// Values of IPV6_PROTECTION_LEVEL.
//
#define PROTECTION_LEVEL_UNRESTRICTED 10
#define PROTECTION_LEVEL_EDGERESTRICTED 20
                                           // Teredo.
#define PROTECTION_LEVEL_RESTRICTED 30




#define PROTECTION_LEVEL_DEFAULT ((UINT)-1)

//
// Structure for IPV6_JOIN_GROUP and IPV6_LEAVE_GROUP (also,
// IPV6_ADD_MEMBERSHIP and IPV6_DROP_MEMBERSHIP).
//
typedef struct ipv6_mreq {
    IN6_ADDR ipv6mr_multiaddr; // IPv6 multicast address.
    ULONG ipv6mr_interface; // Interface index.
} IPV6_MREQ, *PIPV6_MREQ;


//
// Structure for GROUP_REQ used by protocol independent source filters
// (MCAST_JOIN_GROUP and MCAST_LEAVE_GROUP). 
//
typedef struct group_req {
    ULONG gr_interface; // Interface index.
    SOCKADDR_STORAGE gr_group; // Multicast address.
} GROUP_REQ, *PGROUP_REQ;

//
// Structure for GROUP_SOURCE_REQ used by protocol independent source filters
// (MCAST_JOIN_SOURCE_GROUP, MCAST_LEAVE_SOURCE_GROUP etc.).
//
typedef struct group_source_req {
    ULONG gsr_interface; // Interface index.
    SOCKADDR_STORAGE gsr_group; // Group address.
    SOCKADDR_STORAGE gsr_source; // Source address.
} GROUP_SOURCE_REQ, *PGROUP_SOURCE_REQ;

//
// Structure for GROUP_FILTER used by protocol independent source filters
// (SIOCSMSFILTER and SIOCGMSFILTER).
//
typedef struct group_filter {
    ULONG gf_interface; // Interface index.
    SOCKADDR_STORAGE gf_group; // Multicast address.
    MULTICAST_MODE_TYPE gf_fmode; // Filter mode.
    ULONG gf_numsrc; // Number of sources.
    SOCKADDR_STORAGE gf_slist[1]; // Source address.
} GROUP_FILTER, *PGROUP_FILTER;

#define GROUP_FILTER_SIZE(numsrc) (sizeof(GROUP_FILTER) - sizeof(SOCKADDR_STORAGE) + (numsrc) * sizeof(SOCKADDR_STORAGE))




//
// Structure for IP_PKTINFO option.
//
typedef struct in_pktinfo {
    IN_ADDR ipi_addr; // Source/destination IPv4 address.
    ULONG ipi_ifindex; // Send/receive interface index.
} IN_PKTINFO, *PIN_PKTINFO;

C_ASSERT(sizeof(IN_PKTINFO) == 8);

//
// Structure for IPV6_PKTINFO option.
//
typedef struct in6_pktinfo {
    IN6_ADDR ipi6_addr; // Source/destination IPv6 address.
    ULONG ipi6_ifindex; // Send/receive interface index.
} IN6_PKTINFO, *PIN6_PKTINFO;

C_ASSERT(sizeof(IN6_PKTINFO) == 20);

//
// Maximum length of address literals (potentially including a port number)
// generated by any address-to-string conversion routine.  This length can
// be used when declaring buffers used with getnameinfo, WSAAddressToString,
// inet_ntoa, etc.  We just provide one define, rather than one per api,
// to avoid confusion.
//
// The totals are derived from the following data:
//  15: IPv4 address
//  45: IPv6 address including embedded IPv4 address
//  11: Scope Id
//   2: Brackets around IPv6 address when port is present
//   6: Port (including colon)
//   1: Terminating null byte
//
#define INET_ADDRSTRLEN 22
#define INET6_ADDRSTRLEN 65



//
// Options to use with [gs]etsockopt at the IPPROTO_TCP level.
// TCP_NODELAY is defined in ws2def.h for historical reasons.
//

//
// Offload preferences supported.
//
#define TCP_OFFLOAD_NO_PREFERENCE 0
#define TCP_OFFLOAD_NOT_PREFERRED 1
#define TCP_OFFLOAD_PREFERRED 2

//      TCP_NODELAY         	 0x0001
#define TCP_EXPEDITED_1122 0x0002
#define TCP_KEEPALIVE 3
#define TCP_MAXSEG 4
#define TCP_MAXRT 5
#define TCP_STDURG 6
#define TCP_NOURG 7
#define TCP_ATMARK 8
#define TCP_NOSYNRETRIES 9
#define TCP_TIMESTAMPS 10
#define TCP_OFFLOAD_PREFERENCE 11
#define TCP_CONGESTION_ALGORITHM 12
#define TCP_DELAY_FIN_ACK 13





#pragma warning(pop)
