# 1 "c_include/windows/original/stdlib.h"
#define __STDC__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __STDC_HOSTED__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __GNUC__ 4
# 1 "c_include/windows/original/stdlib.h"
#define __GNUC_MINOR__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __GNUC_PATCHLEVEL__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __VERSION__ "4.8.1 20130328 (prerelease)"
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_RELAXED 0
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_SEQ_CST 5
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_ACQUIRE 2
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_RELEASE 3
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_ACQ_REL 4
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_CONSUME 1
# 1 "c_include/windows/original/stdlib.h"
#define __pic__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __PIC__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __FINITE_MATH_ONLY__ 0
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_INT__ 4
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_LONG__ 4
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_LONG_LONG__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_SHORT__ 2
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_FLOAT__ 4
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_DOUBLE__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_LONG_DOUBLE__ 16
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_SIZE_T__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __CHAR_BIT__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __BIGGEST_ALIGNMENT__ 16
# 1 "c_include/windows/original/stdlib.h"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 1 "c_include/windows/original/stdlib.h"
#define __ORDER_BIG_ENDIAN__ 4321
# 1 "c_include/windows/original/stdlib.h"
#define __ORDER_PDP_ENDIAN__ 3412
# 1 "c_include/windows/original/stdlib.h"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/stdlib.h"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_POINTER__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __SIZE_TYPE__ long long unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __PTRDIFF_TYPE__ long long int
# 1 "c_include/windows/original/stdlib.h"
#define __WCHAR_TYPE__ short unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __WINT_TYPE__ short unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __INTMAX_TYPE__ long long int
# 1 "c_include/windows/original/stdlib.h"
#define __UINTMAX_TYPE__ long long unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __CHAR16_TYPE__ short unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __CHAR32_TYPE__ unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __SIG_ATOMIC_TYPE__ int
# 1 "c_include/windows/original/stdlib.h"
#define __INT8_TYPE__ signed char
# 1 "c_include/windows/original/stdlib.h"
#define __INT16_TYPE__ short int
# 1 "c_include/windows/original/stdlib.h"
#define __INT32_TYPE__ int
# 1 "c_include/windows/original/stdlib.h"
#define __INT64_TYPE__ long long int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT8_TYPE__ unsigned char
# 1 "c_include/windows/original/stdlib.h"
#define __UINT16_TYPE__ short unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT32_TYPE__ unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST8_TYPE__ signed char
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST16_TYPE__ short int
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST32_TYPE__ int
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST64_TYPE__ long long int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST8_TYPE__ signed char
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST16_TYPE__ short int
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST32_TYPE__ int
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST64_TYPE__ long long int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __INTPTR_TYPE__ long long int
# 1 "c_include/windows/original/stdlib.h"
#define __UINTPTR_TYPE__ long long unsigned int
# 1 "c_include/windows/original/stdlib.h"
#define __GXX_ABI_VERSION 1002
# 1 "c_include/windows/original/stdlib.h"
#define __SCHAR_MAX__ 127
# 1 "c_include/windows/original/stdlib.h"
#define __SHRT_MAX__ 32767
# 1 "c_include/windows/original/stdlib.h"
#define __INT_MAX__ 2147483647
# 1 "c_include/windows/original/stdlib.h"
#define __LONG_MAX__ 2147483647L
# 1 "c_include/windows/original/stdlib.h"
#define __LONG_LONG_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __WCHAR_MAX__ 65535
# 1 "c_include/windows/original/stdlib.h"
#define __WCHAR_MIN__ 0
# 1 "c_include/windows/original/stdlib.h"
#define __WINT_MAX__ 65535
# 1 "c_include/windows/original/stdlib.h"
#define __WINT_MIN__ 0
# 1 "c_include/windows/original/stdlib.h"
#define __PTRDIFF_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __SIZE_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/stdlib.h"
#define __INTMAX_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __INTMAX_C(c) c ## LL
# 1 "c_include/windows/original/stdlib.h"
#define __UINTMAX_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/stdlib.h"
#define __UINTMAX_C(c) c ## ULL
# 1 "c_include/windows/original/stdlib.h"
#define __SIG_ATOMIC_MAX__ 2147483647
# 1 "c_include/windows/original/stdlib.h"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 1 "c_include/windows/original/stdlib.h"
#define __INT8_MAX__ 127
# 1 "c_include/windows/original/stdlib.h"
#define __INT16_MAX__ 32767
# 1 "c_include/windows/original/stdlib.h"
#define __INT32_MAX__ 2147483647
# 1 "c_include/windows/original/stdlib.h"
#define __INT64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __UINT8_MAX__ 255
# 1 "c_include/windows/original/stdlib.h"
#define __UINT16_MAX__ 65535
# 1 "c_include/windows/original/stdlib.h"
#define __UINT32_MAX__ 4294967295U
# 1 "c_include/windows/original/stdlib.h"
#define __UINT64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST8_MAX__ 127
# 1 "c_include/windows/original/stdlib.h"
#define __INT8_C(c) c
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST16_MAX__ 32767
# 1 "c_include/windows/original/stdlib.h"
#define __INT16_C(c) c
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST32_MAX__ 2147483647
# 1 "c_include/windows/original/stdlib.h"
#define __INT32_C(c) c
# 1 "c_include/windows/original/stdlib.h"
#define __INT_LEAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __INT64_C(c) c ## LL
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST8_MAX__ 255
# 1 "c_include/windows/original/stdlib.h"
#define __UINT8_C(c) c
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST16_MAX__ 65535
# 1 "c_include/windows/original/stdlib.h"
#define __UINT16_C(c) c
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/stdlib.h"
#define __UINT32_C(c) c ## U
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/stdlib.h"
#define __UINT64_C(c) c ## ULL
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST8_MAX__ 127
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST16_MAX__ 32767
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST32_MAX__ 2147483647
# 1 "c_include/windows/original/stdlib.h"
#define __INT_FAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST8_MAX__ 255
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST16_MAX__ 65535
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/stdlib.h"
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/stdlib.h"
#define __INTPTR_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/stdlib.h"
#define __UINTPTR_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_EVAL_METHOD__ 0
# 1 "c_include/windows/original/stdlib.h"
#define __DEC_EVAL_METHOD__ 2
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_RADIX__ 2
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MANT_DIG__ 24
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_DIG__ 6
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MIN_EXP__ (-125)
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MIN_10_EXP__ (-37)
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MAX_EXP__ 128
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MAX_10_EXP__ 38
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_DECIMAL_DIG__ 9
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MAX__ 3.40282346638528859812e+38F
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_MIN__ 1.17549435082228750797e-38F
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_EPSILON__ 1.19209289550781250000e-7F
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_DENORM_MIN__ 1.40129846432481707092e-45F
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_HAS_DENORM__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_HAS_INFINITY__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __FLT_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MANT_DIG__ 53
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_DIG__ 15
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MIN_EXP__ (-1021)
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MIN_10_EXP__ (-307)
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MAX_EXP__ 1024
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MAX_10_EXP__ 308
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_DECIMAL_DIG__ 17
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MAX__ ((double)1.79769313486231570815e+308L)
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_MIN__ ((double)2.22507385850720138309e-308L)
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_EPSILON__ ((double)2.22044604925031308085e-16L)
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_DENORM_MIN__ ((double)4.94065645841246544177e-324L)
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __DBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MANT_DIG__ 64
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_DIG__ 18
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MIN_EXP__ (-16381)
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MIN_10_EXP__ (-4931)
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MAX_EXP__ 16384
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MAX_10_EXP__ 4932
# 1 "c_include/windows/original/stdlib.h"
#define __DECIMAL_DIG__ 21
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __LDBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_MANT_DIG__ 7
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_MIN_EXP__ (-94)
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_MAX_EXP__ 97
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_MIN__ 1E-95DF
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_MAX__ 9.999999E96DF
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_EPSILON__ 1E-6DF
# 1 "c_include/windows/original/stdlib.h"
#define __DEC32_SUBNORMAL_MIN__ 0.000001E-95DF
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_MANT_DIG__ 16
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_MIN_EXP__ (-382)
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_MAX_EXP__ 385
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_MIN__ 1E-383DD
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_MAX__ 9.999999999999999E384DD
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_EPSILON__ 1E-15DD
# 1 "c_include/windows/original/stdlib.h"
#define __DEC64_SUBNORMAL_MIN__ 0.000000000000001E-383DD
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_MANT_DIG__ 34
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_MIN_EXP__ (-6142)
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_MAX_EXP__ 6145
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_MIN__ 1E-6143DL
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_EPSILON__ 1E-33DL
# 1 "c_include/windows/original/stdlib.h"
#define __DEC128_SUBNORMAL_MIN__ 0.000000000000000000000000000000001E-6143DL
# 1 "c_include/windows/original/stdlib.h"
#define __REGISTER_PREFIX__ 
# 1 "c_include/windows/original/stdlib.h"
#define __USER_LABEL_PREFIX__ 
# 1 "c_include/windows/original/stdlib.h"
#define __GNUC_GNU_INLINE__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __NO_INLINE__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 1 "c_include/windows/original/stdlib.h"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 1 "c_include/windows/original/stdlib.h"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_INT128__ 16
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_WCHAR_T__ 2
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_WINT_T__ 2
# 1 "c_include/windows/original/stdlib.h"
#define __SIZEOF_PTRDIFF_T__ 8
# 1 "c_include/windows/original/stdlib.h"
#define __amd64 1
# 1 "c_include/windows/original/stdlib.h"
#define __amd64__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __x86_64 1
# 1 "c_include/windows/original/stdlib.h"
#define __x86_64__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_HLE_ACQUIRE 65536
# 1 "c_include/windows/original/stdlib.h"
#define __ATOMIC_HLE_RELEASE 131072
# 1 "c_include/windows/original/stdlib.h"
#define __k8 1
# 1 "c_include/windows/original/stdlib.h"
#define __k8__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __code_model_small__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __MMX__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __SSE__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __SSE2__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __SSE_MATH__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __SSE2_MATH__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __SEH__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/stdlib.h"
#define __fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/stdlib.h"
#define __thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/stdlib.h"
#define __cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/stdlib.h"
#define _stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/stdlib.h"
#define _fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/stdlib.h"
#define _thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/stdlib.h"
#define _cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/stdlib.h"
#define __GXX_MERGED_TYPEINFO_NAMES 0
# 1 "c_include/windows/original/stdlib.h"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 1 "c_include/windows/original/stdlib.h"
#define __MSVCRT__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __MINGW32__ 1
# 1 "c_include/windows/original/stdlib.h"
#define _WIN32 1
# 1 "c_include/windows/original/stdlib.h"
#define __WIN32 1
# 1 "c_include/windows/original/stdlib.h"
#define __WIN32__ 1
# 1 "c_include/windows/original/stdlib.h"
#define WIN32 1
# 1 "c_include/windows/original/stdlib.h"
#define __WINNT 1
# 1 "c_include/windows/original/stdlib.h"
#define __WINNT__ 1
# 1 "c_include/windows/original/stdlib.h"
#define WINNT 1
# 1 "c_include/windows/original/stdlib.h"
#define _INTEGRAL_MAX_BITS 64
# 1 "c_include/windows/original/stdlib.h"
#define __MINGW64__ 1
# 1 "c_include/windows/original/stdlib.h"
#define __WIN64 1
# 1 "c_include/windows/original/stdlib.h"
#define __WIN64__ 1
# 1 "c_include/windows/original/stdlib.h"
#define WIN64 1
# 1 "c_include/windows/original/stdlib.h"
#define _WIN64 1
# 1 "c_include/windows/original/stdlib.h"
#define __declspec(x) __attribute__((x))
# 1 "c_include/windows/original/stdlib.h"
#define __DECIMAL_BID_FORMAT__ 1
# 1 "<command-line>"
#undef _REENTRANT
# 1 "c_include/windows/original/stdlib.h"
#define _WIN32_WINNT 0x0602
#define WINVER _WIN32_WINNT
#define WIN32_LEAN_AND_MEAN 
#pragma comment (lib, "Ws2_32.lib")
/***
*stdlib.h - declarations/definitions for commonly used library functions
*
*       Copyright (c) Microsoft Corporation. All rights reserved.
*
*Purpose:
*       This include file contains the function declarations for commonly
*       used library functions which either don't fit somewhere else, or,
*       cannot be declared in the normal place for other reasons.
*       [ANSI]
*
*       [Public]
*
****/

       


#define _INC_STDLIB 

# 1 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h" 1
/***

*crtdefs.h - definitions/declarations common to all CRT

*

*       Copyright (c) Microsoft Corporation. All rights reserved.

*

*Purpose:

*       This file has mostly defines used by the entire CRT.

*

*       [Public]

*

****/
# 13 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
/* Lack of pragma once is deliberate */

/* Define _CRTIMP */




#define _CRTIMP 




#define _INC_CRTDEFS 
# 47 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
/* Note on use of "deprecate":

 * Various places in this header and other headers use __declspec(deprecate) or macros that have the term DEPRECATE in them.

 * We use deprecate here ONLY to signal the compiler to emit a warning about these items. The use of deprecate

 * should NOT be taken to imply that any standard committee has deprecated these functions from the relevant standards.

 * In fact, these functions are NOT deprecated from the standard.

 *

 * Full details can be found in our documentation by searching for "Security Enhancements in the CRT".

*/
# 56 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
# 1 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h" 1
/***

*sal.h - markers for documenting the semantics of APIs

*

*       Copyright (c) Microsoft Corporation. All rights reserved.

*

*Purpose:

*       sal.h provides a set of annotations to describe how a function uses its

*       parameters - the assumptions it makes about them, and the guarantees it makes

*       upon finishing.

*

*       [Public]

*

****/
# 15 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
       
/*==========================================================================



   The macros are defined in 3 layers:



   _In_\_Out_ Layer:

   ----------------

   This layer provides the highest abstraction and its macros should be used

   in most cases. Its macros start with _In_, _Out_ or _Inout_. For the

   typical case they provide the most concise annotations.



   _Pre_\_Post_ Layer:

   ------------------

   The macros of this layer only should be used when there is no suitable macro

   in the _In_\_Out_ layer. Its macros start with _Pre_, _Post_, _Ret_,

   _Deref_pre_ _Deref_post_ and _Deref_ret_. This layer provides the most

   flexibility for annotations.



   Implementation Abstraction Layer:

   --------------------------------

   Macros from this layer should never be used directly. The layer only exists

   to hide the implementation of the annotation macros.





   Annotation Syntax:

   |--------------|----------|----------------|-----------------------------|

   |   Usage      | Nullness | ZeroTerminated |  Extent                     |

   |--------------|----------|----------------|-----------------------------|

   | _In_         | <>       | <>             | <>                          |

   | _Out_        | opt_     | z_             | [byte]cap_[c_|x_]( size )   |

   | _Inout_      |          |                | [byte]count_[c_|x_]( size ) |

   | _Deref_out_  |          |                | ptrdiff_cap_( ptr )         |

   |--------------|          |                | ptrdiff_count_( ptr )       |

   | _Ret_        |          |                |                             |

   | _Deref_ret_  |          |                |                             |

   |--------------|          |                |                             |

   | _Pre_        |          |                |                             |

   | _Post_       |          |                |                             |

   | _Deref_pre_  |          |                |                             |

   | _Deref_post_ |          |                |                             |

   |--------------|----------|----------------|-----------------------------|



   Usage:

   -----

   _In_, _Out_, _Inout_, _Pre_, _Post_, _Deref_pre_, _Deref_post_ are for

   formal parameters.

   _Ret_, _Deref_ret_ must be used for return values.



   Nullness:

   --------

   If the pointer can be NULL the annotation contains _opt. If the macro

   does not contain '_opt' the pointer may not be NULL.



   String Type:

   -----------

   _z: NullTerminated string

   for _In_ parameters the buffer must have the specified stringtype before the call

   for _Out_ parameters the buffer must have the specified stringtype after the call

   for _Inout_ parameters both conditions apply



   Extent Syntax:

   |------|---------------|---------------|

   | Unit | Writ\Readable | Argument Type |

   |------|---------------|---------------|

   |  <>  | cap_          | <>            |

   | byte | count_        | c_            |

   |      |               | x_            |

   |------|---------------|---------------|



   'cap' (capacity) describes the writable size of the buffer and is typically used

   with _Out_. The default unit is elements. Use 'bytecap' if the size is given in bytes

   'count' describes the readable size of the buffer and is typically used with _In_.

   The default unit is elements. Use 'bytecount' if the size is given in bytes.

   

   Argument syntax for cap_, bytecap_, count_, bytecount_:

   (<parameter>|return)[+n]  e.g. cch, return, cb+2

   

   If the buffer size is a constant expression use the c_ postfix.

   E.g. cap_c_(20), count_c_(MAX_PATH), bytecount_c_(16)



   If the buffer size is given by a limiting pointer use the ptrdiff_ versions

   of the macros.



   If the buffer size is neither a parameter nor a constant expression use the x_

   postfix. e.g. bytecount_x_(num*size) x_ annotations accept any arbitrary string.

   No analysis can be done for x_ annotations but they at least tell the tool that

   the buffer has some sort of extent description. x_ annotations might be supported

   by future compiler versions.



============================================================================*/
# 106 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define __ATTR_SAL 
# 140 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
// Disable expansion of SAL macros in non-Prefast mode to 
// improve compiler throughput.

#define _USE_DECLSPECS_FOR_SAL 0


#define _USE_ATTRIBUTES_FOR_SAL 0


// safeguard for MIDL and RC builds
# 163 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
//============================================================================
//   _In_\_Out_ Layer:
//============================================================================

// 'in' parameters --------------------------

// input pointer parameter
// e.g. void SetPoint( _In_ const POINT* pPT );
#define _In_ _Pre1_impl_(_$notnull) _Deref_pre2_impl_(_$valid, _$readaccess)
#define _In_opt_ _Pre_opt_valid_ _Deref_pre_readonly_

// nullterminated 'in' parameters.
// e.g. void CopyStr( _In_z_ const char* szFrom, _Out_z_cap_(cchTo) char* szTo, size_t cchTo );
#define _In_z_ _Pre_z_ _Deref_pre_readonly_
#define _In_opt_z_ _Pre_opt_z_ _Deref_pre_readonly_

// 'input' buffers with given size

// e.g. void SetCharRange( _In_count_(cch) const char* rgch, size_t cch )
// valid buffer extent described by another parameter
#define _In_count_(size) _Pre_count_(size) _Deref_pre_readonly_
#define _In_opt_count_(size) _Pre_opt_count_(size) _Deref_pre_readonly_
#define _In_bytecount_(size) _Pre_bytecount_(size) _Deref_pre_readonly_
#define _In_opt_bytecount_(size) _Pre_opt_bytecount_(size) _Deref_pre_readonly_

// valid buffer extent described by a constant extression
#define _In_count_c_(size) _Pre_count_c_(size) _Deref_pre_readonly_
#define _In_opt_count_c_(size) _Pre_opt_count_c_(size) _Deref_pre_readonly_
#define _In_bytecount_c_(size) _Pre_bytecount_c_(size) _Deref_pre_readonly_
#define _In_opt_bytecount_c_(size) _Pre_opt_bytecount_c_(size) _Deref_pre_readonly_

// nullterminated  'input' buffers with given size

// e.g. void SetCharRange( _In_count_(cch) const char* rgch, size_t cch )
// nullterminated valid buffer extent described by another parameter
#define _In_z_count_(size) _Pre_z_ _Pre_count_(size) _Deref_pre_readonly_
#define _In_opt_z_count_(size) _Pre_opt_z_ _Pre_opt_count_(size) _Deref_pre_readonly_
#define _In_z_bytecount_(size) _Pre_z_ _Pre_bytecount_(size) _Deref_pre_readonly_
#define _In_opt_z_bytecount_(size) _Pre_opt_z_ _Pre_opt_bytecount_(size) _Deref_pre_readonly_

// nullterminated valid buffer extent described by a constant extression
#define _In_z_count_c_(size) _Pre_z_ _Pre_count_c_(size) _Deref_pre_readonly_
#define _In_opt_z_count_c_(size) _Pre_opt_z_ _Pre_opt_count_c_(size) _Deref_pre_readonly_
#define _In_z_bytecount_c_(size) _Pre_z_ _Pre_bytecount_c_(size) _Deref_pre_readonly_
#define _In_opt_z_bytecount_c_(size) _Pre_opt_z_ _Pre_opt_bytecount_c_(size) _Deref_pre_readonly_

// buffer capacity is described by another pointer
// e.g. void Foo( _In_ptrdiff_count_(pchMax) const char* pch, const char* pchMax ) { while pch < pchMax ) pch++; }
#define _In_ptrdiff_count_(size) _Pre_ptrdiff_count_(size) _Deref_pre_readonly_
#define _In_opt_ptrdiff_count_(size) _Pre_opt_ptrdiff_count_(size) _Deref_pre_readonly_

// 'x' version for complex expressions that are not supported by the current compiler version
// e.g. void Set3ColMatrix( _In_count_x_(3*cRows) const Elem* matrix, int cRows );
#define _In_count_x_(size) _Pre_count_x_(size) _Deref_pre_readonly_
#define _In_opt_count_x_(size) _Pre_opt_count_x_(size) _Deref_pre_readonly_
#define _In_bytecount_x_(size) _Pre_bytecount_x_(size) _Deref_pre_readonly_
#define _In_opt_bytecount_x_(size) _Pre_opt_bytecount_x_(size) _Deref_pre_readonly_

// 'out' parameters --------------------------

// output pointer parameter
// e.g. void GetPoint( _Out_ POINT* pPT );
#define _Out_ _Pre_cap_c_(1) _Pre_invalid_
#define _Out_opt_ _Pre_opt_cap_c_(1) _Pre_invalid_

// 'out' with buffer size
// e.g. void GetIndeces( _Out_cap_(cIndeces) int* rgIndeces, size_t cIndices );
// buffer capacity is described by another parameter
#define _Out_cap_(size) _Pre_cap_(size) _Pre_invalid_
#define _Out_opt_cap_(size) _Pre_opt_cap_(size) _Pre_invalid_
#define _Out_bytecap_(size) _Pre_bytecap_(size) _Pre_invalid_
#define _Out_opt_bytecap_(size) _Pre_opt_bytecap_(size) _Pre_invalid_

// buffer capacity is described by a constant expression
#define _Out_cap_c_(size) _Pre_cap_c_(size) _Pre_invalid_
#define _Out_opt_cap_c_(size) _Pre_opt_cap_c_(size) _Pre_invalid_
#define _Out_bytecap_c_(size) _Pre_bytecap_c_(size) _Pre_invalid_
#define _Out_opt_bytecap_c_(size) _Pre_opt_bytecap_c_(size) _Pre_invalid_

// buffer capacity is described by another parameter multiplied by a constant expression
#define _Out_cap_m_(mult,size) _Pre_cap_m_(mult,size) _Pre_invalid_
#define _Out_opt_cap_m_(mult,size) _Pre_opt_cap_m_(mult,size) _Pre_invalid_
#define _Out_z_cap_m_(mult,size) _Pre_cap_m_(mult,size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_cap_m_(mult,size) _Pre_opt_cap_m_(mult,size) _Pre_invalid_ _Post_z_

// buffer capacity is described by another pointer
// e.g. void Foo( _Out_ptrdiff_cap_(pchMax) char* pch, const char* pchMax ) { while pch < pchMax ) pch++; }
#define _Out_ptrdiff_cap_(size) _Pre_ptrdiff_cap_(size) _Pre_invalid_
#define _Out_opt_ptrdiff_cap_(size) _Pre_opt_ptrdiff_cap_(size) _Pre_invalid_

// buffer capacity is described by a complex expression
#define _Out_cap_x_(size) _Pre_cap_x_(size) _Pre_invalid_
#define _Out_opt_cap_x_(size) _Pre_opt_cap_x_(size) _Pre_invalid_
#define _Out_bytecap_x_(size) _Pre_bytecap_x_(size) _Pre_invalid_
#define _Out_opt_bytecap_x_(size) _Pre_opt_bytecap_x_(size) _Pre_invalid_

// a zero terminated string is filled into a buffer of given capacity
// e.g. void CopyStr( _In_z_ const char* szFrom, _Out_z_cap_(cchTo) char* szTo, size_t cchTo );
// buffer capacity is described by another parameter
#define _Out_z_cap_(size) _Pre_cap_(size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_cap_(size) _Pre_opt_cap_(size) _Pre_invalid_ _Post_z_
#define _Out_z_bytecap_(size) _Pre_bytecap_(size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_bytecap_(size) _Pre_opt_bytecap_(size) _Pre_invalid_ _Post_z_

// buffer capacity is described by a constant expression
#define _Out_z_cap_c_(size) _Pre_cap_c_(size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_cap_c_(size) _Pre_opt_cap_c_(size) _Pre_invalid_ _Post_z_
#define _Out_z_bytecap_c_(size) _Pre_bytecap_c_(size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_bytecap_c_(size) _Pre_opt_bytecap_c_(size) _Pre_invalid_ _Post_z_

// buffer capacity is described by a complex expression
#define _Out_z_cap_x_(size) _Pre_cap_x_(size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_cap_x_(size) _Pre_opt_cap_x_(size) _Pre_invalid_ _Post_z_
#define _Out_z_bytecap_x_(size) _Pre_bytecap_x_(size) _Pre_invalid_ _Post_z_
#define _Out_opt_z_bytecap_x_(size) _Pre_opt_bytecap_x_(size) _Pre_invalid_ _Post_z_

// a zero terminated string is filled into a buffer of given capacity
// e.g. size_t CopyCharRange( _In_count_(cchFrom) const char* rgchFrom, size_t cchFrom, _Out_cap_post_count_(cchTo,return)) char* rgchTo, size_t cchTo );
#define _Out_cap_post_count_(cap,count) _Pre_cap_(cap) _Pre_invalid_ _Post_count_(count)
#define _Out_opt_cap_post_count_(cap,count) _Pre_opt_cap_(cap) _Pre_invalid_ _Post_count_(count)
#define _Out_bytecap_post_bytecount_(cap,count) _Pre_bytecap_(cap) _Pre_invalid_ _Post_bytecount_(count)
#define _Out_opt_bytecap_post_bytecount_(cap,count) _Pre_opt_bytecap_(cap) _Pre_invalid_ _Post_bytecount_(count)

// a zero terminated string is filled into a buffer of given capacity
// e.g. size_t CopyStr( _In_z_ const char* szFrom, _Out_z_cap_post_count_(cchTo,return+1) char* szTo, size_t cchTo );
#define _Out_z_cap_post_count_(cap,count) _Pre_cap_(cap) _Pre_invalid_ _Post_z_count_(count)
#define _Out_opt_z_cap_post_count_(cap,count) _Pre_opt_cap_(cap) _Pre_invalid_ _Post_z_count_(count)
#define _Out_z_bytecap_post_bytecount_(cap,count) _Pre_bytecap_(cap) _Pre_invalid_ _Post_z_bytecount_(count)
#define _Out_opt_z_bytecap_post_bytecount_(cap,count) _Pre_opt_bytecap_(cap) _Pre_invalid_ _Post_z_bytecount_(count)

// only use with dereferenced arguments e.g. '*pcch' 
#define _Out_capcount_(capcount) _Pre_cap_(capcount) _Pre_invalid_ _Post_count_(capcount)
#define _Out_opt_capcount_(capcount) _Pre_opt_cap_(capcount) _Pre_invalid_ _Post_count_(capcount)
#define _Out_bytecapcount_(capcount) _Pre_bytecap_(capcount) _Pre_invalid_ _Post_bytecount_(capcount)
#define _Out_opt_bytecapcount_(capcount) _Pre_opt_bytecap_(capcount) _Pre_invalid_ _Post_bytecount_(capcount)

#define _Out_capcount_x_(capcount) _Pre_cap_x_(capcount) _Pre_invalid_ _Post_count_x_(capcount)
#define _Out_opt_capcount_x_(capcount) _Pre_opt_cap_x_(capcount) _Pre_invalid_ _Post_count_x_(capcount)
#define _Out_bytecapcount_x_(capcount) _Pre_bytecap_x_(capcount) _Pre_invalid_ _Post_bytecount_x_(capcount)
#define _Out_opt_bytecapcount_x_(capcount) _Pre_opt_bytecap_x_(capcount) _Pre_invalid_ _Post_bytecount_x_(capcount)

// e.g. GetString( _Out_z_capcount_(*pLen+1) char* sz, size_t* pLen );
#define _Out_z_capcount_(capcount) _Pre_cap_(capcount) _Pre_invalid_ _Post_z_count_(capcount)
#define _Out_opt_z_capcount_(capcount) _Pre_opt_cap_(capcount) _Pre_invalid_ _Post_z_count_(capcount)
#define _Out_z_bytecapcount_(capcount) _Pre_bytecap_(capcount) _Pre_invalid_ _Post_z_bytecount_(capcount)
#define _Out_opt_z_bytecapcount_(capcount) _Pre_opt_bytecap_(capcount) _Pre_invalid_ _Post_z_bytecount_(capcount)

// inout parameters ----------------------------

// inout pointer parameter
// e.g. void ModifyPoint( _Inout_ POINT* pPT );
#define _Inout_ _Prepost_valid_
#define _Inout_opt_ _Prepost_opt_valid_

// string buffers
// e.g. void toupper( _Inout_z_ char* sz );
#define _Inout_z_ _Prepost_z_
#define _Inout_opt_z_ _Prepost_opt_z_

// 'inout' buffers with initialized elements before and after the call
// e.g. void ModifyIndices( _Inout_count_(cIndices) int* rgIndeces, size_t cIndices );
#define _Inout_count_(size) _Prepost_count_(size)
#define _Inout_opt_count_(size) _Prepost_opt_count_(size)
#define _Inout_bytecount_(size) _Prepost_bytecount_(size)
#define _Inout_opt_bytecount_(size) _Prepost_opt_bytecount_(size)

#define _Inout_count_c_(size) _Prepost_count_c_(size)
#define _Inout_opt_count_c_(size) _Prepost_opt_count_c_(size)
#define _Inout_bytecount_c_(size) _Prepost_bytecount_c_(size)
#define _Inout_opt_bytecount_c_(size) _Prepost_opt_bytecount_c_(size)

// nullterminated 'inout' buffers with initialized elements before and after the call
// e.g. void ModifyIndices( _Inout_count_(cIndices) int* rgIndeces, size_t cIndices );
#define _Inout_z_count_(size) _Prepost_z_ _Prepost_count_(size)
#define _Inout_opt_z_count_(size) _Prepost_z_ _Prepost_opt_count_(size)
#define _Inout_z_bytecount_(size) _Prepost_z_ _Prepost_bytecount_(size)
#define _Inout_opt_z_bytecount_(size) _Prepost_z_ _Prepost_opt_bytecount_(size)

#define _Inout_z_count_c_(size) _Prepost_z_ _Prepost_count_c_(size)
#define _Inout_opt_z_count_c_(size) _Prepost_z_ _Prepost_opt_count_c_(size)
#define _Inout_z_bytecount_c_(size) _Prepost_z_ _Prepost_bytecount_c_(size)
#define _Inout_opt_z_bytecount_c_(size) _Prepost_z_ _Prepost_opt_bytecount_c_(size)

#define _Inout_ptrdiff_count_(size) _Pre_ptrdiff_count_(size)
#define _Inout_opt_ptrdiff_count_(size) _Pre_opt_ptrdiff_count_(size)

#define _Inout_count_x_(size) _Prepost_count_x_(size)
#define _Inout_opt_count_x_(size) _Prepost_opt_count_x_(size)
#define _Inout_bytecount_x_(size) _Prepost_bytecount_x_(size)
#define _Inout_opt_bytecount_x_(size) _Prepost_opt_bytecount_x_(size)

// e.g. void AppendToLPSTR( _In_ LPCSTR szFrom, _Inout_cap_(cchTo) LPSTR* szTo, size_t cchTo );
#define _Inout_cap_(size) _Pre_valid_cap_(size) _Post_valid_
#define _Inout_opt_cap_(size) _Pre_opt_valid_cap_(size) _Post_valid_
#define _Inout_bytecap_(size) _Pre_valid_bytecap_(size) _Post_valid_
#define _Inout_opt_bytecap_(size) _Pre_opt_valid_bytecap_(size) _Post_valid_

#define _Inout_cap_c_(size) _Pre_valid_cap_c_(size) _Post_valid_
#define _Inout_opt_cap_c_(size) _Pre_opt_valid_cap_c_(size) _Post_valid_
#define _Inout_bytecap_c_(size) _Pre_valid_bytecap_c_(size) _Post_valid_
#define _Inout_opt_bytecap_c_(size) _Pre_opt_valid_bytecap_c_(size) _Post_valid_

#define _Inout_cap_x_(size) _Pre_valid_cap_x_(size) _Post_valid_
#define _Inout_opt_cap_x_(size) _Pre_opt_valid_cap_x_(size) _Post_valid_
#define _Inout_bytecap_x_(size) _Pre_valid_bytecap_x_(size) _Post_valid_
#define _Inout_opt_bytecap_x_(size) _Pre_opt_valid_bytecap_x_(size) _Post_valid_

// inout string buffers with writable size
// e.g. void AppendStr( _In_z_ const char* szFrom, _Inout_z_cap_(cchTo) char* szTo, size_t cchTo );
#define _Inout_z_cap_(size) _Pre_z_cap_(size) _Post_z_
#define _Inout_opt_z_cap_(size) _Pre_opt_z_cap_(size) _Post_z_
#define _Inout_z_bytecap_(size) _Pre_z_bytecap_(size) _Post_z_
#define _Inout_opt_z_bytecap_(size) _Pre_opt_z_bytecap_(size) _Post_z_

#define _Inout_z_cap_c_(size) _Pre_z_cap_c_(size) _Post_z_
#define _Inout_opt_z_cap_c_(size) _Pre_opt_z_cap_c_(size) _Post_z_
#define _Inout_z_bytecap_c_(size) _Pre_z_bytecap_c_(size) _Post_z_
#define _Inout_opt_z_bytecap_c_(size) _Pre_opt_z_bytecap_c_(size) _Post_z_

#define _Inout_z_cap_x_(size) _Pre_z_cap_x_(size) _Post_z_
#define _Inout_opt_z_cap_x_(size) _Pre_opt_z_cap_x_(size) _Post_z_
#define _Inout_z_bytecap_x_(size) _Pre_z_bytecap_x_(size) _Post_z_
#define _Inout_opt_z_bytecap_x_(size) _Pre_opt_z_bytecap_x_(size) _Post_z_

// return values -------------------------------

// returning pointers to valid objects
#define _Ret_ _Ret_valid_
#define _Ret_opt_ _Ret_opt_valid_

// More _Ret_ annotations are defined below

// Pointer to pointers -------------------------

// e.g.  HRESULT HrCreatePoint( _Deref_out_opt_ POINT** ppPT );
#define _Deref_out_ _Out_ _Deref_pre_invalid_ _Deref_post_valid_
#define _Deref_out_opt_ _Out_ _Deref_pre_invalid_ _Deref_post_opt_valid_
#define _Deref_opt_out_ _Out_opt_ _Deref_pre_invalid_ _Deref_post_valid_
#define _Deref_opt_out_opt_ _Out_opt_ _Deref_pre_invalid_ _Deref_post_opt_valid_

// e.g.  void CloneString( _In_z_ const wchar_t* wzFrom, _Deref_out_z_ wchar_t** pWzTo );
#define _Deref_out_z_ _Out_ _Deref_pre_invalid_ _Deref_post_z_
#define _Deref_out_opt_z_ _Out_ _Deref_pre_invalid_ _Deref_post_opt_z_
#define _Deref_opt_out_z_ _Out_opt_ _Deref_pre_invalid_ _Deref_post_z_
#define _Deref_opt_out_opt_z_ _Out_opt_ _Deref_pre_invalid_ _Deref_post_opt_z_

// More _Deref_ annotations are defined below

// Other annotations

// Check the return value of a function e.g. _Check_return_ ErrorCode Foo();
#define _Check_return_ _Check_return_impl_

// e.g. MyPrintF( _Printf_format_string_ const wchar_t* wzFormat, ... );
#define _Printf_format_string_ _Printf_format_string_impl_
#define _Scanf_format_string_ _Scanf_format_string_impl_
#define _Scanf_s_format_string_ _Scanf_s_format_string_impl_
#define _FormatMessage_format_string_ 

// <expr> indicates whether post conditions apply
#define _Success_(expr) _Success_impl_(expr)

// annotations to express 'boundedness' of integral value parameter
#define _In_bound_ _In_bound_impl_
#define _Out_bound_ _Out_bound_impl_
#define _Ret_bound_ _Ret_bound_impl_
#define _Deref_in_bound_ _Deref_in_bound_impl_
#define _Deref_out_bound_ _Deref_out_bound_impl_
#define _Deref_inout_bound_ _Deref_in_bound_ _Deref_out_bound_
#define _Deref_ret_bound_ _Deref_ret_bound_impl_

// annotations to express upper and lower bounds of integral value parameter
#define _In_range_(lb,ub) _In_range_impl_(lb,ub)
#define _Out_range_(lb,ub) _Out_range_impl_(lb,ub)
#define _Ret_range_(lb,ub) _Ret_range_impl_(lb,ub)
#define _Deref_in_range_(lb,ub) _Deref_in_range_impl_(lb,ub)
#define _Deref_out_range_(lb,ub) _Deref_out_range_impl_(lb,ub)
#define _Deref_ret_range_(lb,ub) _Deref_ret_range_impl_(lb,ub)

//============================================================================
//   _Pre_\_Post_ Layer:
//============================================================================

//
// _Pre_ annotation ---
//
// describing conditions that must be met before the call of the function

// e.g. int strlen( _Pre_z_ const char* sz );
// buffer is a zero terminated string
#define _Pre_z_ _Pre2_impl_(_$notnull, _$zterm) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_ _Pre2_impl_(_$maybenull,_$zterm) _Deref_pre1_impl_(_$valid)

// e.g. void FreeMemory( _Pre_bytecap_(cb) _Post_ptr_invalid_ void* pv, size_t cb );
// buffer capacity described by another parameter
#define _Pre_cap_(size) _Pre2_impl_(_$notnull, _$cap(size))
#define _Pre_opt_cap_(size) _Pre2_impl_(_$maybenull,_$cap(size))
#define _Pre_bytecap_(size) _Pre2_impl_(_$notnull, _$bytecap(size))
#define _Pre_opt_bytecap_(size) _Pre2_impl_(_$maybenull,_$bytecap(size))

// buffer capacity described by a constant expression
#define _Pre_cap_c_(size) _Pre2_impl_(_$notnull, _$cap_c(size))
#define _Pre_opt_cap_c_(size) _Pre2_impl_(_$maybenull,_$cap_c(size))
#define _Pre_bytecap_c_(size) _Pre2_impl_(_$notnull, _$bytecap_c(size))
#define _Pre_opt_bytecap_c_(size) _Pre2_impl_(_$maybenull,_$bytecap_c(size))

// buffer capacity is described by another parameter multiplied by a constant expression
#define _Pre_cap_m_(mult,size) _Pre2_impl_(_$notnull, _$mult(mult,size))
#define _Pre_opt_cap_m_(mult,size) _Pre2_impl_(_$maybenull,_$mult(mult,size))

// buffer capacity described by size of other buffer, only used by dangerous legacy APIs
// e.g. int strcpy(_Pre_cap_for_(src) char* dst, const char* src);
#define _Pre_cap_for_(param) _Pre2_impl_(_$notnull, _$cap_for(param))
#define _Pre_opt_cap_for_(param) _Pre2_impl_(_$maybenull,_$cap_for(param))

// buffer capacity described by a complex condition
#define _Pre_cap_x_(size) _Pre2_impl_(_$notnull, _$cap_x(size))
#define _Pre_opt_cap_x_(size) _Pre2_impl_(_$maybenull,_$cap_x(size))
#define _Pre_bytecap_x_(size) _Pre2_impl_(_$notnull, _$bytecap_x(size))
#define _Pre_opt_bytecap_x_(size) _Pre2_impl_(_$maybenull,_$bytecap_x(size))

// buffer capacity described by the difference to another pointer parameter
#define _Pre_ptrdiff_cap_(ptr) _Pre2_impl_(_$notnull, _$cap_x(__ptrdiff(ptr)))
#define _Pre_opt_ptrdiff_cap_(ptr) _Pre2_impl_(_$maybenull,_$cap_x(__ptrdiff(ptr)))

// e.g. void AppendStr( _Pre_z_ const char* szFrom, _Pre_z_cap_(cchTo) _Post_z_ char* szTo, size_t cchTo );
#define _Pre_z_cap_(size) _Pre3_impl_(_$notnull, _$zterm,_$cap(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_cap_(size) _Pre3_impl_(_$maybenull,_$zterm,_$cap(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_z_bytecap_(size) _Pre3_impl_(_$notnull, _$zterm,_$bytecap(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_bytecap_(size) _Pre3_impl_(_$maybenull,_$zterm,_$bytecap(size)) _Deref_pre1_impl_(_$valid)

#define _Pre_z_cap_c_(size) _Pre3_impl_(_$notnull, _$zterm,_$cap_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_cap_c_(size) _Pre3_impl_(_$maybenull,_$zterm,_$cap_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_z_bytecap_c_(size) _Pre3_impl_(_$notnull, _$zterm,_$bytecap_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_bytecap_c_(size) _Pre3_impl_(_$maybenull,_$zterm,_$bytecap_c(size)) _Deref_pre1_impl_(_$valid)

#define _Pre_z_cap_x_(size) _Pre3_impl_(_$notnull, _$zterm,_$cap_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_cap_x_(size) _Pre3_impl_(_$maybenull,_$zterm,_$cap_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_z_bytecap_x_(size) _Pre3_impl_(_$notnull, _$zterm,_$bytecap_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_z_bytecap_x_(size) _Pre3_impl_(_$maybenull,_$zterm,_$bytecap_x(size)) _Deref_pre1_impl_(_$valid)

// known capacity and valid but unknown readable extent
#define _Pre_valid_cap_(size) _Pre2_impl_(_$notnull, _$cap(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_cap_(size) _Pre2_impl_(_$maybenull,_$cap(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_valid_bytecap_(size) _Pre2_impl_(_$notnull, _$bytecap(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_bytecap_(size) _Pre2_impl_(_$maybenull,_$bytecap(size)) _Deref_pre1_impl_(_$valid)

#define _Pre_valid_cap_c_(size) _Pre2_impl_(_$notnull, _$cap_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_cap_c_(size) _Pre2_impl_(_$maybenull,_$cap_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_valid_bytecap_c_(size) _Pre2_impl_(_$notnull, _$bytecap_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_bytecap_c_(size) _Pre2_impl_(_$maybenull,_$bytecap_c(size)) _Deref_pre1_impl_(_$valid)

#define _Pre_valid_cap_x_(size) _Pre2_impl_(_$notnull, _$cap_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_cap_x_(size) _Pre2_impl_(_$maybenull,_$cap_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_valid_bytecap_x_(size) _Pre2_impl_(_$notnull, _$bytecap_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_bytecap_x_(size) _Pre2_impl_(_$maybenull,_$bytecap_x(size)) _Deref_pre1_impl_(_$valid)

// e.g. void AppendCharRange( _Pre_count_(cchFrom) const char* rgFrom, size_t cchFrom, _Out_z_cap_(cchTo) char* szTo, size_t cchTo );
// Valid buffer extent described by another parameter
#define _Pre_count_(size) _Pre2_impl_(_$notnull, _$count(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_count_(size) _Pre2_impl_(_$maybenull,_$count(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_bytecount_(size) _Pre2_impl_(_$notnull, _$bytecount(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_bytecount_(size) _Pre2_impl_(_$maybenull,_$bytecount(size)) _Deref_pre1_impl_(_$valid)

// Valid buffer extent described by a constant expression
#define _Pre_count_c_(size) _Pre2_impl_(_$notnull, _$count_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_count_c_(size) _Pre2_impl_(_$maybenull,_$count_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_bytecount_c_(size) _Pre2_impl_(_$notnull, _$bytecount_c(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_bytecount_c_(size) _Pre2_impl_(_$maybenull,_$bytecount_c(size)) _Deref_pre1_impl_(_$valid)

// Valid buffer extent described by a complex expression
#define _Pre_count_x_(size) _Pre2_impl_(_$notnull, _$count_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_count_x_(size) _Pre2_impl_(_$maybenull,_$count_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_bytecount_x_(size) _Pre2_impl_(_$notnull, _$bytecount_x(size)) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_bytecount_x_(size) _Pre2_impl_(_$maybenull,_$bytecount_x(size)) _Deref_pre1_impl_(_$valid)

// Valid buffer extent described by the difference to another pointer parameter
#define _Pre_ptrdiff_count_(ptr) _Pre2_impl_(_$notnull, _$count_x(__ptrdiff(ptr))) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_ptrdiff_count_(ptr) _Pre2_impl_(_$maybenull,_$count_x(__ptrdiff(ptr))) _Deref_pre1_impl_(_$valid)

// valid size unknown or indicated by type (e.g.:LPSTR)
#define _Pre_valid_ _Pre1_impl_(_$notnull) _Deref_pre1_impl_(_$valid)
#define _Pre_opt_valid_ _Pre1_impl_(_$maybenull) _Deref_pre1_impl_(_$valid)

#define _Pre_invalid_ _Deref_pre1_impl_(_$notvalid)

// used with allocated but not yet initialized objects
#define _Pre_notnull_ _Pre1_impl_(_$notnull)
#define _Pre_maybenull_ _Pre1_impl_(_$maybenull)
#define _Pre_null_ _Pre1_impl_(_$null)

// restrict access rights
#define _Pre_readonly_ _Pre1_impl_(_$readaccess)
#define _Pre_writeonly_ _Pre1_impl_(_$writeaccess)
//
// _Post_ annotations ---
//
// describing conditions that hold after the function call

// void CopyStr( _In_z_ const char* szFrom, _Pre_cap_(cch) _Post_z_ char* szFrom, size_t cchFrom );
// buffer will be a zero-terminated string after the call
#define _Post_z_ _Post1_impl_(_$zterm) _Deref_post1_impl_(_$valid)

// char * strncpy(_Out_cap_(_Count) _Post_maybez_ char * _Dest, _In_z_ const char * _Source, _In_ size_t _Count)
// buffer maybe zero-terminated after the call
#define _Post_maybez_ _Post1_impl_(_$maybezterm)

// e.g. SIZE_T HeapSize( _In_ HANDLE hHeap, DWORD dwFlags, _Pre_notnull_ _Post_bytecap_(return) LPCVOID lpMem );
#define _Post_cap_(size) _Post1_impl_(_$cap(size))
#define _Post_bytecap_(size) _Post1_impl_(_$bytecap(size))

// e.g. int strlen( _In_z_ _Post_count_(return+1) const char* sz );
#define _Post_count_(size) _Post1_impl_(_$count(size)) _Deref_post1_impl_(_$valid)
#define _Post_bytecount_(size) _Post1_impl_(_$bytecount(size)) _Deref_post1_impl_(_$valid)
#define _Post_count_c_(size) _Post1_impl_(_$count_c(size)) _Deref_post1_impl_(_$valid)
#define _Post_bytecount_c_(size) _Post1_impl_(_$bytecount_c(size)) _Deref_post1_impl_(_$valid)
#define _Post_count_x_(size) _Post1_impl_(_$count_x(size)) _Deref_post1_impl_(_$valid)
#define _Post_bytecount_x_(size) _Post1_impl_(_$bytecount_x(size)) _Deref_post1_impl_(_$valid)

// e.g. size_t CopyStr( _In_z_ const char* szFrom, _Pre_cap_(cch) _Post_z_count_(return+1) char* szFrom, size_t cchFrom );
#define _Post_z_count_(size) _Post2_impl_(_$zterm,_$count(size)) _Deref_post1_impl_(_$valid)
#define _Post_z_bytecount_(size) _Post2_impl_(_$zterm,_$bytecount(size)) _Deref_post1_impl_(_$valid)
#define _Post_z_count_c_(size) _Post2_impl_(_$zterm,_$count_c(size)) _Deref_post1_impl_(_$valid)
#define _Post_z_bytecount_c_(size) _Post2_impl_(_$zterm,_$bytecount_c(size)) _Deref_post1_impl_(_$valid)
#define _Post_z_count_x_(size) _Post2_impl_(_$zterm,_$count_x(size)) _Deref_post1_impl_(_$valid)
#define _Post_z_bytecount_x_(size) _Post2_impl_(_$zterm,_$bytecount_x(size)) _Deref_post1_impl_(_$valid)

// e.g. void free( _Post_ptr_invalid_ void* pv );
#define _Post_ptr_invalid_ _Post1_impl_(_$notvalid)

// e.g. HRESULT InitStruct( _Post_valid_ Struct* pobj );
#define _Post_valid_ _Deref_post1_impl_(_$valid)
#define _Post_invalid_ _Deref_post1_impl_(_$notvalid)

// e.g. void ThrowExceptionIfNull( _Post_notnull_ const void* pv );
#define _Post_notnull_ _Post1_impl_(_$notnull)

//
// _Ret_ annotations
//
// describing conditions that hold for return values after the call

// e.g. _Ret_z_ CString::operator const wchar_t*() const throw();
#define _Ret_z_ _Ret2_impl_(_$notnull, _$zterm) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_z_ _Ret2_impl_(_$maybenull,_$zterm) _Deref_ret1_impl_(_$valid)

// e.g. _Ret_opt_bytecap_(cb) void* AllocateMemory( size_t cb );
// Buffer capacity is described by another parameter
#define _Ret_cap_(size) _Ret2_impl_(_$notnull, _$cap(size))
#define _Ret_opt_cap_(size) _Ret2_impl_(_$maybenull,_$cap(size))
#define _Ret_bytecap_(size) _Ret2_impl_(_$notnull, _$bytecap(size))
#define _Ret_opt_bytecap_(size) _Ret2_impl_(_$maybenull,_$bytecap(size))

// Buffer capacity is described by a constant expression
#define _Ret_cap_c_(size) _Ret2_impl_(_$notnull, _$cap_c(size))
#define _Ret_opt_cap_c_(size) _Ret2_impl_(_$maybenull,_$cap_c(size))
#define _Ret_bytecap_c_(size) _Ret2_impl_(_$notnull, _$bytecap_c(size))
#define _Ret_opt_bytecap_c_(size) _Ret2_impl_(_$maybenull,_$bytecap_c(size))

// Buffer capacity is described by a complex condition
#define _Ret_cap_x_(size) _Ret2_impl_(_$notnull, _$cap_x(size))
#define _Ret_opt_cap_x_(size) _Ret2_impl_(_$maybenull,_$cap_x(size))
#define _Ret_bytecap_x_(size) _Ret2_impl_(_$notnull, _$bytecap_x(size))
#define _Ret_opt_bytecap_x_(size) _Ret2_impl_(_$maybenull,_$bytecap_x(size))

// return value is nullterminated and capacity is given by another parameter
#define _Ret_z_cap_(size) _Ret3_impl_(_$notnull, _$zterm,_$cap(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_z_cap_(size) _Ret3_impl_(_$maybenull,_$zterm,_$cap(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_z_bytecap_(size) _Ret3_impl_(_$notnull, _$zterm,_$bytecap(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_z_bytecap_(size) _Ret3_impl_(_$maybenull,_$zterm,_$bytecap(size)) _Deref_ret1_impl_(_$valid)

// e.g. _Ret_opt_bytecount_(cb) void* AllocateZeroInitializedMemory( size_t cb );
// Valid Buffer extent is described by another parameter
#define _Ret_count_(size) _Ret2_impl_(_$notnull, _$count(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_count_(size) _Ret2_impl_(_$maybenull,_$count(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_bytecount_(size) _Ret2_impl_(_$notnull, _$bytecount(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_bytecount_(size) _Ret2_impl_(_$maybenull,_$bytecount(size)) _Deref_ret1_impl_(_$valid)

// Valid Buffer extent is described by a constant expression
#define _Ret_count_c_(size) _Ret2_impl_(_$notnull, _$count_c(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_count_c_(size) _Ret2_impl_(_$maybenull,_$count_c(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_bytecount_c_(size) _Ret2_impl_(_$notnull, _$bytecount_c(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_bytecount_c_(size) _Ret2_impl_(_$maybenull,_$bytecount_c(size)) _Deref_ret1_impl_(_$valid)

// Valid Buffer extent is described by a complex expression
#define _Ret_count_x_(size) _Ret2_impl_(_$notnull, _$count_x(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_count_x_(size) _Ret2_impl_(_$maybenull,_$count_x(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_bytecount_x_(size) _Ret2_impl_(_$notnull, _$bytecount_x(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_bytecount_x_(size) _Ret2_impl_(_$maybenull,_$bytecount_x(size)) _Deref_ret1_impl_(_$valid)

// return value is nullterminated and length is given by another parameter
#define _Ret_z_count_(size) _Ret3_impl_(_$notnull, _$zterm,_$count(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_z_count_(size) _Ret3_impl_(_$maybenull,_$zterm,_$count(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_z_bytecount_(size) _Ret3_impl_(_$notnull, _$zterm,_$bytecount(size)) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_z_bytecount_(size) _Ret3_impl_(_$maybenull,_$zterm,_$bytecount(size)) _Deref_ret1_impl_(_$valid)

// e.g. _Ret_opt_valid_ LPSTR void* CloneSTR( _Pre_valid_ LPSTR src );
#define _Ret_valid_ _Ret1_impl_(_$notnull) _Deref_ret1_impl_(_$valid)
#define _Ret_opt_valid_ _Ret1_impl_(_$maybenull) _Deref_ret1_impl_(_$valid)

// used with allocated but not yet initialized objects
#define _Ret_notnull_ _Ret1_impl_(_$notnull)
#define _Ret_maybenull_ _Ret1_impl_(_$maybenull)
#define _Ret_null_ _Ret1_impl_(_$null)

//
// _Deref_pre_ ---
//
// describing conditions for array elements of dereferenced pointer parameters that must be met before the call

// e.g. void SaveStringArray( _In_count_(cStrings) _Deref_pre_z_ const wchar_t* const rgpwch[] );
#define _Deref_pre_z_ _Deref_pre2_impl_(_$notnull, _$zterm) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_ _Deref_pre2_impl_(_$maybenull,_$zterm) _Deref2_pre1_impl_(_$valid)

// e.g. void FillInArrayOfStr32( _In_count_(cStrings) _Deref_pre_cap_c_(32) _Deref_post_z_ wchar_t* const rgpwch[] );
// buffer capacity is described by another parameter
#define _Deref_pre_cap_(size) _Deref_pre2_impl_(_$notnull, _$cap(size))
#define _Deref_pre_opt_cap_(size) _Deref_pre2_impl_(_$maybenull,_$cap(size))
#define _Deref_pre_bytecap_(size) _Deref_pre2_impl_(_$notnull, _$bytecap(size))
#define _Deref_pre_opt_bytecap_(size) _Deref_pre2_impl_(_$maybenull,_$bytecap(size))

// buffer capacity is described by a constant expression
#define _Deref_pre_cap_c_(size) _Deref_pre2_impl_(_$notnull, _$cap_c(size))
#define _Deref_pre_opt_cap_c_(size) _Deref_pre2_impl_(_$maybenull,_$cap_c(size))
#define _Deref_pre_bytecap_c_(size) _Deref_pre2_impl_(_$notnull, _$bytecap_c(size))
#define _Deref_pre_opt_bytecap_c_(size) _Deref_pre2_impl_(_$maybenull,_$bytecap_c(size))

// buffer capacity is described by a complex condition
#define _Deref_pre_cap_x_(size) _Deref_pre2_impl_(_$notnull, _$cap_x(size))
#define _Deref_pre_opt_cap_x_(size) _Deref_pre2_impl_(_$maybenull,_$cap_x(size))
#define _Deref_pre_bytecap_x_(size) _Deref_pre2_impl_(_$notnull, _$bytecap_x(size))
#define _Deref_pre_opt_bytecap_x_(size) _Deref_pre2_impl_(_$maybenull,_$bytecap_x(size))

// convenience macros for nullterminated buffers with given capacity
#define _Deref_pre_z_cap_(size) _Deref_pre3_impl_(_$notnull, _$zterm,_$cap(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_cap_(size) _Deref_pre3_impl_(_$maybenull,_$zterm,_$cap(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_z_bytecap_(size) _Deref_pre3_impl_(_$notnull, _$zterm,_$bytecap(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_bytecap_(size) _Deref_pre3_impl_(_$maybenull,_$zterm,_$bytecap(size)) _Deref2_pre1_impl_(_$valid)

#define _Deref_pre_z_cap_c_(size) _Deref_pre3_impl_(_$notnull, _$zterm,_$cap_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_cap_c_(size) _Deref_pre3_impl_(_$maybenull,_$zterm,_$cap_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_z_bytecap_c_(size) _Deref_pre3_impl_(_$notnull, _$zterm,_$bytecap_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_bytecap_c_(size) _Deref_pre3_impl_(_$maybenull,_$zterm,_$bytecap_c(size)) _Deref2_pre1_impl_(_$valid)

#define _Deref_pre_z_cap_x_(size) _Deref_pre3_impl_(_$notnull, _$zterm,_$cap_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_cap_x_(size) _Deref_pre3_impl_(_$maybenull,_$zterm,_$cap_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_z_bytecap_x_(size) _Deref_pre3_impl_(_$notnull, _$zterm,_$bytecap_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_z_bytecap_x_(size) _Deref_pre3_impl_(_$maybenull,_$zterm,_$bytecap_x(size)) _Deref2_pre1_impl_(_$valid)

// known capacity and valid but unknown readable extent
#define _Deref_pre_valid_cap_(size) _Deref_pre2_impl_(_$notnull, _$cap(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_cap_(size) _Deref_pre2_impl_(_$maybenull,_$cap(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_valid_bytecap_(size) _Deref_pre2_impl_(_$notnull, _$bytecap(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_bytecap_(size) _Deref_pre2_impl_(_$maybenull,_$bytecap(size)) _Deref2_pre1_impl_(_$valid)

#define _Deref_pre_valid_cap_c_(size) _Deref_pre2_impl_(_$notnull, _$cap_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_cap_c_(size) _Deref_pre2_impl_(_$maybenull,_$cap_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_valid_bytecap_c_(size) _Deref_pre2_impl_(_$notnull, _$bytecap_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_bytecap_c_(size) _Deref_pre2_impl_(_$maybenull,_$bytecap_c(size)) _Deref2_pre1_impl_(_$valid)

#define _Deref_pre_valid_cap_x_(size) _Deref_pre2_impl_(_$notnull, _$cap_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_cap_x_(size) _Deref_pre2_impl_(_$maybenull,_$cap_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_valid_bytecap_x_(size) _Deref_pre2_impl_(_$notnull, _$bytecap_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_bytecap_x_(size) _Deref_pre2_impl_(_$maybenull,_$bytecap_x(size)) _Deref2_pre1_impl_(_$valid)

// e.g. void SaveMatrix( _In_count_(n) _Deref_pre_count_(n) const Elem** matrix, size_t n ); 
// valid buffer extent is described by another parameter
#define _Deref_pre_count_(size) _Deref_pre2_impl_(_$notnull, _$count(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_count_(size) _Deref_pre2_impl_(_$maybenull,_$count(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_bytecount_(size) _Deref_pre2_impl_(_$notnull, _$bytecount(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_bytecount_(size) _Deref_pre2_impl_(_$maybenull,_$bytecount(size)) _Deref2_pre1_impl_(_$valid)

// valid buffer extent is described by a constant expression
#define _Deref_pre_count_c_(size) _Deref_pre2_impl_(_$notnull, _$count_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_count_c_(size) _Deref_pre2_impl_(_$maybenull,_$count_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_bytecount_c_(size) _Deref_pre2_impl_(_$notnull, _$bytecount_c(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_bytecount_c_(size) _Deref_pre2_impl_(_$maybenull,_$bytecount_c(size)) _Deref2_pre1_impl_(_$valid)

// valid buffer extent is described by a complex expression
#define _Deref_pre_count_x_(size) _Deref_pre2_impl_(_$notnull, _$count_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_count_x_(size) _Deref_pre2_impl_(_$maybenull,_$count_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_bytecount_x_(size) _Deref_pre2_impl_(_$notnull, _$bytecount_x(size)) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_bytecount_x_(size) _Deref_pre2_impl_(_$maybenull,_$bytecount_x(size)) _Deref2_pre1_impl_(_$valid)

// e.g. void PrintStringArray( _In_count_(cElems) _Deref_pre_valid_ LPCSTR rgStr[], size_t cElems );
#define _Deref_pre_valid_ _Deref_pre1_impl_(_$notnull) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_opt_valid_ _Deref_pre1_impl_(_$maybenull) _Deref2_pre1_impl_(_$valid)
#define _Deref_pre_invalid_ _Deref2_pre1_impl_(_$notvalid)

#define _Deref_pre_notnull_ _Deref_pre1_impl_(_$notnull)
#define _Deref_pre_maybenull_ _Deref_pre1_impl_(_$maybenull)
#define _Deref_pre_null_ _Deref_pre1_impl_(_$null)

// restrict access rights
#define _Deref_pre_readonly_ _Deref_pre1_impl_(_$readaccess)
#define _Deref_pre_writeonly_ _Deref_pre1_impl_(_$writeaccess)

//
// _Deref_post_ ---
//
// describing conditions for array elements or dereferenced pointer parameters that hold after the call

// e.g. void CloneString( _In_z_ const Wchar_t* wzIn _Out_ _Deref_post_z_ wchar_t** pWzOut );
#define _Deref_post_z_ _Deref_post2_impl_(_$notnull, _$zterm) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_ _Deref_post2_impl_(_$maybenull,_$zterm) _Deref2_post1_impl_(_$valid)

// e.g. HRESULT HrAllocateMemory( size_t cb, _Out_ _Deref_post_bytecap_(cb) void** ppv );
// buffer capacity is described by another parameter
#define _Deref_post_cap_(size) _Deref_post2_impl_(_$notnull, _$cap(size))
#define _Deref_post_opt_cap_(size) _Deref_post2_impl_(_$maybenull,_$cap(size))
#define _Deref_post_bytecap_(size) _Deref_post2_impl_(_$notnull, _$bytecap(size))
#define _Deref_post_opt_bytecap_(size) _Deref_post2_impl_(_$maybenull,_$bytecap(size))

// buffer capacity is described by a constant expression
#define _Deref_post_cap_c_(size) _Deref_post2_impl_(_$notnull, _$cap_z(size))
#define _Deref_post_opt_cap_c_(size) _Deref_post2_impl_(_$maybenull,_$cap_z(size))
#define _Deref_post_bytecap_c_(size) _Deref_post2_impl_(_$notnull, _$bytecap_z(size))
#define _Deref_post_opt_bytecap_c_(size) _Deref_post2_impl_(_$maybenull,_$bytecap_z(size))

// buffer capacity is described by a complex expression
#define _Deref_post_cap_x_(size) _Deref_post2_impl_(_$notnull, _$cap_x(size))
#define _Deref_post_opt_cap_x_(size) _Deref_post2_impl_(_$maybenull,_$cap_x(size))
#define _Deref_post_bytecap_x_(size) _Deref_post2_impl_(_$notnull, _$bytecap_x(size))
#define _Deref_post_opt_bytecap_x_(size) _Deref_post2_impl_(_$maybenull,_$bytecap_x(size))

// convenience macros for nullterminated buffers with given capacity
#define _Deref_post_z_cap_(size) _Deref_post3_impl_(_$notnull, _$zterm,_$cap(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_cap_(size) _Deref_post3_impl_(_$maybenull,_$zterm,_$cap(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_z_bytecap_(size) _Deref_post3_impl_(_$notnull, _$zterm,_$bytecap(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_bytecap_(size) _Deref_post3_impl_(_$maybenull,_$zterm,_$bytecap(size)) _Deref2_post1_impl_(_$valid)

#define _Deref_post_z_cap_c_(size) _Deref_post3_impl_(_$notnull, _$zterm,_$cap_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_cap_c_(size) _Deref_post3_impl_(_$maybenull,_$zterm,_$cap_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_z_bytecap_c_(size) _Deref_post3_impl_(_$notnull, _$zterm,_$bytecap_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_bytecap_c_(size) _Deref_post3_impl_(_$maybenull,_$zterm,_$bytecap_c(size)) _Deref2_post1_impl_(_$valid)

#define _Deref_post_z_cap_x_(size) _Deref_post3_impl_(_$notnull, _$zterm,_$cap_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_cap_x_(size) _Deref_post3_impl_(_$maybenull,_$zterm,_$cap_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_z_bytecap_x_(size) _Deref_post3_impl_(_$notnull, _$zterm,_$bytecap_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_z_bytecap_x_(size) _Deref_post3_impl_(_$maybenull,_$zterm,_$bytecap_x(size)) _Deref2_post1_impl_(_$valid)

// known capacity and valid but unknown readable extent
#define _Deref_post_valid_cap_(size) _Deref_post2_impl_(_$notnull, _$cap(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_cap_(size) _Deref_post2_impl_(_$maybenull,_$cap(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_valid_bytecap_(size) _Deref_post2_impl_(_$notnull, _$bytecap(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_bytecap_(size) _Deref_post2_impl_(_$maybenull,_$bytecap(size)) _Deref2_post1_impl_(_$valid)

#define _Deref_post_valid_cap_c_(size) _Deref_post2_impl_(_$notnull, _$cap_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_cap_c_(size) _Deref_post2_impl_(_$maybenull,_$cap_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_valid_bytecap_c_(size) _Deref_post2_impl_(_$notnull, _$bytecap_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_bytecap_c_(size) _Deref_post2_impl_(_$maybenull,_$bytecap_c(size)) _Deref2_post1_impl_(_$valid)

#define _Deref_post_valid_cap_x_(size) _Deref_post2_impl_(_$notnull, _$cap_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_cap_x_(size) _Deref_post2_impl_(_$maybenull,_$cap_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_valid_bytecap_x_(size) _Deref_post2_impl_(_$notnull, _$bytecap_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_bytecap_x_(size) _Deref_post2_impl_(_$maybenull,_$bytecap_x(size)) _Deref2_post1_impl_(_$valid)

// e.g. HRESULT HrAllocateZeroInitializedMemory( size_t cb, _Out_ _Deref_post_bytecount_(cb) void** ppv );
// valid buffer extent is described by another parameter
#define _Deref_post_count_(size) _Deref_post2_impl_(_$notnull, _$count(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_count_(size) _Deref_post2_impl_(_$maybenull,_$count(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_bytecount_(size) _Deref_post2_impl_(_$notnull, _$bytecount(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_bytecount_(size) _Deref_post2_impl_(_$maybenull,_$bytecount(size)) _Deref2_post1_impl_(_$valid)

// buffer capacity is described by a constant expression
#define _Deref_post_count_c_(size) _Deref_post2_impl_(_$notnull, _$count_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_count_c_(size) _Deref_post2_impl_(_$maybenull,_$count_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_bytecount_c_(size) _Deref_post2_impl_(_$notnull, _$bytecount_c(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_bytecount_c_(size) _Deref_post2_impl_(_$maybenull,_$bytecount_c(size)) _Deref2_post1_impl_(_$valid)

// buffer capacity is described by a complex expression
#define _Deref_post_count_x_(size) _Deref_post2_impl_(_$notnull, _$count_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_count_x_(size) _Deref_post2_impl_(_$maybenull,_$count_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_bytecount_x_(size) _Deref_post2_impl_(_$notnull, _$bytecount_x(size)) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_bytecount_x_(size) _Deref_post2_impl_(_$maybenull,_$bytecount_x(size)) _Deref2_post1_impl_(_$valid)

// e.g. void GetStrings( _Out_count_(cElems) _Deref_post_valid_ LPSTR const rgStr[], size_t cElems );
#define _Deref_post_valid_ _Deref_post1_impl_(_$notnull) _Deref2_post1_impl_(_$valid)
#define _Deref_post_opt_valid_ _Deref_post1_impl_(_$maybenull) _Deref2_post1_impl_(_$valid)

#define _Deref_post_notnull_ _Deref_post1_impl_(_$notnull)
#define _Deref_post_maybenull_ _Deref_post1_impl_(_$maybenull)
#define _Deref_post_null_ _Deref_post1_impl_(_$null)

//
// _Deref_ret_ ---
//

#define _Deref_ret_z_ _Deref_ret2_impl_(_$notnull, _$zterm)
#define _Deref_ret_opt_z_ _Deref_ret2_impl_(_$maybenull,_$zterm)

//
// special _Deref_ ---
//
#define _Deref2_pre_readonly_ _Deref2_pre1_impl_(_$readaccess)

// Convenience macros for more concise annotations

//
// _Pre_post ---
//
// describing conditions that hold before and after the function call

#define _Prepost_z_ _Pre_z_ _Post_z_
#define _Prepost_opt_z_ _Pre_opt_z_ _Post_z_

#define _Prepost_count_(size) _Pre_count_(size) _Post_count_(size)
#define _Prepost_opt_count_(size) _Pre_opt_count_(size) _Post_count_(size)
#define _Prepost_bytecount_(size) _Pre_bytecount_(size) _Post_bytecount_(size)
#define _Prepost_opt_bytecount_(size) _Pre_opt_bytecount_(size) _Post_bytecount_(size)
#define _Prepost_count_c_(size) _Pre_count_c_(size) _Post_count_c_(size)
#define _Prepost_opt_count_c_(size) _Pre_opt_count_c_(size) _Post_count_c_(size)
#define _Prepost_bytecount_c_(size) _Pre_bytecount_c_(size) _Post_bytecount_c_(size)
#define _Prepost_opt_bytecount_c_(size) _Pre_opt_bytecount_c_(size) _Post_bytecount_c_(size)
#define _Prepost_count_x_(size) _Pre_count_x_(size) _Post_count_x_(size)
#define _Prepost_opt_count_x_(size) _Pre_opt_count_x_(size) _Post_count_x_(size)
#define _Prepost_bytecount_x_(size) _Pre_bytecount_x_(size) _Post_bytecount_x_(size)
#define _Prepost_opt_bytecount_x_(size) _Pre_opt_bytecount_x_(size) _Post_bytecount_x_(size)

#define _Prepost_valid_ _Pre_valid_ _Post_valid_
#define _Prepost_opt_valid_ _Pre_opt_valid_ _Post_valid_

//
// _Deref_<both> ---
//
// short version for _Deref_pre_<ann> _Deref_post_<ann>
// describing conditions for array elements or dereferenced pointer parameters that hold before and after the call

#define _Deref_prepost_z_ _Deref_pre_z_ _Deref_post_z_
#define _Deref_prepost_opt_z_ _Deref_pre_opt_z_ _Deref_post_opt_z_

#define _Deref_prepost_cap_(size) _Deref_pre_cap_(size) _Deref_post_cap_(size)
#define _Deref_prepost_opt_cap_(size) _Deref_pre_opt_cap_(size) _Deref_post_opt_cap_(size)
#define _Deref_prepost_bytecap_(size) _Deref_pre_bytecap_(size) _Deref_post_bytecap_(size)
#define _Deref_prepost_opt_bytecap_(size) _Deref_pre_opt_bytecap_(size) _Deref_post_opt_bytecap_(size)

#define _Deref_prepost_cap_x_(size) _Deref_pre_cap_x_(size) _Deref_post_cap_x_(size)
#define _Deref_prepost_opt_cap_x_(size) _Deref_pre_opt_cap_x_(size) _Deref_post_opt_cap_x_(size)
#define _Deref_prepost_bytecap_x_(size) _Deref_pre_bytecap_x_(size) _Deref_post_bytecap_x_(size)
#define _Deref_prepost_opt_bytecap_x_(size) _Deref_pre_opt_bytecap_x_(size) _Deref_post_opt_bytecap_x_(size)

#define _Deref_prepost_z_cap_(size) _Deref_pre_z_cap_(size) _Deref_post_z_cap_(size)
#define _Deref_prepost_opt_z_cap_(size) _Deref_pre_opt_z_cap_(size) _Deref_post_opt_z_cap_(size)
#define _Deref_prepost_z_bytecap_(size) _Deref_pre_z_bytecap_(size) _Deref_post_z_bytecap_(size)
#define _Deref_prepost_opt_z_bytecap_(size) _Deref_pre_opt_z_bytecap_(size) _Deref_post_opt_z_bytecap_(size)

#define _Deref_prepost_valid_cap_(size) _Deref_pre_valid_cap_(size) _Deref_post_valid_cap_(size)
#define _Deref_prepost_opt_valid_cap_(size) _Deref_pre_opt_valid_cap_(size) _Deref_post_opt_valid_cap_(size)
#define _Deref_prepost_valid_bytecap_(size) _Deref_pre_valid_bytecap_(size) _Deref_post_valid_bytecap_(size)
#define _Deref_prepost_opt_valid_bytecap_(size) _Deref_pre_opt_valid_bytecap_(size) _Deref_post_opt_valid_bytecap_(size)

#define _Deref_prepost_valid_cap_x_(size) _Deref_pre_valid_cap_x_(size) _Deref_post_valid_cap_x_(size)
#define _Deref_prepost_opt_valid_cap_x_(size) _Deref_pre_opt_valid_cap_x_(size) _Deref_post_opt_valid_cap_x_(size)
#define _Deref_prepost_valid_bytecap_x_(size) _Deref_pre_valid_bytecap_x_(size) _Deref_post_valid_bytecap_x_(size)
#define _Deref_prepost_opt_valid_bytecap_x_(size) _Deref_pre_opt_valid_bytecap_x_(size) _Deref_post_opt_valid_bytecap_x_(size)

#define _Deref_prepost_count_(size) _Deref_pre_count_(size) _Deref_post_count_(size)
#define _Deref_prepost_opt_count_(size) _Deref_pre_opt_count_(size) _Deref_post_opt_count_(size)
#define _Deref_prepost_bytecount_(size) _Deref_pre_bytecount_(size) _Deref_post_bytecount_(size)
#define _Deref_prepost_opt_bytecount_(size) _Deref_pre_opt_bytecount_(size) _Deref_post_opt_bytecount_(size)

#define _Deref_prepost_count_x_(size) _Deref_pre_count_x_(size) _Deref_post_count_x_(size)
#define _Deref_prepost_opt_count_x_(size) _Deref_pre_opt_count_x_(size) _Deref_post_opt_count_x_(size)
#define _Deref_prepost_bytecount_x_(size) _Deref_pre_bytecount_x_(size) _Deref_post_bytecount_x_(size)
#define _Deref_prepost_opt_bytecount_x_(size) _Deref_pre_opt_bytecount_x_(size) _Deref_post_opt_bytecount_x_(size)

#define _Deref_prepost_valid_ _Deref_pre_valid_ _Deref_post_valid_
#define _Deref_prepost_opt_valid_ _Deref_pre_opt_valid_ _Deref_post_opt_valid_

//
// _Deref_<miscellaneous>
//
// used with references to arrays

#define _Deref_out_z_cap_c_(size) _Deref_pre_cap_c_(size) _Deref_pre_invalid_ _Deref_post_z_
#define _Deref_inout_z_cap_c_(size) _Deref_pre_z_cap_c_(size) _Deref_post_z_
#define _Deref_out_z_bytecap_c_(size) _Deref_pre_bytecap_c_(size) _Deref_pre_invalid_ _Deref_post_z_
#define _Deref_inout_z_bytecap_c_(size) _Deref_pre_z_bytecap_c_(size) _Deref_post_z_
#define _Deref_inout_z_ _Deref_prepost_z_

//============================================================================
//   Implementation Layer:
//============================================================================
# 1231 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define _Check_return_impl_ 

#define _Success_impl_(expr) 

#define _Printf_format_string_impl_ 
#define _Scanf_format_string_impl_ 
#define _Scanf_s_format_string_impl_ 

#define _In_bound_impl_ 
#define _Out_bound_impl_ 
#define _Ret_bound_impl_ 
#define _Deref_in_bound_impl_ 
#define _Deref_out_bound_impl_ 
#define _Deref_ret_bound_impl_ 

#define _In_range_impl_(min,max) 
#define _Out_range_impl_(min,max) 
#define _Ret_range_impl_(min,max) 
#define _Deref_in_range_impl_(min,max) 
#define _Deref_out_range_impl_(min,max) 
#define _Deref_ret_range_impl_(min,max) 

#define _Pre1_impl_(p1) 
#define _Pre2_impl_(p1,p2) 
#define _Pre3_impl_(p1,p2,p3) 

#define _Post1_impl_(p1) 
#define _Post2_impl_(p1,p2) 
#define _Post3_impl_(p1,p2,p3) 

#define _Ret1_impl_(p1) 
#define _Ret2_impl_(p1,p2) 
#define _Ret3_impl_(p1,p2,p3) 

#define _Deref_pre1_impl_(p1) 
#define _Deref_pre2_impl_(p1,p2) 
#define _Deref_pre3_impl_(p1,p2,p3) 

#define _Deref_post1_impl_(p1) 
#define _Deref_post2_impl_(p1,p2) 
#define _Deref_post3_impl_(p1,p2,p3) 

#define _Deref_ret1_impl_(p1) 
#define _Deref_ret2_impl_(p1,p2) 
#define _Deref_ret3_impl_(p1,p2,p3) 

#define _Deref2_pre1_impl_(p1) 
#define _Deref2_post1_impl_(p1) 
#define _Deref2_ret1_impl_(p1) 



// This section contains the deprecated annotations

/* 

 -------------------------------------------------------------------------------

 Introduction



 sal.h provides a set of annotations to describe how a function uses its

 parameters - the assumptions it makes about them, and the guarantees it makes

 upon finishing.



 Annotations may be placed before either a function parameter's type or its return

 type, and describe the function's behavior regarding the parameter or return value.

 There are two classes of annotations: buffer annotations and advanced annotations.

 Buffer annotations describe how functions use their pointer parameters, and

 advanced annotations either describe complex/unusual buffer behavior, or provide

 additional information about a parameter that is not otherwise expressible.



 -------------------------------------------------------------------------------

 Buffer Annotations



 The most important annotations in sal.h provide a consistent way to annotate

 buffer parameters or return values for a function. Each of these annotations describes

 a single buffer (which could be a string, a fixed-length or variable-length array,

 or just a pointer) that the function interacts with: where it is, how large it is,

 how much is initialized, and what the function does with it.



 The appropriate macro for a given buffer can be constructed using the table below.

 Just pick the appropriate values from each category, and combine them together

 with a leading underscore. Some combinations of values do not make sense as buffer

 annotations. Only meaningful annotations can be added to your code; for a list of

 these, see the buffer annotation definitions section.



 Only a single buffer annotation should be used for each parameter.



 |------------|------------|---------|--------|----------|----------|---------------|

 |   Level    |   Usage    |  Size   | Output | NullTerm | Optional |  Parameters   |

 |------------|------------|---------|--------|----------|----------|---------------|

 | <>         | <>         | <>      | <>     | _z       | <>       | <>            |

 | _deref     | _in        | _ecount | _full  | _nz      | _opt     | (size)        |

 | _deref_opt | _out       | _bcount | _part  |          |          | (size,length) |

 |            | _inout     |         |        |          |          |               |

 |            |            |         |        |          |          |               |

 |------------|------------|---------|--------|----------|----------|---------------|



 Level: Describes the buffer pointer's level of indirection from the parameter or

          return value 'p'.



 <>         : p is the buffer pointer.

 _deref     : *p is the buffer pointer. p must not be NULL.

 _deref_opt : *p may be the buffer pointer. p may be NULL, in which case the rest of

                the annotation is ignored.



 Usage: Describes how the function uses the buffer.



 <>     : The buffer is not accessed. If used on the return value or with _deref, the

            function will provide the buffer, and it will be uninitialized at exit.

            Otherwise, the caller must provide the buffer. This should only be used

            for alloc and free functions.

 _in    : The function will only read from the buffer. The caller must provide the

            buffer and initialize it. Cannot be used with _deref.

 _out   : The function will only write to the buffer. If used on the return value or

            with _deref, the function will provide the buffer and initialize it.

            Otherwise, the caller must provide the buffer, and the function will

            initialize it.

 _inout : The function may freely read from and write to the buffer. The caller must

            provide the buffer and initialize it. If used with _deref, the buffer may

            be reallocated by the function.



 Size: Describes the total size of the buffer. This may be less than the space actually

         allocated for the buffer, in which case it describes the accessible amount.



 <>      : No buffer size is given. If the type specifies the buffer size (such as

             with LPSTR and LPWSTR), that amount is used. Otherwise, the buffer is one

             element long. Must be used with _in, _out, or _inout.

 _ecount : The buffer size is an explicit element count.

 _bcount : The buffer size is an explicit byte count.



 Output: Describes how much of the buffer will be initialized by the function. For

           _inout buffers, this also describes how much is initialized at entry. Omit this

           category for _in buffers; they must be fully initialized by the caller.



 <>    : The type specifies how much is initialized. For instance, a function initializing

           an LPWSTR must NULL-terminate the string.

 _full : The function initializes the entire buffer.

 _part : The function initializes part of the buffer, and explicitly indicates how much.



 NullTerm: States if the present of a '\0' marks the end of valid elements in the buffer.

 _z    : A '\0' indicated the end of the buffer

 _nz	 : The buffer may not be null terminated and a '\0' does not indicate the end of the

          buffer.

 Optional: Describes if the buffer itself is optional.



 <>   : The pointer to the buffer must not be NULL.

 _opt : The pointer to the buffer might be NULL. It will be checked before being dereferenced.



 Parameters: Gives explicit counts for the size and length of the buffer.



 <>            : There is no explicit count. Use when neither _ecount nor _bcount is used.

 (size)        : Only the buffer's total size is given. Use with _ecount or _bcount but not _part.

 (size,length) : The buffer's total size and initialized length are given. Use with _ecount_part

                   and _bcount_part.



 -------------------------------------------------------------------------------

 Buffer Annotation Examples



 LWSTDAPI_(BOOL) StrToIntExA(

     LPCSTR pszString,                    -- No annotation required, const implies __in.

     DWORD dwFlags,

     __out int *piRet                     -- A pointer whose dereference will be filled in.

 );



 void MyPaintingFunction(

     __in HWND hwndControl,               -- An initialized read-only parameter.

     __in_opt HDC hdcOptional,            -- An initialized read-only parameter that might be NULL.

     __inout IPropertyStore *ppsStore     -- An initialized parameter that may be freely used

                                          --   and modified.

 );



 LWSTDAPI_(BOOL) PathCompactPathExA(

     __out_ecount(cchMax) LPSTR pszOut,   -- A string buffer with cch elements that will

                                          --   be NULL terminated on exit.

     LPCSTR pszSrc,                       -- No annotation required, const implies __in.

     UINT cchMax,

     DWORD dwFlags

 );



 HRESULT SHLocalAllocBytes(

     size_t cb,

     __deref_bcount(cb) T **ppv           -- A pointer whose dereference will be set to an

                                          --   uninitialized buffer with cb bytes.

 );



 __inout_bcount_full(cb) : A buffer with cb elements that is fully initialized at

     entry and exit, and may be written to by this function.



 __out_ecount_part(count, *countOut) : A buffer with count elements that will be

     partially initialized by this function. The function indicates how much it

     initialized by setting *countOut.



 -------------------------------------------------------------------------------

 Advanced Annotations



 Advanced annotations describe behavior that is not expressible with the regular

 buffer macros. These may be used either to annotate buffer parameters that involve

 complex or conditional behavior, or to enrich existing annotations with additional

 information.



 __success(expr) f :

     <expr> indicates whether function f succeeded or not. If <expr> is true at exit,

     all the function's guarantees (as given by other annotations) must hold. If <expr>

     is false at exit, the caller should not expect any of the function's guarantees

     to hold. If not used, the function must always satisfy its guarantees. Added

     automatically to functions that indicate success in standard ways, such as by

     returning an HRESULT.



 __nullterminated p :

     Pointer p is a buffer that may be read or written up to and including the first

     NULL character or pointer. May be used on typedefs, which marks valid (properly

     initialized) instances of that type as being NULL-terminated.



 __nullnullterminated p :

     Pointer p is a buffer that may be read or written up to and including the first

     sequence of two NULL characters or pointers. May be used on typedefs, which marks

     valid instances of that type as being double-NULL terminated.



 __reserved v :

     Value v must be 0/NULL, reserved for future use.



 __checkReturn v :

     Return value v must not be ignored by callers of this function.



 __typefix(ctype) v :

     Value v should be treated as an instance of ctype, rather than its declared type.



 __override f :

     Specify C#-style 'override' behaviour for overriding virtual methods.



 __callback f :

     Function f can be used as a function pointer.



 __format_string p :

     Pointer p is a string that contains % markers in the style of printf.



 __blocksOn(resource) f :

     Function f blocks on the resource 'resource'.



 __fallthrough :

     Annotates switch statement labels where fall-through is desired, to distinguish

     from forgotten break statements.



 -------------------------------------------------------------------------------

 Advanced Annotation Examples



 __success(return == TRUE) LWSTDAPI_(BOOL) 

 PathCanonicalizeA(__out_ecount(MAX_PATH) LPSTR pszBuf, LPCSTR pszPath) :

    pszBuf is only guaranteed to be NULL-terminated when TRUE is returned.



 typedef __nullterminated WCHAR* LPWSTR : Initialized LPWSTRs are NULL-terminated strings.



 __out_ecount(cch) __typefix(LPWSTR) void *psz : psz is a buffer parameter which will be

     a NULL-terminated WCHAR string at exit, and which initially contains cch WCHARs.



 -------------------------------------------------------------------------------

*/
# 1488 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define __specstrings 
# 1497 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define __nothrow 




/*

 -------------------------------------------------------------------------------

 Helper Macro Definitions



 These express behavior common to many of the high-level annotations.

 DO NOT USE THESE IN YOUR CODE.

 -------------------------------------------------------------------------------

*/
# 1511 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
/*

The helper annotations are only understood by the compiler version used by various

defect detection tools. When the regular compiler is running, they are defined into

nothing, and do not affect the compiled code.

*/
# 1721 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define __null 
#define __notnull 
#define __maybenull 
#define __readonly 
#define __notreadonly 
#define __maybereadonly 
#define __valid 
#define __notvalid 
#define __maybevalid 
#define __readableTo(extent) 
#define __elem_readableTo(size) 
#define __byte_readableTo(size) 
#define __writableTo(size) 
#define __elem_writableTo(size) 
#define __byte_writableTo(size) 
#define __deref 
#define __pre 
#define __post 
#define __precond(expr) 
#define __postcond(expr) 
#define __exceptthat 
#define __execeptthat 
#define __inner_success(expr) 
#define __inner_checkReturn 
#define __inner_typefix(ctype) 
#define __inner_override 
#define __inner_callback 
#define __inner_blocksOn(resource) 
#define __inner_fallthrough_dec 
#define __inner_fallthrough 
#define __refparam 
#define __inner_control_entrypoint(category) 
#define __inner_data_entrypoint(category) 


/* 

-------------------------------------------------------------------------------

Buffer Annotation Definitions



Any of these may be used to directly annotate functions, but only one should

be used for each parameter. To determine which annotation to use for a given

buffer, use the table in the buffer annotations section.

-------------------------------------------------------------------------------

*/
# 1766 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define __ecount(size) __notnull __elem_writableTo(size)
#define __bcount(size) __notnull __byte_writableTo(size)
#define __in __pre __valid __pre __deref __readonly
#define __in_ecount(size) __in __pre __elem_readableTo(size)
#define __in_bcount(size) __in __pre __byte_readableTo(size)
#define __in_z __in __pre __nullterminated
#define __in_ecount_z(size) __in_ecount(size) __pre __nullterminated
#define __in_bcount_z(size) __in_bcount(size) __pre __nullterminated
#define __in_nz __in
#define __in_ecount_nz(size) __in_ecount(size)
#define __in_bcount_nz(size) __in_bcount(size)
#define __out __ecount(1) __post __valid __refparam
#define __out_ecount(size) __ecount(size) __post __valid __refparam
#define __out_bcount(size) __bcount(size) __post __valid __refparam
#define __out_ecount_part(size,length) __out_ecount(size) __post __elem_readableTo(length)
#define __out_bcount_part(size,length) __out_bcount(size) __post __byte_readableTo(length)
#define __out_ecount_full(size) __out_ecount_part(size,size)
#define __out_bcount_full(size) __out_bcount_part(size,size)
#define __out_z __post __valid __refparam __post __nullterminated
#define __out_z_opt __post __valid __refparam __post __nullterminated __exceptthat __maybenull
#define __out_ecount_z(size) __ecount(size) __post __valid __refparam __post __nullterminated
#define __out_bcount_z(size) __bcount(size) __post __valid __refparam __post __nullterminated
#define __out_ecount_part_z(size,length) __out_ecount_part(size,length) __post __nullterminated
#define __out_bcount_part_z(size,length) __out_bcount_part(size,length) __post __nullterminated
#define __out_ecount_full_z(size) __out_ecount_full(size) __post __nullterminated
#define __out_bcount_full_z(size) __out_bcount_full(size) __post __nullterminated
#define __out_nz __post __valid __refparam __post
#define __out_nz_opt __post __valid __refparam __post __exceptthat __maybenull
#define __out_ecount_nz(size) __ecount(size) __post __valid __refparam
#define __out_bcount_nz(size) __bcount(size) __post __valid __refparam
#define __inout __pre __valid __post __valid __refparam
#define __inout_ecount(size) __out_ecount(size) __pre __valid
#define __inout_bcount(size) __out_bcount(size) __pre __valid
#define __inout_ecount_part(size,length) __out_ecount_part(size,length) __pre __valid __pre __elem_readableTo(length)
#define __inout_bcount_part(size,length) __out_bcount_part(size,length) __pre __valid __pre __byte_readableTo(length)
#define __inout_ecount_full(size) __inout_ecount_part(size,size)
#define __inout_bcount_full(size) __inout_bcount_part(size,size)
#define __inout_z __inout __pre __nullterminated __post __nullterminated
#define __inout_ecount_z(size) __inout_ecount(size) __pre __nullterminated __post __nullterminated
#define __inout_bcount_z(size) __inout_bcount(size) __pre __nullterminated __post __nullterminated
#define __inout_nz __inout
#define __inout_ecount_nz(size) __inout_ecount(size)
#define __inout_bcount_nz(size) __inout_bcount(size)
#define __ecount_opt(size) __ecount(size) __exceptthat __maybenull
#define __bcount_opt(size) __bcount(size) __exceptthat __maybenull
#define __in_opt __in __exceptthat __maybenull
#define __in_ecount_opt(size) __in_ecount(size) __exceptthat __maybenull
#define __in_bcount_opt(size) __in_bcount(size) __exceptthat __maybenull
#define __in_z_opt __in_opt __pre __nullterminated
#define __in_ecount_z_opt(size) __in_ecount_opt(size) __pre __nullterminated
#define __in_bcount_z_opt(size) __in_bcount_opt(size) __pre __nullterminated
#define __in_nz_opt __in_opt
#define __in_ecount_nz_opt(size) __in_ecount_opt(size)
#define __in_bcount_nz_opt(size) __in_bcount_opt(size)
#define __out_opt __out __exceptthat __maybenull
#define __out_ecount_opt(size) __out_ecount(size) __exceptthat __maybenull
#define __out_bcount_opt(size) __out_bcount(size) __exceptthat __maybenull
#define __out_ecount_part_opt(size,length) __out_ecount_part(size,length) __exceptthat __maybenull
#define __out_bcount_part_opt(size,length) __out_bcount_part(size,length) __exceptthat __maybenull
#define __out_ecount_full_opt(size) __out_ecount_full(size) __exceptthat __maybenull
#define __out_bcount_full_opt(size) __out_bcount_full(size) __exceptthat __maybenull
#define __out_ecount_z_opt(size) __out_ecount_opt(size) __post __nullterminated
#define __out_bcount_z_opt(size) __out_bcount_opt(size) __post __nullterminated
#define __out_ecount_part_z_opt(size,length) __out_ecount_part_opt(size,length) __post __nullterminated
#define __out_bcount_part_z_opt(size,length) __out_bcount_part_opt(size,length) __post __nullterminated
#define __out_ecount_full_z_opt(size) __out_ecount_full_opt(size) __post __nullterminated
#define __out_bcount_full_z_opt(size) __out_bcount_full_opt(size) __post __nullterminated
#define __out_ecount_nz_opt(size) __out_ecount_opt(size) __post __nullterminated
#define __out_bcount_nz_opt(size) __out_bcount_opt(size) __post __nullterminated
#define __inout_opt __inout __exceptthat __maybenull
#define __inout_ecount_opt(size) __inout_ecount(size) __exceptthat __maybenull
#define __inout_bcount_opt(size) __inout_bcount(size) __exceptthat __maybenull
#define __inout_ecount_part_opt(size,length) __inout_ecount_part(size,length) __exceptthat __maybenull
#define __inout_bcount_part_opt(size,length) __inout_bcount_part(size,length) __exceptthat __maybenull
#define __inout_ecount_full_opt(size) __inout_ecount_full(size) __exceptthat __maybenull
#define __inout_bcount_full_opt(size) __inout_bcount_full(size) __exceptthat __maybenull
#define __inout_z_opt __inout_opt __pre __nullterminated __post __nullterminated
#define __inout_ecount_z_opt(size) __inout_ecount_opt(size) __pre __nullterminated __post __nullterminated
#define __inout_ecount_z_opt(size) __inout_ecount_opt(size) __pre __nullterminated __post __nullterminated
#define __inout_bcount_z_opt(size) __inout_bcount_opt(size)
#define __inout_nz_opt __inout_opt
#define __inout_ecount_nz_opt(size) __inout_ecount_opt(size)
#define __inout_bcount_nz_opt(size) __inout_bcount_opt(size)
#define __deref_ecount(size) __ecount(1) __post __elem_readableTo(1) __post __deref __notnull __post __deref __elem_writableTo(size)
#define __deref_bcount(size) __ecount(1) __post __elem_readableTo(1) __post __deref __notnull __post __deref __byte_writableTo(size)
#define __deref_out __deref_ecount(1) __post __deref __valid __refparam
#define __deref_out_ecount(size) __deref_ecount(size) __post __deref __valid __refparam
#define __deref_out_bcount(size) __deref_bcount(size) __post __deref __valid __refparam
#define __deref_out_ecount_part(size,length) __deref_out_ecount(size) __post __deref __elem_readableTo(length)
#define __deref_out_bcount_part(size,length) __deref_out_bcount(size) __post __deref __byte_readableTo(length)
#define __deref_out_ecount_full(size) __deref_out_ecount_part(size,size)
#define __deref_out_bcount_full(size) __deref_out_bcount_part(size,size)
#define __deref_out_z __post __deref __valid __refparam __post __deref __nullterminated
#define __deref_out_ecount_z(size) __deref_out_ecount(size) __post __deref __nullterminated
#define __deref_out_bcount_z(size) __deref_out_ecount(size) __post __deref __nullterminated
#define __deref_out_nz __deref_out
#define __deref_out_ecount_nz(size) __deref_out_ecount(size)
#define __deref_out_bcount_nz(size) __deref_out_ecount(size)
#define __deref_inout __notnull __elem_readableTo(1) __pre __deref __valid __post __deref __valid __refparam
#define __deref_inout_z __deref_inout __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_ecount(size) __deref_inout __pre __deref __elem_writableTo(size) __post __deref __elem_writableTo(size)
#define __deref_inout_bcount(size) __deref_inout __pre __deref __byte_writableTo(size) __post __deref __byte_writableTo(size)
#define __deref_inout_ecount_part(size,length) __deref_inout_ecount(size) __pre __deref __elem_readableTo(length) __post __deref __elem_readableTo(length)
#define __deref_inout_bcount_part(size,length) __deref_inout_bcount(size) __pre __deref __byte_readableTo(length) __post __deref __byte_readableTo(length)
#define __deref_inout_ecount_full(size) __deref_inout_ecount_part(size,size)
#define __deref_inout_bcount_full(size) __deref_inout_bcount_part(size,size)
#define __deref_inout_z __deref_inout __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_ecount_z(size) __deref_inout_ecount(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_bcount_z(size) __deref_inout_bcount(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_nz __deref_inout
#define __deref_inout_ecount_nz(size) __deref_inout_ecount(size)
#define __deref_inout_bcount_nz(size) __deref_inout_ecount(size)
#define __deref_ecount_opt(size) __deref_ecount(size) __post __deref __exceptthat __maybenull
#define __deref_bcount_opt(size) __deref_bcount(size) __post __deref __exceptthat __maybenull
#define __deref_out_opt __deref_out __post __deref __exceptthat __maybenull
#define __deref_out_ecount_opt(size) __deref_out_ecount(size) __post __deref __exceptthat __maybenull
#define __deref_out_bcount_opt(size) __deref_out_bcount(size) __post __deref __exceptthat __maybenull
#define __deref_out_ecount_part_opt(size,length) __deref_out_ecount_part(size,length) __post __deref __exceptthat __maybenull
#define __deref_out_bcount_part_opt(size,length) __deref_out_bcount_part(size,length) __post __deref __exceptthat __maybenull
#define __deref_out_ecount_full_opt(size) __deref_out_ecount_full(size) __post __deref __exceptthat __maybenull
#define __deref_out_bcount_full_opt(size) __deref_out_bcount_full(size) __post __deref __exceptthat __maybenull
#define __deref_out_z_opt __post __deref __valid __refparam __execeptthat __maybenull __post __deref __nullterminated
#define __deref_out_ecount_z_opt(size) __deref_out_ecount_opt(size) __post __deref __nullterminated
#define __deref_out_bcount_z_opt(size) __deref_out_bcount_opt(size) __post __deref __nullterminated
#define __deref_out_nz_opt __deref_out_opt
#define __deref_out_ecount_nz_opt(size) __deref_out_ecount_opt(size)
#define __deref_out_bcount_nz_opt(size) __deref_out_bcount_opt(size)
#define __deref_inout_opt __deref_inout __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_ecount_opt(size) __deref_inout_ecount(size) __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_bcount_opt(size) __deref_inout_bcount(size) __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_ecount_part_opt(size,length) __deref_inout_ecount_part(size,length) __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_bcount_part_opt(size,length) __deref_inout_bcount_part(size,length) __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_ecount_full_opt(size) __deref_inout_ecount_full(size) __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_bcount_full_opt(size) __deref_inout_bcount_full(size) __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull
#define __deref_inout_z_opt __deref_inout_opt __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_ecount_z_opt(size) __deref_inout_ecount_opt(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_bcount_z_opt(size) __deref_inout_bcount_opt(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_inout_nz_opt __deref_inout_opt
#define __deref_inout_ecount_nz_opt(size) __deref_inout_ecount_opt(size)
#define __deref_inout_bcount_nz_opt(size) __deref_inout_bcount_opt(size)
#define __deref_opt_ecount(size) __deref_ecount(size) __exceptthat __maybenull
#define __deref_opt_bcount(size) __deref_bcount(size) __exceptthat __maybenull
#define __deref_opt_out __deref_out __exceptthat __maybenull
#define __deref_opt_out_z __deref_opt_out __post __deref __nullterminated
#define __deref_opt_out_ecount(size) __deref_out_ecount(size) __exceptthat __maybenull
#define __deref_opt_out_bcount(size) __deref_out_bcount(size) __exceptthat __maybenull
#define __deref_opt_out_ecount_part(size,length) __deref_out_ecount_part(size,length) __exceptthat __maybenull
#define __deref_opt_out_bcount_part(size,length) __deref_out_bcount_part(size,length) __exceptthat __maybenull
#define __deref_opt_out_ecount_full(size) __deref_out_ecount_full(size) __exceptthat __maybenull
#define __deref_opt_out_bcount_full(size) __deref_out_bcount_full(size) __exceptthat __maybenull
#define __deref_opt_inout __deref_inout __exceptthat __maybenull
#define __deref_opt_inout_ecount(size) __deref_inout_ecount(size) __exceptthat __maybenull
#define __deref_opt_inout_bcount(size) __deref_inout_bcount(size) __exceptthat __maybenull
#define __deref_opt_inout_ecount_part(size,length) __deref_inout_ecount_part(size,length) __exceptthat __maybenull
#define __deref_opt_inout_bcount_part(size,length) __deref_inout_bcount_part(size,length) __exceptthat __maybenull
#define __deref_opt_inout_ecount_full(size) __deref_inout_ecount_full(size) __exceptthat __maybenull
#define __deref_opt_inout_bcount_full(size) __deref_inout_bcount_full(size) __exceptthat __maybenull
#define __deref_opt_inout_z __deref_opt_inout __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_opt_inout_ecount_z(size) __deref_opt_inout_ecount(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_opt_inout_bcount_z(size) __deref_opt_inout_bcount(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_opt_inout_nz __deref_opt_inout
#define __deref_opt_inout_ecount_nz(size) __deref_opt_inout_ecount(size)
#define __deref_opt_inout_bcount_nz(size) __deref_opt_inout_bcount(size)
#define __deref_opt_ecount_opt(size) __deref_ecount_opt(size) __exceptthat __maybenull
#define __deref_opt_bcount_opt(size) __deref_bcount_opt(size) __exceptthat __maybenull
#define __deref_opt_out_opt __deref_out_opt __exceptthat __maybenull
#define __deref_opt_out_ecount_opt(size) __deref_out_ecount_opt(size) __exceptthat __maybenull
#define __deref_opt_out_bcount_opt(size) __deref_out_bcount_opt(size) __exceptthat __maybenull
#define __deref_opt_out_ecount_part_opt(size,length) __deref_out_ecount_part_opt(size,length) __exceptthat __maybenull
#define __deref_opt_out_bcount_part_opt(size,length) __deref_out_bcount_part_opt(size,length) __exceptthat __maybenull
#define __deref_opt_out_ecount_full_opt(size) __deref_out_ecount_full_opt(size) __exceptthat __maybenull
#define __deref_opt_out_bcount_full_opt(size) __deref_out_bcount_full_opt(size) __exceptthat __maybenull
#define __deref_opt_out_z_opt __post __deref __valid __refparam __exceptthat __maybenull __pre __deref __exceptthat __maybenull __post __deref __exceptthat __maybenull __post __deref __nullterminated
#define __deref_opt_out_ecount_z_opt(size) __deref_opt_out_ecount_opt(size) __post __deref __nullterminated
#define __deref_opt_out_bcount_z_opt(size) __deref_opt_out_bcount_opt(size) __post __deref __nullterminated
#define __deref_opt_out_nz_opt __deref_opt_out_opt
#define __deref_opt_out_ecount_nz_opt(size) __deref_opt_out_ecount_opt(size)
#define __deref_opt_out_bcount_nz_opt(size) __deref_opt_out_bcount_opt(size)
#define __deref_opt_inout_opt __deref_inout_opt __exceptthat __maybenull
#define __deref_opt_inout_ecount_opt(size) __deref_inout_ecount_opt(size) __exceptthat __maybenull
#define __deref_opt_inout_bcount_opt(size) __deref_inout_bcount_opt(size) __exceptthat __maybenull
#define __deref_opt_inout_ecount_part_opt(size,length) __deref_inout_ecount_part_opt(size,length) __exceptthat __maybenull
#define __deref_opt_inout_bcount_part_opt(size,length) __deref_inout_bcount_part_opt(size,length) __exceptthat __maybenull
#define __deref_opt_inout_ecount_full_opt(size) __deref_inout_ecount_full_opt(size) __exceptthat __maybenull
#define __deref_opt_inout_bcount_full_opt(size) __deref_inout_bcount_full_opt(size) __exceptthat __maybenull
#define __deref_opt_inout_z_opt __deref_opt_inout_opt __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_opt_inout_ecount_z_opt(size) __deref_opt_inout_ecount_opt(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_opt_inout_bcount_z_opt(size) __deref_opt_inout_bcount_opt(size) __pre __deref __nullterminated __post __deref __nullterminated
#define __deref_opt_inout_nz_opt __deref_opt_inout_opt
#define __deref_opt_inout_ecount_nz_opt(size) __deref_opt_inout_ecount_opt(size)
#define __deref_opt_inout_bcount_nz_opt(size) __deref_opt_inout_bcount_opt(size)

/*

-------------------------------------------------------------------------------

Advanced Annotation Definitions



Any of these may be used to directly annotate functions, and may be used in

combination with each other or with regular buffer macros. For an explanation

of each annotation, see the advanced annotations section.

-------------------------------------------------------------------------------

*/
# 1968 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/sal.h"
#define __success(expr) __inner_success(expr)
#define __nullterminated __readableTo(sentinel(0))
#define __nullnullterminated 
#define __reserved __pre __null
#define __checkReturn __inner_checkReturn
#define __typefix(ctype) __inner_typefix(ctype)
#define __override __inner_override
#define __callback __inner_callback
#define __format_string 
#define __blocksOn(resource) __inner_blocksOn(resource)
#define __control_entrypoint(category) __inner_control_entrypoint(category)
#define __data_entrypoint(category) __inner_data_entrypoint(category)


   
#define __fallthrough __inner_fallthrough






#define __analysis_assume(expr) 
# 57 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h" 2

#undef _CRT_PACKING
#define _CRT_PACKING 8

#pragma pack(push,_CRT_PACKING)

# 1 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/vadefs.h" 1
/***

*vadefs.h - defines helper macros for stdarg.h

*

*       Copyright (c) Microsoft Corporation. All rights reserved.

*

*Purpose:

*       This is a helper file for stdarg.h

*

*       [Public]

*

****/
# 13 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/vadefs.h"
       


#define _INC_VADEFS 






/*

 * Currently, all MS C compilers for Win32 platforms default to 8 byte

 * alignment.

 */
# 27 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/vadefs.h"
#undef _CRT_PACKING
#define _CRT_PACKING 8
#pragma pack(push,_CRT_PACKING)
# 40 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/vadefs.h"
#define _W64 





typedef unsigned __int64 uintptr_t;



#define _UINTPTR_T_DEFINED 






typedef char * va_list;

#define _VA_LIST_DEFINED 





#define _ADDRESSOF(v) ( &(v) )
# 79 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/vadefs.h"
#define _SLOTSIZEOF(t) (sizeof(t))
#define _APALIGN(t,ap) (__alignof(t))
# 132 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/vadefs.h"
/* A guess at the proper definitions for other platforms */

#define _INTSIZEOF(n) ( (sizeof(n) + sizeof(int) - 1) & ~(sizeof(int) - 1) )

#define _crt_va_start(ap,v) ( ap = (va_list)_ADDRESSOF(v) + _INTSIZEOF(v) )
#define _crt_va_arg(ap,t) ( *(t *)((ap += _INTSIZEOF(t)) - _INTSIZEOF(t)) )
#define _crt_va_end(ap) ( ap = (va_list)0 )







#pragma pack(pop)
# 64 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h" 2





/* preprocessor string helpers */

#define __CRT_STRINGIZE(_Value) #_Value
#define _CRT_STRINGIZE(_Value) __CRT_STRINGIZE(_Value)



#define __CRT_WIDE(_String) L ## _String
#define _CRT_WIDE(_String) __CRT_WIDE(_String)



#define __CRT_APPEND(_Value1,_Value2) _Value1 ## _Value2
#define _CRT_APPEND(_Value1,_Value2) __CRT_APPEND(_Value1, _Value2)
# 94 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
/* Define _CRTIMP_NOIA64 */




#define _CRTIMP_NOIA64 _CRTIMP



/* Define _CRTIMP2 */





#define _CRTIMP2 



/* Define _CRTIMP_ALTERNATIVE */
# 124 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRTIMP_ALTERNATIVE 



/* Define _MRTIMP */


#define _MRTIMP __declspec(dllimport)


/* Define _MRTIMP2 */






#define _MRTIMP2 
# 151 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _MCRTIMP 







#define __CLR_OR_THIS_CALL 







#define __CLRCALL_OR_CDECL __cdecl







#define _CRTIMP_PURE _CRTIMP
# 187 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _PGLOBAL 







#define _AGLOBAL 



/* define a specific constant for mixed mode */






/* Define __STDC_SECURE_LIB__ */
#define __STDC_SECURE_LIB__ 200411L

/* Retain__GOT_SECURE_LIB__ for back-compat */
#define __GOT_SECURE_LIB__ __STDC_SECURE_LIB__

/* Default value for __STDC_WANT_SECURE_LIB__ is 1 */

#define __STDC_WANT_SECURE_LIB__ 1


/* Turn off warnings if __STDC_WANT_SECURE_LIB__ is 0 */




/* See note on use of deprecate at the top of this file */
#define _CRT_DEPRECATE_TEXT(_Text) __declspec(deprecated(_Text))

/* Define _CRT_INSECURE_DEPRECATE */
/* See note on use of deprecate at the top of this file */
# 235 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_INSECURE_DEPRECATE(_Replacement) _CRT_DEPRECATE_TEXT("This function or variable may be unsafe. Consider using " #_Replacement " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details.")



/* Define _CRT_INSECURE_DEPRECATE_MEMORY */
/* See note on use of deprecate at the top of this file */






#define _CRT_INSECURE_DEPRECATE_MEMORY(_Replacement) 





/* Define _CRT_INSECURE_DEPRECATE_GLOBALS */
/* See note on use of deprecate at the top of this file */
# 268 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_INSECURE_DEPRECATE_GLOBALS(_Replacement) _CRT_INSECURE_DEPRECATE(_Replacement)




/* Define _CRT_MANAGED_HEAP_DEPRECATE */
/* See note on use of deprecate at the top of this file */
# 289 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_MANAGED_HEAP_DEPRECATE 




/* Change the __FILL_BUFFER_PATTERN to 0xFE to fix security function buffer overrun detection bug */
#define _SECURECRT_FILL_BUFFER_PATTERN 0xFE

/* obsolete stuff */

/* Define _CRT_OBSOLETE */
/* See note on use of deprecate at the top of this file */
# 309 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_OBSOLETE(_NewItem) _CRT_DEPRECATE_TEXT("This function or variable has been superceded by newer library or operating system functionality. Consider using " #_NewItem " instead. See online help for details.")




/* jit64 instrinsic stuff */





#define _CRT_JIT_INTRINSIC 



/* Define overload switches */


#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES 0
# 337 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
  /* _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT is ignored if _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES is set to 0 */
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_COUNT 0
# 349 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES 1
# 362 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_SECURE_CPP_OVERLOAD_STANDARD_NAMES_MEMORY 0
# 372 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_SECURE_CPP_OVERLOAD_SECURE_NAMES_MEMORY 0
# 381 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_SECURE_CPP_NOTHROW throw()


/* Define _CRT_NONSTDC_DEPRECATE */
/* See note on use of deprecate at the top of this file */
# 394 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_NONSTDC_DEPRECATE(_NewName) _CRT_DEPRECATE_TEXT("The POSIX name for this item is deprecated. Instead, use the ISO C++ conformant name: " #_NewName ". See online help for details.")





typedef unsigned __int64 size_t;



#define _SIZE_T_DEFINED 




typedef size_t rsize_t;
#define _RSIZE_T_DEFINED 





typedef __int64 intptr_t;



#define _INTPTR_T_DEFINED 
# 434 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
typedef __int64 ptrdiff_t;



#define _PTRDIFF_T_DEFINED 



typedef unsigned short wchar_t;
#define _WCHAR_T_DEFINED 



typedef unsigned short wint_t;
typedef unsigned short wctype_t;
#define _WCTYPE_T_DEFINED 
# 468 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _ERRNO_T_DEFINED 
typedef int errno_t;



typedef long __time32_t; /* 32-bit time value */
#define _TIME32_T_DEFINED 



typedef __int64 __time64_t; /* 64-bit time value */
#define _TIME64_T_DEFINED 






typedef __time64_t time_t; /* time value */

#define _TIME_T_DEFINED 







#define _CONST_RETURN 







#define UNALIGNED 







#define _CRT_ALIGN(x) __declspec(align(x))



/* Define _CRTNOALIAS, _CRTRESTRICT */


#define _CRTNOALIAS __declspec(noalias)



#define _CRTRESTRICT __declspec(restrict)






#define __CRTDECL __cdecl



/* error reporting helpers */
#define __STR2WSTR(str) L ##str
#define _STR2WSTR(str) __STR2WSTR(str)

#define __FILEW__ _STR2WSTR(__FILE__)
#define __FUNCTIONW__ _STR2WSTR(__FUNCTION__)

/* invalid_parameter */



 void __attribute__((__cdecl__)) _invalid_parameter_noinfo(void);
 __attribute__((noreturn)) void __attribute__((__cdecl__)) _invalid_parameter_noinfo_noreturn(void);


 __attribute__((noreturn))
void __attribute__((__cdecl__)) _invoke_watson( const wchar_t *, const wchar_t *, const wchar_t *, unsigned int, uintptr_t);






 /* By default, _CRT_SECURE_INVALID_PARAMETER in retail invokes _invalid_parameter_noinfo_noreturn(),

  * which is marked __declspec(noreturn) and does not return control to the application. Even if 

  * _set_invalid_parameter_handler() is used to set a new invalid parameter handler which does return

  * control to the application, _invalid_parameter_noinfo_noreturn() will terminate the application and

  * invoke Watson. You can overwrite the definition of _CRT_SECURE_INVALID_PARAMETER if you need.

  *

  * _CRT_SECURE_INVALID_PARAMETER is used in the Standard C++ Libraries and the SafeInt library.

  */
# 566 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_SECURE_INVALID_PARAMETER(expr) ::_invalid_parameter_noinfo_noreturn()




#define _ARGMAX 100

/* _TRUNCATE */

#define _TRUNCATE ((size_t)-1)


/* helper macros for cpp overloads */
# 726 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_0(_ReturnType,_FuncName,_DstType,_Dst) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_1(_ReturnType,_FuncName,_DstType,_Dst,_TType1,_TArg1) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_2(_ReturnType,_FuncName,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_3(_ReturnType,_FuncName,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_4(_ReturnType,_FuncName,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3,_TType4,_TArg4) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_1_1(_ReturnType,_FuncName,_HType1,_HArg1,_DstType,_Dst,_TType1,_TArg1) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_1_2(_ReturnType,_FuncName,_HType1,_HArg1,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_1_3(_ReturnType,_FuncName,_HType1,_HArg1,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_2_0(_ReturnType,_FuncName,_HType1,_HArg1,_HType2,_HArg2,_DstType,_Dst) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_1_ARGLIST(_ReturnType,_FuncName,_VFuncName,_DstType,_Dst,_TType1,_TArg1) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_0_2_ARGLIST(_ReturnType,_FuncName,_VFuncName,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) 
#define __DEFINE_CPP_OVERLOAD_SECURE_FUNC_SPLITPATH(_ReturnType,_FuncName,_DstType,_Src) 




#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_0(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_0_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _SalAttributeDst, _DstType, _Dst)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_1(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_1_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_3(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_3_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2, _TType3, _TArg3)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_4(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3,_TType4,_TArg4) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_4_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2, _TType3, _TArg3, _TType4, _TArg4)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_1_1(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_HType1,_HArg1,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_1_1_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _HType1, _HArg1, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_2_0(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_HType1,_HArg1,_HType2,_HArg2,_SalAttributeDst,_DstType,_Dst) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_2_0_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _HType1, _HArg1, _HType2, _HArg2, _SalAttributeDst, _DstType, _Dst)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_1_ARGLIST(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_VFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_1_ARGLIST_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _VFuncName, _VFuncName ##_s, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_ARGLIST(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_VFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_ARGLIST_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _VFuncName, _VFuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_SIZE(_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_SIZE_EX(_DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2)


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_3_SIZE(_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_3_SIZE_EX(_DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2, _TType3, _TArg3)



#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_0(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_0_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _SalAttributeDst, _DstType, _Dst)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_1(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_1_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _SalAttributeDst, _DstType, _DstType, _Dst, _TType1, _TArg1)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_3(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_3_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2, _TType3, _TArg3)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_4(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3,_TType4,_TArg4) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_4_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2, _TType3, _TArg3, _TType4, _TArg4)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_1_1(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_HType1,_HArg1,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_1_1_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _HType1, _HArg1, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_2_0(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_HType1,_HArg1,_HType2,_HArg2,_SalAttributeDst,_DstType,_Dst) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_2_0_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _HType1, _HArg1, _HType2, _HArg2, _SalAttributeDst, _DstType, _Dst)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_1_ARGLIST(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_VFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_1_ARGLIST_EX(_ReturnType, _ReturnPolicy, _DeclSpec, _FuncName, _FuncName ##_s, _VFuncName, _VFuncName ##_s, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_SIZE(_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_SIZE_EX(_DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2)


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_3_SIZE(_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_3_SIZE_EX(_DeclSpec, _FuncName, _FuncName ##_s, _DstType, _SalAttributeDst, _DstType, _Dst, _TType1, _TArg1, _TType2, _TArg2, _TType3, _TArg3)
# 1808 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define __RETURN_POLICY_SAME(_FunctionCall) 
#define __RETURN_POLICY_DST(_FunctionCall) 
#define __RETURN_POLICY_VOID(_FunctionCall) 
#define __EMPTY_DECLSPEC 

#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_0_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SalAttributeDst,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_0_CGETS(_ReturnType,_DeclSpec,_FuncName,_SalAttributeDst,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_FuncName ##_s) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_1_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_3_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_4_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3,_TType4,_TArg4) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3, _TType4 _TArg4);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_1_1_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_HType1,_HArg1,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_HType1 _HArg1, _SalAttributeDst _DstType *_Dst, _TType1 _TArg1);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_2_0_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_HType1,_HArg1,_HType2,_HArg2,_SalAttributeDst,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_HType1 _HArg1, _HType2 _HArg2, _SalAttributeDst _DstType *_Dst);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_1_ARGLIST_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_VFuncName,_SecureVFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, ...); _CRT_INSECURE_DEPRECATE(_SecureVFuncName) _DeclSpec _ReturnType __cdecl _VFuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, va_list _Args);



#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_ARGLIST_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_VFuncName,_SecureVFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_FuncName ##_s) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, ...); _CRT_INSECURE_DEPRECATE(_SecureVFuncName) _DeclSpec _ReturnType __cdecl _VFuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, va_list _Args);



#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_2_SIZE_EX(_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec size_t __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2);


#define __DEFINE_CPP_OVERLOAD_STANDARD_FUNC_0_3_SIZE_EX(_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec size_t __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_0_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SalAttributeDst,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_0_GETS(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_FuncName ##_s) _DeclSpec _ReturnType __cdecl _FuncName(_DstType *_Dst);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_1_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_3_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_4_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3,_TType4,_TArg4) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3, _TType4 _TArg4);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_1_1_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_HType1,_HArg1,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_HType1 _HArg1, _SalAttributeDst _DstType *_Dst, _TType1 _TArg1);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_2_0_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_HType1,_HArg1,_HType2,_HArg2,_SalAttributeDst,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_HType1 _HArg1, _HType2 _HArg2, _SalAttributeDst _DstType *_Dst);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_1_ARGLIST_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_SecureFuncName,_VFuncName,_SecureVFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, ...); _CRT_INSECURE_DEPRECATE(_SecureVFuncName) _DeclSpec _ReturnType __cdecl _VFuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, va_list _Args);



#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_ARGLIST(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_VFuncName,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_FuncName ##_s) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, ...); _CRT_INSECURE_DEPRECATE(_VFuncName ##_s) _DeclSpec _ReturnType __cdecl _VFuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, va_list _Args);



#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_ARGLIST_EX(_ReturnType,_ReturnPolicy,_DeclSpec,_FuncName,_VFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_FuncName ##_s) _DeclSpec _ReturnType __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, ...); _CRT_INSECURE_DEPRECATE(_VFuncName ##_s) _DeclSpec _ReturnType __cdecl _VFuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, va_list _Args);



#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_2_SIZE_EX(_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec size_t __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2);


#define __DEFINE_CPP_OVERLOAD_STANDARD_NFUNC_0_3_SIZE_EX(_DeclSpec,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) _CRT_INSECURE_DEPRECATE(_SecureFuncName) _DeclSpec size_t __cdecl _FuncName(_SalAttributeDst _DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3);



#define __DECLARE_CPP_OVERLOAD_INLINE_FUNC_0_0_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst)




#define __DEFINE_CPP_OVERLOAD_INLINE_FUNC_0_0_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst) 

#define __DECLARE_CPP_OVERLOAD_INLINE_FUNC_0_1_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst, _TType1 _TArg1)




#define __DEFINE_CPP_OVERLOAD_INLINE_FUNC_0_1_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1) 

#define __DECLARE_CPP_OVERLOAD_INLINE_FUNC_0_2_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2)




#define __DEFINE_CPP_OVERLOAD_INLINE_FUNC_0_2_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) 

#define __DECLARE_CPP_OVERLOAD_INLINE_FUNC_0_3_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3)




#define __DEFINE_CPP_OVERLOAD_INLINE_FUNC_0_3_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) 

#define __DECLARE_CPP_OVERLOAD_INLINE_NFUNC_0_0_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst)




#define __DEFINE_CPP_OVERLOAD_INLINE_NFUNC_0_0_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst) 

#define __DECLARE_CPP_OVERLOAD_INLINE_NFUNC_0_1_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst, _TType1 _TArg1)




#define __DEFINE_CPP_OVERLOAD_INLINE_NFUNC_0_1_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1) 

#define __DECLARE_CPP_OVERLOAD_INLINE_NFUNC_0_2_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2)




#define __DEFINE_CPP_OVERLOAD_INLINE_NFUNC_0_2_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2) 

#define __DECLARE_CPP_OVERLOAD_INLINE_NFUNC_0_3_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) _CRT_INSECURE_DEPRECATE(_SecureFuncName) __inline _ReturnType __CRTDECL _FuncName(_DstType *_Dst, _TType1 _TArg1, _TType2 _TArg2, _TType3 _TArg3)




#define __DEFINE_CPP_OVERLOAD_INLINE_NFUNC_0_3_EX(_ReturnType,_ReturnPolicy,_FuncName,_SecureFuncName,_SecureDstType,_SalAttributeDst,_DstType,_Dst,_TType1,_TArg1,_TType2,_TArg2,_TType3,_TArg3) 




struct threadlocaleinfostruct;
struct threadmbcinfostruct;
typedef struct threadlocaleinfostruct * pthreadlocinfo;
typedef struct threadmbcinfostruct * pthreadmbcinfo;
struct __lc_time_data;

typedef struct localeinfo_struct
{
    pthreadlocinfo locinfo;
    pthreadmbcinfo mbcinfo;
} _locale_tstruct, *_locale_t;


typedef struct tagLC_ID {
        unsigned short wLanguage;
        unsigned short wCountry;
        unsigned short wCodePage;
} LC_ID, *LPLC_ID;
#define _TAGLC_ID_DEFINED 



typedef struct threadlocaleinfostruct {
        int refcount;
        unsigned int lc_codepage;
        unsigned int lc_collate_cp;
        unsigned long lc_handle[6]; /* LCID */
        LC_ID lc_id[6];
        struct {
            char *locale;
            wchar_t *wlocale;
            int *refcount;
            int *wrefcount;
        } lc_category[6];
        int lc_clike;
        int mb_cur_max;
        int * lconv_intl_refcount;
        int * lconv_num_refcount;
        int * lconv_mon_refcount;
        struct lconv * lconv;
        int * ctype1_refcount;
        unsigned short * ctype1;
        const unsigned short * pctype;
        const unsigned char * pclmap;
        const unsigned char * pcumap;
        struct __lc_time_data * lc_time_curr;
} threadlocinfo;
#define _THREADLOCALEINFO 
# 2010 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _Check_return_opt_ 





#define _Check_return_wat_ 





#define __crt_typefix(ctype) 
# 2033 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
#define _CRT_UNUSED(x) (void)x


#pragma pack(pop)
# 26 "c_include/windows/original/stdlib.h" 2
# 1 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/limits.h" 1
/***

*limits.h - implementation dependent values

*

*       Copyright (c) Microsoft Corporation.  All rights reserved.

*

*Purpose:

*       Contains defines for a number of implementation dependent values

*       which are commonly used in C programs.

*       [ANSI]

*

*       [Public]

*

****/
# 15 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/limits.h"
       

# 1 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h" 1
/***

*crtdefs.h - definitions/declarations common to all CRT

*

*       Copyright (c) Microsoft Corporation. All rights reserved.

*

*Purpose:

*       This file has mostly defines used by the entire CRT.

*

*       [Public]

*

****/
# 13 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/crtdefs.h"
/* Lack of pragma once is deliberate */

/* Define _CRTIMP */
# 18 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/limits.h" 2


#define _INC_LIMITS 


#define CHAR_BIT 8
#define SCHAR_MIN (-128)
#define SCHAR_MAX 127
#define UCHAR_MAX 0xff


#define CHAR_MIN SCHAR_MIN
#define CHAR_MAX SCHAR_MAX





#define MB_LEN_MAX 5
#define SHRT_MIN (-32768)
#define SHRT_MAX 32767
#define USHRT_MAX 0xffff
#define INT_MIN (-2147483647 - 1)
#define INT_MAX 2147483647
#define UINT_MAX 0xffffffff
#define LONG_MIN (-2147483647L - 1)
#define LONG_MAX 2147483647L
#define ULONG_MAX 0xffffffffUL
#define LLONG_MAX 9223372036854775807i64
#define LLONG_MIN (-9223372036854775807i64 - 1)
#define ULLONG_MAX 0xffffffffffffffffui64

#define _I8_MIN (-127i8 - 1)
#define _I8_MAX 127i8
#define _UI8_MAX 0xffui8

#define _I16_MIN (-32767i16 - 1)
#define _I16_MAX 32767i16
#define _UI16_MAX 0xffffui16

#define _I32_MIN (-2147483647i32 - 1)
#define _I32_MAX 2147483647i32
#define _UI32_MAX 0xffffffffui32

/* minimum signed 64 bit value */
#define _I64_MIN (-9223372036854775807i64 - 1)
/* maximum signed 64 bit value */
#define _I64_MAX 9223372036854775807i64
/* maximum unsigned 64 bit value */
#define _UI64_MAX 0xffffffffffffffffui64
# 80 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/limits.h"
#define SIZE_MAX _UI64_MAX






/* While waiting to the C standard committee to finalize the decision on RSIZE_MAX and rsize_t,

 * we define RSIZE_MAX as SIZE_MAX

 */
# 91 "C:/Program Files (x86)/Microsoft Visual Studio 10.0/VC/include/limits.h"
#define RSIZE_MAX SIZE_MAX
# 27 "c_include/windows/original/stdlib.h" 2

/*
 * Currently, all MS C compilers for Win32 platforms default to 8 byte
 * alignment.
 */
#pragma pack(push,_CRT_PACKING)





/* Define NULL pointer value */




#define NULL ((void *)0)



/* Definition of the argument values for the exit() function */

#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1





typedef int (__attribute__((__cdecl__)) * _onexit_t)(void);
# 71 "c_include/windows/original/stdlib.h"
#define _ONEXIT_T_DEFINED 



/* Data structure definitions for div and ldiv runtimes. */



typedef struct _div_t {
        int quot;
        int rem;
} div_t;

typedef struct _ldiv_t {
        long quot;
        long rem;
} ldiv_t;

typedef struct _lldiv_t {
        long long quot;
        long long rem;
} lldiv_t;

#define _DIV_T_DEFINED 


/*
 * structs used to fool the compiler into not generating floating point
 * instructions when copying and pushing [long] double values
 */





#pragma pack(4)
typedef struct {
    unsigned char ld[10];
} _LDOUBLE;
#pragma pack()

#define _PTR_LD(x) ((unsigned char *)(&(x)->ld))
# 126 "c_include/windows/original/stdlib.h"
typedef struct {
        double x;
} _CRT_DOUBLE;

typedef struct {
    float f;
} _CRT_FLOAT;

/* push and pop long, which is #defined as __int64 by a spec2k test */
       
#undef long

typedef struct {
        /*
         * Assume there is a long double type
         */
        long double x;
} _LONGDOUBLE;

       

#pragma pack(4)
typedef struct {
    unsigned char ld12[12];
} _LDBL12;
#pragma pack()

#define _CRT_DOUBLE_DEC 


/* Maximum value that can be returned by the rand function. */

#define RAND_MAX 0x7fff

/*
 * Maximum number of bytes in multi-byte character in the current locale
 * (also defined in ctype.h).
 */

#define MB_CUR_MAX ___mb_cur_max_func()

 extern int __mb_cur_max;




 int __attribute__((__cdecl__)) ___mb_cur_max_func(void);
 int __attribute__((__cdecl__)) ___mb_cur_max_l_func(_locale_t);


/* Minimum and maximum macros */

#define __max(a,b) (((a) > (b)) ? (a) : (b))
#define __min(a,b) (((a) < (b)) ? (a) : (b))

/*
 * Sizes for buffers used by the _makepath() and _splitpath() functions.
 * note that the sizes include space for 0-terminator
 */
#define _MAX_PATH 260
#define _MAX_DRIVE 3
#define _MAX_DIR 256
#define _MAX_FNAME 256
#define _MAX_EXT 256

/*
 * Argument values for _set_error_mode().
 */
#define _OUT_TO_DEFAULT 0
#define _OUT_TO_STDERR 1
#define _OUT_TO_MSGBOX 2
#define _REPORT_ERRMODE 3

/*
 * Argument values for _set_abort_behavior().
 */
#define _WRITE_ABORT_MSG 0x1
#define _CALL_REPORTFAULT 0x2

/*
 * Sizes for buffers used by the getenv/putenv family of functions.
 */
#define _MAX_ENV 32767


/* a purecall handler procedure. Never returns normally */
typedef void (__attribute__((__cdecl__)) *_purecall_handler)(void);

/* establishes a purecall handler for the process */
 _purecall_handler __attribute__((__cdecl__)) _set_purecall_handler( _purecall_handler _Handler);
 _purecall_handler __attribute__((__cdecl__)) _get_purecall_handler(void);
# 231 "c_include/windows/original/stdlib.h"
/* a invalid_arg handler procedure. */
typedef void (__attribute__((__cdecl__)) *_invalid_parameter_handler)(const wchar_t *, const wchar_t *, const wchar_t *, unsigned int, uintptr_t);

/* establishes a invalid_arg handler for the process */
 _invalid_parameter_handler __attribute__((__cdecl__)) _set_invalid_parameter_handler( _invalid_parameter_handler _Handler);
 _invalid_parameter_handler __attribute__((__cdecl__)) _get_invalid_parameter_handler(void);
# 250 "c_include/windows/original/stdlib.h"
/* External variable declarations */

#define _CRT_ERRNO_DEFINED 
 extern int * __attribute__((__cdecl__)) _errno(void);
#define errno (*_errno())

errno_t __attribute__((__cdecl__)) _set_errno( int _Value);
errno_t __attribute__((__cdecl__)) _get_errno( int * _Value);


 unsigned long * __attribute__((__cdecl__)) __doserrno(void);
#define _doserrno (*__doserrno())

errno_t __attribute__((__cdecl__)) _set_doserrno( unsigned long _Value);
errno_t __attribute__((__cdecl__)) _get_doserrno( unsigned long * _Value);

/* you can't modify this, but it is non-const for backcompat */
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "strerror" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char ** __attribute__((__cdecl__)) __sys_errlist(void);
#define _sys_errlist (__sys_errlist())

 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "strerror" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) int * __attribute__((__cdecl__)) __sys_nerr(void);
#define _sys_nerr (*__sys_nerr())
# 287 "c_include/windows/original/stdlib.h"
 extern int __argc; /* count of cmd line args */
 extern char ** __argv; /* pointer to table of cmd line args */
 extern wchar_t ** __wargv; /* pointer to table of wide cmd line args */
# 303 "c_include/windows/original/stdlib.h"
 extern char ** _environ; /* pointer to environment table */
 extern wchar_t ** _wenviron; /* pointer to wide environment table */


__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_get_pgmptr" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) extern char * _pgmptr; /* points to the module (EXE) name */
__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_get_wpgmptr" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) extern wchar_t * _wpgmptr; /* points to the module (EXE) wide name */
# 325 "c_include/windows/original/stdlib.h"
errno_t __attribute__((__cdecl__)) _get_pgmptr( char ** _Value);
errno_t __attribute__((__cdecl__)) _get_wpgmptr( wchar_t ** _Value);



__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_get_fmode" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) extern int _fmode; /* default file translation mode */





 errno_t __attribute__((__cdecl__)) _set_fmode( int _Mode);
 errno_t __attribute__((__cdecl__)) _get_fmode( int * _PMode);

/* _countof helper */


#define _countof(_Array) (sizeof(_Array) / sizeof(_Array[0]))
# 353 "c_include/windows/original/stdlib.h"
/* function prototypes */


#define _CRT_TERMINATE_DEFINED 
 __attribute__((noreturn)) void __attribute__((__cdecl__)) exit( int _Code);
 __attribute__((noreturn)) void __attribute__((__cdecl__)) _exit( int _Code);
 void __attribute__((__cdecl__)) abort(void);


 unsigned int __attribute__((__cdecl__)) _set_abort_behavior( unsigned int _Flags, unsigned int _Mask);


#define _CRT_ABS_DEFINED 
        int __attribute__((__cdecl__)) abs( int _X);
        long __attribute__((__cdecl__)) labs( long _X);
        long long __attribute__((__cdecl__)) llabs( long long _X);


        __int64 __attribute__((__cdecl__)) _abs64(__int64);
# 402 "c_include/windows/original/stdlib.h"
        int __attribute__((__cdecl__)) atexit(void (__attribute__((__cdecl__)) *)(void));


#define _CRT_ATOF_DEFINED 
 double __attribute__((__cdecl__)) atof( const char *_String);
 double __attribute__((__cdecl__)) _atof_l( const char *_String, _locale_t _Locale);

 int __attribute__((__cdecl__)) atoi( const char *_Str);
 int __attribute__((__cdecl__)) _atoi_l( const char *_Str, _locale_t _Locale);
 long __attribute__((__cdecl__)) atol( const char *_Str);
 long __attribute__((__cdecl__)) _atol_l( const char *_Str, _locale_t _Locale);

#define _CRT_ALGO_DEFINED 

 void * __attribute__((__cdecl__)) bsearch_s( const void * _Key, const void * _Base,
        rsize_t _NumOfElements, rsize_t _SizeOfElements,
        int (__attribute__((__cdecl__)) * _PtFuncCompare)(void *, const void *, const void *), void * _Context);

 void * __attribute__((__cdecl__)) bsearch( const void * _Key, const void * _Base,
        size_t _NumOfElements, size_t _SizeOfElements,
        int (__attribute__((__cdecl__)) * _PtFuncCompare)(const void *, const void *));


 void __attribute__((__cdecl__)) qsort_s( void * _Base,
        rsize_t _NumOfElements, rsize_t _SizeOfElements,
        int (__attribute__((__cdecl__)) * _PtFuncCompare)(void *, const void *, const void *), void *_Context);

 void __attribute__((__cdecl__)) qsort( void * _Base,
 size_t _NumOfElements, size_t _SizeOfElements,
        int (__attribute__((__cdecl__)) * _PtFuncCompare)(const void *, const void *));

        unsigned short __attribute__((__cdecl__)) _byteswap_ushort( unsigned short _Short);
        unsigned long __attribute__((__cdecl__)) _byteswap_ulong ( unsigned long _Long);
        unsigned __int64 __attribute__((__cdecl__)) _byteswap_uint64( unsigned __int64 _Int64);
 div_t __attribute__((__cdecl__)) div( int _Numerator, int _Denominator);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_dupenv_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) getenv( const char * _VarName);

 errno_t __attribute__((__cdecl__)) getenv_s( size_t * _ReturnSize, char * _DstBuf, rsize_t _DstSize, const char * _VarName);







 errno_t __attribute__((__cdecl__)) _dupenv_s( char **_PBuffer, size_t * _PBufferSizeInBytes, const char * _VarName);





 errno_t __attribute__((__cdecl__)) _itoa_s( int _Value, char * _DstBuf, size_t _Size, int _Radix);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_itoa_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _itoa(int _Value, char *_Dest, int _Radix);
 errno_t __attribute__((__cdecl__)) _i64toa_s( __int64 _Val, char * _DstBuf, size_t _Size, int _Radix);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_i64toa_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _i64toa( __int64 _Val, char * _DstBuf, int _Radix);
 errno_t __attribute__((__cdecl__)) _ui64toa_s( unsigned __int64 _Val, char * _DstBuf, size_t _Size, int _Radix);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ui64toa_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _ui64toa( unsigned __int64 _Val, char * _DstBuf, int _Radix);
 __int64 __attribute__((__cdecl__)) _atoi64( const char * _String);
 __int64 __attribute__((__cdecl__)) _atoi64_l( const char * _String, _locale_t _Locale);
 __int64 __attribute__((__cdecl__)) _strtoi64( const char * _String, char ** _EndPtr, int _Radix);
 __int64 __attribute__((__cdecl__)) _strtoi64_l( const char * _String, char ** _EndPtr, int _Radix, _locale_t _Locale);
 unsigned __int64 __attribute__((__cdecl__)) _strtoui64( const char * _String, char ** _EndPtr, int _Radix);
 unsigned __int64 __attribute__((__cdecl__)) _strtoui64_l( const char * _String, char ** _EndPtr, int _Radix, _locale_t _Locale);
 ldiv_t __attribute__((__cdecl__)) ldiv( long _Numerator, long _Denominator);
 lldiv_t __attribute__((__cdecl__)) lldiv( long long _Numerator, long long _Denominator);
# 489 "c_include/windows/original/stdlib.h"
 errno_t __attribute__((__cdecl__)) _ltoa_s( long _Val, char * _DstBuf, size_t _Size, int _Radix);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ltoa_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _ltoa(long _Value, char *_Dest, int _Radix);
 int __attribute__((__cdecl__)) mblen( const char * _Ch, size_t _MaxCount);
 int __attribute__((__cdecl__)) _mblen_l( const char * _Ch, size_t _MaxCount, _locale_t _Locale);
 size_t __attribute__((__cdecl__)) _mbstrlen( const char * _Str);
 size_t __attribute__((__cdecl__)) _mbstrlen_l( const char *_Str, _locale_t _Locale);
 size_t __attribute__((__cdecl__)) _mbstrnlen( const char *_Str, size_t _MaxCount);
 size_t __attribute__((__cdecl__)) _mbstrnlen_l( const char *_Str, size_t _MaxCount, _locale_t _Locale);
 int __attribute__((__cdecl__)) mbtowc( wchar_t * _DstCh, const char * _SrcCh, size_t _SrcSizeInBytes);
 int __attribute__((__cdecl__)) _mbtowc_l( wchar_t * _DstCh, const char * _SrcCh, size_t _SrcSizeInBytes, _locale_t _Locale);
 errno_t __attribute__((__cdecl__)) mbstowcs_s( size_t * _PtNumOfCharConverted, wchar_t * _DstBuf, size_t _SizeInWords, const char * _SrcBuf, size_t _MaxCount );

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "mbstowcs_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) size_t __attribute__((__cdecl__)) mbstowcs( wchar_t *_Dest, const char * _Source, size_t _MaxCount);

 errno_t __attribute__((__cdecl__)) _mbstowcs_s_l( size_t * _PtNumOfCharConverted, wchar_t * _DstBuf, size_t _SizeInWords, const char * _SrcBuf, size_t _MaxCount, _locale_t _Locale);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_mbstowcs_s_l" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) size_t __attribute__((__cdecl__)) _mbstowcs_l( wchar_t *_Dest, const char * _Source, size_t _MaxCount, _locale_t _Locale);

 int __attribute__((__cdecl__)) rand(void);




 int __attribute__((__cdecl__)) _set_error_mode( int _Mode);

 void __attribute__((__cdecl__)) srand( unsigned int _Seed);
 double __attribute__((__cdecl__)) strtod( const char * _Str, char ** _EndPtr);
 double __attribute__((__cdecl__)) _strtod_l( const char * _Str, char ** _EndPtr, _locale_t _Locale);
 long __attribute__((__cdecl__)) strtol( const char * _Str, char ** _EndPtr, int _Radix );
 long __attribute__((__cdecl__)) _strtol_l( const char *_Str, char **_EndPtr, int _Radix, _locale_t _Locale);
 unsigned long __attribute__((__cdecl__)) strtoul( const char * _Str, char ** _EndPtr, int _Radix);
 unsigned long __attribute__((__cdecl__)) _strtoul_l(const char * _Str, char **_EndPtr, int _Radix, _locale_t _Locale);

#define _CRT_SYSTEM_DEFINED 
 int __attribute__((__cdecl__)) system( const char * _Command);

 errno_t __attribute__((__cdecl__)) _ultoa_s( unsigned long _Val, char * _DstBuf, size_t _Size, int _Radix);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ultoa_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _ultoa(unsigned long _Value, char *_Dest, int _Radix);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "wctomb_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) int __attribute__((__cdecl__)) wctomb( char * _MbCh, wchar_t _WCh);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_wctomb_s_l" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) int __attribute__((__cdecl__)) _wctomb_l( char * _MbCh, wchar_t _WCh, _locale_t _Locale);

 errno_t __attribute__((__cdecl__)) wctomb_s( int * _SizeConverted, char * _MbCh, rsize_t _SizeInBytes, wchar_t _WCh);

 errno_t __attribute__((__cdecl__)) _wctomb_s_l( int * _SizeConverted, char * _MbCh, size_t _SizeInBytes, wchar_t _WCh, _locale_t _Locale);
 errno_t __attribute__((__cdecl__)) wcstombs_s( size_t * _PtNumOfCharConverted, char * _Dst, size_t _DstSizeInBytes, const wchar_t * _Src, size_t _MaxCountInBytes);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "wcstombs_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) size_t __attribute__((__cdecl__)) wcstombs( char *_Dest, const wchar_t * _Source, size_t _MaxCount);
 errno_t __attribute__((__cdecl__)) _wcstombs_s_l( size_t * _PtNumOfCharConverted, char * _Dst, size_t _DstSizeInBytes, const wchar_t * _Src, size_t _MaxCountInBytes, _locale_t _Locale);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_wcstombs_s_l" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) size_t __attribute__((__cdecl__)) _wcstombs_l( char *_Dest, const wchar_t * _Source, size_t _MaxCount, _locale_t _Locale);
# 569 "c_include/windows/original/stdlib.h"
#define _CRT_ALLOCATION_DEFINED 
# 602 "c_include/windows/original/stdlib.h"
 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) calloc( size_t _Count, size_t _Size);
 __attribute__((noalias)) void __attribute__((__cdecl__)) free( void * _Memory);
 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) malloc( size_t _Size);

 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) realloc( void * _Memory, size_t _NewSize);

 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _recalloc( void * _Memory, size_t _Count, size_t _Size);
 __attribute__((noalias)) void __attribute__((__cdecl__)) _aligned_free( void * _Memory);
 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _aligned_malloc( size_t _Size, size_t _Alignment);
 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _aligned_offset_malloc( size_t _Size, size_t _Alignment, size_t _Offset);

 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _aligned_realloc( void * _Memory, size_t _NewSize, size_t _Alignment);

 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _aligned_recalloc( void * _Memory, size_t _Count, size_t _Size, size_t _Alignment);

 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _aligned_offset_realloc( void * _Memory, size_t _NewSize, size_t _Alignment, size_t _Offset);

 __attribute__((noalias)) __attribute__((restrict)) void * __attribute__((__cdecl__)) _aligned_offset_recalloc( void * _Memory, size_t _Count, size_t _Size, size_t _Alignment, size_t _Offset);
 size_t __attribute__((__cdecl__)) _aligned_msize( void * _Memory, size_t _Alignment, size_t _Offset);
# 645 "c_include/windows/original/stdlib.h"
/* wide function prototypes, also declared in wchar.h  */

 errno_t __attribute__((__cdecl__)) _itow_s ( int _Val, wchar_t * _DstBuf, size_t _SizeInWords, int _Radix);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_itow_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) wchar_t * __attribute__((__cdecl__)) _itow(int _Value, wchar_t *_Dest, int _Radix);
 errno_t __attribute__((__cdecl__)) _ltow_s ( long _Val, wchar_t * _DstBuf, size_t _SizeInWords, int _Radix);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ltow_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) wchar_t * __attribute__((__cdecl__)) _ltow(long _Value, wchar_t *_Dest, int _Radix);
 errno_t __attribute__((__cdecl__)) _ultow_s ( unsigned long _Val, wchar_t * _DstBuf, size_t _SizeInWords, int _Radix);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ultow_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) wchar_t * __attribute__((__cdecl__)) _ultow(unsigned long _Value, wchar_t *_Dest, int _Radix);
 double __attribute__((__cdecl__)) wcstod( const wchar_t * _Str, wchar_t ** _EndPtr);
 double __attribute__((__cdecl__)) _wcstod_l( const wchar_t *_Str, wchar_t ** _EndPtr, _locale_t _Locale);
 long __attribute__((__cdecl__)) wcstol( const wchar_t *_Str, wchar_t ** _EndPtr, int _Radix);
 long __attribute__((__cdecl__)) _wcstol_l( const wchar_t *_Str, wchar_t **_EndPtr, int _Radix, _locale_t _Locale);
 unsigned long __attribute__((__cdecl__)) wcstoul( const wchar_t *_Str, wchar_t ** _EndPtr, int _Radix);
 unsigned long __attribute__((__cdecl__)) _wcstoul_l( const wchar_t *_Str, wchar_t **_EndPtr, int _Radix, _locale_t _Locale);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_wdupenv_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) wchar_t * __attribute__((__cdecl__)) _wgetenv( const wchar_t * _VarName);
 errno_t __attribute__((__cdecl__)) _wgetenv_s( size_t * _ReturnSize, wchar_t * _DstBuf, size_t _DstSizeInWords, const wchar_t * _VarName);







 errno_t __attribute__((__cdecl__)) _wdupenv_s( wchar_t **_Buffer, size_t *_BufferSizeInWords, const wchar_t *_VarName);






#define _CRT_WSYSTEM_DEFINED 
 int __attribute__((__cdecl__)) _wsystem( const wchar_t * _Command);

 double __attribute__((__cdecl__)) _wtof( const wchar_t *_Str);
 double __attribute__((__cdecl__)) _wtof_l( const wchar_t *_Str, _locale_t _Locale);
 int __attribute__((__cdecl__)) _wtoi( const wchar_t *_Str);
 int __attribute__((__cdecl__)) _wtoi_l( const wchar_t *_Str, _locale_t _Locale);
 long __attribute__((__cdecl__)) _wtol( const wchar_t *_Str);
 long __attribute__((__cdecl__)) _wtol_l( const wchar_t *_Str, _locale_t _Locale);

 errno_t __attribute__((__cdecl__)) _i64tow_s( __int64 _Val, wchar_t * _DstBuf, size_t _SizeInWords, int _Radix);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_i64tow_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) wchar_t * __attribute__((__cdecl__)) _i64tow( __int64 _Val, wchar_t * _DstBuf, int _Radix);
 errno_t __attribute__((__cdecl__)) _ui64tow_s( unsigned __int64 _Val, wchar_t * _DstBuf, size_t _SizeInWords, int _Radix);
 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ui64tow_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) wchar_t * __attribute__((__cdecl__)) _ui64tow( unsigned __int64 _Val, wchar_t * _DstBuf, int _Radix);
 __int64 __attribute__((__cdecl__)) _wtoi64( const wchar_t *_Str);
 __int64 __attribute__((__cdecl__)) _wtoi64_l( const wchar_t *_Str, _locale_t _Locale);
 __int64 __attribute__((__cdecl__)) _wcstoi64( const wchar_t * _Str, wchar_t ** _EndPtr, int _Radix);
 __int64 __attribute__((__cdecl__)) _wcstoi64_l( const wchar_t * _Str, wchar_t ** _EndPtr, int _Radix, _locale_t _Locale);
 unsigned __int64 __attribute__((__cdecl__)) _wcstoui64( const wchar_t * _Str, wchar_t ** _EndPtr, int _Radix);
 unsigned __int64 __attribute__((__cdecl__)) _wcstoui64_l( const wchar_t *_Str , wchar_t ** _EndPtr, int _Radix, _locale_t _Locale);

#define _WSTDLIB_DEFINED 





/* 
Buffer size required to be passed to _gcvt, fcvt and other fp conversion routines
*/
#define _CVTBUFSIZE (309+40)
# 717 "c_include/windows/original/stdlib.h"
 char * __attribute__((__cdecl__)) _fullpath( char * _FullPath, const char * _Path, size_t _SizeInBytes);







 errno_t __attribute__((__cdecl__)) _ecvt_s( char * _DstBuf, size_t _Size, double _Val, int _NumOfDights, int * _PtDec, int * _PtSign);

 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_ecvt_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _ecvt( double _Val, int _NumOfDigits, int * _PtDec, int * _PtSign);
 errno_t __attribute__((__cdecl__)) _fcvt_s( char * _DstBuf, size_t _Size, double _Val, int _NumOfDec, int * _PtDec, int * _PtSign);

 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_fcvt_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _fcvt( double _Val, int _NumOfDec, int * _PtDec, int * _PtSign);
 errno_t __attribute__((__cdecl__)) _gcvt_s( char * _DstBuf, size_t _Size, double _Val, int _NumOfDigits);

 __attribute__((deprecated("This function or variable may be unsafe. Consider using " "_gcvt_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) char * __attribute__((__cdecl__)) _gcvt( double _Val, int _NumOfDigits, char * _DstBuf);

 int __attribute__((__cdecl__)) _atodbl( _CRT_DOUBLE * _Result, char * _Str);
 int __attribute__((__cdecl__)) _atoldbl( _LDOUBLE * _Result, char * _Str);
 int __attribute__((__cdecl__)) _atoflt( _CRT_FLOAT * _Result, char * _Str);
 int __attribute__((__cdecl__)) _atodbl_l( _CRT_DOUBLE * _Result, char * _Str, _locale_t _Locale);
 int __attribute__((__cdecl__)) _atoldbl_l( _LDOUBLE * _Result, char * _Str, _locale_t _Locale);
 int __attribute__((__cdecl__)) _atoflt_l( _CRT_FLOAT * _Result, char * _Str, _locale_t _Locale);
        unsigned long __attribute__((__cdecl__)) _lrotl( unsigned long _Val, int _Shift);
        unsigned long __attribute__((__cdecl__)) _lrotr( unsigned long _Val, int _Shift);
 errno_t __attribute__((__cdecl__)) _makepath_s( char * _PathResult, size_t _SizeInWords, const char * _Drive, const char * _Dir, const char * _Filename,
        const char * _Ext);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_makepath_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) void __attribute__((__cdecl__)) _makepath( char *_Path, const char * _Drive, const char * _Dir, const char * _Filename, const char * _Ext);
# 773 "c_include/windows/original/stdlib.h"
        _onexit_t __attribute__((__cdecl__)) _onexit( _onexit_t _Func);



#define _CRT_PERROR_DEFINED 
 void __attribute__((__cdecl__)) perror( const char * _ErrMsg);


#pragma warning (push)
#pragma warning (disable:6540)
 int __attribute__((__cdecl__)) _putenv( const char * _EnvString);
 errno_t __attribute__((__cdecl__)) _putenv_s( const char * _Name, const char * _Value);
        unsigned int __attribute__((__cdecl__)) _rotl( unsigned int _Val, int _Shift);
        unsigned __int64 __attribute__((__cdecl__)) _rotl64( unsigned __int64 _Val, int _Shift);
        unsigned int __attribute__((__cdecl__)) _rotr( unsigned int _Val, int _Shift);
        unsigned __int64 __attribute__((__cdecl__)) _rotr64( unsigned __int64 _Val, int _Shift);
#pragma warning (pop)

 errno_t __attribute__((__cdecl__)) _searchenv_s( const char * _Filename, const char * _EnvVar, char * _ResultPath, size_t _SizeInBytes);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_searchenv_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) void __attribute__((__cdecl__)) _searchenv(const char * _Filename, const char * _EnvVar, char *_ResultPath);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_splitpath_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) void __attribute__((__cdecl__)) _splitpath( const char * _FullPath, char * _Drive, char * _Dir, char * _Filename, char * _Ext);
 errno_t __attribute__((__cdecl__)) _splitpath_s( const char * _FullPath,
  char * _Drive, size_t _DriveSize,
  char * _Dir, size_t _DirSize,
  char * _Filename, size_t _FilenameSize,
  char * _Ext, size_t _ExtSize);


 void __attribute__((__cdecl__)) _swab( char * _Buf1, char * _Buf2, int _SizeInBytes);



/* wide function prototypes, also declared in wchar.h  */






 wchar_t * __attribute__((__cdecl__)) _wfullpath( wchar_t * _FullPath, const wchar_t * _Path, size_t _SizeInWords);





 errno_t __attribute__((__cdecl__)) _wmakepath_s( wchar_t * _PathResult, size_t _SIZE, const wchar_t * _Drive, const wchar_t * _Dir, const wchar_t * _Filename,
        const wchar_t * _Ext);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_wmakepath_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) void __attribute__((__cdecl__)) _wmakepath( wchar_t *_ResultPath, const wchar_t * _Drive, const wchar_t * _Dir, const wchar_t * _Filename, const wchar_t * _Ext);

#define _CRT_WPERROR_DEFINED 
 void __attribute__((__cdecl__)) _wperror( const wchar_t * _ErrMsg);

 int __attribute__((__cdecl__)) _wputenv( const wchar_t * _EnvString);
 errno_t __attribute__((__cdecl__)) _wputenv_s( const wchar_t * _Name, const wchar_t * _Value);
 errno_t __attribute__((__cdecl__)) _wsearchenv_s( const wchar_t * _Filename, const wchar_t * _EnvVar, wchar_t * _ResultPath, size_t _SizeInWords);

__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_wsearchenv_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) void __attribute__((__cdecl__)) _wsearchenv(const wchar_t * _Filename, const wchar_t * _EnvVar, wchar_t *_ResultPath);
__attribute__((deprecated("This function or variable may be unsafe. Consider using " "_wsplitpath_s" " instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details."))) void __attribute__((__cdecl__)) _wsplitpath( const wchar_t * _FullPath, wchar_t * _Drive, wchar_t * _Dir, wchar_t * _Filename, wchar_t * _Ext);
 errno_t __attribute__((__cdecl__)) _wsplitpath_s( const wchar_t * _FullPath,
  wchar_t * _Drive, size_t _DriveSize,
  wchar_t * _Dir, size_t _DirSize,
  wchar_t * _Filename, size_t _FilenameSize,
  wchar_t * _Ext, size_t _ExtSize);


#define _WSTDLIBP_DEFINED 


/* The Win32 API SetErrorMode, Beep and Sleep should be used instead. */
__attribute__((deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider using " "SetErrorMode" " instead. See online help for details."))) void __attribute__((__cdecl__)) _seterrormode( int _Mode);
__attribute__((deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider using " "Beep" " instead. See online help for details."))) void __attribute__((__cdecl__)) _beep( unsigned _Frequency, unsigned _Duration);
__attribute__((deprecated("This function or variable has been superceded by newer library or operating system functionality. Consider using " "Sleep" " instead. See online help for details."))) void __attribute__((__cdecl__)) _sleep( unsigned long _Duration);
# 888 "c_include/windows/original/stdlib.h"
#pragma pack(pop)
