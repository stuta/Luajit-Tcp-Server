# 1 "c_include/windows/original/wincon.h"
#define __STDC__ 1
# 1 "c_include/windows/original/wincon.h"
#define __STDC_HOSTED__ 1
# 1 "c_include/windows/original/wincon.h"
#define __GNUC__ 4
# 1 "c_include/windows/original/wincon.h"
#define __GNUC_MINOR__ 8
# 1 "c_include/windows/original/wincon.h"
#define __GNUC_PATCHLEVEL__ 1
# 1 "c_include/windows/original/wincon.h"
#define __VERSION__ "4.8.1 20130328 (prerelease)"
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_RELAXED 0
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_SEQ_CST 5
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_ACQUIRE 2
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_RELEASE 3
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_ACQ_REL 4
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_CONSUME 1
# 1 "c_include/windows/original/wincon.h"
#define __pic__ 1
# 1 "c_include/windows/original/wincon.h"
#define __PIC__ 1
# 1 "c_include/windows/original/wincon.h"
#define __FINITE_MATH_ONLY__ 0
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_INT__ 4
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_LONG__ 4
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_LONG_LONG__ 8
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_SHORT__ 2
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_FLOAT__ 4
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_DOUBLE__ 8
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_LONG_DOUBLE__ 16
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_SIZE_T__ 8
# 1 "c_include/windows/original/wincon.h"
#define __CHAR_BIT__ 8
# 1 "c_include/windows/original/wincon.h"
#define __BIGGEST_ALIGNMENT__ 16
# 1 "c_include/windows/original/wincon.h"
#define __ORDER_LITTLE_ENDIAN__ 1234
# 1 "c_include/windows/original/wincon.h"
#define __ORDER_BIG_ENDIAN__ 4321
# 1 "c_include/windows/original/wincon.h"
#define __ORDER_PDP_ENDIAN__ 3412
# 1 "c_include/windows/original/wincon.h"
#define __BYTE_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/wincon.h"
#define __FLOAT_WORD_ORDER__ __ORDER_LITTLE_ENDIAN__
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_POINTER__ 8
# 1 "c_include/windows/original/wincon.h"
#define __SIZE_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __PTRDIFF_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __WCHAR_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __WINT_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INTMAX_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINTMAX_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __CHAR16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __CHAR32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __SIG_ATOMIC_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT8_TYPE__ signed char
# 1 "c_include/windows/original/wincon.h"
#define __INT16_TYPE__ short int
# 1 "c_include/windows/original/wincon.h"
#define __INT32_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT64_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINT8_TYPE__ unsigned char
# 1 "c_include/windows/original/wincon.h"
#define __UINT16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST8_TYPE__ signed char
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST16_TYPE__ short int
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST32_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST64_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST8_TYPE__ signed char
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST16_TYPE__ short int
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST32_TYPE__ int
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST64_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST8_TYPE__ unsigned char
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST16_TYPE__ short unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST32_TYPE__ unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST64_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __INTPTR_TYPE__ long long int
# 1 "c_include/windows/original/wincon.h"
#define __UINTPTR_TYPE__ long long unsigned int
# 1 "c_include/windows/original/wincon.h"
#define __GXX_ABI_VERSION 1002
# 1 "c_include/windows/original/wincon.h"
#define __SCHAR_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __SHRT_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __LONG_MAX__ 2147483647L
# 1 "c_include/windows/original/wincon.h"
#define __LONG_LONG_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __WCHAR_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __WCHAR_MIN__ 0
# 1 "c_include/windows/original/wincon.h"
#define __WINT_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __WINT_MIN__ 0
# 1 "c_include/windows/original/wincon.h"
#define __PTRDIFF_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __SIZE_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __INTMAX_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __INTMAX_C(c) c ## LL
# 1 "c_include/windows/original/wincon.h"
#define __UINTMAX_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __UINTMAX_C(c) c ## ULL
# 1 "c_include/windows/original/wincon.h"
#define __SIG_ATOMIC_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __SIG_ATOMIC_MIN__ (-__SIG_ATOMIC_MAX__ - 1)
# 1 "c_include/windows/original/wincon.h"
#define __INT8_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __INT16_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT32_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __INT64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __UINT8_MAX__ 255
# 1 "c_include/windows/original/wincon.h"
#define __UINT16_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __UINT32_MAX__ 4294967295U
# 1 "c_include/windows/original/wincon.h"
#define __UINT64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST8_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __INT8_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST16_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT16_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST32_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __INT32_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __INT_LEAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __INT64_C(c) c ## LL
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST8_MAX__ 255
# 1 "c_include/windows/original/wincon.h"
#define __UINT8_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST16_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __UINT16_C(c) c
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/wincon.h"
#define __UINT32_C(c) c ## U
# 1 "c_include/windows/original/wincon.h"
#define __UINT_LEAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __UINT64_C(c) c ## ULL
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST8_MAX__ 127
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST16_MAX__ 32767
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST32_MAX__ 2147483647
# 1 "c_include/windows/original/wincon.h"
#define __INT_FAST64_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST8_MAX__ 255
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST16_MAX__ 65535
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST32_MAX__ 4294967295U
# 1 "c_include/windows/original/wincon.h"
#define __UINT_FAST64_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __INTPTR_MAX__ 9223372036854775807LL
# 1 "c_include/windows/original/wincon.h"
#define __UINTPTR_MAX__ 18446744073709551615ULL
# 1 "c_include/windows/original/wincon.h"
#define __FLT_EVAL_METHOD__ 0
# 1 "c_include/windows/original/wincon.h"
#define __DEC_EVAL_METHOD__ 2
# 1 "c_include/windows/original/wincon.h"
#define __FLT_RADIX__ 2
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MANT_DIG__ 24
# 1 "c_include/windows/original/wincon.h"
#define __FLT_DIG__ 6
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MIN_EXP__ (-125)
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MIN_10_EXP__ (-37)
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MAX_EXP__ 128
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MAX_10_EXP__ 38
# 1 "c_include/windows/original/wincon.h"
#define __FLT_DECIMAL_DIG__ 9
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MAX__ 3.40282346638528859812e+38F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_MIN__ 1.17549435082228750797e-38F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_EPSILON__ 1.19209289550781250000e-7F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_DENORM_MIN__ 1.40129846432481707092e-45F
# 1 "c_include/windows/original/wincon.h"
#define __FLT_HAS_DENORM__ 1
# 1 "c_include/windows/original/wincon.h"
#define __FLT_HAS_INFINITY__ 1
# 1 "c_include/windows/original/wincon.h"
#define __FLT_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MANT_DIG__ 53
# 1 "c_include/windows/original/wincon.h"
#define __DBL_DIG__ 15
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MIN_EXP__ (-1021)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MIN_10_EXP__ (-307)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MAX_EXP__ 1024
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MAX_10_EXP__ 308
# 1 "c_include/windows/original/wincon.h"
#define __DBL_DECIMAL_DIG__ 17
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MAX__ ((double)1.79769313486231570815e+308L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_MIN__ ((double)2.22507385850720138309e-308L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_EPSILON__ ((double)2.22044604925031308085e-16L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_DENORM_MIN__ ((double)4.94065645841246544177e-324L)
# 1 "c_include/windows/original/wincon.h"
#define __DBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MANT_DIG__ 64
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_DIG__ 18
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MIN_EXP__ (-16381)
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MIN_10_EXP__ (-4931)
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MAX_EXP__ 16384
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MAX_10_EXP__ 4932
# 1 "c_include/windows/original/wincon.h"
#define __DECIMAL_DIG__ 21
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MAX__ 1.18973149535723176502e+4932L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_MIN__ 3.36210314311209350626e-4932L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_EPSILON__ 1.08420217248550443401e-19L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_DENORM_MIN__ 3.64519953188247460253e-4951L
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_HAS_DENORM__ 1
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_HAS_INFINITY__ 1
# 1 "c_include/windows/original/wincon.h"
#define __LDBL_HAS_QUIET_NAN__ 1
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MANT_DIG__ 7
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MIN_EXP__ (-94)
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MAX_EXP__ 97
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MIN__ 1E-95DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_MAX__ 9.999999E96DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_EPSILON__ 1E-6DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC32_SUBNORMAL_MIN__ 0.000001E-95DF
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MANT_DIG__ 16
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MIN_EXP__ (-382)
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MAX_EXP__ 385
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MIN__ 1E-383DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_MAX__ 9.999999999999999E384DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_EPSILON__ 1E-15DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC64_SUBNORMAL_MIN__ 0.000000000000001E-383DD
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MANT_DIG__ 34
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MIN_EXP__ (-6142)
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MAX_EXP__ 6145
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MIN__ 1E-6143DL
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_MAX__ 9.999999999999999999999999999999999E6144DL
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_EPSILON__ 1E-33DL
# 1 "c_include/windows/original/wincon.h"
#define __DEC128_SUBNORMAL_MIN__ 0.000000000000000000000000000000001E-6143DL
# 1 "c_include/windows/original/wincon.h"
#define __REGISTER_PREFIX__ 
# 1 "c_include/windows/original/wincon.h"
#define __USER_LABEL_PREFIX__ 
# 1 "c_include/windows/original/wincon.h"
#define __GNUC_GNU_INLINE__ 1
# 1 "c_include/windows/original/wincon.h"
#define __NO_INLINE__ 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_1 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_2 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_4 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_HAVE_SYNC_COMPARE_AND_SWAP_8 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_BOOL_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_CHAR_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_CHAR16_T_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_CHAR32_T_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_WCHAR_T_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_SHORT_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_INT_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_LONG_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_LLONG_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_TEST_AND_SET_TRUEVAL 1
# 1 "c_include/windows/original/wincon.h"
#define __GCC_ATOMIC_POINTER_LOCK_FREE 2
# 1 "c_include/windows/original/wincon.h"
#define __PRAGMA_REDEFINE_EXTNAME 1
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_INT128__ 16
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_WCHAR_T__ 2
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_WINT_T__ 2
# 1 "c_include/windows/original/wincon.h"
#define __SIZEOF_PTRDIFF_T__ 8
# 1 "c_include/windows/original/wincon.h"
#define __amd64 1
# 1 "c_include/windows/original/wincon.h"
#define __amd64__ 1
# 1 "c_include/windows/original/wincon.h"
#define __x86_64 1
# 1 "c_include/windows/original/wincon.h"
#define __x86_64__ 1
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_HLE_ACQUIRE 65536
# 1 "c_include/windows/original/wincon.h"
#define __ATOMIC_HLE_RELEASE 131072
# 1 "c_include/windows/original/wincon.h"
#define __k8 1
# 1 "c_include/windows/original/wincon.h"
#define __k8__ 1
# 1 "c_include/windows/original/wincon.h"
#define __code_model_small__ 1
# 1 "c_include/windows/original/wincon.h"
#define __MMX__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE2__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE_MATH__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SSE2_MATH__ 1
# 1 "c_include/windows/original/wincon.h"
#define __SEH__ 1
# 1 "c_include/windows/original/wincon.h"
#define __stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/wincon.h"
#define __fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/wincon.h"
#define __thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/wincon.h"
#define __cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/wincon.h"
#define _stdcall __attribute__((__stdcall__))
# 1 "c_include/windows/original/wincon.h"
#define _fastcall __attribute__((__fastcall__))
# 1 "c_include/windows/original/wincon.h"
#define _thiscall __attribute__((__thiscall__))
# 1 "c_include/windows/original/wincon.h"
#define _cdecl __attribute__((__cdecl__))
# 1 "c_include/windows/original/wincon.h"
#define __GXX_MERGED_TYPEINFO_NAMES 0
# 1 "c_include/windows/original/wincon.h"
#define __GXX_TYPEINFO_EQUALITY_INLINE 0
# 1 "c_include/windows/original/wincon.h"
#define __MSVCRT__ 1
# 1 "c_include/windows/original/wincon.h"
#define __MINGW32__ 1
# 1 "c_include/windows/original/wincon.h"
#define _WIN32 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN32 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN32__ 1
# 1 "c_include/windows/original/wincon.h"
#define WIN32 1
# 1 "c_include/windows/original/wincon.h"
#define __WINNT 1
# 1 "c_include/windows/original/wincon.h"
#define __WINNT__ 1
# 1 "c_include/windows/original/wincon.h"
#define WINNT 1
# 1 "c_include/windows/original/wincon.h"
#define _INTEGRAL_MAX_BITS 64
# 1 "c_include/windows/original/wincon.h"
#define __MINGW64__ 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN64 1
# 1 "c_include/windows/original/wincon.h"
#define __WIN64__ 1
# 1 "c_include/windows/original/wincon.h"
#define WIN64 1
# 1 "c_include/windows/original/wincon.h"
#define _WIN64 1
# 1 "c_include/windows/original/wincon.h"
#define __declspec(x) __attribute__((x))
# 1 "c_include/windows/original/wincon.h"
#define __DECIMAL_BID_FORMAT__ 1
# 1 "<command-line>"
#undef _REENTRANT
# 1 "c_include/windows/original/wincon.h"
#define _WIN32_WINNT 0x0602
#define WINVER _WIN32_WINNT
#define WIN32_LEAN_AND_MEAN 
#pragma comment (lib, "Ws2_32.lib")
/*++ BUILD Version: 0002    // Increment this if a change has global effects

Copyright (c) Microsoft Corporation. All rights reserved.

Module Name:

    wincon.h

Abstract:

    This module contains the public data structures, data types,
    and procedures exported by the NT console subsystem.

Created:

    26-Oct-1990

Revision History:

--*/


#define _WINCON_ 

       






# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 1
/**************************************************************************

*                                                                         *

* wingdi.h -- GDI procedure declarations, constant definitions and macros *

*                                                                         *

* Copyright (c) Microsoft Corp. All rights reserved.                      *

*                                                                         *

**************************************************************************/
# 10 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
#define _WINGDI_ 


       
# 25 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
//
// Define API decoration for direct importing of DLL references.
//


#define WINGDIAPI DECLSPEC_IMPORT




//
// Define API decoration for direct importing of DLL references.
//


#define WINSPOOLAPI DECLSPEC_IMPORT
# 57 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
/* Binary raster ops */
#define R2_BLACK 1
#define R2_NOTMERGEPEN 2
#define R2_MASKNOTPEN 3
#define R2_NOTCOPYPEN 4
#define R2_MASKPENNOT 5
#define R2_NOT 6
#define R2_XORPEN 7
#define R2_NOTMASKPEN 8
#define R2_MASKPEN 9
#define R2_NOTXORPEN 10
#define R2_NOP 11
#define R2_MERGENOTPEN 12
#define R2_COPYPEN 13
#define R2_MERGEPENNOT 14
#define R2_MERGEPEN 15
#define R2_WHITE 16
#define R2_LAST 16

/* Ternary raster operations */
#define SRCCOPY (DWORD)0x00CC0020
#define SRCPAINT (DWORD)0x00EE0086
#define SRCAND (DWORD)0x008800C6
#define SRCINVERT (DWORD)0x00660046
#define SRCERASE (DWORD)0x00440328
#define NOTSRCCOPY (DWORD)0x00330008
#define NOTSRCERASE (DWORD)0x001100A6
#define MERGECOPY (DWORD)0x00C000CA
#define MERGEPAINT (DWORD)0x00BB0226
#define PATCOPY (DWORD)0x00F00021
#define PATPAINT (DWORD)0x00FB0A09
#define PATINVERT (DWORD)0x005A0049
#define DSTINVERT (DWORD)0x00550009
#define BLACKNESS (DWORD)0x00000042
#define WHITENESS (DWORD)0x00FF0062


#define NOMIRRORBITMAP (DWORD)0x80000000
#define CAPTUREBLT (DWORD)0x40000000



/* Quaternary raster codes */
#define MAKEROP4(fore,back) (DWORD)((((back) << 8) & 0xFF000000) | (fore))



#define GDI_ERROR (0xFFFFFFFFL)

#define HGDI_ERROR (LongToHandle(0xFFFFFFFFL))




/* Region Flags */
#define ERROR 0
#define NULLREGION 1
#define SIMPLEREGION 2
#define COMPLEXREGION 3
#define RGN_ERROR ERROR

/* CombineRgn() Styles */
#define RGN_AND 1
#define RGN_OR 2
#define RGN_XOR 3
#define RGN_DIFF 4
#define RGN_COPY 5
#define RGN_MIN RGN_AND
#define RGN_MAX RGN_COPY

/* StretchBlt() Modes */
#define BLACKONWHITE 1
#define WHITEONBLACK 2
#define COLORONCOLOR 3
#define HALFTONE 4
#define MAXSTRETCHBLTMODE 4


/* New StretchBlt() Modes */
#define STRETCH_ANDSCANS BLACKONWHITE
#define STRETCH_ORSCANS WHITEONBLACK
#define STRETCH_DELETESCANS COLORONCOLOR
#define STRETCH_HALFTONE HALFTONE


/* PolyFill() Modes */
#define ALTERNATE 1
#define WINDING 2
#define POLYFILL_LAST 2

/* Layout Orientation Options */

#define LAYOUT_RTL 0x00000001
#define LAYOUT_BTT 0x00000002
#define LAYOUT_VBH 0x00000004
#define LAYOUT_ORIENTATIONMASK (LAYOUT_RTL | LAYOUT_BTT | LAYOUT_VBH)
#define LAYOUT_BITMAPORIENTATIONPRESERVED 0x00000008


/* Text Alignment Options */
#define TA_NOUPDATECP 0
#define TA_UPDATECP 1

#define TA_LEFT 0
#define TA_RIGHT 2
#define TA_CENTER 6

#define TA_TOP 0
#define TA_BOTTOM 8
#define TA_BASELINE 24

#define TA_RTLREADING 256
#define TA_MASK (TA_BASELINE+TA_CENTER+TA_UPDATECP+TA_RTLREADING)




#define VTA_BASELINE TA_BASELINE
#define VTA_LEFT TA_BOTTOM
#define VTA_RIGHT TA_TOP
#define VTA_CENTER TA_CENTER
#define VTA_BOTTOM TA_RIGHT
#define VTA_TOP TA_LEFT

#define ETO_OPAQUE 0x0002
#define ETO_CLIPPED 0x0004

#define ETO_GLYPH_INDEX 0x0010
#define ETO_RTLREADING 0x0080
#define ETO_NUMERICSLOCAL 0x0400
#define ETO_NUMERICSLATIN 0x0800
#define ETO_IGNORELANGUAGE 0x1000


#define ETO_PDY 0x2000


#define ETO_REVERSE_INDEX_MAP 0x10000


#define ASPECT_FILTERING 0x0001

/* Bounds Accumulation APIs */

#define DCB_RESET 0x0001
#define DCB_ACCUMULATE 0x0002
#define DCB_DIRTY DCB_ACCUMULATE
#define DCB_SET (DCB_RESET | DCB_ACCUMULATE)
#define DCB_ENABLE 0x0004
#define DCB_DISABLE 0x0008



/* Metafile Functions */
#define META_SETBKCOLOR 0x0201
#define META_SETBKMODE 0x0102
#define META_SETMAPMODE 0x0103
#define META_SETROP2 0x0104
#define META_SETRELABS 0x0105
#define META_SETPOLYFILLMODE 0x0106
#define META_SETSTRETCHBLTMODE 0x0107
#define META_SETTEXTCHAREXTRA 0x0108
#define META_SETTEXTCOLOR 0x0209
#define META_SETTEXTJUSTIFICATION 0x020A
#define META_SETWINDOWORG 0x020B
#define META_SETWINDOWEXT 0x020C
#define META_SETVIEWPORTORG 0x020D
#define META_SETVIEWPORTEXT 0x020E
#define META_OFFSETWINDOWORG 0x020F
#define META_SCALEWINDOWEXT 0x0410
#define META_OFFSETVIEWPORTORG 0x0211
#define META_SCALEVIEWPORTEXT 0x0412
#define META_LINETO 0x0213
#define META_MOVETO 0x0214
#define META_EXCLUDECLIPRECT 0x0415
#define META_INTERSECTCLIPRECT 0x0416
#define META_ARC 0x0817
#define META_ELLIPSE 0x0418
#define META_FLOODFILL 0x0419
#define META_PIE 0x081A
#define META_RECTANGLE 0x041B
#define META_ROUNDRECT 0x061C
#define META_PATBLT 0x061D
#define META_SAVEDC 0x001E
#define META_SETPIXEL 0x041F
#define META_OFFSETCLIPRGN 0x0220
#define META_TEXTOUT 0x0521
#define META_BITBLT 0x0922
#define META_STRETCHBLT 0x0B23
#define META_POLYGON 0x0324
#define META_POLYLINE 0x0325
#define META_ESCAPE 0x0626
#define META_RESTOREDC 0x0127
#define META_FILLREGION 0x0228
#define META_FRAMEREGION 0x0429
#define META_INVERTREGION 0x012A
#define META_PAINTREGION 0x012B
#define META_SELECTCLIPREGION 0x012C
#define META_SELECTOBJECT 0x012D
#define META_SETTEXTALIGN 0x012E
#define META_CHORD 0x0830
#define META_SETMAPPERFLAGS 0x0231
#define META_EXTTEXTOUT 0x0a32
#define META_SETDIBTODEV 0x0d33
#define META_SELECTPALETTE 0x0234
#define META_REALIZEPALETTE 0x0035
#define META_ANIMATEPALETTE 0x0436
#define META_SETPALENTRIES 0x0037
#define META_POLYPOLYGON 0x0538
#define META_RESIZEPALETTE 0x0139
#define META_DIBBITBLT 0x0940
#define META_DIBSTRETCHBLT 0x0b41
#define META_DIBCREATEPATTERNBRUSH 0x0142
#define META_STRETCHDIB 0x0f43
#define META_EXTFLOODFILL 0x0548

#define META_SETLAYOUT 0x0149

#define META_DELETEOBJECT 0x01f0
#define META_CREATEPALETTE 0x00f7
#define META_CREATEPATTERNBRUSH 0x01F9
#define META_CREATEPENINDIRECT 0x02FA
#define META_CREATEFONTINDIRECT 0x02FB
#define META_CREATEBRUSHINDIRECT 0x02FC
#define META_CREATEREGION 0x06FF


typedef struct _DRAWPATRECT {
        POINT ptPosition;
        POINT ptSize;
        WORD wStyle;
        WORD wPattern;
} DRAWPATRECT, *PDRAWPATRECT;




/* GDI Escapes */
#define NEWFRAME 1
#define ABORTDOC 2
#define NEXTBAND 3
#define SETCOLORTABLE 4
#define GETCOLORTABLE 5
#define FLUSHOUTPUT 6
#define DRAFTMODE 7
#define QUERYESCSUPPORT 8
#define SETABORTPROC 9
#define STARTDOC 10
#define ENDDOC 11
#define GETPHYSPAGESIZE 12
#define GETPRINTINGOFFSET 13
#define GETSCALINGFACTOR 14
#define MFCOMMENT 15
#define GETPENWIDTH 16
#define SETCOPYCOUNT 17
#define SELECTPAPERSOURCE 18
#define DEVICEDATA 19
#define PASSTHROUGH 19
#define GETTECHNOLGY 20
#define GETTECHNOLOGY 20
#define SETLINECAP 21
#define SETLINEJOIN 22
#define SETMITERLIMIT 23
#define BANDINFO 24
#define DRAWPATTERNRECT 25
#define GETVECTORPENSIZE 26
#define GETVECTORBRUSHSIZE 27
#define ENABLEDUPLEX 28
#define GETSETPAPERBINS 29
#define GETSETPRINTORIENT 30
#define ENUMPAPERBINS 31
#define SETDIBSCALING 32
#define EPSPRINTING 33
#define ENUMPAPERMETRICS 34
#define GETSETPAPERMETRICS 35
#define POSTSCRIPT_DATA 37
#define POSTSCRIPT_IGNORE 38
#define MOUSETRAILS 39
#define GETDEVICEUNITS 42

#define GETEXTENDEDTEXTMETRICS 256
#define GETEXTENTTABLE 257
#define GETPAIRKERNTABLE 258
#define GETTRACKKERNTABLE 259
#define EXTTEXTOUT 512
#define GETFACENAME 513
#define DOWNLOADFACE 514
#define ENABLERELATIVEWIDTHS 768
#define ENABLEPAIRKERNING 769
#define SETKERNTRACK 770
#define SETALLJUSTVALUES 771
#define SETCHARSET 772

#define STRETCHBLT 2048
#define METAFILE_DRIVER 2049
#define GETSETSCREENPARAMS 3072
#define QUERYDIBSUPPORT 3073
#define BEGIN_PATH 4096
#define CLIP_TO_PATH 4097
#define END_PATH 4098
#define EXT_DEVICE_CAPS 4099
#define RESTORE_CTM 4100
#define SAVE_CTM 4101
#define SET_ARC_DIRECTION 4102
#define SET_BACKGROUND_COLOR 4103
#define SET_POLY_MODE 4104
#define SET_SCREEN_ANGLE 4105
#define SET_SPREAD 4106
#define TRANSFORM_CTM 4107
#define SET_CLIP_BOX 4108
#define SET_BOUNDS 4109
#define SET_MIRROR_MODE 4110
#define OPENCHANNEL 4110
#define DOWNLOADHEADER 4111
#define CLOSECHANNEL 4112
#define POSTSCRIPT_PASSTHROUGH 4115
#define ENCAPSULATED_POSTSCRIPT 4116

#define POSTSCRIPT_IDENTIFY 4117
#define POSTSCRIPT_INJECTION 4118

#define CHECKJPEGFORMAT 4119
#define CHECKPNGFORMAT 4120

#define GET_PS_FEATURESETTING 4121

#define GDIPLUS_TS_QUERYVER 4122
#define GDIPLUS_TS_RECORD 4123

/*

 * Return Values for MILCORE_TS_QUERYVER

 */
#define MILCORE_TS_QUERYVER_RESULT_FALSE 0x0
#define MILCORE_TS_QUERYVER_RESULT_TRUE 0x7FFFFFFF



#define SPCLPASSTHROUGH2 4568

/*

 * Parameters for POSTSCRIPT_IDENTIFY escape

 */
# 402 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
#define PSIDENT_GDICENTRIC 0
#define PSIDENT_PSCENTRIC 1

/*

 * Header structure for the input buffer to POSTSCRIPT_INJECTION escape

 */
# 409 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef struct _PSINJECTDATA {

    DWORD DataBytes; /* number of raw data bytes (NOT including this header) */
    WORD InjectionPoint; /* injection point */
    WORD PageNumber; /* page number to apply the injection */

    /* Followed by raw data to be injected */

} PSINJECTDATA, *PPSINJECTDATA;

/*

 * Constants for PSINJECTDATA.InjectionPoint field

 */
# 423 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
#define PSINJECT_BEGINSTREAM 1
#define PSINJECT_PSADOBE 2
#define PSINJECT_PAGESATEND 3
#define PSINJECT_PAGES 4

#define PSINJECT_DOCNEEDEDRES 5
#define PSINJECT_DOCSUPPLIEDRES 6
#define PSINJECT_PAGEORDER 7
#define PSINJECT_ORIENTATION 8
#define PSINJECT_BOUNDINGBOX 9
#define PSINJECT_DOCUMENTPROCESSCOLORS 10

#define PSINJECT_COMMENTS 11
#define PSINJECT_BEGINDEFAULTS 12
#define PSINJECT_ENDDEFAULTS 13
#define PSINJECT_BEGINPROLOG 14
#define PSINJECT_ENDPROLOG 15
#define PSINJECT_BEGINSETUP 16
#define PSINJECT_ENDSETUP 17
#define PSINJECT_TRAILER 18
#define PSINJECT_EOF 19
#define PSINJECT_ENDSTREAM 20
#define PSINJECT_DOCUMENTPROCESSCOLORSATEND 21

#define PSINJECT_PAGENUMBER 100
#define PSINJECT_BEGINPAGESETUP 101
#define PSINJECT_ENDPAGESETUP 102
#define PSINJECT_PAGETRAILER 103
#define PSINJECT_PLATECOLOR 104

#define PSINJECT_SHOWPAGE 105
#define PSINJECT_PAGEBBOX 106
#define PSINJECT_ENDPAGECOMMENTS 107

#define PSINJECT_VMSAVE 200
#define PSINJECT_VMRESTORE 201

/*

 * InjectionPoint for publisher mode PScript5 OEM plugin to

 * generate DSC comment for included font resource

 */
# 464 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
#define PSINJECT_DLFONT 0xdddddddd

/*

 * Parameter for GET_PS_FEATURESETTING escape

 */
# 470 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
#define FEATURESETTING_NUP 0
#define FEATURESETTING_OUTPUT 1
#define FEATURESETTING_PSLEVEL 2
#define FEATURESETTING_CUSTPAPER 3
#define FEATURESETTING_MIRROR 4
#define FEATURESETTING_NEGATIVE 5
#define FEATURESETTING_PROTOCOL 6


//
// The range of selectors between FEATURESETTING_PRIVATE_BEGIN and
// FEATURESETTING_PRIVATE_END is reserved by Microsoft for private use
//
#define FEATURESETTING_PRIVATE_BEGIN 0x1000
#define FEATURESETTING_PRIVATE_END 0x1FFF


/*

 * Information about output options

 */
# 491 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef struct _PSFEATURE_OUTPUT {

    BOOL bPageIndependent;
    BOOL bSetPageDevice;

} PSFEATURE_OUTPUT, *PPSFEATURE_OUTPUT;

/*

 * Information about custom paper size

 */
# 502 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef struct _PSFEATURE_CUSTPAPER {

    LONG lOrientation;
    LONG lWidth;
    LONG lHeight;
    LONG lWidthOffset;
    LONG lHeightOffset;

} PSFEATURE_CUSTPAPER, *PPSFEATURE_CUSTPAPER;

/* Value returned for FEATURESETTING_PROTOCOL */
#define PSPROTOCOL_ASCII 0
#define PSPROTOCOL_BCP 1
#define PSPROTOCOL_TBCP 2
#define PSPROTOCOL_BINARY 3

/* Flag returned from QUERYDIBSUPPORT */
#define QDI_SETDIBITS 1
#define QDI_GETDIBITS 2
#define QDI_DIBTOSCREEN 4
#define QDI_STRETCHDIB 8

/* Spooler Error Codes */
#define SP_NOTREPORTED 0x4000
#define SP_ERROR (-1)
#define SP_APPABORT (-2)
#define SP_USERABORT (-3)
#define SP_OUTOFDISK (-4)
#define SP_OUTOFMEMORY (-5)

#define PR_JOBSTATUS 0x0000

/* Object Definitions for EnumObjects() */
#define OBJ_PEN 1
#define OBJ_BRUSH 2
#define OBJ_DC 3
#define OBJ_METADC 4
#define OBJ_PAL 5
#define OBJ_FONT 6
#define OBJ_BITMAP 7
#define OBJ_REGION 8
#define OBJ_METAFILE 9
#define OBJ_MEMDC 10
#define OBJ_EXTPEN 11
#define OBJ_ENHMETADC 12
#define OBJ_ENHMETAFILE 13
#define OBJ_COLORSPACE 14

#define GDI_OBJ_LAST OBJ_COLORSPACE

/* xform stuff */
#define MWT_IDENTITY 1
#define MWT_LEFTMULTIPLY 2
#define MWT_RIGHTMULTIPLY 3

#define MWT_MIN MWT_IDENTITY
#define MWT_MAX MWT_RIGHTMULTIPLY

#define _XFORM_ 
typedef struct tagXFORM
  {
    FLOAT eM11;
    FLOAT eM12;
    FLOAT eM21;
    FLOAT eM22;
    FLOAT eDx;
    FLOAT eDy;
  } XFORM, *PXFORM, FAR *LPXFORM;

/* Bitmap Header Definition */
typedef struct tagBITMAP
  {
    LONG bmType;
    LONG bmWidth;
    LONG bmHeight;
    LONG bmWidthBytes;
    WORD bmPlanes;
    WORD bmBitsPixel;
    LPVOID bmBits;
  } BITMAP, *PBITMAP, NEAR *NPBITMAP, FAR *LPBITMAP;

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack1.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    pshpack1.h



Abstract:



    This file turns 1 byte packing of structures on.  (That is, it disables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.  For Microsoft

    compatible compilers, this files uses the push option to the pack pragma

    so that the poppack.h include file can restore the previous packing

    reliably.



    The file poppack.h is the complement to this file.



--*/
# 31 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack1.h"
#pragma pack(1)
# 584 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2
typedef struct tagRGBTRIPLE {
        BYTE rgbtBlue;
        BYTE rgbtGreen;
        BYTE rgbtRed;
} RGBTRIPLE, *PRGBTRIPLE, NEAR *NPRGBTRIPLE, FAR *LPRGBTRIPLE;
# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    poppack.h



Abstract:



    This file turns packing of structures off.  (That is, it enables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.



    poppack.h is the complement to pshpack?.h.  An inclusion of poppack.h

    MUST ALWAYS be preceded by an inclusion of one of pshpack?.h, in one-to-one

    correspondence.



    For Microsoft compatible compilers, this file uses the pop option

    to the pack pragma so that it can restore the previous saved by the

    pshpack?.h include file.



--*/
# 34 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h"
#pragma pack()
# 590 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2

typedef struct tagRGBQUAD {
        BYTE rgbBlue;
        BYTE rgbGreen;
        BYTE rgbRed;
        BYTE rgbReserved;
} RGBQUAD;
typedef RGBQUAD FAR* LPRGBQUAD;



/* Image Color Matching color definitions */

#define CS_ENABLE 0x00000001L
#define CS_DISABLE 0x00000002L
#define CS_DELETE_TRANSFORM 0x00000003L

/* Logcolorspace signature */

#define LCS_SIGNATURE 'PSOC'

/* Logcolorspace lcsType values */

#define LCS_sRGB 'sRGB'
#define LCS_WINDOWS_COLOR_SPACE 'Win '

typedef LONG LCSCSTYPE;
#define LCS_CALIBRATED_RGB 0x00000000L

typedef LONG LCSGAMUTMATCH;
#define LCS_GM_BUSINESS 0x00000001L
#define LCS_GM_GRAPHICS 0x00000002L
#define LCS_GM_IMAGES 0x00000004L
#define LCS_GM_ABS_COLORIMETRIC 0x00000008L

/* ICM Defines for results from CheckColorInGamut() */
#define CM_OUT_OF_GAMUT 255
#define CM_IN_GAMUT 0

/* UpdateICMRegKey Constants               */
#define ICM_ADDPROFILE 1
#define ICM_DELETEPROFILE 2
#define ICM_QUERYPROFILE 3
#define ICM_SETDEFAULTPROFILE 4
#define ICM_REGISTERICMATCHER 5
#define ICM_UNREGISTERICMATCHER 6
#define ICM_QUERYMATCH 7

/* Macros to retrieve CMYK values from a COLORREF */
#define GetKValue(cmyk) ((BYTE)(cmyk))
#define GetYValue(cmyk) ((BYTE)((cmyk)>> 8))
#define GetMValue(cmyk) ((BYTE)((cmyk)>>16))
#define GetCValue(cmyk) ((BYTE)((cmyk)>>24))

#define CMYK(c,m,y,k) ((COLORREF)((((BYTE)(k)|((WORD)((BYTE)(y))<<8))|(((DWORD)(BYTE)(m))<<16))|(((DWORD)(BYTE)(c))<<24)))

typedef long FXPT16DOT16, FAR *LPFXPT16DOT16;
typedef long FXPT2DOT30, FAR *LPFXPT2DOT30;

/* ICM Color Definitions */
// The following two structures are used for defining RGB's in terms of CIEXYZ.

typedef struct tagCIEXYZ
{
        FXPT2DOT30 ciexyzX;
        FXPT2DOT30 ciexyzY;
        FXPT2DOT30 ciexyzZ;
} CIEXYZ;
typedef CIEXYZ FAR *LPCIEXYZ;

typedef struct tagICEXYZTRIPLE
{
        CIEXYZ ciexyzRed;
        CIEXYZ ciexyzGreen;
        CIEXYZ ciexyzBlue;
} CIEXYZTRIPLE;
typedef CIEXYZTRIPLE FAR *LPCIEXYZTRIPLE;

// The next structures the logical color space. Unlike pens and brushes,
// but like palettes, there is only one way to create a LogColorSpace.
// A pointer to it must be passed, its elements can't be pushed as
// arguments.

typedef struct tagLOGCOLORSPACEA {
    DWORD lcsSignature;
    DWORD lcsVersion;
    DWORD lcsSize;
    LCSCSTYPE lcsCSType;
    LCSGAMUTMATCH lcsIntent;
    CIEXYZTRIPLE lcsEndpoints;
    DWORD lcsGammaRed;
    DWORD lcsGammaGreen;
    DWORD lcsGammaBlue;
    CHAR lcsFilename[MAX_PATH];
} LOGCOLORSPACEA, *LPLOGCOLORSPACEA;
typedef struct tagLOGCOLORSPACEW {
    DWORD lcsSignature;
    DWORD lcsVersion;
    DWORD lcsSize;
    LCSCSTYPE lcsCSType;
    LCSGAMUTMATCH lcsIntent;
    CIEXYZTRIPLE lcsEndpoints;
    DWORD lcsGammaRed;
    DWORD lcsGammaGreen;
    DWORD lcsGammaBlue;
    WCHAR lcsFilename[MAX_PATH];
} LOGCOLORSPACEW, *LPLOGCOLORSPACEW;




typedef LOGCOLORSPACEA LOGCOLORSPACE;
typedef LPLOGCOLORSPACEA LPLOGCOLORSPACE;




/* structures for defining DIBs */
typedef struct tagBITMAPCOREHEADER {
        DWORD bcSize; /* used to get to color table */
        WORD bcWidth;
        WORD bcHeight;
        WORD bcPlanes;
        WORD bcBitCount;
} BITMAPCOREHEADER, FAR *LPBITMAPCOREHEADER, *PBITMAPCOREHEADER;

typedef struct tagBITMAPINFOHEADER{
        DWORD biSize;
        LONG biWidth;
        LONG biHeight;
        WORD biPlanes;
        WORD biBitCount;
        DWORD biCompression;
        DWORD biSizeImage;
        LONG biXPelsPerMeter;
        LONG biYPelsPerMeter;
        DWORD biClrUsed;
        DWORD biClrImportant;
} BITMAPINFOHEADER, FAR *LPBITMAPINFOHEADER, *PBITMAPINFOHEADER;


typedef struct {
        DWORD bV4Size;
        LONG bV4Width;
        LONG bV4Height;
        WORD bV4Planes;
        WORD bV4BitCount;
        DWORD bV4V4Compression;
        DWORD bV4SizeImage;
        LONG bV4XPelsPerMeter;
        LONG bV4YPelsPerMeter;
        DWORD bV4ClrUsed;
        DWORD bV4ClrImportant;
        DWORD bV4RedMask;
        DWORD bV4GreenMask;
        DWORD bV4BlueMask;
        DWORD bV4AlphaMask;
        DWORD bV4CSType;
        CIEXYZTRIPLE bV4Endpoints;
        DWORD bV4GammaRed;
        DWORD bV4GammaGreen;
        DWORD bV4GammaBlue;
} BITMAPV4HEADER, FAR *LPBITMAPV4HEADER, *PBITMAPV4HEADER;



typedef struct {
        DWORD bV5Size;
        LONG bV5Width;
        LONG bV5Height;
        WORD bV5Planes;
        WORD bV5BitCount;
        DWORD bV5Compression;
        DWORD bV5SizeImage;
        LONG bV5XPelsPerMeter;
        LONG bV5YPelsPerMeter;
        DWORD bV5ClrUsed;
        DWORD bV5ClrImportant;
        DWORD bV5RedMask;
        DWORD bV5GreenMask;
        DWORD bV5BlueMask;
        DWORD bV5AlphaMask;
        DWORD bV5CSType;
        CIEXYZTRIPLE bV5Endpoints;
        DWORD bV5GammaRed;
        DWORD bV5GammaGreen;
        DWORD bV5GammaBlue;
        DWORD bV5Intent;
        DWORD bV5ProfileData;
        DWORD bV5ProfileSize;
        DWORD bV5Reserved;
} BITMAPV5HEADER, FAR *LPBITMAPV5HEADER, *PBITMAPV5HEADER;

// Values for bV5CSType
#define PROFILE_LINKED 'LINK'
#define PROFILE_EMBEDDED 'MBED'


/* constants for the biCompression field */
#define BI_RGB 0L
#define BI_RLE8 1L
#define BI_RLE4 2L
#define BI_BITFIELDS 3L
#define BI_JPEG 4L
#define BI_PNG 5L



typedef struct tagBITMAPINFO {
    BITMAPINFOHEADER bmiHeader;
    RGBQUAD bmiColors[1];
} BITMAPINFO, FAR *LPBITMAPINFO, *PBITMAPINFO;

typedef struct tagBITMAPCOREINFO {
    BITMAPCOREHEADER bmciHeader;
    RGBTRIPLE bmciColors[1];
} BITMAPCOREINFO, FAR *LPBITMAPCOREINFO, *PBITMAPCOREINFO;

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack2.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    pshpack2.h



Abstract:



    This file turns 2 byte packing of structures on.  (That is, it disables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.  For Microsoft

    compatible compilers, this files uses the push option to the pack pragma

    so that the poppack.h include file can restore the previous packing

    reliably.



    The file poppack.h is the complement to this file.



--*/
# 31 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack2.h"
#pragma pack(2)
# 809 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2
typedef struct tagBITMAPFILEHEADER {
        WORD bfType;
        DWORD bfSize;
        WORD bfReserved1;
        WORD bfReserved2;
        DWORD bfOffBits;
} BITMAPFILEHEADER, FAR *LPBITMAPFILEHEADER, *PBITMAPFILEHEADER;
# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    poppack.h



Abstract:



    This file turns packing of structures off.  (That is, it enables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.



    poppack.h is the complement to pshpack?.h.  An inclusion of poppack.h

    MUST ALWAYS be preceded by an inclusion of one of pshpack?.h, in one-to-one

    correspondence.



    For Microsoft compatible compilers, this file uses the pop option

    to the pack pragma so that it can restore the previous saved by the

    pshpack?.h include file.



--*/
# 34 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h"
#pragma pack()
# 817 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2

#define MAKEPOINTS(l) (*((POINTS FAR *)&(l)))



typedef struct tagFONTSIGNATURE
{
    DWORD fsUsb[4];
    DWORD fsCsb[2];
} FONTSIGNATURE, *PFONTSIGNATURE,FAR *LPFONTSIGNATURE;

typedef struct tagCHARSETINFO
{
    UINT ciCharset;
    UINT ciACP;
    FONTSIGNATURE fs;
} CHARSETINFO, *PCHARSETINFO, NEAR *NPCHARSETINFO, FAR *LPCHARSETINFO;

#define TCI_SRCCHARSET 1
#define TCI_SRCCODEPAGE 2
#define TCI_SRCFONTSIG 3

#define TCI_SRCLOCALE 0x1000


typedef struct tagLOCALESIGNATURE
{
    DWORD lsUsb[4];
    DWORD lsCsbDefault[2];
    DWORD lsCsbSupported[2];
} LOCALESIGNATURE, *PLOCALESIGNATURE,FAR *LPLOCALESIGNATURE;







/* Clipboard Metafile Picture Structure */
typedef struct tagHANDLETABLE
  {
    HGDIOBJ objectHandle[1];
  } HANDLETABLE, *PHANDLETABLE, FAR *LPHANDLETABLE;

typedef struct tagMETARECORD
  {
    DWORD rdSize;
    WORD rdFunction;
    WORD rdParm[1];
  } METARECORD;
typedef struct tagMETARECORD UNALIGNED *PMETARECORD;
typedef struct tagMETARECORD UNALIGNED FAR *LPMETARECORD;

typedef struct tagMETAFILEPICT
  {
    LONG mm;
    LONG xExt;
    LONG yExt;
    HMETAFILE hMF;
  } METAFILEPICT, FAR *LPMETAFILEPICT;

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack2.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    pshpack2.h



Abstract:



    This file turns 2 byte packing of structures on.  (That is, it disables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.  For Microsoft

    compatible compilers, this files uses the push option to the pack pragma

    so that the poppack.h include file can restore the previous packing

    reliably.



    The file poppack.h is the complement to this file.



--*/
# 31 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack2.h"
#pragma pack(2)
# 879 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2
typedef struct tagMETAHEADER
{
    WORD mtType;
    WORD mtHeaderSize;
    WORD mtVersion;
    DWORD mtSize;
    WORD mtNoObjects;
    DWORD mtMaxRecord;
    WORD mtNoParameters;
} METAHEADER;
typedef struct tagMETAHEADER UNALIGNED *PMETAHEADER;
typedef struct tagMETAHEADER UNALIGNED FAR *LPMETAHEADER;

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    poppack.h



Abstract:



    This file turns packing of structures off.  (That is, it enables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.



    poppack.h is the complement to pshpack?.h.  An inclusion of poppack.h

    MUST ALWAYS be preceded by an inclusion of one of pshpack?.h, in one-to-one

    correspondence.



    For Microsoft compatible compilers, this file uses the pop option

    to the pack pragma so that it can restore the previous saved by the

    pshpack?.h include file.



--*/
# 34 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h"
#pragma pack()
# 893 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2

/* Enhanced Metafile structures */
typedef struct tagENHMETARECORD
{
    DWORD iType; // Record type EMR_XXX
    DWORD nSize; // Record size in bytes
    DWORD dParm[1]; // Parameters
} ENHMETARECORD, *PENHMETARECORD, *LPENHMETARECORD;

typedef struct tagENHMETAHEADER
{
    DWORD iType; // Record typeEMR_HEADER
    DWORD nSize; // Record size in bytes.  This may be greater
                                // than the sizeof(ENHMETAHEADER).
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    RECTL rclFrame; // Inclusive-inclusive Picture Frame of metafile in .01 mm units
    DWORD dSignature; // Signature.  Must be ENHMETA_SIGNATURE.
    DWORD nVersion; // Version number
    DWORD nBytes; // Size of the metafile in bytes
    DWORD nRecords; // Number of records in the metafile
    WORD nHandles; // Number of handles in the handle table
                                // Handle index zero is reserved.
    WORD sReserved; // Reserved.  Must be zero.
    DWORD nDescription; // Number of chars in the unicode description string
                                // This is 0 if there is no description string
    DWORD offDescription; // Offset to the metafile description record.
                                // This is 0 if there is no description string
    DWORD nPalEntries; // Number of entries in the metafile palette.
    SIZEL szlDevice; // Size of the reference device in pels
    SIZEL szlMillimeters; // Size of the reference device in millimeters

    DWORD cbPixelFormat; // Size of PIXELFORMATDESCRIPTOR information
                                // This is 0 if no pixel format is set
    DWORD offPixelFormat; // Offset to PIXELFORMATDESCRIPTOR
                                // This is 0 if no pixel format is set
    DWORD bOpenGL; // TRUE if OpenGL commands are present in
                                // the metafile, otherwise FALSE


    SIZEL szlMicrometers; // Size of the reference device in micrometers


} ENHMETAHEADER, *PENHMETAHEADER, *LPENHMETAHEADER;





/* tmPitchAndFamily flags */
#define TMPF_FIXED_PITCH 0x01
#define TMPF_VECTOR 0x02
#define TMPF_DEVICE 0x08
#define TMPF_TRUETYPE 0x04

//
// BCHAR definition for APPs
//



    typedef BYTE BCHAR;



#define _TEXTMETRIC_DEFINED 
# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack4.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    pshpack4.h



Abstract:



    This file turns 4 byte packing of structures on.  (That is, it disables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.  For Microsoft

    compatible compilers, this files uses the push option to the pack pragma

    so that the poppack.h include file can restore the previous packing

    reliably.



    The file poppack.h is the complement to this file.



--*/
# 31 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack4.h"
#pragma pack(4)
# 959 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2
typedef struct tagTEXTMETRICA
{
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    BYTE tmFirstChar;
    BYTE tmLastChar;
    BYTE tmDefaultChar;
    BYTE tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
} TEXTMETRICA, *PTEXTMETRICA, NEAR *NPTEXTMETRICA, FAR *LPTEXTMETRICA;
typedef struct tagTEXTMETRICW
{
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    WCHAR tmFirstChar;
    WCHAR tmLastChar;
    WCHAR tmDefaultChar;
    WCHAR tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
} TEXTMETRICW, *PTEXTMETRICW, NEAR *NPTEXTMETRICW, FAR *LPTEXTMETRICW;






typedef TEXTMETRICA TEXTMETRIC;
typedef PTEXTMETRICA PTEXTMETRIC;
typedef NPTEXTMETRICA NPTEXTMETRIC;
typedef LPTEXTMETRICA LPTEXTMETRIC;

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    poppack.h



Abstract:



    This file turns packing of structures off.  (That is, it enables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.



    poppack.h is the complement to pshpack?.h.  An inclusion of poppack.h

    MUST ALWAYS be preceded by an inclusion of one of pshpack?.h, in one-to-one

    correspondence.



    For Microsoft compatible compilers, this file uses the pop option

    to the pack pragma so that it can restore the previous saved by the

    pshpack?.h include file.



--*/
# 34 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h"
#pragma pack()
# 1017 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2


/* ntmFlags field flags */
#define NTM_REGULAR 0x00000040L
#define NTM_BOLD 0x00000020L
#define NTM_ITALIC 0x00000001L

/* new in NT 5.0 */

#define NTM_NONNEGATIVE_AC 0x00010000
#define NTM_PS_OPENTYPE 0x00020000
#define NTM_TT_OPENTYPE 0x00040000
#define NTM_MULTIPLEMASTER 0x00080000
#define NTM_TYPE1 0x00100000
#define NTM_DSIG 0x00200000

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack4.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    pshpack4.h



Abstract:



    This file turns 4 byte packing of structures on.  (That is, it disables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.  For Microsoft

    compatible compilers, this files uses the push option to the pack pragma

    so that the poppack.h include file can restore the previous packing

    reliably.



    The file poppack.h is the complement to this file.



--*/
# 31 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/pshpack4.h"
#pragma pack(4)
# 1034 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2
typedef struct tagNEWTEXTMETRICA
{
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    BYTE tmFirstChar;
    BYTE tmLastChar;
    BYTE tmDefaultChar;
    BYTE tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
    DWORD ntmFlags;
    UINT ntmSizeEM;
    UINT ntmCellHeight;
    UINT ntmAvgWidth;
} NEWTEXTMETRICA, *PNEWTEXTMETRICA, NEAR *NPNEWTEXTMETRICA, FAR *LPNEWTEXTMETRICA;
typedef struct tagNEWTEXTMETRICW
{
    LONG tmHeight;
    LONG tmAscent;
    LONG tmDescent;
    LONG tmInternalLeading;
    LONG tmExternalLeading;
    LONG tmAveCharWidth;
    LONG tmMaxCharWidth;
    LONG tmWeight;
    LONG tmOverhang;
    LONG tmDigitizedAspectX;
    LONG tmDigitizedAspectY;
    WCHAR tmFirstChar;
    WCHAR tmLastChar;
    WCHAR tmDefaultChar;
    WCHAR tmBreakChar;
    BYTE tmItalic;
    BYTE tmUnderlined;
    BYTE tmStruckOut;
    BYTE tmPitchAndFamily;
    BYTE tmCharSet;
    DWORD ntmFlags;
    UINT ntmSizeEM;
    UINT ntmCellHeight;
    UINT ntmAvgWidth;
} NEWTEXTMETRICW, *PNEWTEXTMETRICW, NEAR *NPNEWTEXTMETRICW, FAR *LPNEWTEXTMETRICW;






typedef NEWTEXTMETRICA NEWTEXTMETRIC;
typedef PNEWTEXTMETRICA PNEWTEXTMETRIC;
typedef NPNEWTEXTMETRICA NPNEWTEXTMETRIC;
typedef LPNEWTEXTMETRICA LPNEWTEXTMETRIC;

# 1 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h" 1
/*++



Copyright (c) Microsoft Corporation.  All rights reserved.



Module Name:



    poppack.h



Abstract:



    This file turns packing of structures off.  (That is, it enables

    automatic alignment of structure fields.)  An include file is needed

    because various compilers do this in different ways.



    poppack.h is the complement to pshpack?.h.  An inclusion of poppack.h

    MUST ALWAYS be preceded by an inclusion of one of pshpack?.h, in one-to-one

    correspondence.



    For Microsoft compatible compilers, this file uses the pop option

    to the pack pragma so that it can restore the previous saved by the

    pshpack?.h include file.



--*/
# 34 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/poppack.h"
#pragma pack()
# 1100 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h" 2


typedef struct tagNEWTEXTMETRICEXA
{
    NEWTEXTMETRICA ntmTm;
    FONTSIGNATURE ntmFontSig;
}NEWTEXTMETRICEXA;
typedef struct tagNEWTEXTMETRICEXW
{
    NEWTEXTMETRICW ntmTm;
    FONTSIGNATURE ntmFontSig;
}NEWTEXTMETRICEXW;



typedef NEWTEXTMETRICEXA NEWTEXTMETRICEX;




/* GDI Logical Objects: */

/* Pel Array */
typedef struct tagPELARRAY
  {
    LONG paXCount;
    LONG paYCount;
    LONG paXExt;
    LONG paYExt;
    BYTE paRGBs;
  } PELARRAY, *PPELARRAY, NEAR *NPPELARRAY, FAR *LPPELARRAY;

/* Logical Brush (or Pattern) */
typedef struct tagLOGBRUSH
  {
    UINT lbStyle;
    COLORREF lbColor;
    ULONG_PTR lbHatch;
  } LOGBRUSH, *PLOGBRUSH, NEAR *NPLOGBRUSH, FAR *LPLOGBRUSH;

typedef struct tagLOGBRUSH32
  {
    UINT lbStyle;
    COLORREF lbColor;
    ULONG lbHatch;
  } LOGBRUSH32, *PLOGBRUSH32, NEAR *NPLOGBRUSH32, FAR *LPLOGBRUSH32;

typedef LOGBRUSH PATTERN;
typedef PATTERN *PPATTERN;
typedef PATTERN NEAR *NPPATTERN;
typedef PATTERN FAR *LPPATTERN;

/* Logical Pen */
typedef struct tagLOGPEN
  {
    UINT lopnStyle;
    POINT lopnWidth;
    COLORREF lopnColor;
  } LOGPEN, *PLOGPEN, NEAR *NPLOGPEN, FAR *LPLOGPEN;

typedef struct tagEXTLOGPEN {
    DWORD elpPenStyle;
    DWORD elpWidth;
    UINT elpBrushStyle;
    COLORREF elpColor;
    ULONG_PTR elpHatch;
    DWORD elpNumEntries;
    DWORD elpStyleEntry[1];
} EXTLOGPEN, *PEXTLOGPEN, NEAR *NPEXTLOGPEN, FAR *LPEXTLOGPEN;

typedef struct tagEXTLOGPEN32 {
    DWORD elpPenStyle;
    DWORD elpWidth;
    UINT elpBrushStyle;
    COLORREF elpColor;
    ULONG elpHatch;
    DWORD elpNumEntries;
    DWORD elpStyleEntry[1];
} EXTLOGPEN32, *PEXTLOGPEN32, NEAR *NPEXTLOGPEN32, FAR *LPEXTLOGPEN32;


#define _PALETTEENTRY_DEFINED 
typedef struct tagPALETTEENTRY {
    BYTE peRed;
    BYTE peGreen;
    BYTE peBlue;
    BYTE peFlags;
} PALETTEENTRY, *PPALETTEENTRY, FAR *LPPALETTEENTRY;



#define _LOGPALETTE_DEFINED 
/* Logical Palette */
typedef struct tagLOGPALETTE {
    WORD palVersion;
    WORD palNumEntries;
    __field_ecount_opt(palNumEntries) PALETTEENTRY palPalEntry[1];
} LOGPALETTE, *PLOGPALETTE, NEAR *NPLOGPALETTE, FAR *LPLOGPALETTE;



/* Logical Font */
#define LF_FACESIZE 32

typedef struct tagLOGFONTA
{
    LONG lfHeight;
    LONG lfWidth;
    LONG lfEscapement;
    LONG lfOrientation;
    LONG lfWeight;
    BYTE lfItalic;
    BYTE lfUnderline;
    BYTE lfStrikeOut;
    BYTE lfCharSet;
    BYTE lfOutPrecision;
    BYTE lfClipPrecision;
    BYTE lfQuality;
    BYTE lfPitchAndFamily;
    CHAR lfFaceName[32];
} LOGFONTA, *PLOGFONTA, NEAR *NPLOGFONTA, FAR *LPLOGFONTA;
typedef struct tagLOGFONTW
{
    LONG lfHeight;
    LONG lfWidth;
    LONG lfEscapement;
    LONG lfOrientation;
    LONG lfWeight;
    BYTE lfItalic;
    BYTE lfUnderline;
    BYTE lfStrikeOut;
    BYTE lfCharSet;
    BYTE lfOutPrecision;
    BYTE lfClipPrecision;
    BYTE lfQuality;
    BYTE lfPitchAndFamily;
    WCHAR lfFaceName[32];
} LOGFONTW, *PLOGFONTW, NEAR *NPLOGFONTW, FAR *LPLOGFONTW;






typedef LOGFONTA LOGFONT;
typedef PLOGFONTA PLOGFONT;
typedef NPLOGFONTA NPLOGFONT;
typedef LPLOGFONTA LPLOGFONT;


#define LF_FULLFACESIZE 64

/* Structure passed to FONTENUMPROC */
typedef struct tagENUMLOGFONTA
{
    LOGFONTA elfLogFont;
    BYTE elfFullName[64];
    BYTE elfStyle[32];
} ENUMLOGFONTA, FAR* LPENUMLOGFONTA;
/* Structure passed to FONTENUMPROC */
typedef struct tagENUMLOGFONTW
{
    LOGFONTW elfLogFont;
    WCHAR elfFullName[64];
    WCHAR elfStyle[32];
} ENUMLOGFONTW, FAR* LPENUMLOGFONTW;




typedef ENUMLOGFONTA ENUMLOGFONT;
typedef LPENUMLOGFONTA LPENUMLOGFONT;



typedef struct tagENUMLOGFONTEXA
{
    LOGFONTA elfLogFont;
    BYTE elfFullName[64];
    BYTE elfStyle[32];
    BYTE elfScript[32];
} ENUMLOGFONTEXA, FAR *LPENUMLOGFONTEXA;
typedef struct tagENUMLOGFONTEXW
{
    LOGFONTW elfLogFont;
    WCHAR elfFullName[64];
    WCHAR elfStyle[32];
    WCHAR elfScript[32];
} ENUMLOGFONTEXW, FAR *LPENUMLOGFONTEXW;




typedef ENUMLOGFONTEXA ENUMLOGFONTEX;
typedef LPENUMLOGFONTEXA LPENUMLOGFONTEX;



#define OUT_DEFAULT_PRECIS 0
#define OUT_STRING_PRECIS 1
#define OUT_CHARACTER_PRECIS 2
#define OUT_STROKE_PRECIS 3
#define OUT_TT_PRECIS 4
#define OUT_DEVICE_PRECIS 5
#define OUT_RASTER_PRECIS 6
#define OUT_TT_ONLY_PRECIS 7
#define OUT_OUTLINE_PRECIS 8
#define OUT_SCREEN_OUTLINE_PRECIS 9
#define OUT_PS_ONLY_PRECIS 10

#define CLIP_DEFAULT_PRECIS 0
#define CLIP_CHARACTER_PRECIS 1
#define CLIP_STROKE_PRECIS 2
#define CLIP_MASK 0xf
#define CLIP_LH_ANGLES (1<<4)
#define CLIP_TT_ALWAYS (2<<4)

#define CLIP_DFA_DISABLE (4<<4)

#define CLIP_EMBEDDED (8<<4)

#define DEFAULT_QUALITY 0
#define DRAFT_QUALITY 1
#define PROOF_QUALITY 2

#define NONANTIALIASED_QUALITY 3
#define ANTIALIASED_QUALITY 4



#define CLEARTYPE_QUALITY 5
#define CLEARTYPE_NATURAL_QUALITY 6


#define DEFAULT_PITCH 0
#define FIXED_PITCH 1
#define VARIABLE_PITCH 2

#define MONO_FONT 8


#define ANSI_CHARSET 0
#define DEFAULT_CHARSET 1
#define SYMBOL_CHARSET 2
#define SHIFTJIS_CHARSET 128
#define HANGEUL_CHARSET 129
#define HANGUL_CHARSET 129
#define GB2312_CHARSET 134
#define CHINESEBIG5_CHARSET 136
#define OEM_CHARSET 255

#define JOHAB_CHARSET 130
#define HEBREW_CHARSET 177
#define ARABIC_CHARSET 178
#define GREEK_CHARSET 161
#define TURKISH_CHARSET 162
#define VIETNAMESE_CHARSET 163
#define THAI_CHARSET 222
#define EASTEUROPE_CHARSET 238
#define RUSSIAN_CHARSET 204

#define MAC_CHARSET 77
#define BALTIC_CHARSET 186

#define FS_LATIN1 0x00000001L
#define FS_LATIN2 0x00000002L
#define FS_CYRILLIC 0x00000004L
#define FS_GREEK 0x00000008L
#define FS_TURKISH 0x00000010L
#define FS_HEBREW 0x00000020L
#define FS_ARABIC 0x00000040L
#define FS_BALTIC 0x00000080L
#define FS_VIETNAMESE 0x00000100L
#define FS_THAI 0x00010000L
#define FS_JISJAPAN 0x00020000L
#define FS_CHINESESIMP 0x00040000L
#define FS_WANSUNG 0x00080000L
#define FS_CHINESETRAD 0x00100000L
#define FS_JOHAB 0x00200000L
#define FS_SYMBOL 0x80000000L


/* Font Families */
#define FF_DONTCARE (0<<4)
#define FF_ROMAN (1<<4)
                                    /* Times Roman, Century Schoolbook, etc. */
#define FF_SWISS (2<<4)
                                    /* Helvetica, Swiss, etc. */
#define FF_MODERN (3<<4)
                                    /* Pica, Elite, Courier, etc. */
#define FF_SCRIPT (4<<4)
#define FF_DECORATIVE (5<<4)

/* Font Weights */
#define FW_DONTCARE 0
#define FW_THIN 100
#define FW_EXTRALIGHT 200
#define FW_LIGHT 300
#define FW_NORMAL 400
#define FW_MEDIUM 500
#define FW_SEMIBOLD 600
#define FW_BOLD 700
#define FW_EXTRABOLD 800
#define FW_HEAVY 900

#define FW_ULTRALIGHT FW_EXTRALIGHT
#define FW_REGULAR FW_NORMAL
#define FW_DEMIBOLD FW_SEMIBOLD
#define FW_ULTRABOLD FW_EXTRABOLD
#define FW_BLACK FW_HEAVY

#define PANOSE_COUNT 10
#define PAN_FAMILYTYPE_INDEX 0
#define PAN_SERIFSTYLE_INDEX 1
#define PAN_WEIGHT_INDEX 2
#define PAN_PROPORTION_INDEX 3
#define PAN_CONTRAST_INDEX 4
#define PAN_STROKEVARIATION_INDEX 5
#define PAN_ARMSTYLE_INDEX 6
#define PAN_LETTERFORM_INDEX 7
#define PAN_MIDLINE_INDEX 8
#define PAN_XHEIGHT_INDEX 9

#define PAN_CULTURE_LATIN 0

typedef struct tagPANOSE
{
    BYTE bFamilyType;
    BYTE bSerifStyle;
    BYTE bWeight;
    BYTE bProportion;
    BYTE bContrast;
    BYTE bStrokeVariation;
    BYTE bArmStyle;
    BYTE bLetterform;
    BYTE bMidline;
    BYTE bXHeight;
} PANOSE, * LPPANOSE;

#define PAN_ANY 0
#define PAN_NO_FIT 1

#define PAN_FAMILY_TEXT_DISPLAY 2
#define PAN_FAMILY_SCRIPT 3
#define PAN_FAMILY_DECORATIVE 4
#define PAN_FAMILY_PICTORIAL 5

#define PAN_SERIF_COVE 2
#define PAN_SERIF_OBTUSE_COVE 3
#define PAN_SERIF_SQUARE_COVE 4
#define PAN_SERIF_OBTUSE_SQUARE_COVE 5
#define PAN_SERIF_SQUARE 6
#define PAN_SERIF_THIN 7
#define PAN_SERIF_BONE 8
#define PAN_SERIF_EXAGGERATED 9
#define PAN_SERIF_TRIANGLE 10
#define PAN_SERIF_NORMAL_SANS 11
#define PAN_SERIF_OBTUSE_SANS 12
#define PAN_SERIF_PERP_SANS 13
#define PAN_SERIF_FLARED 14
#define PAN_SERIF_ROUNDED 15

#define PAN_WEIGHT_VERY_LIGHT 2
#define PAN_WEIGHT_LIGHT 3
#define PAN_WEIGHT_THIN 4
#define PAN_WEIGHT_BOOK 5
#define PAN_WEIGHT_MEDIUM 6
#define PAN_WEIGHT_DEMI 7
#define PAN_WEIGHT_BOLD 8
#define PAN_WEIGHT_HEAVY 9
#define PAN_WEIGHT_BLACK 10
#define PAN_WEIGHT_NORD 11

#define PAN_PROP_OLD_STYLE 2
#define PAN_PROP_MODERN 3
#define PAN_PROP_EVEN_WIDTH 4
#define PAN_PROP_EXPANDED 5
#define PAN_PROP_CONDENSED 6
#define PAN_PROP_VERY_EXPANDED 7
#define PAN_PROP_VERY_CONDENSED 8
#define PAN_PROP_MONOSPACED 9

#define PAN_CONTRAST_NONE 2
#define PAN_CONTRAST_VERY_LOW 3
#define PAN_CONTRAST_LOW 4
#define PAN_CONTRAST_MEDIUM_LOW 5
#define PAN_CONTRAST_MEDIUM 6
#define PAN_CONTRAST_MEDIUM_HIGH 7
#define PAN_CONTRAST_HIGH 8
#define PAN_CONTRAST_VERY_HIGH 9

#define PAN_STROKE_GRADUAL_DIAG 2
#define PAN_STROKE_GRADUAL_TRAN 3
#define PAN_STROKE_GRADUAL_VERT 4
#define PAN_STROKE_GRADUAL_HORZ 5
#define PAN_STROKE_RAPID_VERT 6
#define PAN_STROKE_RAPID_HORZ 7
#define PAN_STROKE_INSTANT_VERT 8

#define PAN_STRAIGHT_ARMS_HORZ 2
#define PAN_STRAIGHT_ARMS_WEDGE 3
#define PAN_STRAIGHT_ARMS_VERT 4
#define PAN_STRAIGHT_ARMS_SINGLE_SERIF 5
#define PAN_STRAIGHT_ARMS_DOUBLE_SERIF 6
#define PAN_BENT_ARMS_HORZ 7
#define PAN_BENT_ARMS_WEDGE 8
#define PAN_BENT_ARMS_VERT 9
#define PAN_BENT_ARMS_SINGLE_SERIF 10
#define PAN_BENT_ARMS_DOUBLE_SERIF 11

#define PAN_LETT_NORMAL_CONTACT 2
#define PAN_LETT_NORMAL_WEIGHTED 3
#define PAN_LETT_NORMAL_BOXED 4
#define PAN_LETT_NORMAL_FLATTENED 5
#define PAN_LETT_NORMAL_ROUNDED 6
#define PAN_LETT_NORMAL_OFF_CENTER 7
#define PAN_LETT_NORMAL_SQUARE 8
#define PAN_LETT_OBLIQUE_CONTACT 9
#define PAN_LETT_OBLIQUE_WEIGHTED 10
#define PAN_LETT_OBLIQUE_BOXED 11
#define PAN_LETT_OBLIQUE_FLATTENED 12
#define PAN_LETT_OBLIQUE_ROUNDED 13
#define PAN_LETT_OBLIQUE_OFF_CENTER 14
#define PAN_LETT_OBLIQUE_SQUARE 15

#define PAN_MIDLINE_STANDARD_TRIMMED 2
#define PAN_MIDLINE_STANDARD_POINTED 3
#define PAN_MIDLINE_STANDARD_SERIFED 4
#define PAN_MIDLINE_HIGH_TRIMMED 5
#define PAN_MIDLINE_HIGH_POINTED 6
#define PAN_MIDLINE_HIGH_SERIFED 7
#define PAN_MIDLINE_CONSTANT_TRIMMED 8
#define PAN_MIDLINE_CONSTANT_POINTED 9
#define PAN_MIDLINE_CONSTANT_SERIFED 10
#define PAN_MIDLINE_LOW_TRIMMED 11
#define PAN_MIDLINE_LOW_POINTED 12
#define PAN_MIDLINE_LOW_SERIFED 13

#define PAN_XHEIGHT_CONSTANT_SMALL 2
#define PAN_XHEIGHT_CONSTANT_STD 3
#define PAN_XHEIGHT_CONSTANT_LARGE 4
#define PAN_XHEIGHT_DUCKING_SMALL 5
#define PAN_XHEIGHT_DUCKING_STD 6
#define PAN_XHEIGHT_DUCKING_LARGE 7


#define ELF_VENDOR_SIZE 4

/* The extended logical font       */
/* An extension of the ENUMLOGFONT */

typedef struct tagEXTLOGFONTA {
    LOGFONTA elfLogFont;
    BYTE elfFullName[64];
    BYTE elfStyle[32];
    DWORD elfVersion; /* 0 for the first release of NT */
    DWORD elfStyleSize;
    DWORD elfMatch;
    DWORD elfReserved;
    BYTE elfVendorId[4];
    DWORD elfCulture; /* 0 for Latin                   */
    PANOSE elfPanose;
} EXTLOGFONTA, *PEXTLOGFONTA, NEAR *NPEXTLOGFONTA, FAR *LPEXTLOGFONTA;
typedef struct tagEXTLOGFONTW {
    LOGFONTW elfLogFont;
    WCHAR elfFullName[64];
    WCHAR elfStyle[32];
    DWORD elfVersion; /* 0 for the first release of NT */
    DWORD elfStyleSize;
    DWORD elfMatch;
    DWORD elfReserved;
    BYTE elfVendorId[4];
    DWORD elfCulture; /* 0 for Latin                   */
    PANOSE elfPanose;
} EXTLOGFONTW, *PEXTLOGFONTW, NEAR *NPEXTLOGFONTW, FAR *LPEXTLOGFONTW;






typedef EXTLOGFONTA EXTLOGFONT;
typedef PEXTLOGFONTA PEXTLOGFONT;
typedef NPEXTLOGFONTA NPEXTLOGFONT;
typedef LPEXTLOGFONTA LPEXTLOGFONT;


#define ELF_VERSION 0
#define ELF_CULTURE_LATIN 0

/* EnumFonts Masks */
#define RASTER_FONTTYPE 0x0001
#define DEVICE_FONTTYPE 0x0002
#define TRUETYPE_FONTTYPE 0x0004

#define RGB(r,g,b) ((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
#define PALETTERGB(r,g,b) (0x02000000 | RGB(r,g,b))
#define PALETTEINDEX(i) ((COLORREF)(0x01000000 | (DWORD)(WORD)(i)))

/* palette entry flags */

#define PC_RESERVED 0x01
#define PC_EXPLICIT 0x02
#define PC_NOCOLLAPSE 0x04

#define GetRValue(rgb) (LOBYTE(rgb))
#define GetGValue(rgb) (LOBYTE(((WORD)(rgb)) >> 8))
#define GetBValue(rgb) (LOBYTE((rgb)>>16))

/* Background Modes */
#define TRANSPARENT 1
#define OPAQUE 2
#define BKMODE_LAST 2

/* Graphics Modes */

#define GM_COMPATIBLE 1
#define GM_ADVANCED 2
#define GM_LAST 2

/* PolyDraw and GetPath point types */
#define PT_CLOSEFIGURE 0x01
#define PT_LINETO 0x02
#define PT_BEZIERTO 0x04
#define PT_MOVETO 0x06

/* Mapping Modes */
#define MM_TEXT 1
#define MM_LOMETRIC 2
#define MM_HIMETRIC 3
#define MM_LOENGLISH 4
#define MM_HIENGLISH 5
#define MM_TWIPS 6
#define MM_ISOTROPIC 7
#define MM_ANISOTROPIC 8

/* Min and Max Mapping Mode values */
#define MM_MIN MM_TEXT
#define MM_MAX MM_ANISOTROPIC
#define MM_MAX_FIXEDSCALE MM_TWIPS

/* Coordinate Modes */
#define ABSOLUTE 1
#define RELATIVE 2

/* Stock Logical Objects */
#define WHITE_BRUSH 0
#define LTGRAY_BRUSH 1
#define GRAY_BRUSH 2
#define DKGRAY_BRUSH 3
#define BLACK_BRUSH 4
#define NULL_BRUSH 5
#define HOLLOW_BRUSH NULL_BRUSH
#define WHITE_PEN 6
#define BLACK_PEN 7
#define NULL_PEN 8
#define OEM_FIXED_FONT 10
#define ANSI_FIXED_FONT 11
#define ANSI_VAR_FONT 12
#define SYSTEM_FONT 13
#define DEVICE_DEFAULT_FONT 14
#define DEFAULT_PALETTE 15
#define SYSTEM_FIXED_FONT 16


#define DEFAULT_GUI_FONT 17



#define DC_BRUSH 18
#define DC_PEN 19



#define STOCK_LAST 19






#define CLR_INVALID 0xFFFFFFFF

/* Brush Styles */
#define BS_SOLID 0
#define BS_NULL 1
#define BS_HOLLOW BS_NULL
#define BS_HATCHED 2
#define BS_PATTERN 3
#define BS_INDEXED 4
#define BS_DIBPATTERN 5
#define BS_DIBPATTERNPT 6
#define BS_PATTERN8X8 7
#define BS_DIBPATTERN8X8 8
#define BS_MONOPATTERN 9

/* Hatch Styles */
#define HS_HORIZONTAL 0
#define HS_VERTICAL 1
#define HS_FDIAGONAL 2
#define HS_BDIAGONAL 3
#define HS_CROSS 4
#define HS_DIAGCROSS 5
#define HS_API_MAX 12

/* Pen Styles */
#define PS_SOLID 0
#define PS_DASH 1
#define PS_DOT 2
#define PS_DASHDOT 3
#define PS_DASHDOTDOT 4
#define PS_NULL 5
#define PS_INSIDEFRAME 6
#define PS_USERSTYLE 7
#define PS_ALTERNATE 8
#define PS_STYLE_MASK 0x0000000F

#define PS_ENDCAP_ROUND 0x00000000
#define PS_ENDCAP_SQUARE 0x00000100
#define PS_ENDCAP_FLAT 0x00000200
#define PS_ENDCAP_MASK 0x00000F00

#define PS_JOIN_ROUND 0x00000000
#define PS_JOIN_BEVEL 0x00001000
#define PS_JOIN_MITER 0x00002000
#define PS_JOIN_MASK 0x0000F000

#define PS_COSMETIC 0x00000000
#define PS_GEOMETRIC 0x00010000
#define PS_TYPE_MASK 0x000F0000

#define AD_COUNTERCLOCKWISE 1
#define AD_CLOCKWISE 2

/* Device Parameters for GetDeviceCaps() */
#define DRIVERVERSION 0
#define TECHNOLOGY 2
#define HORZSIZE 4
#define VERTSIZE 6
#define HORZRES 8
#define VERTRES 10
#define BITSPIXEL 12
#define PLANES 14
#define NUMBRUSHES 16
#define NUMPENS 18
#define NUMMARKERS 20
#define NUMFONTS 22
#define NUMCOLORS 24
#define PDEVICESIZE 26
#define CURVECAPS 28
#define LINECAPS 30
#define POLYGONALCAPS 32
#define TEXTCAPS 34
#define CLIPCAPS 36
#define RASTERCAPS 38
#define ASPECTX 40
#define ASPECTY 42
#define ASPECTXY 44

#define LOGPIXELSX 88
#define LOGPIXELSY 90

#define SIZEPALETTE 104
#define NUMRESERVED 106
#define COLORRES 108

// Printing related DeviceCaps. These replace the appropriate Escapes

#define PHYSICALWIDTH 110
#define PHYSICALHEIGHT 111
#define PHYSICALOFFSETX 112
#define PHYSICALOFFSETY 113
#define SCALINGFACTORX 114
#define SCALINGFACTORY 115

// Display driver specific

#define VREFRESH 116
                             /* display device (for displays only) in Hz*/
#define DESKTOPVERTRES 117
                             /* pixels                                  */
#define DESKTOPHORZRES 118
                             /* pixels                                  */
#define BLTALIGNMENT 119


#define SHADEBLENDCAPS 120
#define COLORMGMTCAPS 121




/* Device Capability Masks: */

/* Device Technologies */
#define DT_PLOTTER 0
#define DT_RASDISPLAY 1
#define DT_RASPRINTER 2
#define DT_RASCAMERA 3
#define DT_CHARSTREAM 4
#define DT_METAFILE 5
#define DT_DISPFILE 6

/* Curve Capabilities */
#define CC_NONE 0
#define CC_CIRCLES 1
#define CC_PIE 2
#define CC_CHORD 4
#define CC_ELLIPSES 8
#define CC_WIDE 16
#define CC_STYLED 32
#define CC_WIDESTYLED 64
#define CC_INTERIORS 128
#define CC_ROUNDRECT 256

/* Line Capabilities */
#define LC_NONE 0
#define LC_POLYLINE 2
#define LC_MARKER 4
#define LC_POLYMARKER 8
#define LC_WIDE 16
#define LC_STYLED 32
#define LC_WIDESTYLED 64
#define LC_INTERIORS 128

/* Polygonal Capabilities */
#define PC_NONE 0
#define PC_POLYGON 1
#define PC_RECTANGLE 2
#define PC_WINDPOLYGON 4
#define PC_TRAPEZOID 4
#define PC_SCANLINE 8
#define PC_WIDE 16
#define PC_STYLED 32
#define PC_WIDESTYLED 64
#define PC_INTERIORS 128
#define PC_POLYPOLYGON 256
#define PC_PATHS 512

/* Clipping Capabilities */
#define CP_NONE 0
#define CP_RECTANGLE 1
#define CP_REGION 2

/* Text Capabilities */
#define TC_OP_CHARACTER 0x00000001
#define TC_OP_STROKE 0x00000002
#define TC_CP_STROKE 0x00000004
#define TC_CR_90 0x00000008
#define TC_CR_ANY 0x00000010
#define TC_SF_X_YINDEP 0x00000020
#define TC_SA_DOUBLE 0x00000040
#define TC_SA_INTEGER 0x00000080
#define TC_SA_CONTIN 0x00000100
#define TC_EA_DOUBLE 0x00000200
#define TC_IA_ABLE 0x00000400
#define TC_UA_ABLE 0x00000800
#define TC_SO_ABLE 0x00001000
#define TC_RA_ABLE 0x00002000
#define TC_VA_ABLE 0x00004000
#define TC_RESERVED 0x00008000
#define TC_SCROLLBLT 0x00010000



/* Raster Capabilities */
#define RC_NONE 
#define RC_BITBLT 1
#define RC_BANDING 2
#define RC_SCALING 4
#define RC_BITMAP64 8
#define RC_GDI20_OUTPUT 0x0010
#define RC_GDI20_STATE 0x0020
#define RC_SAVEBITMAP 0x0040
#define RC_DI_BITMAP 0x0080
#define RC_PALETTE 0x0100
#define RC_DIBTODEV 0x0200
#define RC_BIGFONT 0x0400
#define RC_STRETCHBLT 0x0800
#define RC_FLOODFILL 0x1000
#define RC_STRETCHDIB 0x2000
#define RC_OP_DX_OUTPUT 0x4000
#define RC_DEVBITS 0x8000



/* Shading and blending caps */
#define SB_NONE 0x00000000
#define SB_CONST_ALPHA 0x00000001
#define SB_PIXEL_ALPHA 0x00000002
#define SB_PREMULT_ALPHA 0x00000004

#define SB_GRAD_RECT 0x00000010
#define SB_GRAD_TRI 0x00000020

/* Color Management caps */
#define CM_NONE 0x00000000
#define CM_DEVICE_ICM 0x00000001
#define CM_GAMMA_RAMP 0x00000002
#define CM_CMYK_COLOR 0x00000004




/* DIB color table identifiers */

#define DIB_RGB_COLORS 0
#define DIB_PAL_COLORS 1

/* constants for Get/SetSystemPaletteUse() */

#define SYSPAL_ERROR 0
#define SYSPAL_STATIC 1
#define SYSPAL_NOSTATIC 2
#define SYSPAL_NOSTATIC256 3

/* constants for CreateDIBitmap */
#define CBM_INIT 0x04L

/* ExtFloodFill style flags */
#define FLOODFILLBORDER 0
#define FLOODFILLSURFACE 1

/* size of a device name string */
#define CCHDEVICENAME 32

/* size of a form name string */
#define CCHFORMNAME 32
# 2050 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef struct _devicemodeA {
    BYTE dmDeviceName[32];
    WORD dmSpecVersion;
    WORD dmDriverVersion;
    WORD dmSize;
    WORD dmDriverExtra;
    DWORD dmFields;
    union {
      struct {
        short dmOrientation;
        short dmPaperSize;
        short dmPaperLength;
        short dmPaperWidth;
      };
      POINTL dmPosition;
    };
    short dmScale;
    short dmCopies;
    short dmDefaultSource;
    short dmPrintQuality;
    short dmColor;
    short dmDuplex;
    short dmYResolution;
    short dmTTOption;
    short dmCollate;
    BYTE dmFormName[32];
    WORD dmLogPixels;
    DWORD dmBitsPerPel;
    DWORD dmPelsWidth;
    DWORD dmPelsHeight;
    union {
        DWORD dmDisplayFlags;
        DWORD dmNup;
    };
    DWORD dmDisplayFrequency;

    DWORD dmICMMethod;
    DWORD dmICMIntent;
    DWORD dmMediaType;
    DWORD dmDitherType;
    DWORD dmReserved1;
    DWORD dmReserved2;

    DWORD dmPanningWidth;
    DWORD dmPanningHeight;


} DEVMODEA, *PDEVMODEA, *NPDEVMODEA, *LPDEVMODEA;
typedef struct _devicemodeW {
    WCHAR dmDeviceName[32];
    WORD dmSpecVersion;
    WORD dmDriverVersion;
    WORD dmSize;
    WORD dmDriverExtra;
    DWORD dmFields;
    union {
      struct {
        short dmOrientation;
        short dmPaperSize;
        short dmPaperLength;
        short dmPaperWidth;
      };
      POINTL dmPosition;
    };
    short dmScale;
    short dmCopies;
    short dmDefaultSource;
    short dmPrintQuality;
    short dmColor;
    short dmDuplex;
    short dmYResolution;
    short dmTTOption;
    short dmCollate;
    WCHAR dmFormName[32];
    WORD dmLogPixels;
    DWORD dmBitsPerPel;
    DWORD dmPelsWidth;
    DWORD dmPelsHeight;
    union {
        DWORD dmDisplayFlags;
        DWORD dmNup;
    };
    DWORD dmDisplayFrequency;

    DWORD dmICMMethod;
    DWORD dmICMIntent;
    DWORD dmMediaType;
    DWORD dmDitherType;
    DWORD dmReserved1;
    DWORD dmReserved2;

    DWORD dmPanningWidth;
    DWORD dmPanningHeight;


} DEVMODEW, *PDEVMODEW, *NPDEVMODEW, *LPDEVMODEW;






typedef DEVMODEA DEVMODE;
typedef PDEVMODEA PDEVMODE;
typedef NPDEVMODEA NPDEVMODE;
typedef LPDEVMODEA LPDEVMODE;


/* current version of specification */

#define DM_SPECVERSION 0x0401






/* field selection bits */
#define DM_ORIENTATION 0x00000001L
#define DM_PAPERSIZE 0x00000002L
#define DM_PAPERLENGTH 0x00000004L
#define DM_PAPERWIDTH 0x00000008L
#define DM_SCALE 0x00000010L

#define DM_POSITION 0x00000020L
#define DM_NUP 0x00000040L


#define DM_DISPLAYORIENTATION 0x00000080L

#define DM_COPIES 0x00000100L
#define DM_DEFAULTSOURCE 0x00000200L
#define DM_PRINTQUALITY 0x00000400L
#define DM_COLOR 0x00000800L
#define DM_DUPLEX 0x00001000L
#define DM_YRESOLUTION 0x00002000L
#define DM_TTOPTION 0x00004000L
#define DM_COLLATE 0x00008000L
#define DM_FORMNAME 0x00010000L
#define DM_LOGPIXELS 0x00020000L
#define DM_BITSPERPEL 0x00040000L
#define DM_PELSWIDTH 0x00080000L
#define DM_PELSHEIGHT 0x00100000L
#define DM_DISPLAYFLAGS 0x00200000L
#define DM_DISPLAYFREQUENCY 0x00400000L

#define DM_ICMMETHOD 0x00800000L
#define DM_ICMINTENT 0x01000000L
#define DM_MEDIATYPE 0x02000000L
#define DM_DITHERTYPE 0x04000000L
#define DM_PANNINGWIDTH 0x08000000L
#define DM_PANNINGHEIGHT 0x10000000L


#define DM_DISPLAYFIXEDOUTPUT 0x20000000L



/* orientation selections */
#define DMORIENT_PORTRAIT 1
#define DMORIENT_LANDSCAPE 2

/* paper selections */
#define DMPAPER_FIRST DMPAPER_LETTER
#define DMPAPER_LETTER 1
#define DMPAPER_LETTERSMALL 2
#define DMPAPER_TABLOID 3
#define DMPAPER_LEDGER 4
#define DMPAPER_LEGAL 5
#define DMPAPER_STATEMENT 6
#define DMPAPER_EXECUTIVE 7
#define DMPAPER_A3 8
#define DMPAPER_A4 9
#define DMPAPER_A4SMALL 10
#define DMPAPER_A5 11
#define DMPAPER_B4 12
#define DMPAPER_B5 13
#define DMPAPER_FOLIO 14
#define DMPAPER_QUARTO 15
#define DMPAPER_10X14 16
#define DMPAPER_11X17 17
#define DMPAPER_NOTE 18
#define DMPAPER_ENV_9 19
#define DMPAPER_ENV_10 20
#define DMPAPER_ENV_11 21
#define DMPAPER_ENV_12 22
#define DMPAPER_ENV_14 23
#define DMPAPER_CSHEET 24
#define DMPAPER_DSHEET 25
#define DMPAPER_ESHEET 26
#define DMPAPER_ENV_DL 27
#define DMPAPER_ENV_C5 28
#define DMPAPER_ENV_C3 29
#define DMPAPER_ENV_C4 30
#define DMPAPER_ENV_C6 31
#define DMPAPER_ENV_C65 32
#define DMPAPER_ENV_B4 33
#define DMPAPER_ENV_B5 34
#define DMPAPER_ENV_B6 35
#define DMPAPER_ENV_ITALY 36
#define DMPAPER_ENV_MONARCH 37
#define DMPAPER_ENV_PERSONAL 38
#define DMPAPER_FANFOLD_US 39
#define DMPAPER_FANFOLD_STD_GERMAN 40
#define DMPAPER_FANFOLD_LGL_GERMAN 41

#define DMPAPER_ISO_B4 42
#define DMPAPER_JAPANESE_POSTCARD 43
#define DMPAPER_9X11 44
#define DMPAPER_10X11 45
#define DMPAPER_15X11 46
#define DMPAPER_ENV_INVITE 47
#define DMPAPER_RESERVED_48 48
#define DMPAPER_RESERVED_49 49
#define DMPAPER_LETTER_EXTRA 50
#define DMPAPER_LEGAL_EXTRA 51
#define DMPAPER_TABLOID_EXTRA 52
#define DMPAPER_A4_EXTRA 53
#define DMPAPER_LETTER_TRANSVERSE 54
#define DMPAPER_A4_TRANSVERSE 55
#define DMPAPER_LETTER_EXTRA_TRANSVERSE 56
#define DMPAPER_A_PLUS 57
#define DMPAPER_B_PLUS 58
#define DMPAPER_LETTER_PLUS 59
#define DMPAPER_A4_PLUS 60
#define DMPAPER_A5_TRANSVERSE 61
#define DMPAPER_B5_TRANSVERSE 62
#define DMPAPER_A3_EXTRA 63
#define DMPAPER_A5_EXTRA 64
#define DMPAPER_B5_EXTRA 65
#define DMPAPER_A2 66
#define DMPAPER_A3_TRANSVERSE 67
#define DMPAPER_A3_EXTRA_TRANSVERSE 68



#define DMPAPER_DBL_JAPANESE_POSTCARD 69
#define DMPAPER_A6 70
#define DMPAPER_JENV_KAKU2 71
#define DMPAPER_JENV_KAKU3 72
#define DMPAPER_JENV_CHOU3 73
#define DMPAPER_JENV_CHOU4 74
#define DMPAPER_LETTER_ROTATED 75
#define DMPAPER_A3_ROTATED 76
#define DMPAPER_A4_ROTATED 77
#define DMPAPER_A5_ROTATED 78
#define DMPAPER_B4_JIS_ROTATED 79
#define DMPAPER_B5_JIS_ROTATED 80
#define DMPAPER_JAPANESE_POSTCARD_ROTATED 81
#define DMPAPER_DBL_JAPANESE_POSTCARD_ROTATED 82
#define DMPAPER_A6_ROTATED 83
#define DMPAPER_JENV_KAKU2_ROTATED 84
#define DMPAPER_JENV_KAKU3_ROTATED 85
#define DMPAPER_JENV_CHOU3_ROTATED 86
#define DMPAPER_JENV_CHOU4_ROTATED 87
#define DMPAPER_B6_JIS 88
#define DMPAPER_B6_JIS_ROTATED 89
#define DMPAPER_12X11 90
#define DMPAPER_JENV_YOU4 91
#define DMPAPER_JENV_YOU4_ROTATED 92
#define DMPAPER_P16K 93
#define DMPAPER_P32K 94
#define DMPAPER_P32KBIG 95
#define DMPAPER_PENV_1 96
#define DMPAPER_PENV_2 97
#define DMPAPER_PENV_3 98
#define DMPAPER_PENV_4 99
#define DMPAPER_PENV_5 100
#define DMPAPER_PENV_6 101
#define DMPAPER_PENV_7 102
#define DMPAPER_PENV_8 103
#define DMPAPER_PENV_9 104
#define DMPAPER_PENV_10 105
#define DMPAPER_P16K_ROTATED 106
#define DMPAPER_P32K_ROTATED 107
#define DMPAPER_P32KBIG_ROTATED 108
#define DMPAPER_PENV_1_ROTATED 109
#define DMPAPER_PENV_2_ROTATED 110
#define DMPAPER_PENV_3_ROTATED 111
#define DMPAPER_PENV_4_ROTATED 112
#define DMPAPER_PENV_5_ROTATED 113
#define DMPAPER_PENV_6_ROTATED 114
#define DMPAPER_PENV_7_ROTATED 115
#define DMPAPER_PENV_8_ROTATED 116
#define DMPAPER_PENV_9_ROTATED 117
#define DMPAPER_PENV_10_ROTATED 118



#define DMPAPER_LAST DMPAPER_PENV_10_ROTATED






#define DMPAPER_USER 256

/* bin selections */
#define DMBIN_FIRST DMBIN_UPPER
#define DMBIN_UPPER 1
#define DMBIN_ONLYONE 1
#define DMBIN_LOWER 2
#define DMBIN_MIDDLE 3
#define DMBIN_MANUAL 4
#define DMBIN_ENVELOPE 5
#define DMBIN_ENVMANUAL 6
#define DMBIN_AUTO 7
#define DMBIN_TRACTOR 8
#define DMBIN_SMALLFMT 9
#define DMBIN_LARGEFMT 10
#define DMBIN_LARGECAPACITY 11
#define DMBIN_CASSETTE 14
#define DMBIN_FORMSOURCE 15
#define DMBIN_LAST DMBIN_FORMSOURCE

#define DMBIN_USER 256

/* print qualities */
#define DMRES_DRAFT (-1)
#define DMRES_LOW (-2)
#define DMRES_MEDIUM (-3)
#define DMRES_HIGH (-4)

/* color enable/disable for color printers */
#define DMCOLOR_MONOCHROME 1
#define DMCOLOR_COLOR 2

/* duplex enable */
#define DMDUP_SIMPLEX 1
#define DMDUP_VERTICAL 2
#define DMDUP_HORIZONTAL 3

/* TrueType options */
#define DMTT_BITMAP 1
#define DMTT_DOWNLOAD 2
#define DMTT_SUBDEV 3

#define DMTT_DOWNLOAD_OUTLINE 4


/* Collation selections */
#define DMCOLLATE_FALSE 0
#define DMCOLLATE_TRUE 1


/* DEVMODE dmDisplayOrientation specifiations */
#define DMDO_DEFAULT 0
#define DMDO_90 1
#define DMDO_180 2
#define DMDO_270 3

/* DEVMODE dmDisplayFixedOutput specifiations */
#define DMDFO_DEFAULT 0
#define DMDFO_STRETCH 1
#define DMDFO_CENTER 2


/* DEVMODE dmDisplayFlags flags */

// #define DM_GRAYSCALE            0x00000001 /* This flag is no longer valid */
#define DM_INTERLACED 0x00000002
#define DMDISPLAYFLAGS_TEXTMODE 0x00000004

/* dmNup , multiple logical page per physical page options */
#define DMNUP_SYSTEM 1
#define DMNUP_ONEUP 2


/* ICM methods */
#define DMICMMETHOD_NONE 1
#define DMICMMETHOD_SYSTEM 2
#define DMICMMETHOD_DRIVER 3
#define DMICMMETHOD_DEVICE 4

#define DMICMMETHOD_USER 256

/* ICM Intents */
#define DMICM_SATURATE 1
#define DMICM_CONTRAST 2
#define DMICM_COLORIMETRIC 3
#define DMICM_ABS_COLORIMETRIC 4

#define DMICM_USER 256

/* Media types */

#define DMMEDIA_STANDARD 1
#define DMMEDIA_TRANSPARENCY 2
#define DMMEDIA_GLOSSY 3

#define DMMEDIA_USER 256

/* Dither types */
#define DMDITHER_NONE 1
#define DMDITHER_COARSE 2
#define DMDITHER_FINE 3
#define DMDITHER_LINEART 4
#define DMDITHER_ERRORDIFFUSION 5
#define DMDITHER_RESERVED6 6
#define DMDITHER_RESERVED7 7
#define DMDITHER_RESERVED8 8
#define DMDITHER_RESERVED9 9
#define DMDITHER_GRAYSCALE 10

#define DMDITHER_USER 256


typedef struct _DISPLAY_DEVICEA {
    DWORD cb;
    CHAR DeviceName[32];
    CHAR DeviceString[128];
    DWORD StateFlags;
    CHAR DeviceID[128];
    CHAR DeviceKey[128];
} DISPLAY_DEVICEA, *PDISPLAY_DEVICEA, *LPDISPLAY_DEVICEA;
typedef struct _DISPLAY_DEVICEW {
    DWORD cb;
    WCHAR DeviceName[32];
    WCHAR DeviceString[128];
    DWORD StateFlags;
    WCHAR DeviceID[128];
    WCHAR DeviceKey[128];
} DISPLAY_DEVICEW, *PDISPLAY_DEVICEW, *LPDISPLAY_DEVICEW;





typedef DISPLAY_DEVICEA DISPLAY_DEVICE;
typedef PDISPLAY_DEVICEA PDISPLAY_DEVICE;
typedef LPDISPLAY_DEVICEA LPDISPLAY_DEVICE;


#define DISPLAY_DEVICE_ATTACHED_TO_DESKTOP 0x00000001
#define DISPLAY_DEVICE_MULTI_DRIVER 0x00000002
#define DISPLAY_DEVICE_PRIMARY_DEVICE 0x00000004
#define DISPLAY_DEVICE_MIRRORING_DRIVER 0x00000008
#define DISPLAY_DEVICE_VGA_COMPATIBLE 0x00000010

#define DISPLAY_DEVICE_REMOVABLE 0x00000020

#define DISPLAY_DEVICE_MODESPRUNED 0x08000000

#define DISPLAY_DEVICE_REMOTE 0x04000000
#define DISPLAY_DEVICE_DISCONNECT 0x02000000

#define DISPLAY_DEVICE_TS_COMPATIBLE 0x00200000

#define DISPLAY_DEVICE_UNSAFE_MODES_ON 0x00080000


/* Child device state */

#define DISPLAY_DEVICE_ACTIVE 0x00000001
#define DISPLAY_DEVICE_ATTACHED 0x00000002




#define DISPLAYCONFIG_MAXPATH 1024
                                          // Max adapter (16) * Max source (16) *
                                          // Max clone pre source (4)

typedef struct DISPLAYCONFIG_RATIONAL
{
    UINT32 Numerator;
    UINT32 Denominator;
} DISPLAYCONFIG_RATIONAL;

typedef enum
{
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_OTHER = -1,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_HD15 = 0,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_SVIDEO = 1,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_COMPOSITE_VIDEO = 2,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_COMPONENT_VIDEO = 3,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DVI = 4,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_HDMI = 5,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_LVDS = 6,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_D_JPN = 8,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_SDI = 9,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DISPLAYPORT_EXTERNAL = 10,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_DISPLAYPORT_EMBEDDED = 11,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_UDI_EXTERNAL = 12,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_UDI_EMBEDDED = 13,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_SDTVDONGLE = 14,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_INTERNAL = 0x80000000,
    DISPLAYCONFIG_OUTPUT_TECHNOLOGY_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY;

typedef enum
{
    DISPLAYCONFIG_SCANLINE_ORDERING_UNSPECIFIED = 0,
    DISPLAYCONFIG_SCANLINE_ORDERING_PROGRESSIVE = 1,
    DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED = 2,
    DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED_UPPERFIELDFIRST = DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED,
    DISPLAYCONFIG_SCANLINE_ORDERING_INTERLACED_LOWERFIELDFIRST = 3,
    DISPLAYCONFIG_SCANLINE_ORDERING_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_SCANLINE_ORDERING;

typedef struct DISPLAYCONFIG_2DREGION
{
    UINT32 cx;
    UINT32 cy;
} DISPLAYCONFIG_2DREGION;

typedef struct DISPLAYCONFIG_VIDEO_SIGNAL_INFO
{
    UINT64 pixelRate;
    DISPLAYCONFIG_RATIONAL hSyncFreq;
    DISPLAYCONFIG_RATIONAL vSyncFreq;
    DISPLAYCONFIG_2DREGION activeSize;
    DISPLAYCONFIG_2DREGION totalSize;
    UINT32 videoStandard;
    DISPLAYCONFIG_SCANLINE_ORDERING scanLineOrdering;
} DISPLAYCONFIG_VIDEO_SIGNAL_INFO;

typedef enum
{
    DISPLAYCONFIG_SCALING_IDENTITY = 1,
    DISPLAYCONFIG_SCALING_CENTERED = 2,
    DISPLAYCONFIG_SCALING_STRETCHED = 3,
    DISPLAYCONFIG_SCALING_ASPECTRATIOCENTEREDMAX = 4,
    DISPLAYCONFIG_SCALING_CUSTOM = 5,
    DISPLAYCONFIG_SCALING_PREFERRED = 128,
    DISPLAYCONFIG_SCALING_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_SCALING;

typedef enum
{
    DISPLAYCONFIG_ROTATION_IDENTITY = 1,
    DISPLAYCONFIG_ROTATION_ROTATE90 = 2,
    DISPLAYCONFIG_ROTATION_ROTATE180 = 3,
    DISPLAYCONFIG_ROTATION_ROTATE270 = 4,
    DISPLAYCONFIG_ROTATION_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_ROTATION;

typedef enum
{
    DISPLAYCONFIG_MODE_INFO_TYPE_SOURCE = 1,
    DISPLAYCONFIG_MODE_INFO_TYPE_TARGET = 2,
    DISPLAYCONFIG_MODE_INFO_TYPE_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_MODE_INFO_TYPE;

typedef enum
{
    DISPLAYCONFIG_PIXELFORMAT_8BPP = 1,
    DISPLAYCONFIG_PIXELFORMAT_16BPP = 2,
    DISPLAYCONFIG_PIXELFORMAT_24BPP = 3,
    DISPLAYCONFIG_PIXELFORMAT_32BPP = 4,
    DISPLAYCONFIG_PIXELFORMAT_NONGDI = 5,
    DISPLAYCONFIG_PIXELFORMAT_FORCE_UINT32 = 0xffffffff
} DISPLAYCONFIG_PIXELFORMAT;

typedef struct DISPLAYCONFIG_SOURCE_MODE
{
    UINT32 width;
    UINT32 height;
    DISPLAYCONFIG_PIXELFORMAT pixelFormat;
    POINTL position;
} DISPLAYCONFIG_SOURCE_MODE;

typedef struct DISPLAYCONFIG_TARGET_MODE
{
    DISPLAYCONFIG_VIDEO_SIGNAL_INFO targetVideoSignalInfo;
} DISPLAYCONFIG_TARGET_MODE;

typedef struct DISPLAYCONFIG_MODE_INFO
{
    DISPLAYCONFIG_MODE_INFO_TYPE infoType;
    UINT32 id;
    LUID adapterId;
    union
    {
        DISPLAYCONFIG_TARGET_MODE targetMode;
        DISPLAYCONFIG_SOURCE_MODE sourceMode;
    };
} DISPLAYCONFIG_MODE_INFO;

#define DISPLAYCONFIG_PATH_MODE_IDX_INVALID 0xffffffff

typedef struct DISPLAYCONFIG_PATH_SOURCE_INFO
{
    LUID adapterId;
    UINT32 id;
    UINT32 modeInfoIdx;
    UINT32 statusFlags;
} DISPLAYCONFIG_PATH_SOURCE_INFO;

//
// Flags for source info structure (from OS to application through QDC)
//

#define DISPLAYCONFIG_SOURCE_IN_USE 0x00000001

typedef struct DISPLAYCONFIG_PATH_TARGET_INFO
{
    LUID adapterId;
    UINT32 id;
    UINT32 modeInfoIdx;
    DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY outputTechnology;
    DISPLAYCONFIG_ROTATION rotation;
    DISPLAYCONFIG_SCALING scaling;
    DISPLAYCONFIG_RATIONAL refreshRate;
    DISPLAYCONFIG_SCANLINE_ORDERING scanLineOrdering;
    BOOL targetAvailable;
    UINT32 statusFlags;
} DISPLAYCONFIG_PATH_TARGET_INFO;

//
// Status flags for target info structure (from OS to application through QDC)
//
#define DISPLAYCONFIG_TARGET_IN_USE 0x00000001
#define DISPLAYCONFIG_TARGET_FORCIBLE 0x00000002
#define DISPLAYCONFIG_TARGET_FORCED_AVAILABILITY_BOOT 0x00000004
#define DISPLAYCONFIG_TARGET_FORCED_AVAILABILITY_PATH 0x00000008
#define DISPLAYCONFIG_TARGET_FORCED_AVAILABILITY_SYSTEM 0x00000010

typedef struct DISPLAYCONFIG_PATH_INFO
{
    DISPLAYCONFIG_PATH_SOURCE_INFO sourceInfo;
    DISPLAYCONFIG_PATH_TARGET_INFO targetInfo;
    UINT32 flags;
} DISPLAYCONFIG_PATH_INFO;

//
// Flags for path info structure (from OS to application through QDC)
//

#define DISPLAYCONFIG_PATH_ACTIVE 0x00000001

typedef enum
{
      DISPLAYCONFIG_TOPOLOGY_INTERNAL = 0x00000001,
      DISPLAYCONFIG_TOPOLOGY_CLONE = 0x00000002,
      DISPLAYCONFIG_TOPOLOGY_EXTEND = 0x00000004,
      DISPLAYCONFIG_TOPOLOGY_EXTERNAL = 0x00000008,
      DISPLAYCONFIG_TOPOLOGY_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_TOPOLOGY_ID;

typedef enum
{
      DISPLAYCONFIG_DEVICE_INFO_GET_SOURCE_NAME = 1,
      DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_NAME = 2,
      DISPLAYCONFIG_DEVICE_INFO_GET_TARGET_PREFERRED_MODE = 3,
      DISPLAYCONFIG_DEVICE_INFO_GET_ADAPTER_NAME = 4,
      DISPLAYCONFIG_DEVICE_INFO_SET_TARGET_PERSISTENCE = 5,
      DISPLAYCONFIG_DEVICE_INFO_FORCE_UINT32 = 0xFFFFFFFF
} DISPLAYCONFIG_DEVICE_INFO_TYPE;

typedef struct DISPLAYCONFIG_DEVICE_INFO_HEADER
{
    DISPLAYCONFIG_DEVICE_INFO_TYPE type;
    UINT32 size;
    LUID adapterId;
    UINT32 id;
} DISPLAYCONFIG_DEVICE_INFO_HEADER;

typedef struct DISPLAYCONFIG_SOURCE_DEVICE_NAME
{
    DISPLAYCONFIG_DEVICE_INFO_HEADER header;
    WCHAR viewGdiDeviceName[32];
} DISPLAYCONFIG_SOURCE_DEVICE_NAME;

typedef struct DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS
{
    union
    {
        struct
        {
            UINT32 friendlyNameFromEdid : 1;
            UINT32 friendlyNameForced : 1;
            UINT32 edidIdsValid : 1;
            UINT32 reserved : 29;
        };
        UINT32 value;
    };
} DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS;

typedef struct DISPLAYCONFIG_TARGET_DEVICE_NAME
{
    DISPLAYCONFIG_DEVICE_INFO_HEADER header;
    DISPLAYCONFIG_TARGET_DEVICE_NAME_FLAGS flags;
    DISPLAYCONFIG_VIDEO_OUTPUT_TECHNOLOGY outputTechnology;
    UINT16 edidManufactureId;
    UINT16 edidProductCodeId;
    UINT32 connectorInstance;
    WCHAR monitorFriendlyDeviceName[64];
    WCHAR monitorDevicePath[128];
} DISPLAYCONFIG_TARGET_DEVICE_NAME;

typedef struct DISPLAYCONFIG_TARGET_PREFERRED_MODE
{
    DISPLAYCONFIG_DEVICE_INFO_HEADER header;
    UINT32 width;
    UINT32 height;
    DISPLAYCONFIG_TARGET_MODE targetMode;
} DISPLAYCONFIG_TARGET_PREFERRED_MODE;

typedef struct DISPLAYCONFIG_ADAPTER_NAME
{
    DISPLAYCONFIG_DEVICE_INFO_HEADER header;
    WCHAR adapterDevicePath[128];
} DISPLAYCONFIG_ADAPTER_NAME;

typedef struct DISPLAYCONFIG_SET_TARGET_PERSISTENCE
{
    DISPLAYCONFIG_DEVICE_INFO_HEADER header;
    union
    {
        struct
        {
            UINT32 bootPersistenceOn : 1;
            UINT32 reserved : 31;
        };
        UINT32 value;
    };
} DISPLAYCONFIG_SET_TARGET_PERSISTENCE;

//
// Definitions to be used by GetDisplayConfigBufferSizes and QueryDisplayConfig.
//

#define QDC_ALL_PATHS 0x00000001
#define QDC_ONLY_ACTIVE_PATHS 0x00000002
#define QDC_DATABASE_CURRENT 0x00000004

//
// Definitions used by SetDisplayConfig.
//

#define SDC_TOPOLOGY_INTERNAL 0x00000001
#define SDC_TOPOLOGY_CLONE 0x00000002
#define SDC_TOPOLOGY_EXTEND 0x00000004
#define SDC_TOPOLOGY_EXTERNAL 0x00000008
#define SDC_TOPOLOGY_SUPPLIED 0x00000010
#define SDC_USE_DATABASE_CURRENT (SDC_TOPOLOGY_INTERNAL | SDC_TOPOLOGY_CLONE | SDC_TOPOLOGY_EXTEND | SDC_TOPOLOGY_EXTERNAL)

#define SDC_USE_SUPPLIED_DISPLAY_CONFIG 0x00000020
#define SDC_VALIDATE 0x00000040
#define SDC_APPLY 0x00000080
#define SDC_NO_OPTIMIZATION 0x00000100
#define SDC_SAVE_TO_DATABASE 0x00000200
#define SDC_ALLOW_CHANGES 0x00000400
#define SDC_PATH_PERSIST_IF_REQUIRED 0x00000800
#define SDC_FORCE_MODE_ENUMERATION 0x00001000
#define SDC_ALLOW_PATH_ORDER_CHANGES 0x00002000




/* GetRegionData/ExtCreateRegion */

#define RDH_RECTANGLES 1

typedef struct _RGNDATAHEADER {
    DWORD dwSize;
    DWORD iType;
    DWORD nCount;
    DWORD nRgnSize;
    RECT rcBound;
} RGNDATAHEADER, *PRGNDATAHEADER;

typedef struct _RGNDATA {
    RGNDATAHEADER rdh;
    char Buffer[1];
} RGNDATA, *PRGNDATA, NEAR *NPRGNDATA, FAR *LPRGNDATA;


/* for GetRandomRgn */
#define SYSRGN 4


typedef struct _ABC {
    int abcA;
    UINT abcB;
    int abcC;
} ABC, *PABC, NEAR *NPABC, FAR *LPABC;

typedef struct _ABCFLOAT {
    FLOAT abcfA;
    FLOAT abcfB;
    FLOAT abcfC;
} ABCFLOAT, *PABCFLOAT, NEAR *NPABCFLOAT, FAR *LPABCFLOAT;






typedef struct _OUTLINETEXTMETRICA {
    UINT otmSize;
    TEXTMETRICA otmTextMetrics;
    BYTE otmFiller;
    PANOSE otmPanoseNumber;
    UINT otmfsSelection;
    UINT otmfsType;
     int otmsCharSlopeRise;
     int otmsCharSlopeRun;
     int otmItalicAngle;
    UINT otmEMSquare;
     int otmAscent;
     int otmDescent;
    UINT otmLineGap;
    UINT otmsCapEmHeight;
    UINT otmsXHeight;
    RECT otmrcFontBox;
     int otmMacAscent;
     int otmMacDescent;
    UINT otmMacLineGap;
    UINT otmusMinimumPPEM;
    POINT otmptSubscriptSize;
    POINT otmptSubscriptOffset;
    POINT otmptSuperscriptSize;
    POINT otmptSuperscriptOffset;
    UINT otmsStrikeoutSize;
     int otmsStrikeoutPosition;
     int otmsUnderscoreSize;
     int otmsUnderscorePosition;
    PSTR otmpFamilyName;
    PSTR otmpFaceName;
    PSTR otmpStyleName;
    PSTR otmpFullName;
} OUTLINETEXTMETRICA, *POUTLINETEXTMETRICA, NEAR *NPOUTLINETEXTMETRICA, FAR *LPOUTLINETEXTMETRICA;
typedef struct _OUTLINETEXTMETRICW {
    UINT otmSize;
    TEXTMETRICW otmTextMetrics;
    BYTE otmFiller;
    PANOSE otmPanoseNumber;
    UINT otmfsSelection;
    UINT otmfsType;
     int otmsCharSlopeRise;
     int otmsCharSlopeRun;
     int otmItalicAngle;
    UINT otmEMSquare;
     int otmAscent;
     int otmDescent;
    UINT otmLineGap;
    UINT otmsCapEmHeight;
    UINT otmsXHeight;
    RECT otmrcFontBox;
     int otmMacAscent;
     int otmMacDescent;
    UINT otmMacLineGap;
    UINT otmusMinimumPPEM;
    POINT otmptSubscriptSize;
    POINT otmptSubscriptOffset;
    POINT otmptSuperscriptSize;
    POINT otmptSuperscriptOffset;
    UINT otmsStrikeoutSize;
     int otmsStrikeoutPosition;
     int otmsUnderscoreSize;
     int otmsUnderscorePosition;
    PSTR otmpFamilyName;
    PSTR otmpFaceName;
    PSTR otmpStyleName;
    PSTR otmpFullName;
} OUTLINETEXTMETRICW, *POUTLINETEXTMETRICW, NEAR *NPOUTLINETEXTMETRICW, FAR *LPOUTLINETEXTMETRICW;






typedef OUTLINETEXTMETRICA OUTLINETEXTMETRIC;
typedef POUTLINETEXTMETRICA POUTLINETEXTMETRIC;
typedef NPOUTLINETEXTMETRICA NPOUTLINETEXTMETRIC;
typedef LPOUTLINETEXTMETRICA LPOUTLINETEXTMETRIC;
# 2928 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef struct tagPOLYTEXTA
{
    int x;
    int y;
    UINT n;
    LPCSTR lpstr;
    UINT uiFlags;
    RECT rcl;
    int *pdx;
} POLYTEXTA, *PPOLYTEXTA, NEAR *NPPOLYTEXTA, FAR *LPPOLYTEXTA;
typedef struct tagPOLYTEXTW
{
    int x;
    int y;
    UINT n;
    LPCWSTR lpstr;
    UINT uiFlags;
    RECT rcl;
    int *pdx;
} POLYTEXTW, *PPOLYTEXTW, NEAR *NPPOLYTEXTW, FAR *LPPOLYTEXTW;






typedef POLYTEXTA POLYTEXT;
typedef PPOLYTEXTA PPOLYTEXT;
typedef NPPOLYTEXTA NPPOLYTEXT;
typedef LPPOLYTEXTA LPPOLYTEXT;


typedef struct _FIXED {

    WORD fract;
    short value;




} FIXED;


typedef struct _MAT2 {
     FIXED eM11;
     FIXED eM12;
     FIXED eM21;
     FIXED eM22;
} MAT2, FAR *LPMAT2;



typedef struct _GLYPHMETRICS {
    UINT gmBlackBoxX;
    UINT gmBlackBoxY;
    POINT gmptGlyphOrigin;
    short gmCellIncX;
    short gmCellIncY;
} GLYPHMETRICS, FAR *LPGLYPHMETRICS;

//  GetGlyphOutline constants

#define GGO_METRICS 0
#define GGO_BITMAP 1
#define GGO_NATIVE 2
#define GGO_BEZIER 3


#define GGO_GRAY2_BITMAP 4
#define GGO_GRAY4_BITMAP 5
#define GGO_GRAY8_BITMAP 6
#define GGO_GLYPH_INDEX 0x0080



#define GGO_UNHINTED 0x0100


#define TT_POLYGON_TYPE 24

#define TT_PRIM_LINE 1
#define TT_PRIM_QSPLINE 2
#define TT_PRIM_CSPLINE 3

typedef struct tagPOINTFX
{
    FIXED x;
    FIXED y;
} POINTFX, FAR* LPPOINTFX;

typedef struct tagTTPOLYCURVE
{
    WORD wType;
    WORD cpfx;
    POINTFX apfx[1];
} TTPOLYCURVE, FAR* LPTTPOLYCURVE;

typedef struct tagTTPOLYGONHEADER
{
    DWORD cb;
    DWORD dwType;
    POINTFX pfxStart;
} TTPOLYGONHEADER, FAR* LPTTPOLYGONHEADER;



#define GCP_DBCS 0x0001
#define GCP_REORDER 0x0002
#define GCP_USEKERNING 0x0008
#define GCP_GLYPHSHAPE 0x0010
#define GCP_LIGATE 0x0020
////#define GCP_GLYPHINDEXING  0x0080
#define GCP_DIACRITIC 0x0100
#define GCP_KASHIDA 0x0400
#define GCP_ERROR 0x8000
#define FLI_MASK 0x103B

#define GCP_JUSTIFY 0x00010000L
////#define GCP_NODIACRITICS   0x00020000L
#define FLI_GLYPHS 0x00040000L
#define GCP_CLASSIN 0x00080000L
#define GCP_MAXEXTENT 0x00100000L
#define GCP_JUSTIFYIN 0x00200000L
#define GCP_DISPLAYZWG 0x00400000L
#define GCP_SYMSWAPOFF 0x00800000L
#define GCP_NUMERICOVERRIDE 0x01000000L
#define GCP_NEUTRALOVERRIDE 0x02000000L
#define GCP_NUMERICSLATIN 0x04000000L
#define GCP_NUMERICSLOCAL 0x08000000L

#define GCPCLASS_LATIN 1
#define GCPCLASS_HEBREW 2
#define GCPCLASS_ARABIC 2
#define GCPCLASS_NEUTRAL 3
#define GCPCLASS_LOCALNUMBER 4
#define GCPCLASS_LATINNUMBER 5
#define GCPCLASS_LATINNUMERICTERMINATOR 6
#define GCPCLASS_LATINNUMERICSEPARATOR 7
#define GCPCLASS_NUMERICSEPARATOR 8
#define GCPCLASS_PREBOUNDLTR 0x80
#define GCPCLASS_PREBOUNDRTL 0x40
#define GCPCLASS_POSTBOUNDLTR 0x20
#define GCPCLASS_POSTBOUNDRTL 0x10

#define GCPGLYPH_LINKBEFORE 0x8000
#define GCPGLYPH_LINKAFTER 0x4000


typedef struct tagGCP_RESULTSA
    {
    DWORD lStructSize;
    LPSTR lpOutString;
    UINT FAR *lpOrder;
    int FAR *lpDx;
    int FAR *lpCaretPos;
    LPSTR lpClass;
    LPWSTR lpGlyphs;
    UINT nGlyphs;
    int nMaxFit;
    } GCP_RESULTSA, FAR* LPGCP_RESULTSA;
typedef struct tagGCP_RESULTSW
    {
    DWORD lStructSize;
    LPWSTR lpOutString;
    UINT FAR *lpOrder;
    int FAR *lpDx;
    int FAR *lpCaretPos;
    LPSTR lpClass;
    LPWSTR lpGlyphs;
    UINT nGlyphs;
    int nMaxFit;
    } GCP_RESULTSW, FAR* LPGCP_RESULTSW;




typedef GCP_RESULTSA GCP_RESULTS;
typedef LPGCP_RESULTSA LPGCP_RESULTS;



typedef struct _RASTERIZER_STATUS {
    short nSize;
    short wFlags;
    short nLanguageID;
} RASTERIZER_STATUS, FAR *LPRASTERIZER_STATUS;

/* bits defined in wFlags of RASTERIZER_STATUS */
#define TT_AVAILABLE 0x0001
#define TT_ENABLED 0x0002

/* Pixel format descriptor */
typedef struct tagPIXELFORMATDESCRIPTOR
{
    WORD nSize;
    WORD nVersion;
    DWORD dwFlags;
    BYTE iPixelType;
    BYTE cColorBits;
    BYTE cRedBits;
    BYTE cRedShift;
    BYTE cGreenBits;
    BYTE cGreenShift;
    BYTE cBlueBits;
    BYTE cBlueShift;
    BYTE cAlphaBits;
    BYTE cAlphaShift;
    BYTE cAccumBits;
    BYTE cAccumRedBits;
    BYTE cAccumGreenBits;
    BYTE cAccumBlueBits;
    BYTE cAccumAlphaBits;
    BYTE cDepthBits;
    BYTE cStencilBits;
    BYTE cAuxBuffers;
    BYTE iLayerType;
    BYTE bReserved;
    DWORD dwLayerMask;
    DWORD dwVisibleMask;
    DWORD dwDamageMask;
} PIXELFORMATDESCRIPTOR, *PPIXELFORMATDESCRIPTOR, FAR *LPPIXELFORMATDESCRIPTOR;

/* pixel types */
#define PFD_TYPE_RGBA 0
#define PFD_TYPE_COLORINDEX 1

/* layer types */
#define PFD_MAIN_PLANE 0
#define PFD_OVERLAY_PLANE 1
#define PFD_UNDERLAY_PLANE (-1)

/* PIXELFORMATDESCRIPTOR flags */
#define PFD_DOUBLEBUFFER 0x00000001
#define PFD_STEREO 0x00000002
#define PFD_DRAW_TO_WINDOW 0x00000004
#define PFD_DRAW_TO_BITMAP 0x00000008
#define PFD_SUPPORT_GDI 0x00000010
#define PFD_SUPPORT_OPENGL 0x00000020
#define PFD_GENERIC_FORMAT 0x00000040
#define PFD_NEED_PALETTE 0x00000080
#define PFD_NEED_SYSTEM_PALETTE 0x00000100
#define PFD_SWAP_EXCHANGE 0x00000200
#define PFD_SWAP_COPY 0x00000400
#define PFD_SWAP_LAYER_BUFFERS 0x00000800
#define PFD_GENERIC_ACCELERATED 0x00001000
#define PFD_SUPPORT_DIRECTDRAW 0x00002000
#define PFD_DIRECT3D_ACCELERATED 0x00004000
#define PFD_SUPPORT_COMPOSITION 0x00008000

/* PIXELFORMATDESCRIPTOR flags for use in ChoosePixelFormat only */
#define PFD_DEPTH_DONTCARE 0x20000000
#define PFD_DOUBLEBUFFER_DONTCARE 0x40000000
#define PFD_STEREO_DONTCARE 0x80000000
# 3212 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef FARPROC OLDFONTENUMPROC;
typedef FARPROC FONTENUMPROCA;
typedef FARPROC FONTENUMPROCW;



typedef FONTENUMPROCA FONTENUMPROC;

typedef FARPROC GOBJENUMPROC;
typedef FARPROC LINEDDAPROC;




DECLSPEC_IMPORT int WINAPI AddFontResourceA(__in LPCSTR);
DECLSPEC_IMPORT int WINAPI AddFontResourceW(__in LPCWSTR);



#define AddFontResource AddFontResourceA


__gdi_entry DECLSPEC_IMPORT BOOL WINAPI AnimatePalette( __in HPALETTE hPal, __in UINT iStartIndex, __in UINT cEntries, __in_ecount(cEntries) CONST PALETTEENTRY * ppe);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Arc( __in HDC hdc, __in int x1, __in int y1, __in int x2, __in int y2, __in int x3, __in int y3, __in int x4, __in int y4);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI BitBlt( __in HDC hdc, __in int x, __in int y, __in int cx, __in int cy, __in_opt HDC hdcSrc, __in int x1, __in int y1, __in DWORD rop);
DECLSPEC_IMPORT BOOL WINAPI CancelDC( __in HDC hdc);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Chord( __in HDC hdc, __in int x1, __in int y1, __in int x2, __in int y2, __in int x3, __in int y3, __in int x4, __in int y4);
DECLSPEC_IMPORT int WINAPI ChoosePixelFormat( __in HDC hdc, __in CONST PIXELFORMATDESCRIPTOR *ppfd);
DECLSPEC_IMPORT HMETAFILE WINAPI CloseMetaFile( __in HDC hdc);
DECLSPEC_IMPORT int WINAPI CombineRgn( __in_opt HRGN hrgnDst, __in_opt HRGN hrgnSrc1, __in_opt HRGN hrgnSrc2, __in int iMode);
DECLSPEC_IMPORT HMETAFILE WINAPI CopyMetaFileA( __in HMETAFILE, __in_opt LPCSTR);
DECLSPEC_IMPORT HMETAFILE WINAPI CopyMetaFileW( __in HMETAFILE, __in_opt LPCWSTR);



#define CopyMetaFile CopyMetaFileA

__gdi_entry DECLSPEC_IMPORT HBITMAP WINAPI CreateBitmap( __in int nWidth, __in int nHeight, __in UINT nPlanes, __in UINT nBitCount, __in_opt CONST VOID *lpBits);
__gdi_entry DECLSPEC_IMPORT HBITMAP WINAPI CreateBitmapIndirect( __in CONST BITMAP *pbm);
__gdi_entry DECLSPEC_IMPORT HBRUSH WINAPI CreateBrushIndirect( __in CONST LOGBRUSH *plbrush);
DECLSPEC_IMPORT HBITMAP WINAPI CreateCompatibleBitmap( __in HDC hdc, __in int cx, __in int cy);
DECLSPEC_IMPORT HBITMAP WINAPI CreateDiscardableBitmap( __in HDC hdc, __in int cx, __in int cy);
DECLSPEC_IMPORT HDC WINAPI CreateCompatibleDC( __in_opt HDC hdc);
DECLSPEC_IMPORT HDC WINAPI CreateDCA( __in_opt LPCSTR pwszDriver, __in_opt LPCSTR pwszDevice, __in_opt LPCSTR pszPort, __in_opt CONST DEVMODEA * pdm);
DECLSPEC_IMPORT HDC WINAPI CreateDCW( __in_opt LPCWSTR pwszDriver, __in_opt LPCWSTR pwszDevice, __in_opt LPCWSTR pszPort, __in_opt CONST DEVMODEW * pdm);



#define CreateDC CreateDCA

DECLSPEC_IMPORT HBITMAP WINAPI CreateDIBitmap( __in HDC hdc, __in_opt CONST BITMAPINFOHEADER *pbmih, __in DWORD flInit, __in_opt CONST VOID *pjBits, __in_opt CONST BITMAPINFO *pbmi, __in UINT iUsage);
DECLSPEC_IMPORT HBRUSH WINAPI CreateDIBPatternBrush( __in HGLOBAL h, __in UINT iUsage);
__gdi_entry DECLSPEC_IMPORT HBRUSH WINAPI CreateDIBPatternBrushPt( __in CONST VOID *lpPackedDIB, __in UINT iUsage);
DECLSPEC_IMPORT HRGN WINAPI CreateEllipticRgn( __in int x1, __in int y1, __in int x2, __in int y2);
DECLSPEC_IMPORT HRGN WINAPI CreateEllipticRgnIndirect( __in CONST RECT *lprect);
__gdi_entry DECLSPEC_IMPORT HFONT WINAPI CreateFontIndirectA( __in CONST LOGFONTA *lplf);
__gdi_entry DECLSPEC_IMPORT HFONT WINAPI CreateFontIndirectW( __in CONST LOGFONTW *lplf);



#define CreateFontIndirect CreateFontIndirectA

DECLSPEC_IMPORT HFONT WINAPI CreateFontA( __in int cHeight, __in int cWidth, __in int cEscapement, __in int cOrientation, __in int cWeight, __in DWORD bItalic,
                             __in DWORD bUnderline, __in DWORD bStrikeOut, __in DWORD iCharSet, __in DWORD iOutPrecision, __in DWORD iClipPrecision,
                             __in DWORD iQuality, __in DWORD iPitchAndFamily, __in_opt LPCSTR pszFaceName);
DECLSPEC_IMPORT HFONT WINAPI CreateFontW( __in int cHeight, __in int cWidth, __in int cEscapement, __in int cOrientation, __in int cWeight, __in DWORD bItalic,
                             __in DWORD bUnderline, __in DWORD bStrikeOut, __in DWORD iCharSet, __in DWORD iOutPrecision, __in DWORD iClipPrecision,
                             __in DWORD iQuality, __in DWORD iPitchAndFamily, __in_opt LPCWSTR pszFaceName);



#define CreateFont CreateFontA


DECLSPEC_IMPORT HBRUSH WINAPI CreateHatchBrush( __in int iHatch, __in COLORREF color);
DECLSPEC_IMPORT HDC WINAPI CreateICA( __in_opt LPCSTR pszDriver, __in_opt LPCSTR pszDevice, __in_opt LPCSTR pszPort, __in_opt CONST DEVMODEA * pdm);
DECLSPEC_IMPORT HDC WINAPI CreateICW( __in_opt LPCWSTR pszDriver, __in_opt LPCWSTR pszDevice, __in_opt LPCWSTR pszPort, __in_opt CONST DEVMODEW * pdm);



#define CreateIC CreateICA

DECLSPEC_IMPORT HDC WINAPI CreateMetaFileA( __in_opt LPCSTR pszFile);
DECLSPEC_IMPORT HDC WINAPI CreateMetaFileW( __in_opt LPCWSTR pszFile);



#define CreateMetaFile CreateMetaFileA

__gdi_entry DECLSPEC_IMPORT HPALETTE WINAPI CreatePalette( __in_xcount(2*sizeof(WORD) + plpal->palNumEntries * sizeof(PALETTEENTRY)) CONST LOGPALETTE * plpal);
DECLSPEC_IMPORT HPEN WINAPI CreatePen( __in int iStyle, __in int cWidth, __in COLORREF color);
__gdi_entry DECLSPEC_IMPORT HPEN WINAPI CreatePenIndirect( __in CONST LOGPEN *plpen);
DECLSPEC_IMPORT HRGN WINAPI CreatePolyPolygonRgn( __in CONST POINT *pptl,
                                                __in CONST INT *pc,
                                                __in int cPoly,
                                                __in int iMode);
__gdi_entry DECLSPEC_IMPORT HBRUSH WINAPI CreatePatternBrush( __in HBITMAP hbm);
DECLSPEC_IMPORT HRGN WINAPI CreateRectRgn( __in int x1, __in int y1, __in int x2, __in int y2);
DECLSPEC_IMPORT HRGN WINAPI CreateRectRgnIndirect( __in CONST RECT *lprect);
DECLSPEC_IMPORT HRGN WINAPI CreateRoundRectRgn( __in int x1, __in int y1, __in int x2, __in int y2, __in int w, __in int h);
DECLSPEC_IMPORT BOOL WINAPI CreateScalableFontResourceA( __in DWORD fdwHidden, __in LPCSTR lpszFont, __in LPCSTR lpszFile, __in_opt LPCSTR lpszPath);
DECLSPEC_IMPORT BOOL WINAPI CreateScalableFontResourceW( __in DWORD fdwHidden, __in LPCWSTR lpszFont, __in LPCWSTR lpszFile, __in_opt LPCWSTR lpszPath);



#define CreateScalableFontResource CreateScalableFontResourceA

DECLSPEC_IMPORT HBRUSH WINAPI CreateSolidBrush( __in COLORREF color);

DECLSPEC_IMPORT BOOL WINAPI DeleteDC( __in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI DeleteMetaFile( __in HMETAFILE hmf);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI DeleteObject( __in HGDIOBJ ho);
DECLSPEC_IMPORT int WINAPI DescribePixelFormat( __in HDC hdc,
                                            __in int iPixelFormat,
                                            __in UINT nBytes,
                                            __out_bcount_opt(nBytes) LPPIXELFORMATDESCRIPTOR ppfd);

/* define types of pointers to ExtDeviceMode() and DeviceCapabilities()

 * functions for Win 3.1 compatibility

 */
# 3333 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
typedef UINT (CALLBACK* LPFNDEVMODE)(HWND, HMODULE, LPDEVMODE, LPSTR, LPSTR, LPDEVMODE, LPSTR, UINT);

typedef DWORD (CALLBACK* LPFNDEVCAPS)(LPSTR, LPSTR, UINT, LPSTR, LPDEVMODE);

/* mode selections for the device mode function */
#define DM_UPDATE 1
#define DM_COPY 2
#define DM_PROMPT 4
#define DM_MODIFY 8

#define DM_IN_BUFFER DM_MODIFY
#define DM_IN_PROMPT DM_PROMPT
#define DM_OUT_BUFFER DM_COPY
#define DM_OUT_DEFAULT DM_UPDATE

/* device capabilities indices */
#define DC_FIELDS 1
#define DC_PAPERS 2
#define DC_PAPERSIZE 3
#define DC_MINEXTENT 4
#define DC_MAXEXTENT 5
#define DC_BINS 6
#define DC_DUPLEX 7
#define DC_SIZE 8
#define DC_EXTRA 9
#define DC_VERSION 10
#define DC_DRIVER 11
#define DC_BINNAMES 12
#define DC_ENUMRESOLUTIONS 13
#define DC_FILEDEPENDENCIES 14
#define DC_TRUETYPE 15
#define DC_PAPERNAMES 16
#define DC_ORIENTATION 17
#define DC_COPIES 18

#define DC_BINADJUST 19
#define DC_EMF_COMPLIANT 20
#define DC_DATATYPE_PRODUCED 21
#define DC_COLLATE 22
#define DC_MANUFACTURER 23
#define DC_MODEL 24



#define DC_PERSONALITY 25
#define DC_PRINTRATE 26
#define DC_PRINTRATEUNIT 27
#define PRINTRATEUNIT_PPM 1
#define PRINTRATEUNIT_CPS 2
#define PRINTRATEUNIT_LPM 3
#define PRINTRATEUNIT_IPM 4
#define DC_PRINTERMEM 28
#define DC_MEDIAREADY 29
#define DC_STAPLE 30
#define DC_PRINTRATEPPM 31
#define DC_COLORDEVICE 32
#define DC_NUP 33

#define DC_MEDIATYPENAMES 34
#define DC_MEDIATYPES 35



/* bit fields of the return value (DWORD) for DC_TRUETYPE */
#define DCTT_BITMAP 0x0000001L
#define DCTT_DOWNLOAD 0x0000002L
#define DCTT_SUBDEV 0x0000004L

#define DCTT_DOWNLOAD_OUTLINE 0x0000008L

/* return values for DC_BINADJUST */
#define DCBA_FACEUPNONE 0x0000
#define DCBA_FACEUPCENTER 0x0001
#define DCBA_FACEUPLEFT 0x0002
#define DCBA_FACEUPRIGHT 0x0003
#define DCBA_FACEDOWNNONE 0x0100
#define DCBA_FACEDOWNCENTER 0x0101
#define DCBA_FACEDOWNLEFT 0x0102
#define DCBA_FACEDOWNRIGHT 0x0103


DECLSPEC_IMPORT
int
WINAPI
DeviceCapabilitiesA(
    __in LPCSTR pDevice,
    __in_opt LPCSTR pPort,
    __in WORD fwCapability,
    __out_xcount_opt(1) LPSTR pOutput,
    __in_opt CONST DEVMODEA *pDevMode
    );
DECLSPEC_IMPORT
int
WINAPI
DeviceCapabilitiesW(
    __in LPCWSTR pDevice,
    __in_opt LPCWSTR pPort,
    __in WORD fwCapability,
    __out_xcount_opt(1) LPWSTR pOutput,
    __in_opt CONST DEVMODEW *pDevMode
    );



#define DeviceCapabilities DeviceCapabilitiesA


DECLSPEC_IMPORT int WINAPI DrawEscape( __in HDC hdc,
                                    __in int iEscape,
                                    __in int cjIn,
                                    __in_bcount_opt(cjIn) LPCSTR lpIn);

__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Ellipse( __in HDC hdc, __in int left, __in int top, __in int right, __in int bottom);


DECLSPEC_IMPORT int WINAPI EnumFontFamiliesExA( __in HDC hdc, __in LPLOGFONTA lpLogfont, __in FONTENUMPROCA lpProc, __in LPARAM lParam, __in DWORD dwFlags);
DECLSPEC_IMPORT int WINAPI EnumFontFamiliesExW( __in HDC hdc, __in LPLOGFONTW lpLogfont, __in FONTENUMPROCW lpProc, __in LPARAM lParam, __in DWORD dwFlags);



#define EnumFontFamiliesEx EnumFontFamiliesExA



DECLSPEC_IMPORT int WINAPI EnumFontFamiliesA( __in HDC hdc, __in_opt LPCSTR lpLogfont, __in FONTENUMPROCA lpProc, __in LPARAM lParam);
DECLSPEC_IMPORT int WINAPI EnumFontFamiliesW( __in HDC hdc, __in_opt LPCWSTR lpLogfont, __in FONTENUMPROCW lpProc, __in LPARAM lParam);



#define EnumFontFamilies EnumFontFamiliesA

DECLSPEC_IMPORT int WINAPI EnumFontsA( __in HDC hdc, __in_opt LPCSTR lpLogfont, __in FONTENUMPROCA lpProc, __in LPARAM lParam);
DECLSPEC_IMPORT int WINAPI EnumFontsW( __in HDC hdc, __in_opt LPCWSTR lpLogfont, __in FONTENUMPROCW lpProc, __in LPARAM lParam);



#define EnumFonts EnumFontsA





DECLSPEC_IMPORT int WINAPI EnumObjects( __in HDC hdc, __in int nType, __in GOBJENUMPROC lpFunc, __in LPVOID lParam);



DECLSPEC_IMPORT BOOL WINAPI EqualRgn( __in HRGN hrgn1, __in HRGN hrgn2);
__gdi_entry DECLSPEC_IMPORT int WINAPI Escape( __in HDC hdc,
                                __in int iEscape,
                                __in int cjIn,
                                __in_bcount_opt(cjIn) LPCSTR pvIn,
                                __out_opt LPVOID pvOut);
DECLSPEC_IMPORT int WINAPI ExtEscape( __in HDC hdc,
                                    __in int iEscape,
                                    __in int cjInput,
                                    __in_bcount_opt(cjInput) LPCSTR lpInData,
                                    __in int cjOutput,
                                    __out_bcount_opt(cjOutput) LPSTR lpOutData);
__gdi_entry DECLSPEC_IMPORT int WINAPI ExcludeClipRect( __in HDC hdc, __in int left, __in int top, __in int right, __in int bottom);
__gdi_entry DECLSPEC_IMPORT HRGN WINAPI ExtCreateRegion( __in_opt CONST XFORM * lpx, __in DWORD nCount, __in_bcount(nCount) CONST RGNDATA * lpData);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI ExtFloodFill( __in HDC hdc, __in int x, __in int y, __in COLORREF color, __in UINT type);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI FillRgn( __in HDC hdc, __in HRGN hrgn, __in HBRUSH hbr);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI FloodFill( __in HDC hdc, __in int x, __in int y, __in COLORREF color);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI FrameRgn( __in HDC hdc, __in HRGN hrgn, __in HBRUSH hbr, __in int w, __in int h);
DECLSPEC_IMPORT int WINAPI GetROP2( __in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI GetAspectRatioFilterEx( __in HDC hdc, __out LPSIZE lpsize);
DECLSPEC_IMPORT COLORREF WINAPI GetBkColor( __in HDC hdc);


DECLSPEC_IMPORT COLORREF WINAPI GetDCBrushColor( __in HDC hdc);
DECLSPEC_IMPORT COLORREF WINAPI GetDCPenColor( __in HDC hdc);


DECLSPEC_IMPORT
int
WINAPI
GetBkMode(
    __in HDC hdc
    );

DECLSPEC_IMPORT
LONG
WINAPI
GetBitmapBits(
    __in HBITMAP hbit,
    __in LONG cb,
    __out_bcount(cb) LPVOID lpvBits
    );

DECLSPEC_IMPORT BOOL WINAPI GetBitmapDimensionEx( __in HBITMAP hbit, __out LPSIZE lpsize);
DECLSPEC_IMPORT UINT WINAPI GetBoundsRect( __in HDC hdc, __out LPRECT lprect, __in UINT flags);

DECLSPEC_IMPORT BOOL WINAPI GetBrushOrgEx( __in HDC hdc, __out LPPOINT lppt);

DECLSPEC_IMPORT BOOL WINAPI GetCharWidthA( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) LPINT lpBuffer);
DECLSPEC_IMPORT BOOL WINAPI GetCharWidthW( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) LPINT lpBuffer);



#define GetCharWidth GetCharWidthA

DECLSPEC_IMPORT BOOL WINAPI GetCharWidth32A( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) LPINT lpBuffer);
DECLSPEC_IMPORT BOOL WINAPI GetCharWidth32W( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) LPINT lpBuffer);



#define GetCharWidth32 GetCharWidth32A

DECLSPEC_IMPORT BOOL APIENTRY GetCharWidthFloatA( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) PFLOAT lpBuffer);
DECLSPEC_IMPORT BOOL APIENTRY GetCharWidthFloatW( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) PFLOAT lpBuffer);



#define GetCharWidthFloat GetCharWidthFloatA


DECLSPEC_IMPORT BOOL APIENTRY GetCharABCWidthsA( __in HDC hdc,
                                            __in UINT wFirst,
                                            __in UINT wLast,
                                            __out_ecount(wLast - wFirst + 1) LPABC lpABC);
DECLSPEC_IMPORT BOOL APIENTRY GetCharABCWidthsW( __in HDC hdc,
                                            __in UINT wFirst,
                                            __in UINT wLast,
                                            __out_ecount(wLast - wFirst + 1) LPABC lpABC);



#define GetCharABCWidths GetCharABCWidthsA


DECLSPEC_IMPORT BOOL APIENTRY GetCharABCWidthsFloatA( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) LPABCFLOAT lpABC);
DECLSPEC_IMPORT BOOL APIENTRY GetCharABCWidthsFloatW( __in HDC hdc, __in UINT iFirst, __in UINT iLast, __out_ecount(iLast + 1 - iFirst) LPABCFLOAT lpABC);



#define GetCharABCWidthsFloat GetCharABCWidthsFloatA

DECLSPEC_IMPORT int WINAPI GetClipBox( __in HDC hdc, __out LPRECT lprect);
DECLSPEC_IMPORT int WINAPI GetClipRgn( __in HDC hdc, __in HRGN hrgn);
DECLSPEC_IMPORT int WINAPI GetMetaRgn( __in HDC hdc, __in HRGN hrgn);
DECLSPEC_IMPORT HGDIOBJ WINAPI GetCurrentObject( __in HDC hdc, __in UINT type);
DECLSPEC_IMPORT BOOL WINAPI GetCurrentPositionEx( __in HDC hdc, __out LPPOINT lppt);
DECLSPEC_IMPORT int WINAPI GetDeviceCaps( __in_opt HDC hdc, __in int index);
DECLSPEC_IMPORT int WINAPI GetDIBits( __in HDC hdc, __in HBITMAP hbm, __in UINT start, __in UINT cLines, __out_opt LPVOID lpvBits, __inout_xcount(sizeof(BITMAPINFOHEADER)) LPBITMAPINFO lpbmi, __in UINT usage); // SAL actual size of lpbmi is computed from structure elements

__success(return != (0xFFFFFFFFL))
DECLSPEC_IMPORT DWORD WINAPI GetFontData ( __in HDC hdc,
                                        __in DWORD dwTable,
                                        __in DWORD dwOffset,
                                        __out_bcount_part_opt(cjBuffer, return) PVOID pvBuffer,
                                        __in DWORD cjBuffer
                                        );

DECLSPEC_IMPORT DWORD WINAPI GetGlyphOutlineA( __in HDC hdc,
                                            __in UINT uChar,
                                            __in UINT fuFormat,
                                            __out LPGLYPHMETRICS lpgm,
                                            __in DWORD cjBuffer,
                                            __out_bcount_opt(cjBuffer) LPVOID pvBuffer,
                                            __in CONST MAT2 *lpmat2
                                        );
DECLSPEC_IMPORT DWORD WINAPI GetGlyphOutlineW( __in HDC hdc,
                                            __in UINT uChar,
                                            __in UINT fuFormat,
                                            __out LPGLYPHMETRICS lpgm,
                                            __in DWORD cjBuffer,
                                            __out_bcount_opt(cjBuffer) LPVOID pvBuffer,
                                            __in CONST MAT2 *lpmat2
                                        );



#define GetGlyphOutline GetGlyphOutlineA


DECLSPEC_IMPORT int WINAPI GetGraphicsMode( __in HDC hdc);
DECLSPEC_IMPORT int WINAPI GetMapMode( __in HDC hdc);
DECLSPEC_IMPORT UINT WINAPI GetMetaFileBitsEx(__in HMETAFILE hMF, __in UINT cbBuffer, __out_bcount_opt(cbBuffer) LPVOID lpData);
DECLSPEC_IMPORT HMETAFILE WINAPI GetMetaFileA( __in LPCSTR lpName);
DECLSPEC_IMPORT HMETAFILE WINAPI GetMetaFileW( __in LPCWSTR lpName);



#define GetMetaFile GetMetaFileA

DECLSPEC_IMPORT COLORREF WINAPI GetNearestColor( __in HDC hdc, __in COLORREF color);
DECLSPEC_IMPORT UINT WINAPI GetNearestPaletteIndex( __in HPALETTE h, __in COLORREF color);
DECLSPEC_IMPORT DWORD WINAPI GetObjectType( __in HGDIOBJ h);



DECLSPEC_IMPORT UINT APIENTRY GetOutlineTextMetricsA( __in HDC hdc,
                                                __in UINT cjCopy,
                                                __out_bcount_opt(cjCopy) LPOUTLINETEXTMETRICA potm);
DECLSPEC_IMPORT UINT APIENTRY GetOutlineTextMetricsW( __in HDC hdc,
                                                __in UINT cjCopy,
                                                __out_bcount_opt(cjCopy) LPOUTLINETEXTMETRICW potm);



#define GetOutlineTextMetrics GetOutlineTextMetricsA




__range(0,cEntries)
DECLSPEC_IMPORT UINT WINAPI GetPaletteEntries( __in HPALETTE hpal,
                                            __in UINT iStart,
                                            __in UINT cEntries,
                                            __out_ecount_part_opt(cEntries,return) LPPALETTEENTRY pPalEntries);
DECLSPEC_IMPORT COLORREF WINAPI GetPixel( __in HDC hdc, __in int x, __in int y);
DECLSPEC_IMPORT int WINAPI GetPixelFormat( __in HDC hdc);
DECLSPEC_IMPORT int WINAPI GetPolyFillMode( __in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI GetRasterizerCaps( __out_bcount(cjBytes) LPRASTERIZER_STATUS lpraststat,
                                            __in UINT cjBytes);

DECLSPEC_IMPORT int WINAPI GetRandomRgn (__in HDC hdc, __in HRGN hrgn, __in INT i);
DECLSPEC_IMPORT DWORD WINAPI GetRegionData( __in HRGN hrgn,
                                        __in DWORD nCount,
                                        __out_bcount_part_opt(nCount, return) LPRGNDATA lpRgnData);
DECLSPEC_IMPORT int WINAPI GetRgnBox( __in HRGN hrgn, __out LPRECT lprc);
DECLSPEC_IMPORT HGDIOBJ WINAPI GetStockObject( __in int i);
DECLSPEC_IMPORT int WINAPI GetStretchBltMode(__in HDC hdc);
DECLSPEC_IMPORT
UINT
WINAPI
GetSystemPaletteEntries(
    __in HDC hdc,
    __in UINT iStart,
    __in UINT cEntries,
    __out_ecount_opt(cEntries) LPPALETTEENTRY pPalEntries
    );

DECLSPEC_IMPORT UINT WINAPI GetSystemPaletteUse(__in HDC hdc);
DECLSPEC_IMPORT int WINAPI GetTextCharacterExtra(__in HDC hdc);
DECLSPEC_IMPORT UINT WINAPI GetTextAlign(__in HDC hdc);
DECLSPEC_IMPORT COLORREF WINAPI GetTextColor(__in HDC hdc);

DECLSPEC_IMPORT
BOOL
APIENTRY
GetTextExtentPointA(
    __in HDC hdc,
    __in_ecount(c) LPCSTR lpString,
    __in int c,
    __out LPSIZE lpsz
    );
DECLSPEC_IMPORT
BOOL
APIENTRY
GetTextExtentPointW(
    __in HDC hdc,
    __in_ecount(c) LPCWSTR lpString,
    __in int c,
    __out LPSIZE lpsz
    );



#define GetTextExtentPoint GetTextExtentPointA


DECLSPEC_IMPORT
BOOL
APIENTRY
GetTextExtentPoint32A(
    __in HDC hdc,
    __in_ecount(c) LPCSTR lpString,
    __in int c,
    __out LPSIZE psizl
    );
DECLSPEC_IMPORT
BOOL
APIENTRY
GetTextExtentPoint32W(
    __in HDC hdc,
    __in_ecount(c) LPCWSTR lpString,
    __in int c,
    __out LPSIZE psizl
    );



#define GetTextExtentPoint32 GetTextExtentPoint32A


DECLSPEC_IMPORT
BOOL
APIENTRY
GetTextExtentExPointA(
    __in HDC hdc,
    __in_ecount(cchString) LPCSTR lpszString,
    __in int cchString,
    __in int nMaxExtent,
    __out_opt LPINT lpnFit,
    __out_ecount_part_opt (cchString, *lpnFit) LPINT lpnDx,
    __out LPSIZE lpSize
    );
DECLSPEC_IMPORT
BOOL
APIENTRY
GetTextExtentExPointW(
    __in HDC hdc,
    __in_ecount(cchString) LPCWSTR lpszString,
    __in int cchString,
    __in int nMaxExtent,
    __out_opt LPINT lpnFit,
    __out_ecount_part_opt (cchString, *lpnFit) LPINT lpnDx,
    __out LPSIZE lpSize
    );



#define GetTextExtentExPoint GetTextExtentExPointA



DECLSPEC_IMPORT int WINAPI GetTextCharset( __in HDC hdc);
DECLSPEC_IMPORT int WINAPI GetTextCharsetInfo( __in HDC hdc, __out_opt LPFONTSIGNATURE lpSig, __in DWORD dwFlags);
DECLSPEC_IMPORT BOOL WINAPI TranslateCharsetInfo( __inout DWORD FAR *lpSrc, __out LPCHARSETINFO lpCs, __in DWORD dwFlags);
DECLSPEC_IMPORT DWORD WINAPI GetFontLanguageInfo( __in HDC hdc);
DECLSPEC_IMPORT DWORD WINAPI GetCharacterPlacementA( __in HDC hdc, __in_ecount(nCount) LPCSTR lpString, __in int nCount, __in int nMexExtent, __inout LPGCP_RESULTSA lpResults, __in DWORD dwFlags);
DECLSPEC_IMPORT DWORD WINAPI GetCharacterPlacementW( __in HDC hdc, __in_ecount(nCount) LPCWSTR lpString, __in int nCount, __in int nMexExtent, __inout LPGCP_RESULTSW lpResults, __in DWORD dwFlags);



#define GetCharacterPlacement GetCharacterPlacementA





typedef struct tagWCRANGE
{
    WCHAR wcLow;
    USHORT cGlyphs;
} WCRANGE, *PWCRANGE,FAR *LPWCRANGE;


typedef struct tagGLYPHSET
{
    DWORD cbThis;
    DWORD flAccel;
    DWORD cGlyphsSupported;
    DWORD cRanges;
    WCRANGE ranges[1];
} GLYPHSET, *PGLYPHSET, FAR *LPGLYPHSET;

/* flAccel flags for the GLYPHSET structure above */

#define GS_8BIT_INDICES 0x00000001

/* flags for GetGlyphIndices */

#define GGI_MARK_NONEXISTING_GLYPHS 0X0001

DECLSPEC_IMPORT DWORD WINAPI GetFontUnicodeRanges( __in HDC hdc, __out_opt LPGLYPHSET lpgs);
DECLSPEC_IMPORT DWORD WINAPI GetGlyphIndicesA( __in HDC hdc, __in_ecount(c) LPCSTR lpstr, __in int c, __out_ecount(c) LPWORD pgi, __in DWORD fl);
DECLSPEC_IMPORT DWORD WINAPI GetGlyphIndicesW( __in HDC hdc, __in_ecount(c) LPCWSTR lpstr, __in int c, __out_ecount(c) LPWORD pgi, __in DWORD fl);



#define GetGlyphIndices GetGlyphIndicesA

DECLSPEC_IMPORT BOOL WINAPI GetTextExtentPointI(__in HDC hdc, __in_ecount(cgi) LPWORD pgiIn, __in int cgi, __out LPSIZE psize);
DECLSPEC_IMPORT BOOL WINAPI GetTextExtentExPointI ( __in HDC hdc,
                                                __in_ecount(cwchString) LPWORD lpwszString,
                                                __in int cwchString,
                                                __in int nMaxExtent,
                                                __out_opt LPINT lpnFit,
                                                __out_ecount_part_opt(cwchString, *lpnFit) LPINT lpnDx,
                                                __out LPSIZE lpSize
                                                );

DECLSPEC_IMPORT BOOL WINAPI GetCharWidthI( __in HDC hdc,
                                        __in UINT giFirst,
                                        __in UINT cgi,
                                        __in_ecount_opt(cgi) LPWORD pgi,
                                        __out_ecount(cgi) LPINT piWidths
                                        );

DECLSPEC_IMPORT BOOL WINAPI GetCharABCWidthsI( __in HDC hdc,
                                            __in UINT giFirst,
                                            __in UINT cgi,
                                            __in_ecount_opt(cgi) LPWORD pgi,
                                            __out_ecount(cgi) LPABC pabc
                                        );


#define STAMP_DESIGNVECTOR (0x8000000 + 'd' + ('v' << 8))
#define STAMP_AXESLIST (0x8000000 + 'a' + ('l' << 8))
#define MM_MAX_NUMAXES 16



typedef struct tagDESIGNVECTOR
{
    DWORD dvReserved;
    DWORD dvNumAxes;
    LONG dvValues[16];
} DESIGNVECTOR, *PDESIGNVECTOR, FAR *LPDESIGNVECTOR;

DECLSPEC_IMPORT int WINAPI AddFontResourceExA( __in LPCSTR name, __in DWORD fl, __reserved PVOID res);
DECLSPEC_IMPORT int WINAPI AddFontResourceExW( __in LPCWSTR name, __in DWORD fl, __reserved PVOID res);



#define AddFontResourceEx AddFontResourceExA

DECLSPEC_IMPORT BOOL WINAPI RemoveFontResourceExA( __in LPCSTR name, __in DWORD fl, __reserved PVOID pdv);
DECLSPEC_IMPORT BOOL WINAPI RemoveFontResourceExW( __in LPCWSTR name, __in DWORD fl, __reserved PVOID pdv);



#define RemoveFontResourceEx RemoveFontResourceExA

DECLSPEC_IMPORT HANDLE WINAPI AddFontMemResourceEx( __in_bcount(cjSize) PVOID pFileView,
                                                __in DWORD cjSize,
                                                __reserved PVOID pvResrved,
                                                __in DWORD* pNumFonts);

DECLSPEC_IMPORT BOOL WINAPI RemoveFontMemResourceEx( __in HANDLE h);
#define FR_PRIVATE 0x10
#define FR_NOT_ENUM 0x20

// The actual size of the DESIGNVECTOR and ENUMLOGFONTEXDV structures
// is determined by dvNumAxes,
// MM_MAX_NUMAXES only detemines the maximal size allowed

#define MM_MAX_AXES_NAMELEN 16

typedef struct tagAXISINFOA
{
    LONG axMinValue;
    LONG axMaxValue;
    BYTE axAxisName[16];
} AXISINFOA, *PAXISINFOA, FAR *LPAXISINFOA;
typedef struct tagAXISINFOW
{
    LONG axMinValue;
    LONG axMaxValue;
    WCHAR axAxisName[16];
} AXISINFOW, *PAXISINFOW, FAR *LPAXISINFOW;





typedef AXISINFOA AXISINFO;
typedef PAXISINFOA PAXISINFO;
typedef LPAXISINFOA LPAXISINFO;


typedef struct tagAXESLISTA
{
    DWORD axlReserved;
    DWORD axlNumAxes;
    AXISINFOA axlAxisInfo[16];
} AXESLISTA, *PAXESLISTA, FAR *LPAXESLISTA;
typedef struct tagAXESLISTW
{
    DWORD axlReserved;
    DWORD axlNumAxes;
    AXISINFOW axlAxisInfo[16];
} AXESLISTW, *PAXESLISTW, FAR *LPAXESLISTW;





typedef AXESLISTA AXESLIST;
typedef PAXESLISTA PAXESLIST;
typedef LPAXESLISTA LPAXESLIST;


// The actual size of the AXESLIST and ENUMTEXTMETRIC structure is
// determined by axlNumAxes,
// MM_MAX_NUMAXES only detemines the maximal size allowed

typedef struct tagENUMLOGFONTEXDVA
{
    ENUMLOGFONTEXA elfEnumLogfontEx;
    DESIGNVECTOR elfDesignVector;
} ENUMLOGFONTEXDVA, *PENUMLOGFONTEXDVA, FAR *LPENUMLOGFONTEXDVA;
typedef struct tagENUMLOGFONTEXDVW
{
    ENUMLOGFONTEXW elfEnumLogfontEx;
    DESIGNVECTOR elfDesignVector;
} ENUMLOGFONTEXDVW, *PENUMLOGFONTEXDVW, FAR *LPENUMLOGFONTEXDVW;





typedef ENUMLOGFONTEXDVA ENUMLOGFONTEXDV;
typedef PENUMLOGFONTEXDVA PENUMLOGFONTEXDV;
typedef LPENUMLOGFONTEXDVA LPENUMLOGFONTEXDV;


DECLSPEC_IMPORT HFONT WINAPI CreateFontIndirectExA( __in CONST ENUMLOGFONTEXDVA *);
DECLSPEC_IMPORT HFONT WINAPI CreateFontIndirectExW( __in CONST ENUMLOGFONTEXDVW *);



#define CreateFontIndirectEx CreateFontIndirectExA



typedef struct tagENUMTEXTMETRICA
{
    NEWTEXTMETRICEXA etmNewTextMetricEx;
    AXESLISTA etmAxesList;
} ENUMTEXTMETRICA, *PENUMTEXTMETRICA, FAR *LPENUMTEXTMETRICA;
typedef struct tagENUMTEXTMETRICW
{
    NEWTEXTMETRICEXW etmNewTextMetricEx;
    AXESLISTW etmAxesList;
} ENUMTEXTMETRICW, *PENUMTEXTMETRICW, FAR *LPENUMTEXTMETRICW;





typedef ENUMTEXTMETRICA ENUMTEXTMETRIC;
typedef PENUMTEXTMETRICA PENUMTEXTMETRIC;
typedef LPENUMTEXTMETRICA LPENUMTEXTMETRIC;





DECLSPEC_IMPORT BOOL WINAPI GetViewportExtEx( __in HDC hdc, __out LPSIZE lpsize);
DECLSPEC_IMPORT BOOL WINAPI GetViewportOrgEx( __in HDC hdc, __out LPPOINT lppoint);
DECLSPEC_IMPORT BOOL WINAPI GetWindowExtEx( __in HDC hdc, __out LPSIZE lpsize);
DECLSPEC_IMPORT BOOL WINAPI GetWindowOrgEx( __in HDC hdc, __out LPPOINT lppoint);

__gdi_entry DECLSPEC_IMPORT int WINAPI IntersectClipRect( __in HDC hdc, __in int left, __in int top, __in int right, __in int bottom);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI InvertRgn( __in HDC hdc, __in HRGN hrgn);
DECLSPEC_IMPORT BOOL WINAPI LineDDA( __in int xStart, __in int yStart, __in int xEnd, __in int yEnd, __in LINEDDAPROC lpProc, __in_opt LPARAM data);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI LineTo( __in HDC hdc, __in int x, __in int y);
DECLSPEC_IMPORT BOOL WINAPI MaskBlt( __in HDC hdcDest, __in int xDest, __in int yDest, __in int width, __in int height,
              __in HDC hdcSrc, __in int xSrc, __in int ySrc, __in HBITMAP hbmMask, __in int xMask, __in int yMask, __in DWORD rop);
DECLSPEC_IMPORT BOOL WINAPI PlgBlt( __in HDC hdcDest, __in_ecount(3) CONST POINT * lpPoint, __in HDC hdcSrc, __in int xSrc, __in int ySrc, __in int width,
                     __in int height, __in_opt HBITMAP hbmMask, __in int xMask, __in int yMask);

__gdi_entry DECLSPEC_IMPORT int WINAPI OffsetClipRgn(__in HDC hdc, __in int x, __in int y);
DECLSPEC_IMPORT int WINAPI OffsetRgn(__in HRGN hrgn, __in int x, __in int y);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI PatBlt(__in HDC hdc, __in int x, __in int y, __in int w, __in int h, __in DWORD rop);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Pie(__in HDC hdc, __in int left, __in int top, __in int right, __in int bottom, __in int xr1, __in int yr1, __in int xr2, __in int yr2);
DECLSPEC_IMPORT BOOL WINAPI PlayMetaFile(__in HDC hdc, __in HMETAFILE hmf);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI PaintRgn(__in HDC hdc, __in HRGN hrgn);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI PolyPolygon(__in HDC hdc, __in CONST POINT *apt, __in_ecount(csz) CONST INT *asz, __in int csz);
DECLSPEC_IMPORT BOOL WINAPI PtInRegion(__in HRGN hrgn, __in int x, __in int y);
DECLSPEC_IMPORT BOOL WINAPI PtVisible(__in HDC hdc, __in int x, __in int y);
DECLSPEC_IMPORT BOOL WINAPI RectInRegion(__in HRGN hrgn, __in CONST RECT * lprect);
DECLSPEC_IMPORT BOOL WINAPI RectVisible(__in HDC hdc, __in CONST RECT * lprect);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Rectangle(__in HDC hdc, __in int left, __in int top, __in int right, __in int bottom);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI RestoreDC(__in HDC hdc, __in int nSavedDC);
__gdi_entry DECLSPEC_IMPORT HDC WINAPI ResetDCA(__in HDC hdc, __in CONST DEVMODEA * lpdm);
__gdi_entry DECLSPEC_IMPORT HDC WINAPI ResetDCW(__in HDC hdc, __in CONST DEVMODEW * lpdm);



#define ResetDC ResetDCA

__gdi_entry DECLSPEC_IMPORT UINT WINAPI RealizePalette(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI RemoveFontResourceA(__in LPCSTR lpFileName);
DECLSPEC_IMPORT BOOL WINAPI RemoveFontResourceW(__in LPCWSTR lpFileName);



#define RemoveFontResource RemoveFontResourceA

__gdi_entry DECLSPEC_IMPORT BOOL WINAPI RoundRect(__in HDC hdc, __in int left, __in int top, __in int right, __in int bottom, __in int width, __in int height);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI ResizePalette(__in HPALETTE hpal, __in UINT n);

__gdi_entry DECLSPEC_IMPORT int WINAPI SaveDC(__in HDC hdc);
__gdi_entry DECLSPEC_IMPORT int WINAPI SelectClipRgn(__in HDC hdc, __in_opt HRGN hrgn);
DECLSPEC_IMPORT int WINAPI ExtSelectClipRgn(__in HDC hdc, __in_opt HRGN hrgn, __in int mode);
DECLSPEC_IMPORT int WINAPI SetMetaRgn(__in HDC hdc);
__gdi_entry DECLSPEC_IMPORT HGDIOBJ WINAPI SelectObject(__in HDC hdc, __in HGDIOBJ h);
__gdi_entry DECLSPEC_IMPORT HPALETTE WINAPI SelectPalette(__in HDC hdc, __in HPALETTE hPal, __in BOOL bForceBkgd);
__gdi_entry DECLSPEC_IMPORT COLORREF WINAPI SetBkColor(__in HDC hdc, __in COLORREF color);


DECLSPEC_IMPORT COLORREF WINAPI SetDCBrushColor(__in HDC hdc, __in COLORREF color);
DECLSPEC_IMPORT COLORREF WINAPI SetDCPenColor(__in HDC hdc, __in COLORREF color);


__gdi_entry DECLSPEC_IMPORT int WINAPI SetBkMode(__in HDC hdc, __in int mode);

DECLSPEC_IMPORT
LONG WINAPI
SetBitmapBits(
    __in HBITMAP hbm,
    __in DWORD cb,
    __in_bcount(cb) CONST VOID *pvBits);

DECLSPEC_IMPORT UINT WINAPI SetBoundsRect(__in HDC hdc, __in_opt CONST RECT * lprect, __in UINT flags);
DECLSPEC_IMPORT int WINAPI SetDIBits(__in_opt HDC hdc, __in HBITMAP hbm, __in UINT start, __in UINT cLines, __in CONST VOID *lpBits, __in CONST BITMAPINFO * lpbmi, __in UINT ColorUse);
__gdi_entry DECLSPEC_IMPORT int WINAPI SetDIBitsToDevice(__in HDC hdc, __in int xDest, __in int yDest, __in DWORD w, __in DWORD h, __in int xSrc,
        __in int ySrc, __in UINT StartScan, __in UINT cLines, __in CONST VOID * lpvBits, __in CONST BITMAPINFO * lpbmi, __in UINT ColorUse);
__gdi_entry DECLSPEC_IMPORT DWORD WINAPI SetMapperFlags(__in HDC hdc, __in DWORD flags);
DECLSPEC_IMPORT int WINAPI SetGraphicsMode(__in HDC hdc, __in int iMode);
__gdi_entry DECLSPEC_IMPORT int WINAPI SetMapMode(__in HDC hdc, __in int iMode);


__gdi_entry DECLSPEC_IMPORT DWORD WINAPI SetLayout(__in HDC hdc, __in DWORD l);
DECLSPEC_IMPORT DWORD WINAPI GetLayout(__in HDC hdc);


DECLSPEC_IMPORT HMETAFILE WINAPI SetMetaFileBitsEx(__in UINT cbBuffer, __in_bcount(cbBuffer) CONST BYTE *lpData);
__gdi_entry DECLSPEC_IMPORT UINT WINAPI SetPaletteEntries( __in HPALETTE hpal,
                                            __in UINT iStart,
                                            __in UINT cEntries,
                                            __in_ecount(cEntries) CONST PALETTEENTRY *pPalEntries);
__gdi_entry DECLSPEC_IMPORT COLORREF WINAPI SetPixel(__in HDC hdc, __in int x, __in int y, __in COLORREF color);
DECLSPEC_IMPORT BOOL WINAPI SetPixelV(__in HDC hdc, __in int x, __in int y, __in COLORREF color);
DECLSPEC_IMPORT BOOL WINAPI SetPixelFormat(__in HDC hdc, __in int format, __in CONST PIXELFORMATDESCRIPTOR * ppfd);
__gdi_entry DECLSPEC_IMPORT int WINAPI SetPolyFillMode(__in HDC hdc, __in int mode);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI StretchBlt(__in HDC hdcDest, __in int xDest, __in int yDest, __in int wDest, __in int hDest, __in_opt HDC hdcSrc, __in int xSrc, __in int ySrc, __in int wSrc, __in int hSrc, __in DWORD rop);
DECLSPEC_IMPORT BOOL WINAPI SetRectRgn(__in HRGN hrgn, __in int left, __in int top, __in int right, __in int bottom);
__gdi_entry DECLSPEC_IMPORT int WINAPI StretchDIBits(__in HDC hdc, __in int xDest, __in int yDest, __in int DestWidth, __in int DestHeight, __in int xSrc, __in int ySrc, __in int SrcWidth, __in int SrcHeight,
        __in_opt CONST VOID * lpBits, __in CONST BITMAPINFO * lpbmi, __in UINT iUsage, __in DWORD rop);
__gdi_entry DECLSPEC_IMPORT int WINAPI SetROP2(__in HDC hdc, __in int rop2);
__gdi_entry DECLSPEC_IMPORT int WINAPI SetStretchBltMode(__in HDC hdc, __in int mode);
DECLSPEC_IMPORT UINT WINAPI SetSystemPaletteUse(__in HDC hdc, __in UINT use);
__gdi_entry DECLSPEC_IMPORT int WINAPI SetTextCharacterExtra(__in HDC hdc, __in int extra);
__gdi_entry DECLSPEC_IMPORT COLORREF WINAPI SetTextColor(__in HDC hdc, __in COLORREF color);
__gdi_entry DECLSPEC_IMPORT UINT WINAPI SetTextAlign(__in HDC hdc, __in UINT align);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI SetTextJustification(__in HDC hdc, __in int extra, __in int count);
DECLSPEC_IMPORT BOOL WINAPI UpdateColors(__in HDC hdc);
# 4098 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
//
// image blt
//

typedef USHORT COLOR16;

typedef struct _TRIVERTEX
{
    LONG x;
    LONG y;
    COLOR16 Red;
    COLOR16 Green;
    COLOR16 Blue;
    COLOR16 Alpha;
}TRIVERTEX,*PTRIVERTEX,*LPTRIVERTEX;

typedef struct _GRADIENT_TRIANGLE
{
    ULONG Vertex1;
    ULONG Vertex2;
    ULONG Vertex3;
} GRADIENT_TRIANGLE,*PGRADIENT_TRIANGLE,*LPGRADIENT_TRIANGLE;

typedef struct _GRADIENT_RECT
{
    ULONG UpperLeft;
    ULONG LowerRight;
}GRADIENT_RECT,*PGRADIENT_RECT,*LPGRADIENT_RECT;

typedef struct _BLENDFUNCTION
{
    BYTE BlendOp;
    BYTE BlendFlags;
    BYTE SourceConstantAlpha;
    BYTE AlphaFormat;
}BLENDFUNCTION,*PBLENDFUNCTION;


//
// currentlly defined blend function
//

#define AC_SRC_OVER 0x00

//
// alpha format flags
//

#define AC_SRC_ALPHA 0x01

DECLSPEC_IMPORT BOOL WINAPI AlphaBlend(
    __in HDC hdcDest,
    __in int xoriginDest,
    __in int yoriginDest,
    __in int wDest,
    __in int hDest,
    __in HDC hdcSrc,
    __in int xoriginSrc,
    __in int yoriginSrc,
    __in int wSrc,
    __in int hSrc,
    __in BLENDFUNCTION ftn);

DECLSPEC_IMPORT BOOL WINAPI TransparentBlt(
    __in HDC hdcDest,
    __in int xoriginDest,
    __in int yoriginDest,
    __in int wDest,
    __in int hDest,
    __in HDC hdcSrc,
    __in int xoriginSrc,
    __in int yoriginSrc,
    __in int wSrc,
    __in int hSrc,
    __in UINT crTransparent);


//
// gradient drawing modes
//

#define GRADIENT_FILL_RECT_H 0x00000000
#define GRADIENT_FILL_RECT_V 0x00000001
#define GRADIENT_FILL_TRIANGLE 0x00000002
#define GRADIENT_FILL_OP_FLAG 0x000000ff

DECLSPEC_IMPORT
BOOL
WINAPI
GradientFill(
    __in HDC hdc,
    __in_ecount(nVertex) PTRIVERTEX pVertex,
    __in ULONG nVertex,
    __in PVOID pMesh,
    __in ULONG nMesh,
    __in ULONG ulMode
    );






DECLSPEC_IMPORT BOOL WINAPI GdiAlphaBlend(__in HDC hdcDest, __in int xoriginDest, __in int yoriginDest, __in int wDest, __in int hDest, __in HDC hdcSrc, __in int xoriginSrc, __in int yoriginSrc, __in int wSrc, __in int hSrc, __in BLENDFUNCTION ftn);

DECLSPEC_IMPORT BOOL WINAPI GdiTransparentBlt(__in HDC hdcDest,__in int xoriginDest, __in int yoriginDest, __in int wDest, __in int hDest, __in HDC hdcSrc,
                                           __in int xoriginSrc, __in int yoriginSrc, __in int wSrc, __in int hSrc, __in UINT crTransparent);

DECLSPEC_IMPORT BOOL WINAPI GdiGradientFill( __in HDC hdc,
                                        __in_ecount(nVertex) PTRIVERTEX pVertex,
                                        __in ULONG nVertex,
                                        __in PVOID pMesh,
                                        __in ULONG nCount,
                                        __in ULONG ulMode);







DECLSPEC_IMPORT BOOL WINAPI PlayMetaFileRecord( __in HDC hdc,
                                            __in_ecount(noObjs) LPHANDLETABLE lpHandleTable,
                                            __in LPMETARECORD lpMR,
                                            __in UINT noObjs);

typedef int (CALLBACK* MFENUMPROC)( __in HDC hdc, __in_ecount(nObj) HANDLETABLE FAR* lpht, __in METARECORD FAR* lpMR, __in int nObj, __in_opt LPARAM param);
DECLSPEC_IMPORT BOOL WINAPI EnumMetaFile( __in HDC hdc, __in HMETAFILE hmf, __in MFENUMPROC proc, __in_opt LPARAM param);

typedef int (CALLBACK* ENHMFENUMPROC)(__in HDC hdc, __in_ecount(nHandles) HANDLETABLE FAR* lpht, __in CONST ENHMETARECORD * lpmr, __in int nHandles, __in_opt LPARAM data);

// Enhanced Metafile Function Declarations

DECLSPEC_IMPORT HENHMETAFILE WINAPI CloseEnhMetaFile( __in HDC hdc);
DECLSPEC_IMPORT HENHMETAFILE WINAPI CopyEnhMetaFileA( __in HENHMETAFILE hEnh, __in_opt LPCSTR lpFileName);
DECLSPEC_IMPORT HENHMETAFILE WINAPI CopyEnhMetaFileW( __in HENHMETAFILE hEnh, __in_opt LPCWSTR lpFileName);



#define CopyEnhMetaFile CopyEnhMetaFileA

DECLSPEC_IMPORT HDC WINAPI CreateEnhMetaFileA( __in_opt HDC hdc, __in_opt LPCSTR lpFilename, __in_opt CONST RECT *lprc, __in_opt LPCSTR lpDesc);
DECLSPEC_IMPORT HDC WINAPI CreateEnhMetaFileW( __in_opt HDC hdc, __in_opt LPCWSTR lpFilename, __in_opt CONST RECT *lprc, __in_opt LPCWSTR lpDesc);



#define CreateEnhMetaFile CreateEnhMetaFileA

DECLSPEC_IMPORT BOOL WINAPI DeleteEnhMetaFile( __in_opt HENHMETAFILE hmf);
DECLSPEC_IMPORT BOOL WINAPI EnumEnhMetaFile( __in_opt HDC hdc, __in HENHMETAFILE hmf, __in ENHMFENUMPROC proc,
                                        __in_opt LPVOID param, __in_opt CONST RECT * lpRect);
DECLSPEC_IMPORT HENHMETAFILE WINAPI GetEnhMetaFileA( __in LPCSTR lpName);
DECLSPEC_IMPORT HENHMETAFILE WINAPI GetEnhMetaFileW( __in LPCWSTR lpName);



#define GetEnhMetaFile GetEnhMetaFileA

DECLSPEC_IMPORT UINT WINAPI GetEnhMetaFileBits( __in HENHMETAFILE hEMF,
                                            __in UINT nSize,
                                            __out_bcount_opt(nSize) LPBYTE lpData);
DECLSPEC_IMPORT UINT WINAPI GetEnhMetaFileDescriptionA( __in HENHMETAFILE hemf,
                                                    __in UINT cchBuffer,
                                                    __out_ecount_opt(cchBuffer) LPSTR lpDescription);
DECLSPEC_IMPORT UINT WINAPI GetEnhMetaFileDescriptionW( __in HENHMETAFILE hemf,
                                                    __in UINT cchBuffer,
                                                    __out_ecount_opt(cchBuffer) LPWSTR lpDescription);



#define GetEnhMetaFileDescription GetEnhMetaFileDescriptionA

DECLSPEC_IMPORT UINT WINAPI GetEnhMetaFileHeader( __in HENHMETAFILE hemf,
                                                __in UINT nSize,
                                                __out_bcount_opt(nSize) LPENHMETAHEADER lpEnhMetaHeader);
DECLSPEC_IMPORT UINT WINAPI GetEnhMetaFilePaletteEntries(__in HENHMETAFILE hemf,
                                                    __in UINT nNumEntries,
                                                    __out_ecount_opt(nNumEntries) LPPALETTEENTRY lpPaletteEntries);

DECLSPEC_IMPORT UINT WINAPI GetEnhMetaFilePixelFormat( __in HENHMETAFILE hemf,
                                                    __in UINT cbBuffer,
                                                    __out_bcount_opt(cbBuffer) PIXELFORMATDESCRIPTOR *ppfd);
DECLSPEC_IMPORT UINT WINAPI GetWinMetaFileBits( __in HENHMETAFILE hemf,
                                            __in UINT cbData16,
                                            __out_bcount_opt(cbData16) LPBYTE pData16,
                                            __in INT iMapMode,
                                            __in HDC hdcRef);
DECLSPEC_IMPORT BOOL WINAPI PlayEnhMetaFile( __in HDC hdc, __in HENHMETAFILE hmf, __in CONST RECT * lprect);
DECLSPEC_IMPORT BOOL WINAPI PlayEnhMetaFileRecord( __in HDC hdc,
                                                __in_ecount(cht) LPHANDLETABLE pht,
                                                __in CONST ENHMETARECORD *pmr,
                                                __in UINT cht);

DECLSPEC_IMPORT HENHMETAFILE WINAPI SetEnhMetaFileBits( __in UINT nSize,
                                                    __in_bcount(nSize) CONST BYTE * pb);

DECLSPEC_IMPORT HENHMETAFILE WINAPI SetWinMetaFileBits( __in UINT nSize,
                                                    __in_bcount(nSize) CONST BYTE *lpMeta16Data,
                                                    __in_opt HDC hdcRef,
                                                    __in_opt CONST METAFILEPICT *lpMFP);
DECLSPEC_IMPORT BOOL WINAPI GdiComment(__in HDC hdc, __in UINT nSize, __in_bcount(nSize) CONST BYTE *lpData);





DECLSPEC_IMPORT BOOL WINAPI GetTextMetricsA( __in HDC hdc, __out LPTEXTMETRICA lptm);
DECLSPEC_IMPORT BOOL WINAPI GetTextMetricsW( __in HDC hdc, __out LPTEXTMETRICW lptm);



#define GetTextMetrics GetTextMetricsA
# 4334 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
/* new GDI */

typedef struct tagDIBSECTION {
    BITMAP dsBm;
    BITMAPINFOHEADER dsBmih;
    DWORD dsBitfields[3];
    HANDLE dshSection;
    DWORD dsOffset;
} DIBSECTION, FAR *LPDIBSECTION, *PDIBSECTION;


DECLSPEC_IMPORT BOOL WINAPI AngleArc( __in HDC hdc, __in int x, __in int y, __in DWORD r, __in FLOAT StartAngle, __in FLOAT SweepAngle);
DECLSPEC_IMPORT BOOL WINAPI PolyPolyline(__in HDC hdc, __in CONST POINT *apt, __in_ecount(csz) CONST DWORD *asz, __in DWORD csz);
DECLSPEC_IMPORT BOOL WINAPI GetWorldTransform( __in HDC hdc, __out LPXFORM lpxf);
DECLSPEC_IMPORT BOOL WINAPI SetWorldTransform( __in HDC hdc, __in CONST XFORM * lpxf);
DECLSPEC_IMPORT BOOL WINAPI ModifyWorldTransform( __in HDC hdc, __in_opt CONST XFORM * lpxf, __in DWORD mode);
DECLSPEC_IMPORT BOOL WINAPI CombineTransform( __out LPXFORM lpxfOut, __in CONST XFORM *lpxf1, __in CONST XFORM *lpxf2);
DECLSPEC_IMPORT HBITMAP WINAPI CreateDIBSection(__in_opt HDC hdc, __in CONST BITMAPINFO *lpbmi, __in UINT usage, __deref_opt_out VOID **ppvBits, __in_opt HANDLE hSection, __in DWORD offset);
__range(0,cEntries)
DECLSPEC_IMPORT UINT WINAPI GetDIBColorTable( __in HDC hdc,
                                        __in UINT iStart,
                                        __in UINT cEntries,
                                        __out_ecount_part(cEntries,return) RGBQUAD *prgbq);
DECLSPEC_IMPORT UINT WINAPI SetDIBColorTable( __in HDC hdc,
                                        __in UINT iStart,
                                        __in UINT cEntries,
                                        __in_ecount(cEntries) CONST RGBQUAD *prgbq);

/* Flags value for COLORADJUSTMENT */
#define CA_NEGATIVE 0x0001
#define CA_LOG_FILTER 0x0002

/* IlluminantIndex values */
#define ILLUMINANT_DEVICE_DEFAULT 0
#define ILLUMINANT_A 1
#define ILLUMINANT_B 2
#define ILLUMINANT_C 3
#define ILLUMINANT_D50 4
#define ILLUMINANT_D55 5
#define ILLUMINANT_D65 6
#define ILLUMINANT_D75 7
#define ILLUMINANT_F2 8
#define ILLUMINANT_MAX_INDEX ILLUMINANT_F2

#define ILLUMINANT_TUNGSTEN ILLUMINANT_A
#define ILLUMINANT_DAYLIGHT ILLUMINANT_C
#define ILLUMINANT_FLUORESCENT ILLUMINANT_F2
#define ILLUMINANT_NTSC ILLUMINANT_C

/* Min and max for RedGamma, GreenGamma, BlueGamma */
#define RGB_GAMMA_MIN (WORD)02500
#define RGB_GAMMA_MAX (WORD)65000

/* Min and max for ReferenceBlack and ReferenceWhite */
#define REFERENCE_WHITE_MIN (WORD)6000
#define REFERENCE_WHITE_MAX (WORD)10000
#define REFERENCE_BLACK_MIN (WORD)0
#define REFERENCE_BLACK_MAX (WORD)4000

/* Min and max for Contrast, Brightness, Colorfulness, RedGreenTint */
#define COLOR_ADJ_MIN (SHORT)-100
#define COLOR_ADJ_MAX (SHORT)100

typedef struct tagCOLORADJUSTMENT {
    WORD caSize;
    WORD caFlags;
    WORD caIlluminantIndex;
    WORD caRedGamma;
    WORD caGreenGamma;
    WORD caBlueGamma;
    WORD caReferenceBlack;
    WORD caReferenceWhite;
    SHORT caContrast;
    SHORT caBrightness;
    SHORT caColorfulness;
    SHORT caRedGreenTint;
} COLORADJUSTMENT, *PCOLORADJUSTMENT, FAR *LPCOLORADJUSTMENT;

DECLSPEC_IMPORT BOOL WINAPI SetColorAdjustment( __in HDC hdc, __in CONST COLORADJUSTMENT *lpca);
DECLSPEC_IMPORT BOOL WINAPI GetColorAdjustment( __in HDC hdc, __out LPCOLORADJUSTMENT lpca);
DECLSPEC_IMPORT HPALETTE WINAPI CreateHalftonePalette( __in_opt HDC hdc);




typedef FARPROC ABORTPROC;


typedef struct _DOCINFOA {
    int cbSize;
    LPCSTR lpszDocName;
    LPCSTR lpszOutput;

    LPCSTR lpszDatatype;
    DWORD fwType;

} DOCINFOA, *LPDOCINFOA;
typedef struct _DOCINFOW {
    int cbSize;
    LPCWSTR lpszDocName;
    LPCWSTR lpszOutput;

    LPCWSTR lpszDatatype;
    DWORD fwType;

} DOCINFOW, *LPDOCINFOW;




typedef DOCINFOA DOCINFO;
typedef LPDOCINFOA LPDOCINFO;



#define DI_APPBANDING 0x00000001
#define DI_ROPS_READ_DESTINATION 0x00000002


__gdi_entry DECLSPEC_IMPORT int WINAPI StartDocA(__in HDC hdc, __in CONST DOCINFOA *lpdi);
__gdi_entry DECLSPEC_IMPORT int WINAPI StartDocW(__in HDC hdc, __in CONST DOCINFOW *lpdi);



#define StartDoc StartDocA

__gdi_entry DECLSPEC_IMPORT int WINAPI EndDoc(__in HDC hdc);
__gdi_entry DECLSPEC_IMPORT int WINAPI StartPage(__in HDC hdc);
__gdi_entry DECLSPEC_IMPORT int WINAPI EndPage(__in HDC hdc);
__gdi_entry DECLSPEC_IMPORT int WINAPI AbortDoc(__in HDC hdc);
DECLSPEC_IMPORT int WINAPI SetAbortProc(__in HDC hdc, __in ABORTPROC proc);

DECLSPEC_IMPORT BOOL WINAPI AbortPath(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI ArcTo(__in HDC hdc, __in int left, __in int top, __in int right, __in int bottom, __in int xr1, __in int yr1, __in int xr2, __in int yr2);
DECLSPEC_IMPORT BOOL WINAPI BeginPath(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI CloseFigure(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI EndPath(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI FillPath(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI FlattenPath(__in HDC hdc);
DECLSPEC_IMPORT int WINAPI GetPath(__in HDC hdc, __out_ecount_opt(cpt) LPPOINT apt, __out_ecount_opt(cpt) LPBYTE aj, int cpt);
DECLSPEC_IMPORT HRGN WINAPI PathToRegion(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI PolyDraw(__in HDC hdc, __in_ecount(cpt) CONST POINT * apt, __in_ecount(cpt) CONST BYTE * aj, __in int cpt);
DECLSPEC_IMPORT BOOL WINAPI SelectClipPath(__in HDC hdc, __in int mode);
DECLSPEC_IMPORT int WINAPI SetArcDirection(__in HDC hdc, __in int dir);
DECLSPEC_IMPORT BOOL WINAPI SetMiterLimit(__in HDC hdc, __in FLOAT limit, __out_opt PFLOAT old);
DECLSPEC_IMPORT BOOL WINAPI StrokeAndFillPath(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI StrokePath(__in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI WidenPath(__in HDC hdc);
DECLSPEC_IMPORT HPEN WINAPI ExtCreatePen( __in DWORD iPenStyle,
                                    __in DWORD cWidth,
                                    __in CONST LOGBRUSH *plbrush,
                                    __in DWORD cStyle,
                                    __in_ecount_opt(cStyle) CONST DWORD *pstyle);
DECLSPEC_IMPORT BOOL WINAPI GetMiterLimit(__in HDC hdc, __out PFLOAT plimit);
DECLSPEC_IMPORT int WINAPI GetArcDirection(__in HDC hdc);

DECLSPEC_IMPORT int WINAPI GetObjectA(__in HANDLE h, __in int c, __out_bcount_opt(c) LPVOID pv);
DECLSPEC_IMPORT int WINAPI GetObjectW(__in HANDLE h, __in int c, __out_bcount_opt(c) LPVOID pv);



#define GetObject GetObjectA
# 4520 "C:/Program Files (x86)/Microsoft SDKs/Windows/v7.0A/Include/wingdi.h"
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI MoveToEx( __in HDC hdc, __in int x, __in int y, __out_opt LPPOINT lppt);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI TextOutA( __in HDC hdc, __in int x, __in int y, __in_ecount(c) LPCSTR lpString, __in int c);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI TextOutW( __in HDC hdc, __in int x, __in int y, __in_ecount(c) LPCWSTR lpString, __in int c);



#define TextOut TextOutA

__gdi_entry DECLSPEC_IMPORT BOOL WINAPI ExtTextOutA( __in HDC hdc, __in int x, __in int y, __in UINT options, __in_opt CONST RECT * lprect, __in_ecount_opt(c) LPCSTR lpString, __in UINT c, __in_ecount_opt(c) CONST INT * lpDx);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI ExtTextOutW( __in HDC hdc, __in int x, __in int y, __in UINT options, __in_opt CONST RECT * lprect, __in_ecount_opt(c) LPCWSTR lpString, __in UINT c, __in_ecount_opt(c) CONST INT * lpDx);



#define ExtTextOut ExtTextOutA

DECLSPEC_IMPORT BOOL WINAPI PolyTextOutA(__in HDC hdc, __in_ecount(nstrings) CONST POLYTEXTA * ppt, __in int nstrings);
DECLSPEC_IMPORT BOOL WINAPI PolyTextOutW(__in HDC hdc, __in_ecount(nstrings) CONST POLYTEXTW * ppt, __in int nstrings);



#define PolyTextOut PolyTextOutA


DECLSPEC_IMPORT HRGN WINAPI CreatePolygonRgn( __in_ecount(cPoint) CONST POINT *pptl,
                                            __in int cPoint,
                                            __in int iMode);
DECLSPEC_IMPORT BOOL WINAPI DPtoLP( __in HDC hdc, __inout_ecount(c) LPPOINT lppt, __in int c);
DECLSPEC_IMPORT BOOL WINAPI LPtoDP( __in HDC hdc, __inout_ecount(c) LPPOINT lppt, __in int c);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Polygon(__in HDC hdc, __in_ecount(cpt) CONST POINT *apt, __in int cpt);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI Polyline(__in HDC hdc, __in_ecount(cpt) CONST POINT *apt, __in int cpt);

DECLSPEC_IMPORT BOOL WINAPI PolyBezier(__in HDC hdc, __in_ecount(cpt) CONST POINT * apt, __in DWORD cpt);
DECLSPEC_IMPORT BOOL WINAPI PolyBezierTo(__in HDC hdc, __in_ecount(cpt) CONST POINT * apt, __in DWORD cpt);
DECLSPEC_IMPORT BOOL WINAPI PolylineTo(__in HDC hdc, __in_ecount(cpt) CONST POINT * apt, __in DWORD cpt);

__gdi_entry DECLSPEC_IMPORT BOOL WINAPI SetViewportExtEx( __in HDC hdc, __in int x, __in int y, __out_opt LPSIZE lpsz);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI SetViewportOrgEx( __in HDC hdc, __in int x, __in int y, __out_opt LPPOINT lppt);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI SetWindowExtEx( __in HDC hdc, __in int x, __in int y, __out_opt LPSIZE lpsz);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI SetWindowOrgEx( __in HDC hdc, __in int x, __in int y, __out_opt LPPOINT lppt);

__gdi_entry DECLSPEC_IMPORT BOOL WINAPI OffsetViewportOrgEx( __in HDC hdc, __in int x, __in int y, __out_opt LPPOINT lppt);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI OffsetWindowOrgEx( __in HDC hdc, __in int x, __in int y, __out_opt LPPOINT lppt);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI ScaleViewportExtEx( __in HDC hdc, __in int xn, __in int dx, __in int yn, __in int yd, __out_opt LPSIZE lpsz);
__gdi_entry DECLSPEC_IMPORT BOOL WINAPI ScaleWindowExtEx( __in HDC hdc, __in int xn, __in int xd, __in int yn, __in int yd, __out_opt LPSIZE lpsz);
DECLSPEC_IMPORT BOOL WINAPI SetBitmapDimensionEx( __in HBITMAP hbm, __in int w, __in int h, __out_opt LPSIZE lpsz);
DECLSPEC_IMPORT BOOL WINAPI SetBrushOrgEx( __in HDC hdc, __in int x, __in int y, __out_opt LPPOINT lppt);

DECLSPEC_IMPORT int WINAPI GetTextFaceA( __in HDC hdc, __in int c, __out_ecount_part_opt(c, return) LPSTR lpName);
DECLSPEC_IMPORT int WINAPI GetTextFaceW( __in HDC hdc, __in int c, __out_ecount_part_opt(c, return) LPWSTR lpName);



#define GetTextFace GetTextFaceA


#define FONTMAPPER_MAX 10

typedef struct tagKERNINGPAIR {
   WORD wFirst;
   WORD wSecond;
   int iKernAmount;
} KERNINGPAIR, *LPKERNINGPAIR;

DECLSPEC_IMPORT DWORD WINAPI GetKerningPairsA( __in HDC hdc,
                                            __in DWORD nPairs,
                                            __out_ecount_part_opt(nPairs, return) LPKERNINGPAIR lpKernPair);
DECLSPEC_IMPORT DWORD WINAPI GetKerningPairsW( __in HDC hdc,
                                            __in DWORD nPairs,
                                            __out_ecount_part_opt(nPairs, return) LPKERNINGPAIR lpKernPair);



#define GetKerningPairs GetKerningPairsA



DECLSPEC_IMPORT BOOL WINAPI GetDCOrgEx( __in HDC hdc, __out LPPOINT lppt);
DECLSPEC_IMPORT BOOL WINAPI FixBrushOrgEx( __in HDC hdc, __in int x, __in int y, __in_opt LPPOINT ptl);
DECLSPEC_IMPORT BOOL WINAPI UnrealizeObject( __in HGDIOBJ h);

DECLSPEC_IMPORT BOOL WINAPI GdiFlush(void);
DECLSPEC_IMPORT DWORD WINAPI GdiSetBatchLimit( __in DWORD dw);
DECLSPEC_IMPORT DWORD WINAPI GdiGetBatchLimit(void);



#define ICM_OFF 1
#define ICM_ON 2
#define ICM_QUERY 3
#define ICM_DONE_OUTSIDEDC 4

typedef int (CALLBACK* ICMENUMPROCA)(LPSTR, LPARAM);
typedef int (CALLBACK* ICMENUMPROCW)(LPWSTR, LPARAM);



#define ICMENUMPROC ICMENUMPROCA


DECLSPEC_IMPORT int WINAPI SetICMMode( __in HDC hdc, __in int mode);
DECLSPEC_IMPORT BOOL WINAPI CheckColorsInGamut( __in HDC hdc,
                                                    __in_ecount(nCount) LPRGBTRIPLE lpRGBTriple,
                                                    __out_bcount(nCount) LPVOID dlpBuffer,
                                                    __in DWORD nCount);

DECLSPEC_IMPORT HCOLORSPACE WINAPI GetColorSpace( __in HDC hdc);
DECLSPEC_IMPORT BOOL WINAPI GetLogColorSpaceA( __in HCOLORSPACE hColorSpace,
                                                __out_bcount(nSize) LPLOGCOLORSPACEA lpBuffer,
                                                __in DWORD nSize);
DECLSPEC_IMPORT BOOL WINAPI GetLogColorSpaceW( __in HCOLORSPACE hColorSpace,
                                                __out_bcount(nSize) LPLOGCOLORSPACEW lpBuffer,
                                                __in DWORD nSize);



#define GetLogColorSpace GetLogColorSpaceA


DECLSPEC_IMPORT HCOLORSPACE WINAPI CreateColorSpaceA( __in LPLOGCOLORSPACEA lplcs);
DECLSPEC_IMPORT HCOLORSPACE WINAPI CreateColorSpaceW( __in LPLOGCOLORSPACEW lplcs);



#define CreateColorSpace CreateColorSpaceA

DECLSPEC_IMPORT HCOLORSPACE WINAPI SetColorSpace( __in HDC hdc, __in HCOLORSPACE hcs);
DECLSPEC_IMPORT BOOL WINAPI DeleteColorSpace( __in HCOLORSPACE hcs);
DECLSPEC_IMPORT BOOL WINAPI GetICMProfileA( __in HDC hdc,
                                                __inout LPDWORD pBufSize,
                                                __out_ecount_opt(*pBufSize) LPSTR pszFilename);
DECLSPEC_IMPORT BOOL WINAPI GetICMProfileW( __in HDC hdc,
                                                __inout LPDWORD pBufSize,
                                                __out_ecount_opt(*pBufSize) LPWSTR pszFilename);



#define GetICMProfile GetICMProfileA


DECLSPEC_IMPORT BOOL WINAPI SetICMProfileA( __in HDC hdc, __in LPSTR lpFileName);
DECLSPEC_IMPORT BOOL WINAPI SetICMProfileW( __in HDC hdc, __in LPWSTR lpFileName);



#define SetICMProfile SetICMProfileA

DECLSPEC_IMPORT BOOL WINAPI GetDeviceGammaRamp( __in HDC hdc, __out_bcount(3*256*2) LPVOID lpRamp);
DECLSPEC_IMPORT BOOL WINAPI SetDeviceGammaRamp( __in HDC hdc, __in_bcount(3*256*2) LPVOID lpRamp);
DECLSPEC_IMPORT BOOL WINAPI ColorMatchToTarget( __in HDC hdc, __in HDC hdcTarget, __in DWORD action);
DECLSPEC_IMPORT int WINAPI EnumICMProfilesA( __in HDC hdc, __in ICMENUMPROCA proc, __in_opt LPARAM param);
DECLSPEC_IMPORT int WINAPI EnumICMProfilesW( __in HDC hdc, __in ICMENUMPROCW proc, __in_opt LPARAM param);



#define EnumICMProfiles EnumICMProfilesA

// The Win95 update API UpdateICMRegKeyA is deprecated to set last error to ERROR_NOT_SUPPORTED and return FALSE
DECLSPEC_IMPORT BOOL WINAPI UpdateICMRegKeyA( __reserved DWORD reserved, __in LPSTR lpszCMID, __in LPSTR lpszFileName, __in UINT command);
// The Win95 update API UpdateICMRegKeyW is deprecated to set last error to ERROR_NOT_SUPPORTED and return FALSE
DECLSPEC_IMPORT BOOL WINAPI UpdateICMRegKeyW( __reserved DWORD reserved, __in LPWSTR lpszCMID, __in LPWSTR lpszFileName, __in UINT command);



#define UpdateICMRegKey UpdateICMRegKeyA

#pragma deprecated (UpdateICMRegKeyW)
#pragma deprecated (UpdateICMRegKeyA)




DECLSPEC_IMPORT BOOL WINAPI ColorCorrectPalette( __in HDC hdc, __in HPALETTE hPal, __in DWORD deFirst, __in DWORD num);




// Enhanced metafile constants.


#define ENHMETA_SIGNATURE 0x464D4520




// Stock object flag used in the object handle index in the enhanced
// metafile records.
// E.g. The object handle index (META_STOCK_OBJECT | BLACK_BRUSH)
// represents the stock object BLACK_BRUSH.

#define ENHMETA_STOCK_OBJECT 0x80000000

// Enhanced metafile record types.

#define EMR_HEADER 1
#define EMR_POLYBEZIER 2
#define EMR_POLYGON 3
#define EMR_POLYLINE 4
#define EMR_POLYBEZIERTO 5
#define EMR_POLYLINETO 6
#define EMR_POLYPOLYLINE 7
#define EMR_POLYPOLYGON 8
#define EMR_SETWINDOWEXTEX 9
#define EMR_SETWINDOWORGEX 10
#define EMR_SETVIEWPORTEXTEX 11
#define EMR_SETVIEWPORTORGEX 12
#define EMR_SETBRUSHORGEX 13
#define EMR_EOF 14
#define EMR_SETPIXELV 15
#define EMR_SETMAPPERFLAGS 16
#define EMR_SETMAPMODE 17
#define EMR_SETBKMODE 18
#define EMR_SETPOLYFILLMODE 19
#define EMR_SETROP2 20
#define EMR_SETSTRETCHBLTMODE 21
#define EMR_SETTEXTALIGN 22
#define EMR_SETCOLORADJUSTMENT 23
#define EMR_SETTEXTCOLOR 24
#define EMR_SETBKCOLOR 25
#define EMR_OFFSETCLIPRGN 26
#define EMR_MOVETOEX 27
#define EMR_SETMETARGN 28
#define EMR_EXCLUDECLIPRECT 29
#define EMR_INTERSECTCLIPRECT 30
#define EMR_SCALEVIEWPORTEXTEX 31
#define EMR_SCALEWINDOWEXTEX 32
#define EMR_SAVEDC 33
#define EMR_RESTOREDC 34
#define EMR_SETWORLDTRANSFORM 35
#define EMR_MODIFYWORLDTRANSFORM 36
#define EMR_SELECTOBJECT 37
#define EMR_CREATEPEN 38
#define EMR_CREATEBRUSHINDIRECT 39
#define EMR_DELETEOBJECT 40
#define EMR_ANGLEARC 41
#define EMR_ELLIPSE 42
#define EMR_RECTANGLE 43
#define EMR_ROUNDRECT 44
#define EMR_ARC 45
#define EMR_CHORD 46
#define EMR_PIE 47
#define EMR_SELECTPALETTE 48
#define EMR_CREATEPALETTE 49
#define EMR_SETPALETTEENTRIES 50
#define EMR_RESIZEPALETTE 51
#define EMR_REALIZEPALETTE 52
#define EMR_EXTFLOODFILL 53
#define EMR_LINETO 54
#define EMR_ARCTO 55
#define EMR_POLYDRAW 56
#define EMR_SETARCDIRECTION 57
#define EMR_SETMITERLIMIT 58
#define EMR_BEGINPATH 59
#define EMR_ENDPATH 60
#define EMR_CLOSEFIGURE 61
#define EMR_FILLPATH 62
#define EMR_STROKEANDFILLPATH 63
#define EMR_STROKEPATH 64
#define EMR_FLATTENPATH 65
#define EMR_WIDENPATH 66
#define EMR_SELECTCLIPPATH 67
#define EMR_ABORTPATH 68

#define EMR_GDICOMMENT 70
#define EMR_FILLRGN 71
#define EMR_FRAMERGN 72
#define EMR_INVERTRGN 73
#define EMR_PAINTRGN 74
#define EMR_EXTSELECTCLIPRGN 75
#define EMR_BITBLT 76
#define EMR_STRETCHBLT 77
#define EMR_MASKBLT 78
#define EMR_PLGBLT 79
#define EMR_SETDIBITSTODEVICE 80
#define EMR_STRETCHDIBITS 81
#define EMR_EXTCREATEFONTINDIRECTW 82
#define EMR_EXTTEXTOUTA 83
#define EMR_EXTTEXTOUTW 84
#define EMR_POLYBEZIER16 85
#define EMR_POLYGON16 86
#define EMR_POLYLINE16 87
#define EMR_POLYBEZIERTO16 88
#define EMR_POLYLINETO16 89
#define EMR_POLYPOLYLINE16 90
#define EMR_POLYPOLYGON16 91
#define EMR_POLYDRAW16 92
#define EMR_CREATEMONOBRUSH 93
#define EMR_CREATEDIBPATTERNBRUSHPT 94
#define EMR_EXTCREATEPEN 95
#define EMR_POLYTEXTOUTA 96
#define EMR_POLYTEXTOUTW 97


#define EMR_SETICMMODE 98
#define EMR_CREATECOLORSPACE 99
#define EMR_SETCOLORSPACE 100
#define EMR_DELETECOLORSPACE 101
#define EMR_GLSRECORD 102
#define EMR_GLSBOUNDEDRECORD 103
#define EMR_PIXELFORMAT 104



#define EMR_RESERVED_105 105
#define EMR_RESERVED_106 106
#define EMR_RESERVED_107 107
#define EMR_RESERVED_108 108
#define EMR_RESERVED_109 109
#define EMR_RESERVED_110 110
#define EMR_COLORCORRECTPALETTE 111
#define EMR_SETICMPROFILEA 112
#define EMR_SETICMPROFILEW 113
#define EMR_ALPHABLEND 114
#define EMR_SETLAYOUT 115
#define EMR_TRANSPARENTBLT 116

#define EMR_RESERVED_117 117

#define EMR_GRADIENTFILL 118
#define EMR_RESERVED_119 119
#define EMR_RESERVED_120 120
#define EMR_COLORMATCHTOTARGETW 121
#define EMR_CREATECOLORSPACEW 122


#define EMR_MIN 1


#define EMR_MAX 122






// Base record type for the enhanced metafile.

typedef struct tagEMR
{
    DWORD iType; // Enhanced metafile record type
    DWORD nSize; // Length of the record in bytes.
                                // This must be a multiple of 4.
} EMR, *PEMR;

// Base text record type for the enhanced metafile.

typedef struct tagEMRTEXT
{
    POINTL ptlReference;
    DWORD nChars;
    DWORD offString; // Offset to the string
    DWORD fOptions;
    RECTL rcl;
    DWORD offDx; // Offset to the inter-character spacing array.
                                // This is always given.
} EMRTEXT, *PEMRTEXT;

// Record structures for the enhanced metafile.

typedef struct tagABORTPATH
{
    EMR emr;
} EMRABORTPATH, *PEMRABORTPATH,
  EMRBEGINPATH, *PEMRBEGINPATH,
  EMRENDPATH, *PEMRENDPATH,
  EMRCLOSEFIGURE, *PEMRCLOSEFIGURE,
  EMRFLATTENPATH, *PEMRFLATTENPATH,
  EMRWIDENPATH, *PEMRWIDENPATH,
  EMRSETMETARGN, *PEMRSETMETARGN,
  EMRSAVEDC, *PEMRSAVEDC,
  EMRREALIZEPALETTE, *PEMRREALIZEPALETTE;

typedef struct tagEMRSELECTCLIPPATH
{
    EMR emr;
    DWORD iMode;
} EMRSELECTCLIPPATH, *PEMRSELECTCLIPPATH,
  EMRSETBKMODE, *PEMRSETBKMODE,
  EMRSETMAPMODE, *PEMRSETMAPMODE,

  EMRSETLAYOUT, *PEMRSETLAYOUT,

  EMRSETPOLYFILLMODE, *PEMRSETPOLYFILLMODE,
  EMRSETROP2, *PEMRSETROP2,
  EMRSETSTRETCHBLTMODE, *PEMRSETSTRETCHBLTMODE,
  EMRSETICMMODE, *PEMRSETICMMODE,
  EMRSETTEXTALIGN, *PEMRSETTEXTALIGN;

typedef struct tagEMRSETMITERLIMIT
{
    EMR emr;
    FLOAT eMiterLimit;
} EMRSETMITERLIMIT, *PEMRSETMITERLIMIT;

typedef struct tagEMRRESTOREDC
{
    EMR emr;
    LONG iRelative; // Specifies a relative instance
} EMRRESTOREDC, *PEMRRESTOREDC;

typedef struct tagEMRSETARCDIRECTION
{
    EMR emr;
    DWORD iArcDirection; // Specifies the arc direction in the
                                // advanced graphics mode.
} EMRSETARCDIRECTION, *PEMRSETARCDIRECTION;

typedef struct tagEMRSETMAPPERFLAGS
{
    EMR emr;
    DWORD dwFlags;
} EMRSETMAPPERFLAGS, *PEMRSETMAPPERFLAGS;

typedef struct tagEMRSETTEXTCOLOR
{
    EMR emr;
    COLORREF crColor;
} EMRSETBKCOLOR, *PEMRSETBKCOLOR,
  EMRSETTEXTCOLOR, *PEMRSETTEXTCOLOR;

typedef struct tagEMRSELECTOBJECT
{
    EMR emr;
    DWORD ihObject; // Object handle index
} EMRSELECTOBJECT, *PEMRSELECTOBJECT,
  EMRDELETEOBJECT, *PEMRDELETEOBJECT;

typedef struct tagEMRSELECTPALETTE
{
    EMR emr;
    DWORD ihPal; // Palette handle index, background mode only
} EMRSELECTPALETTE, *PEMRSELECTPALETTE;

typedef struct tagEMRRESIZEPALETTE
{
    EMR emr;
    DWORD ihPal; // Palette handle index
    DWORD cEntries;
} EMRRESIZEPALETTE, *PEMRRESIZEPALETTE;

typedef struct tagEMRSETPALETTEENTRIES
{
    EMR emr;
    DWORD ihPal; // Palette handle index
    DWORD iStart;
    DWORD cEntries;
    PALETTEENTRY aPalEntries[1];// The peFlags fields do not contain any flags
} EMRSETPALETTEENTRIES, *PEMRSETPALETTEENTRIES;

typedef struct tagEMRSETCOLORADJUSTMENT
{
    EMR emr;
    COLORADJUSTMENT ColorAdjustment;
} EMRSETCOLORADJUSTMENT, *PEMRSETCOLORADJUSTMENT;

typedef struct tagEMRGDICOMMENT
{
    EMR emr;
    DWORD cbData; // Size of data in bytes
    BYTE Data[1];
} EMRGDICOMMENT, *PEMRGDICOMMENT;

typedef struct tagEMREOF
{
    EMR emr;
    DWORD nPalEntries; // Number of palette entries
    DWORD offPalEntries; // Offset to the palette entries
    DWORD nSizeLast; // Same as nSize and must be the last DWORD
                                // of the record.  The palette entries,
                                // if exist, precede this field.
} EMREOF, *PEMREOF;

typedef struct tagEMRLINETO
{
    EMR emr;
    POINTL ptl;
} EMRLINETO, *PEMRLINETO,
  EMRMOVETOEX, *PEMRMOVETOEX;

typedef struct tagEMROFFSETCLIPRGN
{
    EMR emr;
    POINTL ptlOffset;
} EMROFFSETCLIPRGN, *PEMROFFSETCLIPRGN;

typedef struct tagEMRFILLPATH
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
} EMRFILLPATH, *PEMRFILLPATH,
  EMRSTROKEANDFILLPATH, *PEMRSTROKEANDFILLPATH,
  EMRSTROKEPATH, *PEMRSTROKEPATH;

typedef struct tagEMREXCLUDECLIPRECT
{
    EMR emr;
    RECTL rclClip;
} EMREXCLUDECLIPRECT, *PEMREXCLUDECLIPRECT,
  EMRINTERSECTCLIPRECT, *PEMRINTERSECTCLIPRECT;

typedef struct tagEMRSETVIEWPORTORGEX
{
    EMR emr;
    POINTL ptlOrigin;
} EMRSETVIEWPORTORGEX, *PEMRSETVIEWPORTORGEX,
  EMRSETWINDOWORGEX, *PEMRSETWINDOWORGEX,
  EMRSETBRUSHORGEX, *PEMRSETBRUSHORGEX;

typedef struct tagEMRSETVIEWPORTEXTEX
{
    EMR emr;
    SIZEL szlExtent;
} EMRSETVIEWPORTEXTEX, *PEMRSETVIEWPORTEXTEX,
  EMRSETWINDOWEXTEX, *PEMRSETWINDOWEXTEX;

typedef struct tagEMRSCALEVIEWPORTEXTEX
{
    EMR emr;
    LONG xNum;
    LONG xDenom;
    LONG yNum;
    LONG yDenom;
} EMRSCALEVIEWPORTEXTEX, *PEMRSCALEVIEWPORTEXTEX,
  EMRSCALEWINDOWEXTEX, *PEMRSCALEWINDOWEXTEX;

typedef struct tagEMRSETWORLDTRANSFORM
{
    EMR emr;
    XFORM xform;
} EMRSETWORLDTRANSFORM, *PEMRSETWORLDTRANSFORM;

typedef struct tagEMRMODIFYWORLDTRANSFORM
{
    EMR emr;
    XFORM xform;
    DWORD iMode;
} EMRMODIFYWORLDTRANSFORM, *PEMRMODIFYWORLDTRANSFORM;

typedef struct tagEMRSETPIXELV
{
    EMR emr;
    POINTL ptlPixel;
    COLORREF crColor;
} EMRSETPIXELV, *PEMRSETPIXELV;

typedef struct tagEMREXTFLOODFILL
{
    EMR emr;
    POINTL ptlStart;
    COLORREF crColor;
    DWORD iMode;
} EMREXTFLOODFILL, *PEMREXTFLOODFILL;

typedef struct tagEMRELLIPSE
{
    EMR emr;
    RECTL rclBox; // Inclusive-inclusive bounding rectangle
} EMRELLIPSE, *PEMRELLIPSE,
  EMRRECTANGLE, *PEMRRECTANGLE;


typedef struct tagEMRROUNDRECT
{
    EMR emr;
    RECTL rclBox; // Inclusive-inclusive bounding rectangle
    SIZEL szlCorner;
} EMRROUNDRECT, *PEMRROUNDRECT;

typedef struct tagEMRARC
{
    EMR emr;
    RECTL rclBox; // Inclusive-inclusive bounding rectangle
    POINTL ptlStart;
    POINTL ptlEnd;
} EMRARC, *PEMRARC,
  EMRARCTO, *PEMRARCTO,
  EMRCHORD, *PEMRCHORD,
  EMRPIE, *PEMRPIE;

typedef struct tagEMRANGLEARC
{
    EMR emr;
    POINTL ptlCenter;
    DWORD nRadius;
    FLOAT eStartAngle;
    FLOAT eSweepAngle;
} EMRANGLEARC, *PEMRANGLEARC;

typedef struct tagEMRPOLYLINE
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cptl;
    POINTL aptl[1];
} EMRPOLYLINE, *PEMRPOLYLINE,
  EMRPOLYBEZIER, *PEMRPOLYBEZIER,
  EMRPOLYGON, *PEMRPOLYGON,
  EMRPOLYBEZIERTO, *PEMRPOLYBEZIERTO,
  EMRPOLYLINETO, *PEMRPOLYLINETO;

typedef struct tagEMRPOLYLINE16
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cpts;
    POINTS apts[1];
} EMRPOLYLINE16, *PEMRPOLYLINE16,
  EMRPOLYBEZIER16, *PEMRPOLYBEZIER16,
  EMRPOLYGON16, *PEMRPOLYGON16,
  EMRPOLYBEZIERTO16, *PEMRPOLYBEZIERTO16,
  EMRPOLYLINETO16, *PEMRPOLYLINETO16;

typedef struct tagEMRPOLYDRAW
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cptl; // Number of points
    POINTL aptl[1]; // Array of points
    BYTE abTypes[1]; // Array of point types
} EMRPOLYDRAW, *PEMRPOLYDRAW;

typedef struct tagEMRPOLYDRAW16
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cpts; // Number of points
    POINTS apts[1]; // Array of points
    BYTE abTypes[1]; // Array of point types
} EMRPOLYDRAW16, *PEMRPOLYDRAW16;

typedef struct tagEMRPOLYPOLYLINE
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD nPolys; // Number of polys
    DWORD cptl; // Total number of points in all polys
    DWORD aPolyCounts[1]; // Array of point counts for each poly
    POINTL aptl[1]; // Array of points
} EMRPOLYPOLYLINE, *PEMRPOLYPOLYLINE,
  EMRPOLYPOLYGON, *PEMRPOLYPOLYGON;

typedef struct tagEMRPOLYPOLYLINE16
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD nPolys; // Number of polys
    DWORD cpts; // Total number of points in all polys
    DWORD aPolyCounts[1]; // Array of point counts for each poly
    POINTS apts[1]; // Array of points
} EMRPOLYPOLYLINE16, *PEMRPOLYPOLYLINE16,
  EMRPOLYPOLYGON16, *PEMRPOLYPOLYGON16;

typedef struct tagEMRINVERTRGN
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cbRgnData; // Size of region data in bytes
    BYTE RgnData[1];
} EMRINVERTRGN, *PEMRINVERTRGN,
  EMRPAINTRGN, *PEMRPAINTRGN;

typedef struct tagEMRFILLRGN
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cbRgnData; // Size of region data in bytes
    DWORD ihBrush; // Brush handle index
    BYTE RgnData[1];
} EMRFILLRGN, *PEMRFILLRGN;

typedef struct tagEMRFRAMERGN
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD cbRgnData; // Size of region data in bytes
    DWORD ihBrush; // Brush handle index
    SIZEL szlStroke;
    BYTE RgnData[1];
} EMRFRAMERGN, *PEMRFRAMERGN;

typedef struct tagEMREXTSELECTCLIPRGN
{
    EMR emr;
    DWORD cbRgnData; // Size of region data in bytes
    DWORD iMode;
    BYTE RgnData[1];
} EMREXTSELECTCLIPRGN, *PEMREXTSELECTCLIPRGN;

typedef struct tagEMREXTTEXTOUTA
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD iGraphicsMode; // Current graphics mode
    FLOAT exScale; // X and Y scales from Page units to .01mm units
    FLOAT eyScale; //   if graphics mode is GM_COMPATIBLE.
    EMRTEXT emrtext; // This is followed by the string and spacing
                                // array
} EMREXTTEXTOUTA, *PEMREXTTEXTOUTA,
  EMREXTTEXTOUTW, *PEMREXTTEXTOUTW;

typedef struct tagEMRPOLYTEXTOUTA
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD iGraphicsMode; // Current graphics mode
    FLOAT exScale; // X and Y scales from Page units to .01mm units
    FLOAT eyScale; //   if graphics mode is GM_COMPATIBLE.
    LONG cStrings;
    EMRTEXT aemrtext[1]; // Array of EMRTEXT structures.  This is
                                // followed by the strings and spacing arrays.
} EMRPOLYTEXTOUTA, *PEMRPOLYTEXTOUTA,
  EMRPOLYTEXTOUTW, *PEMRPOLYTEXTOUTW;

typedef struct tagEMRBITBLT
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc; // Source DC transform
    COLORREF crBkColorSrc; // Source DC BkColor in RGB
    DWORD iUsageSrc; // Source bitmap info color table usage
                                // (DIB_RGB_COLORS)
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
} EMRBITBLT, *PEMRBITBLT;

typedef struct tagEMRSTRETCHBLT
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc; // Source DC transform
    COLORREF crBkColorSrc; // Source DC BkColor in RGB
    DWORD iUsageSrc; // Source bitmap info color table usage
                                // (DIB_RGB_COLORS)
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    LONG cxSrc;
    LONG cySrc;
} EMRSTRETCHBLT, *PEMRSTRETCHBLT;

typedef struct tagEMRMASKBLT
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc; // Source DC transform
    COLORREF crBkColorSrc; // Source DC BkColor in RGB
    DWORD iUsageSrc; // Source bitmap info color table usage
                                // (DIB_RGB_COLORS)
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    LONG xMask;
    LONG yMask;
    DWORD iUsageMask; // Mask bitmap info color table usage
    DWORD offBmiMask; // Offset to the mask BITMAPINFO structure if any
    DWORD cbBmiMask; // Size of the mask BITMAPINFO structure if any
    DWORD offBitsMask; // Offset to the mask bitmap bits if any
    DWORD cbBitsMask; // Size of the mask bitmap bits if any
} EMRMASKBLT, *PEMRMASKBLT;

typedef struct tagEMRPLGBLT
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    POINTL aptlDest[3];
    LONG xSrc;
    LONG ySrc;
    LONG cxSrc;
    LONG cySrc;
    XFORM xformSrc; // Source DC transform
    COLORREF crBkColorSrc; // Source DC BkColor in RGB
    DWORD iUsageSrc; // Source bitmap info color table usage
                                // (DIB_RGB_COLORS)
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    LONG xMask;
    LONG yMask;
    DWORD iUsageMask; // Mask bitmap info color table usage
    DWORD offBmiMask; // Offset to the mask BITMAPINFO structure if any
    DWORD cbBmiMask; // Size of the mask BITMAPINFO structure if any
    DWORD offBitsMask; // Offset to the mask bitmap bits if any
    DWORD cbBitsMask; // Size of the mask bitmap bits if any
} EMRPLGBLT, *PEMRPLGBLT;

typedef struct tagEMRSETDIBITSTODEVICE
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG xSrc;
    LONG ySrc;
    LONG cxSrc;
    LONG cySrc;
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    DWORD iUsageSrc; // Source bitmap info color table usage
    DWORD iStartScan;
    DWORD cScans;
} EMRSETDIBITSTODEVICE, *PEMRSETDIBITSTODEVICE;

typedef struct tagEMRSTRETCHDIBITS
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG xSrc;
    LONG ySrc;
    LONG cxSrc;
    LONG cySrc;
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    DWORD iUsageSrc; // Source bitmap info color table usage
    DWORD dwRop;
    LONG cxDest;
    LONG cyDest;
} EMRSTRETCHDIBITS, *PEMRSTRETCHDIBITS;

typedef struct tagEMREXTCREATEFONTINDIRECTW
{
    EMR emr;
    DWORD ihFont; // Font handle index
    EXTLOGFONTW elfw;
} EMREXTCREATEFONTINDIRECTW, *PEMREXTCREATEFONTINDIRECTW;

typedef struct tagEMRCREATEPALETTE
{
    EMR emr;
    DWORD ihPal; // Palette handle index
    LOGPALETTE lgpl; // The peFlags fields in the palette entries
                                // do not contain any flags
} EMRCREATEPALETTE, *PEMRCREATEPALETTE;

typedef struct tagEMRCREATEPEN
{
    EMR emr;
    DWORD ihPen; // Pen handle index
    LOGPEN lopn;
} EMRCREATEPEN, *PEMRCREATEPEN;

typedef struct tagEMREXTCREATEPEN
{
    EMR emr;
    DWORD ihPen; // Pen handle index
    DWORD offBmi; // Offset to the BITMAPINFO structure if any
    DWORD cbBmi; // Size of the BITMAPINFO structure if any
                                // The bitmap info is followed by the bitmap
                                // bits to form a packed DIB.
    DWORD offBits; // Offset to the brush bitmap bits if any
    DWORD cbBits; // Size of the brush bitmap bits if any
    EXTLOGPEN32 elp; // The extended pen with the style array.
} EMREXTCREATEPEN, *PEMREXTCREATEPEN;

typedef struct tagEMRCREATEBRUSHINDIRECT
{
    EMR emr;
    DWORD ihBrush; // Brush handle index
    LOGBRUSH32 lb; // The style must be BS_SOLID, BS_HOLLOW,
                                 // BS_NULL or BS_HATCHED.
} EMRCREATEBRUSHINDIRECT, *PEMRCREATEBRUSHINDIRECT;

typedef struct tagEMRCREATEMONOBRUSH
{
    EMR emr;
    DWORD ihBrush; // Brush handle index
    DWORD iUsage; // Bitmap info color table usage
    DWORD offBmi; // Offset to the BITMAPINFO structure
    DWORD cbBmi; // Size of the BITMAPINFO structure
    DWORD offBits; // Offset to the bitmap bits
    DWORD cbBits; // Size of the bitmap bits
} EMRCREATEMONOBRUSH, *PEMRCREATEMONOBRUSH;

typedef struct tagEMRCREATEDIBPATTERNBRUSHPT
{
    EMR emr;
    DWORD ihBrush; // Brush handle index
    DWORD iUsage; // Bitmap info color table usage
    DWORD offBmi; // Offset to the BITMAPINFO structure
    DWORD cbBmi; // Size of the BITMAPINFO structure
                                // The bitmap info is followed by the bitmap
                                // bits to form a packed DIB.
    DWORD offBits; // Offset to the bitmap bits
    DWORD cbBits; // Size of the bitmap bits
} EMRCREATEDIBPATTERNBRUSHPT, *PEMRCREATEDIBPATTERNBRUSHPT;

typedef struct tagEMRFORMAT
{
    DWORD dSignature; // Format signature, e.g. ENHMETA_SIGNATURE.
    DWORD nVersion; // Format version number.
    DWORD cbData; // Size of data in bytes.
    DWORD offData; // Offset to data from GDICOMMENT_IDENTIFIER.
                                // It must begin at a DWORD offset.
} EMRFORMAT, *PEMRFORMAT;



typedef struct tagEMRGLSRECORD
{
    EMR emr;
    DWORD cbData; // Size of data in bytes
    BYTE Data[1];
} EMRGLSRECORD, *PEMRGLSRECORD;

typedef struct tagEMRGLSBOUNDEDRECORD
{
    EMR emr;
    RECTL rclBounds; // Bounds in recording coordinates
    DWORD cbData; // Size of data in bytes
    BYTE Data[1];
} EMRGLSBOUNDEDRECORD, *PEMRGLSBOUNDEDRECORD;

typedef struct tagEMRPIXELFORMAT
{
    EMR emr;
    PIXELFORMATDESCRIPTOR pfd;
} EMRPIXELFORMAT, *PEMRPIXELFORMAT;

typedef struct tagEMRCREATECOLORSPACE
{
    EMR emr;
    DWORD ihCS; // ColorSpace handle index
    LOGCOLORSPACEA lcs; // Ansi version of LOGCOLORSPACE
} EMRCREATECOLORSPACE, *PEMRCREATECOLORSPACE;

typedef struct tagEMRSETCOLORSPACE
{
    EMR emr;
    DWORD ihCS; // ColorSpace handle index
} EMRSETCOLORSPACE, *PEMRSETCOLORSPACE,
  EMRSELECTCOLORSPACE, *PEMRSELECTCOLORSPACE,
  EMRDELETECOLORSPACE, *PEMRDELETECOLORSPACE;





typedef struct tagEMREXTESCAPE
{
    EMR emr;
    INT iEscape; // Escape code
    INT cbEscData; // Size of escape data
    BYTE EscData[1]; // Escape data
} EMREXTESCAPE, *PEMREXTESCAPE,
  EMRDRAWESCAPE, *PEMRDRAWESCAPE;

typedef struct tagEMRNAMEDESCAPE
{
    EMR emr;
    INT iEscape; // Escape code
    INT cbDriver; // Size of driver name
    INT cbEscData; // Size of escape data
    BYTE EscData[1]; // Driver name and Escape data
} EMRNAMEDESCAPE, *PEMRNAMEDESCAPE;

#define SETICMPROFILE_EMBEDED 0x00000001

typedef struct tagEMRSETICMPROFILE
{
    EMR emr;
    DWORD dwFlags; // flags
    DWORD cbName; // Size of desired profile name
    DWORD cbData; // Size of raw profile data if attached
    BYTE Data[1]; // Array size is cbName + cbData
} EMRSETICMPROFILE, *PEMRSETICMPROFILE,
  EMRSETICMPROFILEA, *PEMRSETICMPROFILEA,
  EMRSETICMPROFILEW, *PEMRSETICMPROFILEW;

#define CREATECOLORSPACE_EMBEDED 0x00000001

typedef struct tagEMRCREATECOLORSPACEW
{
    EMR emr;
    DWORD ihCS; // ColorSpace handle index
    LOGCOLORSPACEW lcs; // Unicode version of logical color space structure
    DWORD dwFlags; // flags
    DWORD cbData; // size of raw source profile data if attached
    BYTE Data[1]; // Array size is cbData
} EMRCREATECOLORSPACEW, *PEMRCREATECOLORSPACEW;

#define COLORMATCHTOTARGET_EMBEDED 0x00000001

typedef struct tagCOLORMATCHTOTARGET
{
    EMR emr;
    DWORD dwAction; // CS_ENABLE, CS_DISABLE or CS_DELETE_TRANSFORM
    DWORD dwFlags; // flags
    DWORD cbName; // Size of desired target profile name
    DWORD cbData; // Size of raw target profile data if attached
    BYTE Data[1]; // Array size is cbName + cbData
} EMRCOLORMATCHTOTARGET, *PEMRCOLORMATCHTOTARGET;

typedef struct tagCOLORCORRECTPALETTE
{
    EMR emr;
    DWORD ihPalette; // Palette handle index
    DWORD nFirstEntry; // Index of first entry to correct
    DWORD nPalEntries; // Number of palette entries to correct
    DWORD nReserved; // Reserved
} EMRCOLORCORRECTPALETTE, *PEMRCOLORCORRECTPALETTE;

typedef struct tagEMRALPHABLEND
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc; // Source DC transform
    COLORREF crBkColorSrc; // Source DC BkColor in RGB
    DWORD iUsageSrc; // Source bitmap info color table usage
                                // (DIB_RGB_COLORS)
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    LONG cxSrc;
    LONG cySrc;
} EMRALPHABLEND, *PEMRALPHABLEND;

typedef struct tagEMRGRADIENTFILL
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    DWORD nVer;
    DWORD nTri;
    ULONG ulMode;
    TRIVERTEX Ver[1];
}EMRGRADIENTFILL,*PEMRGRADIENTFILL;

typedef struct tagEMRTRANSPARENTBLT
{
    EMR emr;
    RECTL rclBounds; // Inclusive-inclusive bounds in device units
    LONG xDest;
    LONG yDest;
    LONG cxDest;
    LONG cyDest;
    DWORD dwRop;
    LONG xSrc;
    LONG ySrc;
    XFORM xformSrc; // Source DC transform
    COLORREF crBkColorSrc; // Source DC BkColor in RGB
    DWORD iUsageSrc; // Source bitmap info color table usage
                                // (DIB_RGB_COLORS)
    DWORD offBmiSrc; // Offset to the source BITMAPINFO structure
    DWORD cbBmiSrc; // Size of the source BITMAPINFO structure
    DWORD offBitsSrc; // Offset to the source bitmap bits
    DWORD cbBitsSrc; // Size of the source bitmap bits
    LONG cxSrc;
    LONG cySrc;
} EMRTRANSPARENTBLT, *PEMRTRANSPARENTBLT;




#define GDICOMMENT_IDENTIFIER 0x43494447
#define GDICOMMENT_WINDOWS_METAFILE 0x80000001
#define GDICOMMENT_BEGINGROUP 0x00000002
#define GDICOMMENT_ENDGROUP 0x00000003
#define GDICOMMENT_MULTIFORMATS 0x40000004
#define EPS_SIGNATURE 0x46535045
#define GDICOMMENT_UNICODE_STRING 0x00000040
#define GDICOMMENT_UNICODE_END 0x00000080




// OpenGL wgl prototypes

DECLSPEC_IMPORT BOOL WINAPI wglCopyContext(HGLRC, HGLRC, UINT);
DECLSPEC_IMPORT HGLRC WINAPI wglCreateContext(HDC);
DECLSPEC_IMPORT HGLRC WINAPI wglCreateLayerContext(HDC, int);
DECLSPEC_IMPORT BOOL WINAPI wglDeleteContext(HGLRC);
DECLSPEC_IMPORT HGLRC WINAPI wglGetCurrentContext(VOID);
DECLSPEC_IMPORT HDC WINAPI wglGetCurrentDC(VOID);
DECLSPEC_IMPORT PROC WINAPI wglGetProcAddress(LPCSTR);
DECLSPEC_IMPORT BOOL WINAPI wglMakeCurrent(HDC, HGLRC);
DECLSPEC_IMPORT BOOL WINAPI wglShareLists(HGLRC, HGLRC);
DECLSPEC_IMPORT BOOL WINAPI wglUseFontBitmapsA(HDC, DWORD, DWORD, DWORD);
DECLSPEC_IMPORT BOOL WINAPI wglUseFontBitmapsW(HDC, DWORD, DWORD, DWORD);



#define wglUseFontBitmaps wglUseFontBitmapsA

DECLSPEC_IMPORT BOOL WINAPI SwapBuffers(HDC);

typedef struct _POINTFLOAT {
    FLOAT x;
    FLOAT y;
} POINTFLOAT, *PPOINTFLOAT;

typedef struct _GLYPHMETRICSFLOAT {
    FLOAT gmfBlackBoxX;
    FLOAT gmfBlackBoxY;
    POINTFLOAT gmfptGlyphOrigin;
    FLOAT gmfCellIncX;
    FLOAT gmfCellIncY;
} GLYPHMETRICSFLOAT, *PGLYPHMETRICSFLOAT, FAR *LPGLYPHMETRICSFLOAT;

#define WGL_FONT_LINES 0
#define WGL_FONT_POLYGONS 1
DECLSPEC_IMPORT BOOL WINAPI wglUseFontOutlinesA(HDC, DWORD, DWORD, DWORD, FLOAT,
                                           FLOAT, int, LPGLYPHMETRICSFLOAT);
DECLSPEC_IMPORT BOOL WINAPI wglUseFontOutlinesW(HDC, DWORD, DWORD, DWORD, FLOAT,
                                           FLOAT, int, LPGLYPHMETRICSFLOAT);



#define wglUseFontOutlines wglUseFontOutlinesA


/* Layer plane descriptor */
typedef struct tagLAYERPLANEDESCRIPTOR { // lpd
    WORD nSize;
    WORD nVersion;
    DWORD dwFlags;
    BYTE iPixelType;
    BYTE cColorBits;
    BYTE cRedBits;
    BYTE cRedShift;
    BYTE cGreenBits;
    BYTE cGreenShift;
    BYTE cBlueBits;
    BYTE cBlueShift;
    BYTE cAlphaBits;
    BYTE cAlphaShift;
    BYTE cAccumBits;
    BYTE cAccumRedBits;
    BYTE cAccumGreenBits;
    BYTE cAccumBlueBits;
    BYTE cAccumAlphaBits;
    BYTE cDepthBits;
    BYTE cStencilBits;
    BYTE cAuxBuffers;
    BYTE iLayerPlane;
    BYTE bReserved;
    COLORREF crTransparent;
} LAYERPLANEDESCRIPTOR, *PLAYERPLANEDESCRIPTOR, FAR *LPLAYERPLANEDESCRIPTOR;

/* LAYERPLANEDESCRIPTOR flags */
#define LPD_DOUBLEBUFFER 0x00000001
#define LPD_STEREO 0x00000002
#define LPD_SUPPORT_GDI 0x00000010
#define LPD_SUPPORT_OPENGL 0x00000020
#define LPD_SHARE_DEPTH 0x00000040
#define LPD_SHARE_STENCIL 0x00000080
#define LPD_SHARE_ACCUM 0x00000100
#define LPD_SWAP_EXCHANGE 0x00000200
#define LPD_SWAP_COPY 0x00000400
#define LPD_TRANSPARENT 0x00001000

#define LPD_TYPE_RGBA 0
#define LPD_TYPE_COLORINDEX 1

/* wglSwapLayerBuffers flags */
#define WGL_SWAP_MAIN_PLANE 0x00000001
#define WGL_SWAP_OVERLAY1 0x00000002
#define WGL_SWAP_OVERLAY2 0x00000004
#define WGL_SWAP_OVERLAY3 0x00000008
#define WGL_SWAP_OVERLAY4 0x00000010
#define WGL_SWAP_OVERLAY5 0x00000020
#define WGL_SWAP_OVERLAY6 0x00000040
#define WGL_SWAP_OVERLAY7 0x00000080
#define WGL_SWAP_OVERLAY8 0x00000100
#define WGL_SWAP_OVERLAY9 0x00000200
#define WGL_SWAP_OVERLAY10 0x00000400
#define WGL_SWAP_OVERLAY11 0x00000800
#define WGL_SWAP_OVERLAY12 0x00001000
#define WGL_SWAP_OVERLAY13 0x00002000
#define WGL_SWAP_OVERLAY14 0x00004000
#define WGL_SWAP_OVERLAY15 0x00008000
#define WGL_SWAP_UNDERLAY1 0x00010000
#define WGL_SWAP_UNDERLAY2 0x00020000
#define WGL_SWAP_UNDERLAY3 0x00040000
#define WGL_SWAP_UNDERLAY4 0x00080000
#define WGL_SWAP_UNDERLAY5 0x00100000
#define WGL_SWAP_UNDERLAY6 0x00200000
#define WGL_SWAP_UNDERLAY7 0x00400000
#define WGL_SWAP_UNDERLAY8 0x00800000
#define WGL_SWAP_UNDERLAY9 0x01000000
#define WGL_SWAP_UNDERLAY10 0x02000000
#define WGL_SWAP_UNDERLAY11 0x04000000
#define WGL_SWAP_UNDERLAY12 0x08000000
#define WGL_SWAP_UNDERLAY13 0x10000000
#define WGL_SWAP_UNDERLAY14 0x20000000
#define WGL_SWAP_UNDERLAY15 0x40000000

DECLSPEC_IMPORT BOOL WINAPI wglDescribeLayerPlane(HDC, int, int, UINT,
                                             LPLAYERPLANEDESCRIPTOR);
DECLSPEC_IMPORT int WINAPI wglSetLayerPaletteEntries(HDC, int, int, int,
                                                 CONST COLORREF *);
DECLSPEC_IMPORT int WINAPI wglGetLayerPaletteEntries(HDC, int, int, int,
                                                 COLORREF *);
DECLSPEC_IMPORT BOOL WINAPI wglRealizeLayerPalette(HDC, int, BOOL);
DECLSPEC_IMPORT BOOL WINAPI wglSwapLayerBuffers(HDC, UINT);



typedef struct _WGLSWAP
{
    HDC hdc;
    UINT uiFlags;
} WGLSWAP, *PWGLSWAP, FAR *LPWGLSWAP;

#define WGL_SWAPMULTIPLE_MAX 16

DECLSPEC_IMPORT DWORD WINAPI wglSwapMultipleBuffers(UINT, CONST WGLSWAP *);
# 37 "c_include/windows/original/wincon.h" 2


typedef struct _COORD {
    SHORT X;
    SHORT Y;
} COORD, *PCOORD;

typedef struct _SMALL_RECT {
    SHORT Left;
    SHORT Top;
    SHORT Right;
    SHORT Bottom;
} SMALL_RECT, *PSMALL_RECT;

typedef struct _KEY_EVENT_RECORD {
    BOOL bKeyDown;
    WORD wRepeatCount;
    WORD wVirtualKeyCode;
    WORD wVirtualScanCode;
    union {
        WCHAR UnicodeChar;
        CHAR AsciiChar;
    } uChar;
    DWORD dwControlKeyState;
} KEY_EVENT_RECORD, *PKEY_EVENT_RECORD;

//
// ControlKeyState flags
//

#define RIGHT_ALT_PRESSED 0x0001
#define LEFT_ALT_PRESSED 0x0002
#define RIGHT_CTRL_PRESSED 0x0004
#define LEFT_CTRL_PRESSED 0x0008
#define SHIFT_PRESSED 0x0010
#define NUMLOCK_ON 0x0020
#define SCROLLLOCK_ON 0x0040
#define CAPSLOCK_ON 0x0080
#define ENHANCED_KEY 0x0100
#define NLS_DBCSCHAR 0x00010000
#define NLS_ALPHANUMERIC 0x00000000
#define NLS_KATAKANA 0x00020000
#define NLS_HIRAGANA 0x00040000
#define NLS_ROMAN 0x00400000
#define NLS_IME_CONVERSION 0x00800000
#define NLS_IME_DISABLE 0x20000000

typedef struct _MOUSE_EVENT_RECORD {
    COORD dwMousePosition;
    DWORD dwButtonState;
    DWORD dwControlKeyState;
    DWORD dwEventFlags;
} MOUSE_EVENT_RECORD, *PMOUSE_EVENT_RECORD;

//
// ButtonState flags
//

#define FROM_LEFT_1ST_BUTTON_PRESSED 0x0001
#define RIGHTMOST_BUTTON_PRESSED 0x0002
#define FROM_LEFT_2ND_BUTTON_PRESSED 0x0004
#define FROM_LEFT_3RD_BUTTON_PRESSED 0x0008
#define FROM_LEFT_4TH_BUTTON_PRESSED 0x0010

//
// EventFlags
//

#define MOUSE_MOVED 0x0001
#define DOUBLE_CLICK 0x0002
#define MOUSE_WHEELED 0x0004

#define MOUSE_HWHEELED 0x0008


typedef struct _WINDOW_BUFFER_SIZE_RECORD {
    COORD dwSize;
} WINDOW_BUFFER_SIZE_RECORD, *PWINDOW_BUFFER_SIZE_RECORD;

typedef struct _MENU_EVENT_RECORD {
    UINT dwCommandId;
} MENU_EVENT_RECORD, *PMENU_EVENT_RECORD;

typedef struct _FOCUS_EVENT_RECORD {
    BOOL bSetFocus;
} FOCUS_EVENT_RECORD, *PFOCUS_EVENT_RECORD;

typedef struct _INPUT_RECORD {
    WORD EventType;
    union {
        KEY_EVENT_RECORD KeyEvent;
        MOUSE_EVENT_RECORD MouseEvent;
        WINDOW_BUFFER_SIZE_RECORD WindowBufferSizeEvent;
        MENU_EVENT_RECORD MenuEvent;
        FOCUS_EVENT_RECORD FocusEvent;
    } Event;
} INPUT_RECORD, *PINPUT_RECORD;

//
//  EventType flags:
//

#define KEY_EVENT 0x0001
#define MOUSE_EVENT 0x0002
#define WINDOW_BUFFER_SIZE_EVENT 0x0004
#define MENU_EVENT 0x0008
#define FOCUS_EVENT 0x0010

typedef struct _CHAR_INFO {
    union {
        WCHAR UnicodeChar;
        CHAR AsciiChar;
    } Char;
    WORD Attributes;
} CHAR_INFO, *PCHAR_INFO;

//
// Attributes flags:
//

#define FOREGROUND_BLUE 0x0001
#define FOREGROUND_GREEN 0x0002
#define FOREGROUND_RED 0x0004
#define FOREGROUND_INTENSITY 0x0008
#define BACKGROUND_BLUE 0x0010
#define BACKGROUND_GREEN 0x0020
#define BACKGROUND_RED 0x0040
#define BACKGROUND_INTENSITY 0x0080
#define COMMON_LVB_LEADING_BYTE 0x0100
#define COMMON_LVB_TRAILING_BYTE 0x0200
#define COMMON_LVB_GRID_HORIZONTAL 0x0400
#define COMMON_LVB_GRID_LVERTICAL 0x0800
#define COMMON_LVB_GRID_RVERTICAL 0x1000
#define COMMON_LVB_REVERSE_VIDEO 0x4000
#define COMMON_LVB_UNDERSCORE 0x8000

#define COMMON_LVB_SBCSDBCS 0x0300


typedef struct _CONSOLE_SCREEN_BUFFER_INFO {
    COORD dwSize;
    COORD dwCursorPosition;
    WORD wAttributes;
    SMALL_RECT srWindow;
    COORD dwMaximumWindowSize;
} CONSOLE_SCREEN_BUFFER_INFO, *PCONSOLE_SCREEN_BUFFER_INFO;

typedef struct _CONSOLE_SCREEN_BUFFER_INFOEX {
    ULONG cbSize;
    COORD dwSize;
    COORD dwCursorPosition;
    WORD wAttributes;
    SMALL_RECT srWindow;
    COORD dwMaximumWindowSize;
    WORD wPopupAttributes;
    BOOL bFullscreenSupported;
    COLORREF ColorTable[16];
} CONSOLE_SCREEN_BUFFER_INFOEX, *PCONSOLE_SCREEN_BUFFER_INFOEX;

typedef struct _CONSOLE_CURSOR_INFO {
    DWORD dwSize;
    BOOL bVisible;
} CONSOLE_CURSOR_INFO, *PCONSOLE_CURSOR_INFO;

typedef struct _CONSOLE_FONT_INFO {
    DWORD nFont;
    COORD dwFontSize;
} CONSOLE_FONT_INFO, *PCONSOLE_FONT_INFO;


typedef struct _CONSOLE_FONT_INFOEX {
    ULONG cbSize;
    DWORD nFont;
    COORD dwFontSize;
    UINT FontFamily;
    UINT FontWeight;
    WCHAR FaceName[32];
} CONSOLE_FONT_INFOEX, *PCONSOLE_FONT_INFOEX;


#define HISTORY_NO_DUP_FLAG 0x1

typedef struct _CONSOLE_HISTORY_INFO {
    UINT cbSize;
    UINT HistoryBufferSize;
    UINT NumberOfHistoryBuffers;
    DWORD dwFlags;
} CONSOLE_HISTORY_INFO, *PCONSOLE_HISTORY_INFO;


typedef struct _CONSOLE_SELECTION_INFO {
    DWORD dwFlags;
    COORD dwSelectionAnchor;
    SMALL_RECT srSelection;
} CONSOLE_SELECTION_INFO, *PCONSOLE_SELECTION_INFO;

//
// Selection flags
//

#define CONSOLE_NO_SELECTION 0x0000
#define CONSOLE_SELECTION_IN_PROGRESS 0x0001
#define CONSOLE_SELECTION_NOT_EMPTY 0x0002
#define CONSOLE_MOUSE_SELECTION 0x0004
#define CONSOLE_MOUSE_DOWN 0x0008


//
// typedef for ctrl-c handler routines
//

typedef
BOOL
(WINAPI *PHANDLER_ROUTINE)(
    __in DWORD CtrlType
    );

#define CTRL_C_EVENT 0
#define CTRL_BREAK_EVENT 1
#define CTRL_CLOSE_EVENT 2
// 3 is reserved!
// 4 is reserved!
#define CTRL_LOGOFF_EVENT 5
#define CTRL_SHUTDOWN_EVENT 6

//
//  Input Mode flags:
//

#define ENABLE_PROCESSED_INPUT 0x0001
#define ENABLE_LINE_INPUT 0x0002
#define ENABLE_ECHO_INPUT 0x0004
#define ENABLE_WINDOW_INPUT 0x0008
#define ENABLE_MOUSE_INPUT 0x0010
#define ENABLE_INSERT_MODE 0x0020
#define ENABLE_QUICK_EDIT_MODE 0x0040
#define ENABLE_EXTENDED_FLAGS 0x0080
#define ENABLE_AUTO_POSITION 0x0100

//
// Output Mode flags:
//

#define ENABLE_PROCESSED_OUTPUT 0x0001
#define ENABLE_WRAP_AT_EOL_OUTPUT 0x0002

//
// direct API definitions.
//

WINBASEAPI
BOOL
WINAPI
PeekConsoleInputA(
    __in HANDLE hConsoleInput,
    __out_ecount(nLength) PINPUT_RECORD lpBuffer,
    __in DWORD nLength,
    __out LPDWORD lpNumberOfEventsRead
    );
WINBASEAPI
BOOL
WINAPI
PeekConsoleInputW(
    __in HANDLE hConsoleInput,
    __out_ecount(nLength) PINPUT_RECORD lpBuffer,
    __in DWORD nLength,
    __out LPDWORD lpNumberOfEventsRead
    );



#define PeekConsoleInput PeekConsoleInputA


WINBASEAPI
BOOL
WINAPI
ReadConsoleInputA(
    __in HANDLE hConsoleInput,
    __out_ecount(nLength) PINPUT_RECORD lpBuffer,
    __in DWORD nLength,
    __out LPDWORD lpNumberOfEventsRead
    );
WINBASEAPI
BOOL
WINAPI
ReadConsoleInputW(
    __in HANDLE hConsoleInput,
    __out_ecount(nLength) PINPUT_RECORD lpBuffer,
    __in DWORD nLength,
    __out LPDWORD lpNumberOfEventsRead
    );



#define ReadConsoleInput ReadConsoleInputA


WINBASEAPI
BOOL
WINAPI
WriteConsoleInputA(
    __in HANDLE hConsoleInput,
    __in_ecount(nLength) CONST INPUT_RECORD *lpBuffer,
    __in DWORD nLength,
    __out LPDWORD lpNumberOfEventsWritten
    );
WINBASEAPI
BOOL
WINAPI
WriteConsoleInputW(
    __in HANDLE hConsoleInput,
    __in_ecount(nLength) CONST INPUT_RECORD *lpBuffer,
    __in DWORD nLength,
    __out LPDWORD lpNumberOfEventsWritten
    );



#define WriteConsoleInput WriteConsoleInputA


WINBASEAPI
BOOL
WINAPI
ReadConsoleOutputA(
    __in HANDLE hConsoleOutput,
    __out_ecount(dwBufferSize.X * dwBufferSize.Y) PCHAR_INFO lpBuffer,
    __in COORD dwBufferSize,
    __in COORD dwBufferCoord,
    __inout PSMALL_RECT lpReadRegion
    );
WINBASEAPI
BOOL
WINAPI
ReadConsoleOutputW(
    __in HANDLE hConsoleOutput,
    __out_ecount(dwBufferSize.X * dwBufferSize.Y) PCHAR_INFO lpBuffer,
    __in COORD dwBufferSize,
    __in COORD dwBufferCoord,
    __inout PSMALL_RECT lpReadRegion
    );



#define ReadConsoleOutput ReadConsoleOutputA


WINBASEAPI
BOOL
WINAPI
WriteConsoleOutputA(
    __in HANDLE hConsoleOutput,
    __in_ecount(dwBufferSize.X * dwBufferSize.Y) CONST CHAR_INFO *lpBuffer,
    __in COORD dwBufferSize,
    __in COORD dwBufferCoord,
    __inout PSMALL_RECT lpWriteRegion
    );
WINBASEAPI
BOOL
WINAPI
WriteConsoleOutputW(
    __in HANDLE hConsoleOutput,
    __in_ecount(dwBufferSize.X * dwBufferSize.Y) CONST CHAR_INFO *lpBuffer,
    __in COORD dwBufferSize,
    __in COORD dwBufferCoord,
    __inout PSMALL_RECT lpWriteRegion
    );



#define WriteConsoleOutput WriteConsoleOutputA


WINBASEAPI
BOOL
WINAPI
ReadConsoleOutputCharacterA(
    __in HANDLE hConsoleOutput,
    __out_ecount(nLength) LPSTR lpCharacter,
    __in DWORD nLength,
    __in COORD dwReadCoord,
    __out LPDWORD lpNumberOfCharsRead
    );
WINBASEAPI
BOOL
WINAPI
ReadConsoleOutputCharacterW(
    __in HANDLE hConsoleOutput,
    __out_ecount(nLength) LPWSTR lpCharacter,
    __in DWORD nLength,
    __in COORD dwReadCoord,
    __out LPDWORD lpNumberOfCharsRead
    );



#define ReadConsoleOutputCharacter ReadConsoleOutputCharacterA


WINBASEAPI
BOOL
WINAPI
ReadConsoleOutputAttribute(
    __in HANDLE hConsoleOutput,
    __out_ecount(nLength) LPWORD lpAttribute,
    __in DWORD nLength,
    __in COORD dwReadCoord,
    __out LPDWORD lpNumberOfAttrsRead
    );

WINBASEAPI
BOOL
WINAPI
WriteConsoleOutputCharacterA(
    __in HANDLE hConsoleOutput,
    __in_ecount(nLength) LPCSTR lpCharacter,
    __in DWORD nLength,
    __in COORD dwWriteCoord,
    __out LPDWORD lpNumberOfCharsWritten
    );
WINBASEAPI
BOOL
WINAPI
WriteConsoleOutputCharacterW(
    __in HANDLE hConsoleOutput,
    __in_ecount(nLength) LPCWSTR lpCharacter,
    __in DWORD nLength,
    __in COORD dwWriteCoord,
    __out LPDWORD lpNumberOfCharsWritten
    );



#define WriteConsoleOutputCharacter WriteConsoleOutputCharacterA


WINBASEAPI
BOOL
WINAPI
WriteConsoleOutputAttribute(
    __in HANDLE hConsoleOutput,
    __in_ecount(nLength) CONST WORD *lpAttribute,
    __in DWORD nLength,
    __in COORD dwWriteCoord,
    __out LPDWORD lpNumberOfAttrsWritten
    );

WINBASEAPI
BOOL
WINAPI
FillConsoleOutputCharacterA(
    __in HANDLE hConsoleOutput,
    __in CHAR cCharacter,
    __in DWORD nLength,
    __in COORD dwWriteCoord,
    __out LPDWORD lpNumberOfCharsWritten
    );
WINBASEAPI
BOOL
WINAPI
FillConsoleOutputCharacterW(
    __in HANDLE hConsoleOutput,
    __in WCHAR cCharacter,
    __in DWORD nLength,
    __in COORD dwWriteCoord,
    __out LPDWORD lpNumberOfCharsWritten
    );



#define FillConsoleOutputCharacter FillConsoleOutputCharacterA


WINBASEAPI
BOOL
WINAPI
FillConsoleOutputAttribute(
    __in HANDLE hConsoleOutput,
    __in WORD wAttribute,
    __in DWORD nLength,
    __in COORD dwWriteCoord,
    __out LPDWORD lpNumberOfAttrsWritten
    );

WINBASEAPI
BOOL
WINAPI
GetConsoleMode(
    __in HANDLE hConsoleHandle,
    __out LPDWORD lpMode
    );

WINBASEAPI
BOOL
WINAPI
GetNumberOfConsoleInputEvents(
    __in HANDLE hConsoleInput,
    __out LPDWORD lpNumberOfEvents
    );

#define CONSOLE_REAL_OUTPUT_HANDLE (LongToHandle(-2))
#define CONSOLE_REAL_INPUT_HANDLE (LongToHandle(-3))

WINBASEAPI
BOOL
WINAPI
GetConsoleScreenBufferInfo(
    __in HANDLE hConsoleOutput,
    __out PCONSOLE_SCREEN_BUFFER_INFO lpConsoleScreenBufferInfo
    );

WINBASEAPI
BOOL
WINAPI
GetConsoleScreenBufferInfoEx(
    __in HANDLE hConsoleOutput,
    __inout_bcount_part(sizeof(ULONG), sizeof(CONSOLE_SCREEN_BUFFER_INFOEX) - sizeof(ULONG)) PCONSOLE_SCREEN_BUFFER_INFOEX lpConsoleScreenBufferInfoEx);

WINBASEAPI
BOOL
WINAPI
SetConsoleScreenBufferInfoEx(
    __in HANDLE hConsoleOutput,
    __in PCONSOLE_SCREEN_BUFFER_INFOEX lpConsoleScreenBufferInfoEx);

WINBASEAPI
COORD
WINAPI
GetLargestConsoleWindowSize(
    __in HANDLE hConsoleOutput
    );

WINBASEAPI
BOOL
WINAPI
GetConsoleCursorInfo(
    __in HANDLE hConsoleOutput,
    __out PCONSOLE_CURSOR_INFO lpConsoleCursorInfo
    );



WINBASEAPI
BOOL
WINAPI
GetCurrentConsoleFont(
    __in HANDLE hConsoleOutput,
    __in BOOL bMaximumWindow,
    __out PCONSOLE_FONT_INFO lpConsoleCurrentFont
    );


WINBASEAPI
BOOL
WINAPI
GetCurrentConsoleFontEx(
    __in HANDLE hConsoleOutput,
    __in BOOL bMaximumWindow,
    __out PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx);

WINBASEAPI
BOOL
WINAPI
SetCurrentConsoleFontEx(
    __in HANDLE hConsoleOutput,
    __in BOOL bMaximumWindow,
    __in PCONSOLE_FONT_INFOEX lpConsoleCurrentFontEx);


WINBASEAPI
BOOL
WINAPI
GetConsoleHistoryInfo(
    __out PCONSOLE_HISTORY_INFO lpConsoleHistoryInfo);

WINBASEAPI
BOOL
WINAPI
SetConsoleHistoryInfo(
    __in PCONSOLE_HISTORY_INFO lpConsoleHistoryInfo);

WINBASEAPI
COORD
WINAPI
GetConsoleFontSize(
    __in HANDLE hConsoleOutput,
    __in DWORD nFont
    );

WINBASEAPI
BOOL
WINAPI
GetConsoleSelectionInfo(
    __out PCONSOLE_SELECTION_INFO lpConsoleSelectionInfo
    );



WINBASEAPI
BOOL
WINAPI
GetNumberOfConsoleMouseButtons(
    __out LPDWORD lpNumberOfMouseButtons
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleMode(
    __in HANDLE hConsoleHandle,
    __in DWORD dwMode
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleActiveScreenBuffer(
    __in HANDLE hConsoleOutput
    );

WINBASEAPI
BOOL
WINAPI
FlushConsoleInputBuffer(
    __in HANDLE hConsoleInput
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleScreenBufferSize(
    __in HANDLE hConsoleOutput,
    __in COORD dwSize
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleCursorPosition(
    __in HANDLE hConsoleOutput,
    __in COORD dwCursorPosition
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleCursorInfo(
    __in HANDLE hConsoleOutput,
    __in CONST CONSOLE_CURSOR_INFO *lpConsoleCursorInfo
    );

WINBASEAPI
BOOL
WINAPI
ScrollConsoleScreenBufferA(
    __in HANDLE hConsoleOutput,
    __in CONST SMALL_RECT *lpScrollRectangle,
    __in_opt CONST SMALL_RECT *lpClipRectangle,
    __in COORD dwDestinationOrigin,
    __in CONST CHAR_INFO *lpFill
    );
WINBASEAPI
BOOL
WINAPI
ScrollConsoleScreenBufferW(
    __in HANDLE hConsoleOutput,
    __in CONST SMALL_RECT *lpScrollRectangle,
    __in_opt CONST SMALL_RECT *lpClipRectangle,
    __in COORD dwDestinationOrigin,
    __in CONST CHAR_INFO *lpFill
    );



#define ScrollConsoleScreenBuffer ScrollConsoleScreenBufferA


WINBASEAPI
BOOL
WINAPI
SetConsoleWindowInfo(
    __in HANDLE hConsoleOutput,
    __in BOOL bAbsolute,
    __in CONST SMALL_RECT *lpConsoleWindow
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleTextAttribute(
    __in HANDLE hConsoleOutput,
    __in WORD wAttributes
    );

WINBASEAPI
BOOL
WINAPI
SetConsoleCtrlHandler(
    __in_opt PHANDLER_ROUTINE HandlerRoutine,
    __in BOOL Add);

WINBASEAPI
BOOL
WINAPI
GenerateConsoleCtrlEvent(
    __in DWORD dwCtrlEvent,
    __in DWORD dwProcessGroupId);

WINBASEAPI
BOOL
WINAPI
AllocConsole(
    VOID);

WINBASEAPI
BOOL
WINAPI
FreeConsole(
    VOID);


WINBASEAPI
BOOL
WINAPI
AttachConsole(
    __in DWORD dwProcessId);

#define ATTACH_PARENT_PROCESS ((DWORD)-1)



WINBASEAPI
DWORD
WINAPI
GetConsoleTitleA(
    __out_ecount(nSize) LPSTR lpConsoleTitle,
    __in DWORD nSize
    );
WINBASEAPI
DWORD
WINAPI
GetConsoleTitleW(
    __out_ecount(nSize) LPWSTR lpConsoleTitle,
    __in DWORD nSize
    );



#define GetConsoleTitle GetConsoleTitleA



WINBASEAPI
DWORD
WINAPI
GetConsoleOriginalTitleA(
    __out_ecount(nSize) LPSTR lpConsoleTitle,
    __in DWORD nSize);
WINBASEAPI
DWORD
WINAPI
GetConsoleOriginalTitleW(
    __out_ecount(nSize) LPWSTR lpConsoleTitle,
    __in DWORD nSize);



#define GetConsoleOriginalTitle GetConsoleOriginalTitleA



WINBASEAPI
BOOL
WINAPI
SetConsoleTitleA(
    __in LPCSTR lpConsoleTitle
    );
WINBASEAPI
BOOL
WINAPI
SetConsoleTitleW(
    __in LPCWSTR lpConsoleTitle
    );



#define SetConsoleTitle SetConsoleTitleA


typedef struct _CONSOLE_READCONSOLE_CONTROL {
    ULONG nLength;
    ULONG nInitialChars;
    ULONG dwCtrlWakeupMask;
    ULONG dwControlKeyState;
} CONSOLE_READCONSOLE_CONTROL, *PCONSOLE_READCONSOLE_CONTROL;

WINBASEAPI
BOOL
WINAPI
ReadConsoleA(
    __in HANDLE hConsoleInput,
    __out_ecount_part(nNumberOfCharsToRead, *lpNumberOfCharsRead)
       LPVOID lpBuffer,
    __in DWORD nNumberOfCharsToRead,
    __out LPDWORD lpNumberOfCharsRead,
    __in_opt PCONSOLE_READCONSOLE_CONTROL pInputControl
    );
WINBASEAPI
BOOL
WINAPI
ReadConsoleW(
    __in HANDLE hConsoleInput,
    __out_ecount_part(nNumberOfCharsToRead, *lpNumberOfCharsRead)
       LPVOID lpBuffer,
    __in DWORD nNumberOfCharsToRead,
    __out LPDWORD lpNumberOfCharsRead,
    __in_opt PCONSOLE_READCONSOLE_CONTROL pInputControl
    );



#define ReadConsole ReadConsoleA


WINBASEAPI
BOOL
WINAPI
WriteConsoleA(
    __in HANDLE hConsoleOutput,
    __in_ecount(nNumberOfCharsToWrite) CONST VOID *lpBuffer,
    __in DWORD nNumberOfCharsToWrite,
    __out_opt LPDWORD lpNumberOfCharsWritten,
    __reserved LPVOID lpReserved);
WINBASEAPI
BOOL
WINAPI
WriteConsoleW(
    __in HANDLE hConsoleOutput,
    __in_ecount(nNumberOfCharsToWrite) CONST VOID *lpBuffer,
    __in DWORD nNumberOfCharsToWrite,
    __out_opt LPDWORD lpNumberOfCharsWritten,
    __reserved LPVOID lpReserved);



#define WriteConsole WriteConsoleA


#define CONSOLE_TEXTMODE_BUFFER 1

__allocator
WINBASEAPI
HANDLE
WINAPI
CreateConsoleScreenBuffer(
    __in DWORD dwDesiredAccess,
    __in DWORD dwShareMode,
    __in_opt CONST SECURITY_ATTRIBUTES *lpSecurityAttributes,
    __in DWORD dwFlags,
    __reserved LPVOID lpScreenBufferData
    );

WINBASEAPI
UINT
WINAPI
GetConsoleCP(
    VOID);

WINBASEAPI
BOOL
WINAPI
SetConsoleCP(
    __in UINT wCodePageID
    );

WINBASEAPI
UINT
WINAPI
GetConsoleOutputCP(
    VOID);

WINBASEAPI
BOOL
WINAPI
SetConsoleOutputCP(
    __in UINT wCodePageID
    );



#define CONSOLE_FULLSCREEN 1
#define CONSOLE_FULLSCREEN_HARDWARE 2

WINBASEAPI
BOOL
APIENTRY
GetConsoleDisplayMode(
    __out LPDWORD lpModeFlags);

#define CONSOLE_FULLSCREEN_MODE 1
#define CONSOLE_WINDOWED_MODE 2

BOOL
APIENTRY
SetConsoleDisplayMode(
    __in HANDLE hConsoleOutput,
    __in DWORD dwFlags,
    __out_opt PCOORD lpNewScreenBufferDimensions);

WINBASEAPI
HWND
APIENTRY
GetConsoleWindow(
    VOID
    );





WINBASEAPI
DWORD
APIENTRY
GetConsoleProcessList(
    __out_ecount(dwProcessCount) LPDWORD lpdwProcessList,
    __in DWORD dwProcessCount);

//
// Aliasing apis.
//

WINBASEAPI
BOOL
APIENTRY
AddConsoleAliasA(
    __in LPSTR Source,
    __in LPSTR Target,
    __in LPSTR ExeName);
WINBASEAPI
BOOL
APIENTRY
AddConsoleAliasW(
    __in LPWSTR Source,
    __in LPWSTR Target,
    __in LPWSTR ExeName);



#define AddConsoleAlias AddConsoleAliasA


WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasA(
    __in LPSTR Source,
    __out_ecount(TargetBufferLength) LPSTR TargetBuffer,
    __in DWORD TargetBufferLength,
    __in LPSTR ExeName);
WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasW(
    __in LPWSTR Source,
    __out_ecount(TargetBufferLength) LPWSTR TargetBuffer,
    __in DWORD TargetBufferLength,
    __in LPWSTR ExeName);



#define GetConsoleAlias GetConsoleAliasA


WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasesLengthA(
    __in LPSTR ExeName);
WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasesLengthW(
    __in LPWSTR ExeName);



#define GetConsoleAliasesLength GetConsoleAliasesLengthA


WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasExesLengthA(
    VOID);
WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasExesLengthW(
    VOID);



#define GetConsoleAliasExesLength GetConsoleAliasExesLengthA


WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasesA(
    __out_ecount(AliasBufferLength) LPSTR AliasBuffer,
    __in DWORD AliasBufferLength,
    __in LPSTR ExeName);
WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasesW(
    __out_ecount(AliasBufferLength) LPWSTR AliasBuffer,
    __in DWORD AliasBufferLength,
    __in LPWSTR ExeName);



#define GetConsoleAliases GetConsoleAliasesA


WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasExesA(
    __out_ecount(ExeNameBufferLength) LPSTR ExeNameBuffer,
    __in DWORD ExeNameBufferLength);
WINBASEAPI
DWORD
APIENTRY
GetConsoleAliasExesW(
    __out_ecount(ExeNameBufferLength) LPWSTR ExeNameBuffer,
    __in DWORD ExeNameBufferLength);



#define GetConsoleAliasExes GetConsoleAliasExesA
